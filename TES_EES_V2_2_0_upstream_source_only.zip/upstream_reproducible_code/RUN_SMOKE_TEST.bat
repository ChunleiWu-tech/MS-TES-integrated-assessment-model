@echo off
setlocal
cd /d "%~dp0"
if "%TES_PYTHON%"=="" set "TES_PYTHON=%CD%\.venv\Scripts\python.exe"
if not exist "%TES_PYTHON%" (echo Run SETUP_ENV.bat first, or set TES_PYTHON.& exit /b 2)
"%TES_PYTHON%" -X faulthandler -u src\run_pipeline.py --mode smoke
set RC=%ERRORLEVEL%
if not "%RC%"=="0" exit /b %RC%
echo.
echo TES-JOULE-V12 smoke workflow completed at 500 draws. Smoke outputs are not submission results.
endlocal
