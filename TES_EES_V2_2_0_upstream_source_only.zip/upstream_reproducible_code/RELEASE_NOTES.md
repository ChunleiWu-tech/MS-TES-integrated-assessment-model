# TES-EES-V2.2.0-20260909

This release also adds an independent Solar Salt enthalpy comparison using Wu et al. (2025), DOI 10.7503/cjcu20250170. The unchanged property model is compared over 250–400 °C, retaining all 36 dependent endpoint intervals and a fixed-energy material-mass consequence. Supplementary Figure 17 and its source tables distinguish this external energy check from the retrospective masking calculation and the chronological numerical checks.

This version adds criterion-level decision provenance and reconstructs all 720,000 primary utilities against the unchanged decision model. Derived diagnostic burden indices now use the same operational fixed-anchor transform. A six-gate counterfactual isolates the effect of the historical TMS-2 cycling label. The temperature-masking calculation is explicitly retrospective, not independent performance validation. Main Figure 5e reports retention with one decimal place.

This release connects composition evidence, material architecture and application duty.

- Sensible energy uses fixed salt mass and hot-end volume normalization.
- Source-resolved device data contain 72 experimental mean powers across Solar Salt and HITEC.
- The application assessment computes charge/delivery switching boundaries, capacity-constrained volume, chronological numerical checks and equal-duty hydraulic scaling.
- Expanded-graphite conductivity is unquantified in the matched corrosion record; unrelated precursor values are not transferred.
- Foam charging and discharging powers retain separate measured directions and operating endpoints.
- Six main and 17 supplementary figures are mapped to their source tables.

See README.md, RUN_GUIDE.md and generated QC records for the exact scope and reproduction order. The experiments define laboratory mean-transfer envelopes; time windows, friction exponents and cost boundaries are stated scenarios.
