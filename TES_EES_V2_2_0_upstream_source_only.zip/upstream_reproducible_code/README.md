# MS-TES upstream scientific model

Release TES-EES-V2.2.0-20260909 connects composition screening, evidence-conditioned selection and material–architecture–duty assessment.

## Scope

- 142 exact compositions and 994 composition–service pairs from 779 application records.
- Separate thermophysical opportunity, complete-duty support and engineering-selection outcomes.
- 20,000 Monte Carlo draws with source domains and independently specified seeds.
- Fixed-mass sensible enthalpy expressed per hot-end salt volume.
- 22 composite-property conditions and a separate transcription of 72 measured device mean powers for Solar Salt and HITEC.
- Capacity, charge and delivery volume constraints, 162 chronological optimization cases, and equal-duty hydraulic scaling for mobile nanofluids.

Mean-power experiments are bounded by their tested materials, temperature endpoints and device conditions. Application windows, friction exponents and baseline pumping input are scenarios, not additional observations. The model does not assign unsupported lifetime, installed cost or life-cycle net benefit.

## Reproduction

Use 64-bit Python 3.12 and requirements-lock.txt. Windows: run SETUP_ENV.bat and then RUN_FULL_RECOMPUTE.bat. Linux/macOS: run SETUP_ENV.sh and RUN_FULL_RECOMPUTE.sh. The common entry point is python src/run_pipeline.py --mode full. The full workflow recreates outputs from the supplied inputs. Do not place personal files in outputs/.

The source-only archive excludes generated outputs, environments and fonts. Results appear under outputs/tables/ and checks under outputs/qc/. pipeline_execution_status.json records every executed stage. Application and energy-reference checks are in APPLICATION_ASSESSMENT_STATUS.json and FIXED_MASS_ENERGY_STATUS.json. A smoke run uses fewer draws and is not a scientific release.

Keep this directory beside postprocess_reproducible_code. Exact device transcription is recorded in data/input/application_experiments.json. Legacy module filenames are retained for compatibility; release identity and scope are defined by the configuration and this document.

## Condition-resolved engineering assessment

Release TES-EES-V2.2.0-20260909 includes 26 condition-specific corrosion records from five primary studies. Numerical corrosion endpoints and their reference-rate margins remain separate from ordinal evidence indices. The same 20,000 draws per duty support 175 service–scoring settings. The full upstream pipeline has 41 stages; the final postprocessing pipeline has 11 stages and produces six main and seventeen supplementary figures as vector PDFs and 600 dpi PNGs. The root RUN_ALL.ps1 invokes these same canonical pipelines.

## Decision traceability

The upstream traceability audit reconstructs every stored primary utility and retains composition–duty reasons, criterion assessments, source-condition links, interval provenance and exact closure denominators. It preserves the operational fixed burden transform 1/(1+B/2); source citations do not empirically calibrate the assigned index intervals. TRACEABILITY_AUDIT.json records the calculation checks. The Wei et al. temperature-masking analysis is retrospective because the publication already occurs in the source archive; it is not an independent held-out performance test.

## Independent enthalpy comparison

The full pipeline runs `src/run_external_enthalpy_validation.py` against previously unused Solar Salt drop-calorimetry data (Wu et al., 2025, DOI 10.7503/cjcu20250170). Nine tabulated liquid points cover the shared 250–400 °C interval. The unchanged heat-capacity model gives 232.50 kJ/kg against a measured 223.85 kJ/kg, an energy overestimate of 3.86% and fixed-energy material-mass underestimate of 3.72%. All 36 endpoint intervals remain available as dependent diagnostics. Input metadata preserve composition, calibration, repeatability and the fixed model hashes. The comparison does not validate density, engineering indices or device performance. Supplementary Figure 17 reports these results.
