
# Upstream run guide

## Fast integrity check

Run the 500-draw smoke workflow first:

```bat
SETUP_ENV.bat
RUN_SMOKE_TEST.bat
```

or:

```bash
./SETUP_ENV.sh
./RUN_SMOKE_TEST.sh
```

The smoke run validates the task graph and contracts but is not a publication result.

## Registered publication recompute

```bat
RUN_FULL_RECOMPUTE.bat
```

or:

```bash
./RUN_FULL_RECOMPUTE.sh
```

The full run uses 20,000 draws and recreates the formal 15-candidate model, expanded 142-candidate opportunity layer, decision-boundary analysis, statistical diagnostics, numerical Monte Carlo intervals, submission synthesis, release contracts and SHA-256 component manifest.

A valid release must end with all of the following:

- `outputs/qc/UPSTREAM_RELEASE_STATUS.json`: `status = PASS`, `mc_iterations = 20000`;
- `outputs/qc/expanded_v3_independent_validation.json`: 31/31;
- `outputs/qc/UPSTREAM_RELEASE_CONTRACT_AUDIT.json`: PASS;
- `outputs/qc/seed_registry_validation.json`: PASS.
- `outputs/qc/APPLICATION_ASSESSMENT_STATUS.json`: 58/58;
- `outputs/qc/FIXED_MASS_ENERGY_STATUS.json`: 60/60;
- `outputs/qc/engineering_evidence_validation.json`: 21/21;
- `outputs/qc/EXTERNAL_ENTHALPY_VALIDATION.json`: PASS, including frozen-model and source-interval checks;
- `outputs/qc/pipeline_execution_status.json`: all 41 stages completed, PASS.

Do not reuse partial outputs after a failed release run. Re-run the full workflow from its default clean start.
