from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'outputs'/'tables'; Q=ROOT/'outputs'/'qc'
V='decision_boundary'; B='core'
checks=[]
def add(name, ok, detail): checks.append({'check':name,'status':'PASS' if bool(ok) else 'FAIL','detail':str(detail)})
def read(stem): return pd.read_csv(T/f'{V}_{stem}.csv')

base=json.loads((Q/f'{B}_RELEASE_VALIDATION_SUMMARY.json').read_text(encoding='utf-8'))
ext=json.loads((Q/f'{V}_DECISION_BOUNDARY_EXTENSION_STATUS.json').read_text(encoding='utf-8'))
add('base_release_pass',base.get('status')=='PASS',base.get('status'))
add('baseline_hash_invariance',ext.get('baseline_files_unchanged') is True,ext.get('baseline_files_unchanged'))
scope=read('decision_scope_matrix'); front=read('performance_evidence_pareto_summary'); dep=read('performance_evidence_dependence_audit')
states=read('decision_boundary_backtrace_states'); minima=read('decision_boundary_minimum_upgrade'); grad=read('coverage_gradient_candidate_entry_summary')
add('scope_unique_candidate_service',not scope.duplicated(['scenario','system_id']).any(),len(scope))
add('frontier_matches_scope',set(map(tuple,front[['scenario','system_id']].to_numpy()))==set(map(tuple,scope[['scenario','system_id']].to_numpy())),len(front))
add('opportunity_frontier_nonempty_per_supported_service',all(g.opportunity_pareto_front.any() for _,g in front[front.opportunity_performance_kWh_m3.notna()].groupby('scenario')),front.groupby('scenario').opportunity_pareto_front.sum().to_dict())
add('strict_selected_subset_decision_ready',scope.merge(front[['scenario','system_id','current_strict_selection']],on=['scenario','system_id']).query('current_strict_selection').decision_scope_class.eq('decision_ready').all(),'strict selections checked')
add('thermophysical_limited_not_quantified',minima[minima.current_scope_class.isin(['thermophysical_domain_limited','physical_service_window_limited','outside_standardized_service'])].decision_effect_quantifiable_with_current_data.eq(False).all(),'no unsupported re-ranking')
add('backtrace_materiality_declared',(states.target_selection_frequency.between(0,1).all() if len(states) else True),len(states))
add('dependence_is_audit_not_causal',dep.interpretation_boundary.str.contains('not experimental evidence',case=False).all(),len(dep))
add('coverage_sweep_boundary_declared',grad.interpretation_boundary.str.contains('do not replace',case=False).all(),len(grad))
add('no_nan_identifiers',not pd.concat([scope[['scenario','system_id']],minima[['scenario','system_id']]]).isna().any().any(),'identifier fields')
fail=sum(x['status']=='FAIL' for x in checks)
pd.DataFrame(checks).to_csv(Q/f'{V}_VALIDATION_CHECKS.csv',index=False)
summary={'version':V,'status':'PASS' if fail==0 else 'FAIL','checks':len(checks),'critical_failures':fail,'scope':'Diagnostic extension validation; strict core baseline remains authoritative.'}
(Q/f'{V}_VALIDATION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
(Q/f'{V}_QC_STATUS.json').write_text(json.dumps({'status':summary['status'],'critical_failures':fail},indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
if fail: raise SystemExit(1)
