"""Frozen Solar Salt model versus previously unused drop-calorimetry observations."""
from pathlib import Path
from hashlib import sha256
from itertools import combinations
import json
import numpy as np
import pandas as pd
from run_expanded_library_v3 import current_property_value, domain_covers

ROOT=Path(__file__).resolve().parents[1]

def run():
    inp=ROOT/'data/input';out=ROOT/'outputs/tables';qc=ROOT/'outputs/qc'
    out.mkdir(parents=True,exist_ok=True);qc.mkdir(parents=True,exist_ok=True)
    meta=json.loads((inp/'external_wu2025_metadata.json').read_text(encoding='utf-8'))
    registry=inp/'core_candidate_property_registry.csv'
    assert sha256(registry.read_bytes()).hexdigest()==meta['baseline_property_registry_sha256']
    assert sha256((ROOT/'src/decision_model.py').read_bytes()).hexdigest()==meta['baseline_decision_model_sha256']
    base=pd.read_csv(registry).set_index('system_id').loc[meta['system_id']]
    candidate=pd.Series({'current_'+k:v for k,v in base.items()})
    raw=pd.read_csv(inp/'external_wu2025_enthalpy.csv')
    assert len(raw)==19 and raw.temperature_K.is_unique and raw.temperature_K.is_monotonic_increasing
    raw['temperature_C']=raw.temperature_K-273.15
    raw['inside_frozen_cp_domain']=raw.temperature_C.between(base.cp_Tmin_C,base.cp_Tmax_C)
    raw['primary_liquid_points']=raw.inside_frozen_cp_domain & raw.reported_phase.eq('liquid')
    raw['source_doi']=meta['doi'];raw['source_locator']=meta['data_locator']
    eligible=raw[raw.primary_liquid_points].copy().reset_index(drop=True)
    assert len(eligible)==9 and np.isclose(eligible.temperature_C.iloc[0],250) and np.isclose(eligible.temperature_C.iloc[-1],400)
    anchor=eligible.iloc[0]
    eligible['observed_increment_kJ_kg']=eligible.enthalpy_from_298_15K_J_g-anchor.enthalpy_from_298_15K_J_g
    eligible['frozen_cp_J_gK']=current_property_value(candidate,'cp',eligible.temperature_C.to_numpy())
    eligible['model_increment_kJ_kg']=[float(np.trapezoid(current_property_value(candidate,'cp',np.linspace(anchor.temperature_C,t,257)),np.linspace(anchor.temperature_C,t,257))) for t in eligible.temperature_C]
    rows=[]
    for i,j in combinations(range(len(eligible)),2):
        a,b=eligible.iloc[i],eligible.iloc[j];lo=float(a.temperature_C);hi=float(b.temperature_C)
        temperatures=np.linspace(lo,hi,257)
        model=float(np.trapezoid(current_property_value(candidate,'cp',temperatures),temperatures))
        reference=float(b.enthalpy_from_298_15K_J_g-a.enthalpy_from_298_15K_J_g)
        assert domain_covers(candidate,'cp',lo,hi) and reference>0
        # These two disclosed sensitivity scenarios do not establish confidence limits.
        common=meta['calibration_relative_deviation']*reference
        repeat=meta['reported_repeatability_fraction']*(abs(a.enthalpy_from_298_15K_J_g)+abs(b.enthalpy_from_298_15K_J_g))
        rows.append(dict(system_id=meta['system_id'],low_C=lo,high_C=hi,delta_T_K=hi-lo,
            observed_enthalpy_kJ_kg=reference,model_enthalpy_kJ_kg=model,
            model_minus_observed_kJ_kg=model-reference,relative_error_percent=100*(model/reference-1),
            observed_mean_cp_J_gK=reference/(hi-lo),model_mean_cp_J_gK=model/(hi-lo),
            model_mass_for_1kWh_kg=3600/model,reference_mass_for_1kWh_kg=3600/reference,
            fixed_energy_mass_error_percent=100*(reference/model-1),
            common_scale_sensitivity_kJ_kg=common,endpoint_repeatability_envelope_kJ_kg=repeat,
            reference_sensitivity_low_kJ_kg=reference-common-repeat,reference_sensitivity_high_kJ_kg=reference+common+repeat,
            baseline_declared_cp_sensitivity_fraction=float(base.cp_rel_unc),
            complete_primary_interval=i==0 and j==len(eligible)-1,
            dependency='One experimental source and shared endpoints; not independent replicated cases',
            uncertainty_scope='Sensitivity scenarios, not statistical confidence intervals',source_doi=meta['doi']))
    intervals=pd.DataFrame(rows)
    primary=intervals[intervals.complete_primary_interval].iloc[0].to_dict()
    assert len(intervals)==36 and np.isclose(primary['observed_enthalpy_kJ_kg'],223.85)
    assert np.isclose(primary['model_enthalpy_kJ_kg'],232.5)
    for f,n in [(raw,'external_enthalpy_observations'),(eligible,'external_enthalpy_curve'),(intervals,'external_enthalpy_intervals')]:f.to_csv(out/(n+'.csv'),index=False)
    report=dict(status='PASS',scope='Independent experimental enthalpy check of a frozen same-composition property model',
        doi=meta['doi'],independent_experimental_sources=1,independent_compositions=1,
        measured_points_in_shared_liquid_interval=9,dependent_interval_diagnostics=36,
        primary=primary,absolute_interval_error_range_percent=[float(intervals.relative_error_percent.abs().min()),float(intervals.relative_error_percent.abs().max())],
        ranking_validation=False,density_validation=False,engineering_score_validation=False,device_validation=False,
        distinction='PASS verifies implementation and source binding, not universal physical accuracy or statistical equivalence.',
        limitations='One Solar Salt composition, 250-400 C. Published point means only; no raw repeats or joint uncertainty budget. Frozen Cp remains unchanged. No ranking inference and no extension to 565 C or nanoparticle/scaffold performance.',
        checks=[dict(check='frozen_model_and_registry_unchanged',passed=True),dict(check='nineteen_tabulated_observations_nine_liquid_supported_points',passed=True),dict(check='all_thirty_six_endpoint_pairs_retained',passed=True),dict(check='primary_measured_and_predicted_enthalpy_reconstructed',passed=True)],
        input_sha256={n:sha256((inp/n).read_bytes()).hexdigest() for n in ['external_wu2025_enthalpy.csv','external_wu2025_metadata.json']})
    (qc/'EXTERNAL_ENTHALPY_VALIDATION.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(report,indent=2,ensure_ascii=False));return report

if __name__=='__main__':run()
