from __future__ import annotations

"""Candidate-invariant value-function and reproducibility diagnostics."""

from pathlib import Path
import json
import numpy as np
import pandas as pd

from decision_model import ATOMIC_DIMS, BURDEN_HALF_VALUE


SEED = 760076


def _relative_minmax(values: np.ndarray, feasible: np.ndarray) -> np.ndarray:
    out = np.full_like(values, np.nan, dtype=float)
    for i in range(len(values)):
        mask = feasible[i] & np.isfinite(values[i])
        if not mask.any():
            continue
        lo = np.min(values[i, mask]); hi = np.max(values[i, mask])
        out[i, mask] = 0.5 if hi - lo < 1e-12 else (values[i, mask] - lo) / (hi - lo)
    return out


def _candidate_invariant_performance(values: np.ndarray, reference: np.ndarray, feasible: np.ndarray) -> np.ndarray:
    reference = np.clip(np.asarray(reference, dtype=float), 1e-12, None)
    out = values / (values + reference[:, None])
    out[~feasible] = np.nan
    return out


def _credibility(group: pd.DataFrame, members: list[str], draws: np.ndarray, feasible: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    arrays = []
    for dim in ATOMIC_DIMS:
        col = f"sampled_{dim}"
        arrays.append(group.pivot(index="draw_id", columns="system_id", values=col).reindex(index=draws, columns=members).to_numpy(float))
    burden = group.pivot(index="draw_id", columns="system_id", values="sampled_engineering_burden_index").reindex(index=draws, columns=members).to_numpy(float)
    inverse = 1.0 / (1.0 + burden / BURDEN_HALF_VALUE)
    stack = np.stack(arrays + [inverse], axis=2)
    credibility = np.exp(np.nanmean(np.log(np.clip(stack, 1e-6, 1.0)), axis=2))
    credibility[~feasible] = np.nan
    return credibility, inverse


def _outcomes(utility: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    no = np.all(~np.isfinite(utility), axis=1)
    winner = np.argmax(np.where(np.isfinite(utility), utility, -np.inf), axis=1)
    return no, winner


def run_model_upgrade_v2(root: Path, version: str = "core") -> dict:
    out = root / "outputs" / "tables"; qc = root / "outputs" / "qc"
    draws_frame = pd.read_csv(out / f"{version}_monte_carlo_draws_balanced.csv")
    selection_rows = []; comparison_rows = []; iia_rows = []
    for scenario_index, (scenario, group) in enumerate(draws_frame.groupby("scenario", sort=False)):
        members = group.system_id.drop_duplicates().tolist()
        display = group.drop_duplicates("system_id").set_index("system_id").display_system.to_dict()
        draw_ids = np.sort(group.draw_id.unique())
        energy = group.pivot(index="draw_id", columns="system_id", values="complete_service_energy_density_kWh_m3").reindex(index=draw_ids, columns=members).to_numpy(float)
        strict = group.pivot(index="draw_id", columns="system_id", values="strict_complete").reindex(index=draw_ids, columns=members).to_numpy(bool)
        gate_cols = ["failed_corrosion_gate", "failed_cycling_phase_gate", "failed_containment_gate", "failed_validation_gate", "failed_data_completeness_gate"]
        failed = np.zeros_like(strict, dtype=bool)
        for col in gate_cols:
            failed |= group.pivot(index="draw_id", columns="system_id", values=col).reindex(index=draw_ids, columns=members).to_numpy(bool)
        feasible = strict & ~failed
        benchmark_label = str(group.benchmark_system.iloc[0])
        benchmark_candidates = [i for i, member in enumerate(members) if display[member] == benchmark_label]
        if not benchmark_candidates:
            raise ValueError(f"{scenario}: benchmark {benchmark_label!r} is not registered")
        benchmark_index = benchmark_candidates[0]
        reference = group[group.system_id.eq(members[benchmark_index])].set_index("draw_id").reindex(draw_ids).partial_overlap_energy_density_kWh_m3.to_numpy(float)
        performance = _candidate_invariant_performance(energy, reference, feasible)
        relative = _relative_minmax(energy, feasible)
        credibility, inverse_burden = _credibility(group, members, draw_ids, feasible)
        weights = np.random.default_rng(SEED + 1_700_000 + scenario_index * 1009).dirichlet(np.ones(2), len(draw_ids))
        utility = weights[:, [0]] * performance + weights[:, [1]] * credibility
        relative_utility = weights[:, [0]] * relative + weights[:, [1]] * credibility
        utility[~feasible] = -np.inf; relative_utility[~feasible] = -np.inf
        no, winner = _outcomes(utility); relative_no, relative_winner = _outcomes(relative_utility)
        comparison_rows.append({
            "scenario": scenario, "benchmark_system": benchmark_label,
            "candidate_invariant_no_selection_frequency": float(np.mean(no)),
            "relative_minmax_no_selection_frequency": float(np.mean(relative_no)),
            "same_draw_outcome_frequency": float(np.mean((no & relative_no) | ((~no) & (~relative_no) & (winner == relative_winner)))),
            "candidate_invariant_value_function": "q/(q+q_benchmark_draw)",
            "burden_value_function": f"1/(1+b/{BURDEN_HALF_VALUE:g})",
            "common_preference_draws": True,
        })
        for j, member in enumerate(members):
            selection_rows.append({
                "scenario": scenario, "system_id": member, "display_system": display[member],
                "selection_frequency": float(np.mean((winner == j) & ~no)),
                "relative_minmax_selection_frequency": float(np.mean((relative_winner == j) & ~relative_no)),
                "mean_candidate_invariant_performance_value": float(np.nanmean(performance[:, j])) if np.isfinite(performance[:, j]).any() else np.nan,
                "mean_fixed_inverse_burden_value": float(np.nanmean(inverse_burden[:, j])) if np.isfinite(inverse_burden[:, j]).any() else np.nan,
                "eligible_draw_frequency": float(np.mean(feasible[:, j])),
            })
        # Independence-of-irrelevant-alternatives audit: removing a nonwinner
        # cannot alter the remaining candidates' fixed value functions.
        for removed, member in enumerate(members):
            keep = [j for j in range(len(members)) if j != removed]
            reduced_no, reduced_winner_local = _outcomes(utility[:, keep])
            reduced_winner = np.array([keep[j] for j in reduced_winner_local])
            comparable = (~no) & (winner != removed)
            unchanged = comparable & (~reduced_no) & (winner == reduced_winner)
            iia_rows.append({
                "scenario": scenario, "removed_system_id": member,
                "draws_with_original_winner_retained": int(comparable.sum()),
                "retained_winner_unchanged_frequency": float(unchanged.sum() / comparable.sum()) if comparable.any() else np.nan,
                "value_functions_recomputed_after_removal": False,
            })
    selection = pd.DataFrame(selection_rows); comparison = pd.DataFrame(comparison_rows); iia = pd.DataFrame(iia_rows)
    selection.to_csv(out / f"{version}_candidate_invariant_value_selection.csv", index=False)
    comparison.to_csv(out / f"{version}_candidate_invariant_value_comparison.csv", index=False)
    iia.to_csv(out / f"{version}_candidate_invariant_iia_audit.csv", index=False)
    status = {
        "status": "PASS" if (iia.retained_winner_unchanged_frequency.dropna() >= 1 - 1e-12).all() else "FAIL",
        "method_version": "candidate-invariant-benchmark-value-v2",
        "scenario_count": int(comparison.scenario.nunique()),
        "minimum_same_draw_outcome_frequency_vs_relative_minmax": float(comparison.same_draw_outcome_frequency.min()),
        "minimum_iia_retained_winner_frequency": float(iia.retained_winner_unchanged_frequency.dropna().min()),
    }
    (qc / f"{version}_CANDIDATE_INVARIANT_VALUE_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    return status
