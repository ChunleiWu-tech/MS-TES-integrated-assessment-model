from __future__ import annotations
from pathlib import Path
import hashlib, json, sys
import numpy as np
import pandas as pd
from release_paths import UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT

ROOT=Path(__file__).resolve().parents[1]
TABLES=ROOT/'outputs'/'tables'; QC=ROOT/'outputs'/'qc'; QC.mkdir(parents=True,exist_ok=True)
V='submission'; STAT='statistical'; BASE='core'

def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1<<20),b''): h.update(block)
    return h.hexdigest()

def read(stem,version=BASE):
    return pd.read_csv(TABLES/f'{version}_{stem}.csv')

required=['service_regime_archetype_summary','pareto_dominance_mechanism_summary','property_domain_contraction_summary','atomic_evidence_unlock_summary','nonzero_gate_interaction_summary','research_action_frontier_summary','candidate_research_priority_summary','editorial_synthesis_table_audit']
checks=[]
status_path=QC/f'{V}_EDITORIAL_SYNTHESIS_STATUS.json'; status=json.loads(status_path.read_text(encoding='utf-8')) if status_path.exists() else {}
checks.append(('Editorial synthesis status PASS',status.get('status')=='PASS'))
checks.append(('Editorial synthesis does not change science',status.get('science_changed') is False))
checks.append(('All eight submission diagnostic tables exist',all((TABLES/f'{V}_{x}.csv').exists() for x in required)))

hash_path=QC/f'{V}_FROZEN_TABLE_HASHES.csv'; hashes=pd.read_csv(hash_path) if hash_path.exists() else pd.DataFrame()
hash_ok=bool(len(hashes))
if hash_ok:
    for r in hashes.itertuples(index=False):
        p=TABLES/r.file; hash_ok &= p.exists() and sha256(p)==r.sha256
checks.append(('Frozen strict/Pareto/attribution/DAG table hashes unchanged after synthesis',bool(hash_ok)))

# This clean package validates a from-scratch run; no prior-release result files are bundled.
# Probability and state-space conservation.
sel=read('layered_selection_frequencies'); no=read('no_selection_frequencies')
sel_sum=sel.groupby(['scenario','ranking_layer','weight_prior']).selection_frequency.sum().rename('selection_sum').reset_index()
no_sub=no.merge(sel_sum[['scenario','ranking_layer','weight_prior']],on=['scenario','ranking_layer','weight_prior'],how='inner')
prob=sel_sum.merge(no_sub[['scenario','ranking_layer','weight_prior','no_selection_frequency']],on=['scenario','ranking_layer','weight_prior'],how='inner')
checks.append(('Layered selection and no-selection frequencies conserve probability',bool(len(prob) and np.allclose(prob.selection_sum+prob.no_selection_frequency,1.0,atol=1e-12))))
rpath=read('ranking_pathway_summary'); checks.append(('Ranking-pathway shares conserve probability by service',bool(np.allclose(rpath.groupby('scenario').frequency.sum(),1.0,atol=1e-12))))
joint=read('joint_threshold_regime_map'); state_sum=joint[['no_selection_frequency','single_candidate_frequency','multiple_candidate_frequency']].sum(axis=1)
checks.append(('All 630 joint threshold states are unique and probability-conserving',len(joint)==630 and not joint.duplicated(['scenario','coverage_threshold','evidence_threshold']).any() and bool(np.allclose(state_sum,1.0,atol=1e-12))))

# Pareto registration and intervals.
pa=read('pareto_joint_uncertainty_and_robustness',STAT)
pareto_bounds=pa[['representative_performance_score','representative_credibility_score','frontier_membership_frequency','frontier_frequency_bootstrap_p05','frontier_frequency_bootstrap_p95']].dropna().apply(lambda x:x.between(0,1).all()).all()
valid_pareto=pa.frontier_membership_frequency.notna() & pa.frontier_frequency_bootstrap_p05.notna() & pa.frontier_frequency_bootstrap_p95.notna()
pareto_rule=(pa.loc[pa.frontier_membership_frequency.notna(),'threshold_50_member'].astype(bool)==pa.loc[pa.frontier_membership_frequency.notna(),'frontier_membership_frequency'].ge(.5)).all()
pareto_ci=(pa.loc[valid_pareto,'frontier_frequency_bootstrap_p05'].le(pa.loc[valid_pareto,'frontier_membership_frequency']) & pa.loc[valid_pareto,'frontier_membership_frequency'].le(pa.loc[valid_pareto,'frontier_frequency_bootstrap_p95'])).all()
checks.append(('Pareto coordinates, probabilities and intervals stay within the registered 0–1 domain',bool(pareto_bounds and pareto_ci)))
checks.append(('Robust Pareto membership is exactly the preregistered ≥50% rule',bool(pareto_rule)))

# Continuous/categorical attribution separation.
cont=read('continuous_decision_variance_attribution',STAT); cat=read('categorical_selection_information_attribution',STAT)
checks.append(('Continuous response is decision-margin variance, not candidate identity',cont.continuous_response.astype(str).str.contains('margin|utility|interaction',case=False,regex=True).all()))
checks.append(('Categorical response is information-based or registered categorical interaction, never ordinary ANOVA',cat.categorical_response.astype(str).str.contains('candidate identity|interaction',case=False,regex=True).all() and cat.method.astype(str).str.contains('pick-and-freeze',case=False).all() and cat.method.astype(str).str.contains('no linear ANOVA',case=False).any()))

# Implemented DAG semantics: atomic cycling can start independently; system containment and replication have registered prerequisites.
dag=read('evidence_action_dag_registry',STAT); prereq=dag.set_index('action_id').prerequisite_dimensions.fillna('').astype(str).to_dict()
dag_ok=(prereq.get('system_containment_qualification')=='corrosion_compatibility' and prereq.get('independent_replication')=='data_completeness' and prereq.get('long_duration_cycling')=='')
checks.append(('DAG semantics match code and scientific rationale',bool(dag_ok)))
ina=read('inadmissible_action_combination_audit',STAT)
checks.append(('Rejected DAG routes explicitly record prerequisite failures',bool(len(ina)>0 and ina.rejection_reason.str.contains('requires',case=False).all())))

arche=read('service_regime_archetype_summary',V)
checks.append(('All 630 registered coverage–evidence states conserved in editorial synthesis',int(arche.registered_joint_states.sum())==630))
checks.append(('Three switching services retain detailed diagnostics and four flat services are compressed',int(arche.main_map_informative.sum())==3 and int((~arche.main_map_informative.astype(bool)).sum())==4))
audit=read('editorial_synthesis_table_audit',V); checks.append(('submission diagnostic tables contain no duplicate rows',bool(audit.duplicate_rows.eq(0).all())))
action=read('research_action_frontier_summary',V)
checks.append(('Action benefit is explicitly a registered diagnostic upper envelope, not a composite utility',action.benefit_semantics.str.contains('not a composite utility',case=False).all()))

# Expanded-library scope is validated independently from the frozen 15-candidate
# formal engineering registry. Thermophysical opportunity outside that registry
# must never be reported as a formal failure or formal model selection frequency.
expanded_status_path=QC/'expanded_v3_independent_validation.json'
expanded_status=json.loads(expanded_status_path.read_text(encoding='utf-8')) if expanded_status_path.exists() else {}
checks.append(('Expanded-library independent validation PASS',expanded_status.get('validation_pass') is True))
checks.append(('Expanded-library registered full run uses 20,000 draws',expanded_status.get('monte_carlo_iterations')==20000))
expanded_screen_path=TABLES/'expanded_v3_candidate_service_screen.csv'
if expanded_screen_path.exists():
    expanded_screen=pd.read_csv(expanded_screen_path)
    checks.append(('Legacy hard-coded formal_new_entrant field is absent','formal_new_entrant' not in expanded_screen.columns))
    def _as_bool(series):
        return series.map(lambda value: value if isinstance(value, bool) else str(value).strip().lower() in {'true','1','yes','y'})
    outside=~_as_bool(expanded_screen['engineering_registry_linked'])
    completed=_as_bool(expanded_screen.loc[outside,'formal_assessment_completed'])
    checks.append(('Candidates outside the frozen engineering registry are explicitly not formally evaluated',
                   completed.eq(False).all()
                   and expanded_screen.loc[outside,'formal_assessment_status'].astype(str).str.match(r'^(not_formally_evaluated|excluded_outside_material_boundary)').all()))
else:
    checks.extend([
        ('Legacy hard-coded formal_new_entrant field is absent',False),
        ('Candidates outside the frozen engineering registry are explicitly not formally evaluated',False),
    ])

frame=pd.DataFrame(checks,columns=['check','passed']); frame.to_csv(QC/f'{V}_UPSTREAM_RELEASE_GATE.csv',index=False)
mc_values = sorted(set(pd.to_numeric(read('system_value_monte_carlo_summary').mc_iterations, errors='coerce').dropna().astype(int).tolist()))
out={
    'status':'PASS' if frame.passed.all() and mc_values == [20000] else 'FAIL',
    'science_changed':True,
    'release_id':'TES-EES-V2.2.0-20260909',
    'core_scientific_baseline_changed':True,
    'scientific_extension_added':True,
    'scientific_extension':'second-stage composite-system coupling of nanoparticles and stationary scaffolds',
    'expanded_library_scope_semantics_corrected':True,
    'checks':int(len(frame)),
    'checks_passed':int(frame.passed.sum()),
    'mc_iterations': mc_values[0] if mc_values == [20000] else mc_values,
    'active_extension':'src/run_submission_synthesis.py',
    'dag_semantics':'containment requires corrosion; independent replication requires data completeness; atomic cycling has no artificial universal predecessor',
    'release_status_filename': UPSTREAM_RELEASE_STATUS,
}
payload=json.dumps(out,indent=2)
(QC/UPSTREAM_RELEASE_STATUS).write_text(payload,encoding='utf-8')
(QC/UPSTREAM_RELEASE_STATUS_COMPAT).write_text(payload,encoding='utf-8')
print(json.dumps(out,indent=2))
if out['status']!='PASS':
    print(frame[~frame.passed].to_string(index=False)); sys.exit(2)
