from __future__ import annotations

from pathlib import Path
import hashlib
import json
import re
import sys

import numpy as np
import pandas as pd

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
T = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
QC.mkdir(parents=True, exist_ok=True)
records: list[dict] = []


def check(name: str, passed: bool, detail, severity: str = "critical") -> None:
    records.append({"check": name, "passed": bool(passed), "severity": severity, "detail": str(detail)})


def read(name: str) -> pd.DataFrame:
    path = T / f"{VERSION}_{name}.csv"
    check(f"file::{name}", path.exists(), path.relative_to(ROOT) if path.exists() else "missing")
    return pd.read_csv(path) if path.exists() else pd.DataFrame()


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


# Inputs and primary outputs.
bench = pd.read_csv(ROOT / "config" / f"{VERSION}_system_benchmarks.csv")
membership = pd.read_csv(ROOT / "data" / "input" / f"{VERSION}_candidate_scenario_membership.csv")
appreg = pd.read_csv(ROOT / "data" / "input" / f"{VERSION}_candidate_scenario_evidence_registry.csv")
atomic = pd.read_csv(ROOT / "data" / "input" / f"{VERSION}_atomic_engineering_credibility_registry.csv")
metrics = read("candidate_system_metrics_deterministic")
draw_path = T / f'{VERSION}_monte_carlo_draws_balanced.csv'
check('file::monte_carlo_draws_balanced', draw_path.exists(), draw_path.relative_to(ROOT) if draw_path.exists() else 'missing')
if draw_path.exists():
    draw_columns = set(pd.read_csv(draw_path, nrows=0).columns)
    with draw_path.open('rb') as stream:
        draw_row_count = sum(block.count(b'\n') for block in iter(lambda: stream.read(1 << 20), b'')) - 1
else:
    draw_columns = set()
    draw_row_count = 0
lf = read("layered_selection_frequencies")
ns = read("no_selection_frequencies")
scan = read("continuous_weight_space_scan")
anchors = read("continuous_weight_anchor_results")
scan_design = read("continuous_weight_scan_design")
wrep = read("weight_space_region_replicates")
cred = read("credibility_model_sensitivity")
pert = read("evidence_score_perturbation_sensitivity")
loc = read("leave_one_candidate_out_sensitivity")
los = read("leave_one_source_out_sensitivity")
conv = read("independent_seed_convergence")
cf = read("evidence_closure_counterfactuals")
cff = read("counterfactual_selection_frequencies")
chg = read("counterfactual_selection_changes")
signed = read("counterfactual_candidate_signed_changes")
action_summary = read("figure_action_effect_forest_summary")
portfolio = read("research_action_nondominance_assessment")
joint = read("joint_gate_closure")
shapley = read("gate_shapley_attribution")
redraw = read("decision_redirection_draw_consequences")
redsys = read("decision_redirection_system_consequences")
penalty = read("partial_vs_complete_service_penalty")
link = read("candidate_database_linkage_audit")
funnel = read("database_to_shortlist_transition")
intersections = read("figure_gate_intersection_summary")
alluvial = read("figure_selection_alluvial_flows")
litflow = read("literature_evidence_flow")
feascomp = read("service_feasibility_composition")
synergy_summary = read("gate_pair_synergy_summary")
robustness_consensus = read("robustness_consensus_summary")
action_density = read("action_response_density")
score_rules = read("evidence_score_rule_registry")
score_ledger = read("candidate_service_evidence_score_ledger")
score_draw_summary = read("candidate_service_evidence_score_draw_summary")
property_domain_audit = read("property_domain_coverage_audit")
property_sensitivity = read("property_model_sensitivity_deterministic")
property_registry = pd.read_csv(ROOT / "data" / "input" / f"{VERSION}_candidate_property_registry.csv")
property_ledger = pd.read_csv(ROOT / "data" / "provenance" / f"{VERSION}_property_source_ledger.csv")

# Scenario architecture and source registries.
expected_scenarios = {
    "coal_flexibility_storage",
    "csp_sensible_storage",
    "industrial_medium_heat",
    "sco2_high_temperature_storage",
    "pcm_target_350C",
    "pcm_target_425C",
    "pcm_target_500C",
}
check("seven_explicit_service_scenarios", set(bench.scenario) == expected_scenarios, sorted(bench.scenario.unique()))
check("three_noninterchangeable_pcm_targets", int((bench.service_mode == "latent").sum()) == 3, bench.loc[bench.service_mode == "latent", ["scenario", "phase_target_min_C", "phase_target_max_C"]].to_dict("records"))
check("pcm_target_windows_distinct", bench.loc[bench.service_mode == "latent", ["phase_target_min_C", "phase_target_max_C"]].drop_duplicates().shape[0] == 3, "each PCM target has a distinct service band")
check("scenario_membership_unique", not membership.duplicated(["scenario", "system_id"]).any(), int(membership.duplicated(["scenario", "system_id"]).sum()))
check("application_evidence_unique", not appreg.duplicated(["scenario", "system_id"]).any(), int(appreg.duplicated(["scenario", "system_id"]).sum()))
check("atomic_registry_unique", not atomic.duplicated(["scenario", "system_id"]).any(), int(atomic.duplicated(["scenario", "system_id"]).sum()))
expected_memberships = len(membership)
expected_candidates = property_registry.system_id.nunique()
check("registry_row_alignment", len(membership) == len(appreg) == len(atomic) == len(metrics), {"membership": len(membership), "appreg": len(appreg), "atomic": len(atomic), "metrics": len(metrics)})

# Property-level provenance and thermophysical-domain freeze.
expected_property_groups = {"composition", "melting_temperature", "practical_upper_temperature", "specific_heat", "density", "thermal_conductivity", "viscosity", "latent_heat", "reported_energy_density"}
check("property_ledger_nine_rows_per_candidate", len(property_ledger) == expected_candidates * len(expected_property_groups), {"rows":len(property_ledger),"expected":expected_candidates*len(expected_property_groups)})
check("property_ledger_candidate_alignment", property_ledger.system_id.nunique() == expected_candidates, {"ledger":property_ledger.system_id.nunique(),"registry":expected_candidates})
check("property_ledger_nine_groups_each", property_ledger.groupby("system_id").property_group.apply(set).eq(expected_property_groups).all(), property_ledger.groupby("system_id").property_group.nunique().to_dict())
check("property_ledger_all_closed", property_ledger.review_status.eq("CLOSED").all(), property_ledger.loc[~property_ledger.review_status.eq("CLOSED"), "ledger_id"].tolist())
check("property_domain_audit_complete", len(property_domain_audit) == expected_memberships and {"physical_window_coverage", "thermophysical_window_coverage", "property_domain_extrapolation_required"}.issubset(property_domain_audit.columns), property_domain_audit.shape)
if len(property_domain_audit):
    check("thermophysical_coverage_not_above_physical", (property_domain_audit.thermophysical_window_coverage <= property_domain_audit.physical_window_coverage + 1e-12).all(), property_domain_audit.loc[property_domain_audit.thermophysical_window_coverage > property_domain_audit.physical_window_coverage + 1e-12].to_dict("records"))
    strict_expected = property_domain_audit.thermophysical_window_coverage >= 0.999
    check("strict_gate_uses_property_domain_coverage", (property_domain_audit.strict_complete_thermophysical_feasible.astype(bool) == strict_expected).all(), property_domain_audit.loc[property_domain_audit.strict_complete_thermophysical_feasible.astype(bool) != strict_expected].to_dict("records"))
    knc_sco2 = property_domain_audit[(property_domain_audit.scenario == "sco2_high_temperature_storage") & (property_domain_audit.system_id == "knc")]
    s7_coal = property_domain_audit[(property_domain_audit.scenario == "coal_flexibility_storage") & (property_domain_audit.system_id == "quat_s7")]
    check("knc_sco2_extrapolation_excluded", len(knc_sco2) == 1 and not bool(knc_sco2.iloc[0].strict_complete_thermophysical_feasible), knc_sco2.to_dict("records"))
    check("s7_coal_extrapolation_excluded", len(s7_coal) == 1 and not bool(s7_coal.iloc[0].strict_complete_thermophysical_feasible), s7_coal.to_dict("records"))

pr = property_registry.set_index("system_id")
check("qncc_reported_average_cp_primary", np.isclose(float(pr.loc["qncc", "cp_a"]), 1.56) and pr.loc["qncc", "cp_model"] == "constant", pr.loc["qncc", ["cp_model","cp_a"]].to_dict())
check("nkca_exact_composition_property_set", np.isclose(float(pr.loc["nkca", "latent_J_g"]), 171.5) and np.isclose(float(pr.loc["nkca", "cp_a"]), 0.8) and pd.isna(pr.loc["nkca", "reported_energy_density_MJ_m3"]), pr.loc["nkca", ["composition","latent_J_g","cp_a","reported_energy_density_MJ_m3"]].to_dict())
check("binary_carbonate_exact_source_and_composition", pr.loc["pcm_binary_carbonate", "source_ids"] == "GE_BINARY_CARBONATE_2018" and "51 mol% Li2CO3" in str(pr.loc["pcm_binary_carbonate", "composition"]), pr.loc["pcm_binary_carbonate", ["composition","source_ids"]].to_dict())
check("hitec_temperature_density_correlation", pr.loc["hitec", "rho_model"] == "linear_K" and np.isclose(float(pr.loc["hitec", "rho_a"]), 2.279799) and np.isclose(float(pr.loc["hitec", "rho_b"]), -0.0007324), pr.loc["hitec", ["rho_model","rho_a","rho_b"]].to_dict())
check("hitec_xl_review_average_cp", pr.loc["hitec_xl", "cp_model"] == "constant" and np.isclose(float(pr.loc["hitec_xl", "cp_a"]), 1.45), pr.loc["hitec_xl", ["cp_model","cp_a"]].to_dict())
check("registered_property_sensitivity_cases", {"legacy_physical_window_property_extrapolation", "qncc_temperature_dependent_cp_equation", "mgcl_msd_tp_alternate_melting_temperature", "nkca_rejected_near_composition_latent"}.issubset(set(property_sensitivity.sensitivity_case)), sorted(property_sensitivity.sensitivity_case.unique()))

score_roots = [
    "corrosion_compatibility",
    "cycling_phase_stability",
    "containment_validation",
    "literature_replication",
    "data_completeness",
    "burden_index",
]
bounds_ok = all(
    (atomic[f"{root}_low"] <= atomic[f"{root}_mid"]).all()
    and (atomic[f"{root}_mid"] <= atomic[f"{root}_high"]).all()
    for root in score_roots
)
check("atomic_score_interval_order", bounds_ok, "all low <= mid <= high")
check("atomic_score_range", atomic[[c for c in atomic if c.endswith(("_low", "_mid", "_high")) and "burden" not in c]].apply(lambda s: s.between(0, 1).all()).all(), "atomic credibility scores are in [0,1]")
check("atomic_basis_declares_analytical_intervals", atomic.atomic_evidence_basis.str.contains("sensitivity intervals", case=False).all(), atomic.atomic_evidence_basis.unique())

# Main Monte Carlo dimensions and probability closure.
check("balanced_draw_row_count", draw_row_count == len(metrics) * 20000, f"rows={draw_row_count} expected={len(metrics) * 20000}")
required_draw_cols = {
    "sampled_corrosion_compatibility",
    "sampled_cycling_phase_stability",
    "sampled_containment_validation",
    "sampled_literature_replication",
    "sampled_data_completeness",
    "sampled_engineering_burden_index",
    "sampled_engineering_credibility",
}
check("atomic_uncertainty_in_draw_table", required_draw_cols.issubset(draw_columns), sorted(required_draw_cols - draw_columns))
if len(lf) and len(ns):
    sums = lf.groupby(["scenario", "ranking_layer", "weight_prior"], as_index=False).selection_frequency.sum()
    closure = sums.merge(ns, on=["scenario", "ranking_layer", "weight_prior"], how="left")
    err = float((closure.selection_frequency + closure.no_selection_frequency - 1).abs().max())
    check("selection_probability_closure", err < 1e-10, f"max_abs_error={err:.3e}")

# Continuous top-level preference robustness.
check("continuous_random_weights_only", set(scan.weight_vector_type.unique()) == {"uniform_random"}, scan.weight_vector_type.value_counts().to_dict())
check("continuous_weight_vectors_per_scenario", scan.groupby("scenario").size().eq(10000).all(), scan.groupby("scenario").size().to_dict())
check("deterministic_anchors_separate", anchors.groupby("scenario").size().eq(3).all(), anchors.groupby("scenario").size().to_dict())
check("anchors_excluded_from_occupancy", scan_design.occupancy_denominator.str.contains("anchors excluded", case=False).all(), scan_design.occupancy_denominator.tolist())
check("physical_draws_per_weight", scan.physical_draws_per_weight.eq(500).all(), scan.physical_draws_per_weight.unique())
check("five_independent_weight_replicates", set(wrep.physical_draw_replicate.unique()) == {1, 2, 3, 4, 5}, sorted(wrep.physical_draw_replicate.unique()))

# Hierarchical utility and structural evidence robustness.
expected_models = {"hierarchical_geometric", "hierarchical_arithmetic", "no_literature_replication", "no_data_completeness", "bottleneck_minimum"}
check("credibility_model_set", set(cred.credibility_model.unique()) == expected_models, sorted(cred.credibility_model.unique()))
check("evidence_perturbation_levels", set(pert.atomic_evidence_level.unique()) == {"low", "mid", "high"}, sorted(pert.atomic_evidence_level.unique()))
check("leave_one_candidate_complete", len(loc) == len(metrics), f"rows={len(loc)} expected={len(metrics)}")
check("leave_one_source_stress_declared", len(los) > 0 and los.stress_method.str.contains("low bounds", case=False).all(), los.stress_method.unique())
check("independent_seed_replicates", set(conv.independent_seed_replicate.unique()) == {1, 2, 3, 4, 5}, sorted(conv.independent_seed_replicate.unique()))
check("independent_seed_checkpoints", set(conv.n_draws.unique()) == {500, 1000, 2000, 5000, 10000, 20000}, sorted(conv.n_draws.unique()))

# Atomic action semantics. Each single evidence action may close only its named gate.
gap_cols = ["gap_corrosion", "gap_cycling_phase", "gap_containment", "gap_literature_validation", "gap_data_completeness"]
action_to_gap = {
    "exact_composition_corrosion_closure": "gap_corrosion",
    "pcm_cycling_phase_closure": "gap_cycling_phase",
    "containment_validation_closure": "gap_containment",
    "literature_replication_closure": "gap_literature_validation",
    "data_completeness_closure": "gap_data_completeness",
}
expected_actions = {
    "baseline",
    "property_measurement_precision_50pct",
    "service_redesign_95pct",
    *action_to_gap.keys(),
    "combined_atomic_evidence_closure",
    "comprehensive_upper_bound",
}
check("counterfactual_action_set", set(cff.closure_action.unique()) == expected_actions, sorted(cff.closure_action.unique()))
for action, closed_gap in action_to_gap.items():
    z = signed[signed.closure_action == action].merge(atomic, on=["scenario", "system_id"], how="left")
    other_gaps = [column for column in gap_cols if column != closed_gap]
    expected = (~z[other_gaps].any(axis=1)) & (~z.nonclosable_direct_risk)
    check(f"atomic_action_semantics::{action}", np.array_equal(expected.to_numpy(), z.eligible_after.to_numpy()), f"mismatches={int((expected.to_numpy() != z.eligible_after.to_numpy()).sum())}")
severe = cff.merge(atomic[["scenario", "system_id", "nonclosable_direct_risk"]], on=["scenario", "system_id"])
severe = severe[severe.nonclosable_direct_risk]
check("nonclosable_risk_never_unlocked", not severe.eligible_after_action.any(), f"eligible severe rows={int(severe.eligible_after_action.sum())}")
check("signed_candidate_changes_retained", (signed.delta_selection_frequency < 0).any(), f"minimum delta={signed.delta_selection_frequency.min():.6f}")
check("signed_summary_columns", {"newly_eligible_candidates", "lost_eligible_candidates", "newly_selected_candidates", "lost_selected_candidates"}.issubset(action_summary.columns), action_summary.columns.tolist())

# Six-gate joint closure and application-equal Shapley attribution.
check("all_joint_gate_subsets", joint.groupby("scenario").size().eq(64).all(), joint.groupby("scenario").size().to_dict())
conservation_errors = []
for scenario, group in shapley[shapley.scope == "application"].groupby("scenario"):
    j = joint[joint.scenario == scenario]
    delta = float(j.loc[j.closed_gate_mask == 63, "retained_candidate_draw_frequency"].iloc[0] - j.loc[j.closed_gate_mask == 0, "retained_candidate_draw_frequency"].iloc[0])
    conservation_errors.append(abs(float(group.shapley_unlock_contribution.sum()) - delta))
check("shapley_efficiency_conservation", max(conservation_errors, default=1) < 1e-12, f"max_abs_error={max(conservation_errors, default=float('nan')):.3e}")
app = shapley[shapley.scope == "application"].groupby("gate").shapley_unlock_contribution.mean().sort_index()
eq = shapley[shapley.scope == "application_equal"].set_index("gate").shapley_unlock_contribution.sort_index()
check("application_equal_shapley", len(app) == len(eq) and float((app - eq).abs().max()) < 1e-12, f"max_abs_error={float((app - eq).abs().max()):.3e}")

# Draw-matched redirection consequences replace algebraic duplicates.
check("redirection_draw_consequences_present", len(redraw) > 0, f"rows={len(redraw)}")
check("redirection_system_consequence_quantiles", {"energy_ratio_p05", "energy_ratio_p50", "energy_ratio_p95", "additional_volume_p05_m3_MWh", "additional_volume_p50_m3_MWh", "additional_volume_p95_m3_MWh"}.issubset(redsys.columns), redsys.columns.tolist())
if len(redsys):
    finite = redsys.dropna(subset=["energy_ratio_p05", "energy_ratio_p50", "energy_ratio_p95", "additional_volume_p05_m3_MWh", "additional_volume_p50_m3_MWh", "additional_volume_p95_m3_MWh"])
    quantile_ok = len(finite) > 0 and (finite.energy_ratio_p05 <= finite.energy_ratio_p50).all() and (finite.energy_ratio_p50 <= finite.energy_ratio_p95).all() and (finite.additional_volume_p05_m3_MWh <= finite.additional_volume_p50_m3_MWh).all() and (finite.additional_volume_p50_m3_MWh <= finite.additional_volume_p95_m3_MWh).all()
    check("redirection_quantile_order", quantile_ok, f"finite rows={len(finite)}; p05 <= p50 <= p95")
check("partial_complete_penalty_explicit", {"partial_overlap_energy_fixed_kWh_m3", "complete_service_energy_fixed_kWh_m3"}.issubset(penalty.columns), penalty.columns.tolist())

# Provenance architecture is explicitly parallel, not a false funnel into all candidates.
check("database_funnel_is_prescreen_only", len(funnel) > 0 and not funnel.astype(str).apply(lambda s: s.str.contains("curated shortlist", case=False).any()).any(), f"rows={len(funnel)}")
check("candidate_database_linkage_complete", link.system_id.nunique() == expected_candidates and link.linkage_interpretation.notna().all(), f"unique candidates={link.system_id.nunique()}")
check("exact_database_link_count_declared", int(link.exact_formula_system_match.astype(bool).sum()) == 1, int(link.exact_formula_system_match.astype(bool).sum()), severity="scope")

# Figure-ready scientific closure.
if len(alluvial):
    flow_sum = alluvial.groupby("scenario").transition_frequency.sum()
    check("alluvial_probability_closure", np.allclose(flow_sum, 1), flow_sum.to_dict())
    check("alluvial_classes", set(alluvial.transition_class.unique()) <= {"retained", "redirected", "no_selection"}, sorted(alluvial.transition_class.unique()))
if len(intersections):
    by_scenario = intersections.groupby("scenario").frequency_within_scope.sum()
    check("gate_intersection_probability_closure", np.allclose(by_scenario, 1), by_scenario.to_dict())
check("action_summary_excludes_baseline", "baseline" not in set(action_summary.closure_action), sorted(action_summary.closure_action.unique()))
check("nondominance_signed_and_unclipped", {"total_lost_eligible_candidates", "total_lost_selected_candidates", "adverse_application_fraction"}.issubset(portfolio.columns), portfolio.columns.tolist())
check("evidence_score_rule_registry_complete", len(score_rules) == 11 and {"G","c","y","t","r","d","b","b*","C","P","U"} == set(score_rules.symbol) and {"order","symbol","component","input_fields","scale","sampling_rule","decision_role","closure_floor","interpretation_boundary","mapping_policy"}.issubset(score_rules.columns), score_rules.shape)
thermal_frontier = read("thermal_transport_frontier")
ranking_pathways = read("ranking_pathway_summary")
check("postprocess_contract_thermal_frontier", len(thermal_frontier) == expected_memberships and {"thermal_k_at_service_W_mK", "energy_density_p50_kWh_m3_conditional_on_adequacy", "evidence_qualified_selection_frequency"}.issubset(thermal_frontier.columns), thermal_frontier.shape)
check("postprocess_contract_ranking_pathways", ranking_pathways.scenario.nunique() == 7 and np.allclose(ranking_pathways.groupby("scenario").frequency.sum(), 1.0), {"rows": len(ranking_pathways), "frequency_sums": ranking_pathways.groupby("scenario").frequency.sum().to_dict()})
check("candidate_service_score_ledger_complete", len(score_ledger) == expected_memberships and score_ledger[["scenario","system_id"]].drop_duplicates().shape[0] == expected_memberships, score_ledger.shape)
check("candidate_service_score_draw_summary_complete", len(score_draw_summary) == expected_memberships and score_draw_summary.monte_carlo_rows.eq(20000).all(), score_draw_summary.shape)

# Editorial enrichment tables are direct, auditable aggregations for non-redundant figures.
check("literature_flow_unique_source_candidate_links", not litflow.duplicated(["system_id","source_id"]).any(), int(litflow.duplicated(["system_id","source_id"]).sum()))
check("service_feasibility_share_closure", np.allclose(feascomp.groupby("scenario").share_within_service.sum(), 1), feascomp.groupby("scenario").share_within_service.sum().to_dict())
check("gate_pair_summary_complete", len(synergy_summary) == 15 and synergy_summary.nonzero_service_count.between(0,7).all(), synergy_summary.shape)
check("robustness_consensus_complete", robustness_consensus.scenario.nunique() == 7 and robustness_consensus.leader_retention_share.between(0,1).all(), robustness_consensus.shape)
check("zero_positive_negative_action_responses_explicit", {"positive_response_count","negative_response_count","zero_response_count","zero_response_share"}.issubset(action_density.columns), action_density.columns.tolist())
readiness_audit = read("submission_readiness_audit")
readiness_text = " ".join(readiness_audit.astype(str).fillna("").to_numpy().ravel()).lower()
forbidden_inhouse_1 = "our experimental" + " validation"
forbidden_inhouse_2 = "experimental validation" + " package"
check("no_inhouse_experimental_validation_claim", forbidden_inhouse_1 not in readiness_text and forbidden_inhouse_2 not in readiness_text, "all validation evidence is literature-reported")

# Legacy terminology and package integrity.
legacy = []
pattern = re.compile(r"(?<![A-Za-z0-9])V{1,2}\d+tes(?![A-Za-z0-9])", re.I)
allowed_versions = {VERSION.lower()}
for path in ROOT.rglob("*"):
    if not path.is_file() or "__pycache__" in path.parts or path.suffix.lower() in {".pyc",".zip",".png",".jpg",".jpeg",".pdf"}:
        continue
    if path.parent == QC and path.name.endswith("VERSION_TERM_SCAN.csv"):
        continue
    if path.name == f"{VERSION}_PREDECESSOR_COMPARISON_AND_MERGE_ZH.md":
        continue
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        continue
    tokens=set(pattern.findall(text)) | set(pattern.findall(path.name))
    if any(token.lower() not in allowed_versions for token in tokens):
        legacy.append(str(path.relative_to(ROOT)))
check("legacy_version_term_scan", len(legacy) == 0, legacy)
pd.DataFrame({"legacy_match": legacy}).to_csv(QC / f"{VERSION}_VERSION_TERM_SCAN.csv", index=False)

critical_failures = [record for record in records if record["severity"] == "critical" and not record["passed"]]
status = "PASS" if not critical_failures else "FAIL"

# Fixed-scope and action-boundary blocker checks.
trans = pd.read_csv(T / f"{VERSION}_selection_transition_matrix.csv")
check("evidence_redirection_uses_strict_complete_reference", set(trans.from_layer.astype(str)) == {"strict_complete_thermophysical"}, sorted(trans.from_layer.astype(str).unique()))
scope = pd.read_csv(T / f"{VERSION}_counterfactual_action_scope_audit.csv")
cor = scope[scope.closure_action.eq("exact_composition_corrosion_closure")]
check("corrosion_closure_preserves_independent_burden", not cor[(cor.field.eq("burden_index")) & cor.changed].shape[0], cor[(cor.field.eq("burden_index")) & cor.changed].to_dict("records"))
check("counterfactual_scope_audit_present", len(scope)>0, f"rows={len(scope)}")
portfolio = pd.read_csv(T / f"{VERSION}_research_action_nondominance_assessment.csv")
check("research_nondominance_excludes_diagnostics", not portfolio[portfolio.comparison_eligible & portfolio.action_type.isin(["engineering_redesign","diagnostic_upper_bound","measurement_programme"])].shape[0], portfolio.loc[portfolio.comparison_eligible,["closure_action","action_type"]].to_dict("records"))
check("adverse_metric_dimensionless", "adverse_application_fraction" in portfolio.columns and portfolio.adverse_application_fraction.between(0,1).all(), portfolio[["closure_action","adverse_application_fraction"]].to_dict("records"))
firewall = pd.read_csv(T / f"{VERSION}_ai_decision_firewall_audit.csv")

if {"firewall_status", "ai_derived_values_entering_bounded_decision"}.issubset(firewall.columns):
    firewall_ok = firewall.firewall_status.eq("PASS").all() and firewall.ai_derived_values_entering_bounded_decision.eq(0).all()
elif {"check", "passed", "detail"}.issubset(firewall.columns):
    firewall_ok = firewall["passed"].astype(str).str.lower().isin(["true", "1", "yes"]).all()
else:
    firewall_ok = False
check("native_ai_firewall", firewall_ok, firewall.to_dict("records"))
uncertainty = pd.read_csv(T / f"{VERSION}_uncertainty_source_decomposition.csv")
transition = pd.read_csv(T / f"{VERSION}_selection_uncertainty_transition.csv")
check("entropy_units_are_explicit_bits", {"entropy_unit","entropy_log_base"}.issubset(uncertainty.columns) and {"entropy_unit","entropy_log_base"}.issubset(transition.columns) and uncertainty.entropy_unit.eq("bits").all() and transition.entropy_unit.eq("bits").all() and uncertainty.entropy_log_base.eq(2).all() and transition.entropy_log_base.eq(2).all(), transition[[c for c in ["entropy_unit","entropy_log_base"] if c in transition.columns]].drop_duplicates().to_dict("records"))
check("fixed_scope_uncertainty_source_only", set(uncertainty[uncertainty.source.astype(str).str.contains("thermophysical")].source)=={"strict_complete_thermophysical"}, uncertainty[uncertainty.source.astype(str).str.contains("thermophysical")][["scenario","source"]].to_dict("records"))
omission = pd.read_csv(T / f"{VERSION}_omission_influence.csv")
check("omission_baseline_is_single_hierarchical_geometric", set(omission.baseline_model)=={"hierarchical_geometric"}, omission.baseline_model.unique().tolist())
check("omission_leader_change_is_id_consistent", (omission.leader_changed==(omission.modal_leader_id.astype(str)!=omission.baseline_leader_id.astype(str))).all(), omission.loc[omission.leader_changed!=(omission.modal_leader_id.astype(str)!=omission.baseline_leader_id.astype(str))].to_dict("records"))
source_groups = pd.read_csv(T / f"{VERSION}_source_omission_effect_groups.csv")
check("source_omission_baseline_is_single_hierarchical_geometric", "baseline_model" in source_groups.columns and set(source_groups.baseline_model)=={"hierarchical_geometric"}, source_groups.get("baseline_model",pd.Series(dtype=str)).unique().tolist())
check("source_grouping_uses_complete_outcome_vector", "grouping_rule" in source_groups.columns and source_groups.grouping_rule.astype(str).str.contains("complete displayed outcome vector",case=False).all(), source_groups.get("grouping_rule",pd.Series(dtype=str)).unique().tolist())
contraction = pd.read_csv(T / f"{VERSION}_deployability_contraction.csv")
material_stages = contraction[contraction.deployability_stage.astype(str).str.contains("selection frequency",case=False)]
check("material_selection_threshold_is_one_percent", set(material_stages.deployability_stage)=={"Material selection frequency ≥1%"}, material_stages.deployability_stage.unique().tolist())
critical_failures = [record for record in records if record["severity"] == "critical" and not record["passed"]]
status = "PASS" if not critical_failures else "FAIL"
summary = {
    "status": status,
    "version": VERSION,
    "critical_checks": sum(record["severity"] == "critical" for record in records),
    "critical_failures": len(critical_failures),
    "scope_declarations": sum(record["severity"] == "scope" for record in records),
    "checks": records,
    "scientific_scope": {
        "utility": "two-level performance-versus-engineering-credibility utility; credibility is built from five literature-evidence dimensions and inverse burden",
        "pcm": "three explicit target-temperature services; latent heat is the primary PCM metric and a fixed +50 K sensible term is a separate non-ranking diagnostic",
        "property_domains": "strict sensible-service eligibility requires joint physical phase coverage and source-valid Cp/density coverage; decomposition stability does not extend property validity",
        "energy_calculation": "Cp(T) and rho(T)Cp(T) are integrated over the source-valid interval; midpoint products are exported only as rejected legacy sensitivities",
        "composition_alignment": "direct properties are aligned to the exact registered composition; nearby-composition and derived values are explicitly separated",
        "evidence_uncertainty": "declared low-mid-high analytical sensitivity intervals are sampled; all validation evidence is literature-reported and no new experiment is claimed",
        "weight_space": "10,000 random top-level weights per scenario; three deterministic anchors are reported separately; five independent physical/weight replicates",
        "counterfactuals": "single-gate actions close only their named atomic gap; direct severe risk is never overridden",
        "gate_attribution": "six-gate joint closure with application-equal Shapley attribution",
        "consequences": "draw-matched energy-density and salt-volume consequences replace algebraically redundant display panels",
    },
}
(QC / f"{VERSION}_FINAL_VALIDATION_SUMMARY.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
(QC / f"{VERSION}_QC_STATUS.json").write_text(json.dumps({"status": status, "version": VERSION, "critical_failures": len(critical_failures)}, indent=2), encoding="utf-8")
pd.DataFrame(records).to_csv(QC / f"{VERSION}_VALIDATION_CHECKS.csv", index=False)

manifest_path = ROOT / "PACKAGE_MANIFEST_SHA256.csv"
manifest = []
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path == manifest_path or "__pycache__" in path.parts or path.suffix == ".pyc":
        continue
    manifest.append({"relative_path": str(path.relative_to(ROOT)), "size_bytes": path.stat().st_size, "sha256": sha256(path)})
pd.DataFrame(manifest).to_csv(manifest_path, index=False)

print(json.dumps({"status": status, "critical_failures": len(critical_failures), "checks": len(records)}, indent=2))
for record in critical_failures:
    print("FAIL:", record["check"], record["detail"])
if critical_failures:
    sys.exit(1)
