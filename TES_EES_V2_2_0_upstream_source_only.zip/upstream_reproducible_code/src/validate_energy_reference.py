"""Independent fixed-mass / reference-volume checks without executing the runner."""
import ast
import json
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
tree=ast.parse((ROOT/'src/run_upstream.py').read_text(encoding='utf-8'))
selected=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in {'cp_coefficients','rho_coefficients','integrate_sensible'}]
ns={'np':np}
exec(compile(ast.Module(body=selected,type_ignores=[]),'<isolated-energy-functions>','exec'),ns)
rows=[]
props=pd.read_csv(ROOT/'data/input/core_candidate_property_registry.csv')
for row in props.itertuples():
    for lo,hi in [(300.,450.),(400.,550.),(500.,500.),(600.,500.)]:
        q,qv=ns['integrate_sensible'](row,lo,hi)
        c0,c1=ns['cp_coefficients'](row); d0,d1=ns['rho_coefficients'](row)
        hot=max(lo,hi); temps=np.linspace(lo,hot,1001)
        expected_q=np.trapezoid(c0+c1*temps,temps)/3600
        rho_hot=d0+d1*hot
        expected=q*rho_hot
        rows.append({'candidate':row.system_id,'low_C':lo,'high_C':hi,'mass_energy':float(q),'volume_energy':float(qv),'passed':bool(np.isclose(q,expected_q,rtol=1e-10,atol=1e-12,equal_nan=True) and np.isclose(qv,expected,rtol=1e-12,atol=1e-12,equal_nan=True))})
frame=pd.DataFrame(rows)
frame.to_csv(ROOT/'outputs/tables/fixed_mass_energy_reference_checks.csv',index=False)
payload={'status':'PASS' if frame.passed.all() else 'FAIL','checks':len(frame),'passed':int(frame.passed.sum()),'reference':'Fixed salt mass; sensible enthalpy normalized by hot-end density. Temperature test intervals verify numerical algebra, not source-domain eligibility.'}
(ROOT/'outputs/qc/FIXED_MASS_ENERGY_STATUS.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
print(json.dumps(payload,indent=2))
if payload['status']!='PASS': raise SystemExit(1)
