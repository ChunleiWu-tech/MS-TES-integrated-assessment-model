from __future__ import annotations
from pathlib import Path
import json
import re
import numpy as np
import pandas as pd

VERSION='core'
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'/'tables'
QC=ROOT/'outputs'/'qc'

def read(name): return pd.read_csv(OUT/f'{VERSION}_{name}.csv')
def write(df,name): df.to_csv(OUT/f'{VERSION}_{name}.csv',index=False)

def entropy(vals):
    x=np.asarray(vals,dtype=float)
    x=x[np.isfinite(x)&(x>0)]
    return float(-(x*np.log2(x)).sum()) if len(x) else 0.0

checks=[]

def add(name,passed,detail):
    checks.append({'check':name,'passed':bool(passed),'detail':detail})

# 1) Strict fixed-scope uncertainty decomposition from the draw-matched transition matrix.
trans=read('strict_complete_selection_transition_matrix')
if 'weight_prior' in trans.columns and set(trans.weight_prior.astype(str)) != {'balanced'}:
    raise RuntimeError(f"Strict-complete transition matrix must contain only the balanced prior: {sorted(trans.weight_prior.astype(str).unique())}")
transition_sums=trans.groupby('scenario').transition_frequency.sum()
if not np.allclose(transition_sums.to_numpy(float),1.0,atol=1e-12,rtol=0.0):
    raise RuntimeError(f"Strict-complete transition frequencies must sum to one per scenario: {transition_sums.to_dict()}")
old=read('uncertainty_source_decomposition')
rows=[]
for scenario,g in trans.groupby('scenario',sort=False):
    label=str(g.scenario_label.iloc[0])
    src=g.groupby(['from_system_id','from_display_system'],as_index=False).transition_frequency.sum()
    no=float(src.loc[src.from_system_id.eq('__NO_COMPLETE_SERVICE__'),'transition_frequency'].sum())
    h=entropy(src.transition_frequency)
    rows.append({'scenario':scenario,'scenario_label':label,'source':'strict_complete_thermophysical',
                 'selection_entropy':h,'entropy_scope':'candidates_plus_no_complete_service','no_selection_frequency':no})
strict=pd.DataFrame(rows)
rest=old[~old.source.isin(['thermophysical_screening','strict_complete_thermophysical'])].copy()
unc=pd.concat([strict,rest],ignore_index=True)
order=['strict_complete_thermophysical','balanced_primary','price_inclusive_sensitivity','performance_prior_shift','engineering_prior_shift']
unc['_o']=unc.source.map({x:i for i,x in enumerate(order)}).fillna(99)
unc=unc.sort_values(['scenario','_o']).drop(columns='_o')
unc['entropy_unit']='bits'
unc['entropy_log_base']=2
write(unc,'uncertainty_source_decomposition')

# 2) Matched strict-complete -> strict-complete evidence-bounded transition.
a=unc[unc.source.eq('strict_complete_thermophysical')].set_index('scenario')
b=unc[unc.source.eq('balanced_primary')].set_index('scenario')
tr=[]
for s in a.index:
    tr.append({
        'scenario':s,
        'from_layer':'strict_complete_thermophysical',
        'to_layer':'strict_complete_evidence_bounded',
        'strict_complete_thermophysical_selection_entropy':float(a.loc[s,'selection_entropy']),
        'strict_complete_evidence_bounded_selection_entropy':float(b.loc[s,'selection_entropy']),
        'delta_selection_entropy':float(b.loc[s,'selection_entropy']-a.loc[s,'selection_entropy']),
        'strict_complete_thermophysical_no_selection_frequency':float(a.loc[s,'no_selection_frequency']),
        'strict_complete_evidence_bounded_no_selection_frequency':float(b.loc[s,'no_selection_frequency']),
        'delta_no_selection_frequency':float(b.loc[s,'no_selection_frequency']-a.loc[s,'no_selection_frequency']),
        'collapse_to_no_selection':bool(b.loc[s,'no_selection_frequency']>=0.999),
        'fixed_scope_comparison':True,
        'interpretation':'Draw-matched strict-complete thermophysical versus strict-complete evidence-bounded outcomes; service scope is fixed before evidence gating.'
    })
ut=pd.DataFrame(tr)
ut['entropy_unit']='bits'
ut['entropy_log_base']=2
write(ut,'selection_uncertainty_transition')

# 3) Exact source-omission grouping against the same hierarchical-geometric baseline used in Fig. 5d.
loso=read('leave_one_source_out_sensitivity').copy()
base_model=read('credibility_model_sensitivity')
base_model=base_model[base_model.credibility_model.eq('hierarchical_geometric')].set_index('scenario')
source_rows=[]
for r in loso.itertuples(index=False):
    b=base_model.loc[r.scenario]
    source_rows.append({
        'scenario':r.scenario,
        'source_id':str(r.omitted_source_id),
        'affected_candidate_count':int(r.affected_candidate_count),
        'modal_leader':str(r.modal_leader),
        'modal_leader_frequency':float(r.modal_leader_frequency),
        'no_selection_frequency':float(r.no_selection_frequency),
        'selection_entropy':float(r.selection_entropy),
        'top1_top2_frequency_gap':float(r.top1_top2_frequency_gap),
        'mean_top_two_utility_margin':float(r.mean_top_two_utility_margin),
        'multiple_bounded_candidate_draw_frequency':float(r.multiple_bounded_candidate_draw_frequency),
        'single_bounded_candidate_draw_frequency':float(r.single_bounded_candidate_draw_frequency),
        'no_bounded_candidate_draw_frequency':float(r.no_bounded_candidate_draw_frequency),
        'leader_exceeds_benchmark_probability':float(r.leader_exceeds_benchmark_probability),
        'bounded_candidate_union_count':int(r.bounded_candidate_union_count),
        'leader_changed':str(r.modal_leader)!=str(b.modal_leader),
        'delta_no_selection':float(r.no_selection_frequency-b.no_selection_frequency),
        'delta_selection_entropy':float(r.selection_entropy-b.selection_entropy),
        'delta_modal_leader_frequency':float(r.modal_leader_frequency-b.modal_leader_frequency),
        'delta_top1_top2_frequency_gap':float(r.top1_top2_frequency_gap-b.top1_top2_frequency_gap),
        'delta_mean_top_two_utility_margin':float(r.mean_top_two_utility_margin-b.mean_top_two_utility_margin),
        'delta_leader_exceeds_benchmark_probability':float(r.leader_exceeds_benchmark_probability-b.leader_exceeds_benchmark_probability),
    })
source_effects=pd.DataFrame(source_rows)
full_outcome_cols=[
    'modal_leader','modal_leader_frequency','no_selection_frequency','selection_entropy',
    'top1_top2_frequency_gap','mean_top_two_utility_margin',
    'multiple_bounded_candidate_draw_frequency','single_bounded_candidate_draw_frequency',
    'no_bounded_candidate_draw_frequency','leader_exceeds_benchmark_probability',
    'bounded_candidate_union_count','affected_candidate_count','leader_changed'
]
key_cols=['scenario']
for col in full_outcome_cols:
    if pd.api.types.is_numeric_dtype(source_effects[col]):
        key='_key_'+col
        source_effects[key]=source_effects[col].round(8)
        key_cols.append(key)
    else:
        key_cols.append(col)
groups=[]
for _,g in source_effects.groupby(key_cols,dropna=False,sort=False):
    first=g.iloc[0]
    groups.append({
        'scenario':first.scenario,
        'source_count':int(len(g)),
        'source_ids':';'.join(sorted(g.source_id.astype(str))),
        'affected_candidate_count_min':int(g.affected_candidate_count.min()),
        'affected_candidate_count_max':int(g.affected_candidate_count.max()),
        'modal_leader':first.modal_leader,
        'modal_leader_frequency':first.modal_leader_frequency,
        'no_selection_frequency':first.no_selection_frequency,
        'selection_entropy':first.selection_entropy,
        'top1_top2_frequency_gap':first.top1_top2_frequency_gap,
        'mean_top_two_utility_margin':first.mean_top_two_utility_margin,
        'multiple_bounded_candidate_draw_frequency':first.multiple_bounded_candidate_draw_frequency,
        'single_bounded_candidate_draw_frequency':first.single_bounded_candidate_draw_frequency,
        'no_bounded_candidate_draw_frequency':first.no_bounded_candidate_draw_frequency,
        'leader_exceeds_benchmark_probability':first.leader_exceeds_benchmark_probability,
        'bounded_candidate_union_count':first.bounded_candidate_union_count,
        'leader_changed':bool(first.leader_changed),
        'delta_no_selection':float(first.delta_no_selection),
        'delta_selection_entropy':float(first.delta_selection_entropy),
        'delta_modal_leader_frequency':float(first.delta_modal_leader_frequency),
        'delta_top1_top2_frequency_gap':float(first.delta_top1_top2_frequency_gap),
        'delta_mean_top_two_utility_margin':float(first.delta_mean_top_two_utility_margin),
        'delta_leader_exceeds_benchmark_probability':float(first.delta_leader_exceeds_benchmark_probability),
        'baseline_model':'hierarchical_geometric',
        'grouping_rule':'Exact equality after 1e-8 rounding across the complete displayed outcome vector; never grouped by no-selection alone.'
    })
source_groups=pd.DataFrame(groups)
write(source_groups,'source_omission_effect_groups')

# 4) Main 1% material-selection threshold in contraction table.
layer=read('layered_selection_frequencies')
rows=[]
for scenario,g in layer[layer.ranking_layer.eq('evidence_qualified') & layer.weight_prior.eq('balanced')].groupby('scenario',sort=False):
    label=str(g.scenario_label.iloc[0]); n=int(len(g)); sel=int((g.selection_frequency>=0.01).sum())
    rows.append({'scenario':scenario,'scenario_label':label,'stage_order':5,'deployability_stage':'Material selection frequency ≥1%','candidate_service_pairs':sel,'share_of_registered':sel/n if n else 0})
contr=read('deployability_contraction')
contr=contr[~contr.deployability_stage.astype(str).str.contains('Selection frequency',case=False,regex=False)]
contr=pd.concat([contr,pd.DataFrame(rows)],ignore_index=True).sort_values(['scenario','stage_order'])
write(contr,'deployability_contraction')

# 5) Normalize any legacy versioned output columns to the current version.
dec=read('integrated_system_decision_table')
legacy_column_pattern=re.compile(r'^V\d+tes_')
rename={c:legacy_column_pattern.sub(f'{VERSION}_',c) for c in dec.columns if legacy_column_pattern.match(c) and not c.startswith(f'{VERSION}_')}
if rename: dec=dec.rename(columns=rename)
write(dec,'integrated_system_decision_table')

# 6) Correct readiness/version identity text without retaining legacy version literals.
sub=read('submission_readiness_audit')
legacy_text_pattern=re.compile(r'V\d+tes')
for idx in sub.index:
    for c in sub.columns:
        if isinstance(sub.at[idx,c],str) and legacy_text_pattern.search(sub.at[idx,c]) and VERSION not in sub.at[idx,c]:
            sub.at[idx,c]=legacy_text_pattern.sub(VERSION,sub.at[idx,c])
write(sub,'submission_readiness_audit')

# 7) AI interpretation boundaries: calibration, not independent external validation.
ai=read('ai_model_validation')
ai['validation_interpretation']=np.where(ai.validation_scheme.eq('formula_group_conformal'),
    'Formula-group cross-validation; interval coverage is calibration coverage on out-of-fold residuals, not independent external validation.',
    'Record-random cross-validation is an internal optimistic sensitivity benchmark and not the primary generalization claim.')
ai['external_validation_status']='not_performed'
ai['feature_scope_limitation']='Formula-level elemental occurrence, element count and molecular-weight descriptors; mixture fractions and engineering compatibility are not fully represented.'
write(ai,'ai_model_validation')

app=read('ai_candidate_applicability_audit')
app['dual_target_in_domain']=app['melting_temperature_K_in_domain'].fillna(False)&app['density_kg_m3_in_domain'].fillna(False)
app['ai_role']='audit_only; never substitutes for direct property or engineering evidence'
write(app,'ai_candidate_applicability_audit')

add('strict_uncertainty_source_present',set(unc[unc.source.str.contains('thermophysical')].source)=={'strict_complete_thermophysical'},unc[unc.source.str.contains('thermophysical')][['scenario','source']].to_dict('records'))
add('strict_transition_layers',set(ut.from_layer)=={'strict_complete_thermophysical'} and set(ut.to_layer)=={'strict_complete_evidence_bounded'},ut[['from_layer','to_layer']].drop_duplicates().to_dict('records'))
add('strict_transition_balanced_prior_only',('weight_prior' not in trans.columns) or set(trans.weight_prior.astype(str))=={'balanced'},trans.get('weight_prior',pd.Series(dtype=str)).astype(str).unique().tolist())
add('strict_transition_frequency_sums_one',np.allclose(trans.groupby('scenario').transition_frequency.sum().to_numpy(float),1.0,atol=1e-12,rtol=0.0),trans.groupby('scenario').transition_frequency.sum().to_dict())
add('strict_entropy_nonnegative',(strict.selection_entropy>=-1e-12).all(),strict[['scenario','selection_entropy']].to_dict('records'))
add('strict_entropy_matches_transition',all(abs(entropy(g.groupby('from_system_id').transition_frequency.sum().values)-a.loc[s,'selection_entropy'])<1e-10 for s,g in trans.groupby('scenario')),strict[['scenario','selection_entropy']].to_dict('records'))
add('one_percent_material_threshold',set(pd.DataFrame(rows).deployability_stage)=={'Material selection frequency ≥1%'},rows)
add('no_legacy_version_columns',not any(legacy_column_pattern.match(c) and not c.startswith(f'{VERSION}_') for c in dec.columns),[c for c in dec.columns if legacy_column_pattern.match(c) and not c.startswith(f'{VERSION}_')])
add('ai_external_validation_not_overclaimed',set(ai.external_validation_status)=={'not_performed'},ai[['target','validation_scheme','external_validation_status']].to_dict('records'))
add('entropy_unit_explicit_bits',set(unc.entropy_unit)=={'bits'} and set(ut.entropy_unit)=={'bits'} and set(unc.entropy_log_base)=={2} and set(ut.entropy_log_base)=={2}, {'uncertainty':unc.entropy_unit.unique().tolist(),'transition':ut.entropy_unit.unique().tolist()})
omission=read('omission_influence')
add('omission_single_hierarchical_baseline',set(omission.baseline_model)=={'hierarchical_geometric'},omission.baseline_model.unique().tolist())
add('omission_leader_id_consistency',bool((omission.leader_changed==(omission.modal_leader_id.astype(str)!=omission.baseline_leader_id.astype(str))).all()),int(omission.leader_changed.sum()))
add('source_omission_single_hierarchical_baseline',set(source_groups.baseline_model)=={'hierarchical_geometric'},source_groups.baseline_model.unique().tolist())
add('source_groups_complete_vector_rule',source_groups.grouping_rule.str.contains('complete displayed outcome vector',case=False).all(),source_groups[['scenario','source_count']].to_dict('records'))
status='PASS' if all(x['passed'] for x in checks) else 'FAIL'
payload={'status':status,'version':VERSION,'checks':checks,'critical_failures':sum(not x['passed'] for x in checks)}
(QC/f'{VERSION}_SCIENTIFIC_CORRECTION_STATUS.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
pd.DataFrame(checks).to_csv(QC/f'{VERSION}_SCIENTIFIC_CORRECTION_CHECKS.csv',index=False)
print(json.dumps(payload,indent=2,ensure_ascii=False))
if status!='PASS': raise SystemExit(1)
