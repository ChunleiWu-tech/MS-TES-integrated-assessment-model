from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd
from decision_model import BURDEN_HALF_VALUE

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
DOCS = ROOT / "docs"
for directory in (OUT, QC, DOCS):
    directory.mkdir(parents=True, exist_ok=True)

SCENARIOS = [
    "coal_flexibility_storage",
    "csp_sensible_storage",
    "industrial_medium_heat",
    "sco2_high_temperature_storage",
    "pcm_target_350C",
    "pcm_target_425C",
    "pcm_target_500C",
]
GATE_ORDER = [
    "incomplete_service", "corrosion", "cycling_phase", "containment",
    "literature_validation", "data_completeness",
]
MAIN_ACTION_TYPES = {"evidence_acquisition", "evidence_programme"}


def load(name: str) -> pd.DataFrame:
    return pd.read_csv(OUT / f"{VERSION}_{name}.csv")


def redirection_support_tables() -> tuple[pd.DataFrame, pd.DataFrame]:
    flow = load("figure_selection_alluvial_flows")
    ready = load("candidate_readiness_profile")
    redirected = flow[flow.transition_class.eq("redirected")].copy()
    redirected["route"] = redirected.from_display_system.astype(str) + " → " + redirected.to_display_system.astype(str)
    route = (redirected.groupby(["route", "from_display_system", "to_display_system"], as_index=False)
             .transition_draws.sum())
    denom = float(flow.groupby("scenario").mc_iterations.max().sum())
    route["application_equal_redirection_frequency"] = route.transition_draws / denom
    route = route.sort_values("transition_draws", ascending=False).reset_index(drop=True)
    route.to_csv(OUT / f"{VERSION}_redirection_route_summary.csv", index=False)

    scorecols = [
        "corrosion_compatibility_score", "cycling_phase_stability_score",
        "containment_validation_score", "literature_replication_score",
        "data_completeness_score",
    ]
    ready = ready.copy()
    ready["engineering_credibility"] = (
        ready[scorecols].clip(lower=1e-12).prod(axis=1)
        * (1.0 / (1.0 + ready.engineering_burden_index.clip(lower=0) / BURDEN_HALF_VALUE))
    ).pow(1.0 / 6.0)
    cmap = ready.set_index(["scenario", "system_id"]).engineering_credibility.to_dict()
    redirected["credibility_change"] = [
        cmap.get((r.scenario, r.to_system_id), np.nan)
        - cmap.get((r.scenario, r.from_system_id), np.nan)
        for r in redirected.itertuples(index=False)
    ]
    rows = []
    for scenario, group in redirected.groupby("scenario", sort=False):
        valid = group.credibility_change.notna()
        if not valid.any():
            continue
        vals = group.loc[valid, "credibility_change"].to_numpy(float)
        weights = group.loc[valid, "transition_draws"].to_numpy(float)
        rows.append({
            "scenario": scenario,
            "mean_engineering_credibility_change": float(np.average(vals, weights=weights)),
            "minimum_engineering_credibility_change": float(vals.min()),
            "maximum_engineering_credibility_change": float(vals.max()),
            "redirected_draws": int(weights.sum()),
        })
    cred = pd.DataFrame(rows).set_index("scenario").reindex(SCENARIOS).dropna(how="all").reset_index()
    cred.to_csv(OUT / f"{VERSION}_redirection_credibility_change.csv", index=False)
    return route, cred


def gate_support_tables() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    gint = load("figure_gate_intersection_summary")
    display_to_gate = {
        "Incomplete service": "incomplete_service",
        "Corrosion": "corrosion",
        "Cycling/phase": "cycling_phase",
        "Containment": "containment",
        "Literature validation": "literature_validation",
        "Data completeness": "data_completeness",
    }
    available = {display: gate for display, gate in display_to_gate.items() if display in gint.columns}
    agg_spec = {"application_equal_frequency": ("frequency_within_scope", "mean")}
    for display, gate in available.items():
        agg_spec[gate] = (display, "max")
    inter = gint.groupby("gate_pattern", as_index=False).agg(**agg_spec)
    gate_cols = list(available.values())
    inter["gate_count"] = inter[gate_cols].astype(bool).sum(axis=1)
    inter["intersection_label"] = inter.apply(
        lambda r: " + ".join(g.replace("_", " ") for g in gate_cols if bool(r[g])) or "retained", axis=1
    )
    inter = inter.sort_values(["application_equal_frequency", "gate_count"], ascending=[False, False])
    inter.to_csv(OUT / f"{VERSION}_gate_intersection_horizontal_summary.csv", index=False)

    joint = load("joint_gate_closure")
    joint["closed_gate_count"] = joint.closed_gates.astype(str).map(
        lambda x: 0 if x == "none" else len([z for z in x.split(";") if z])
    )
    depth = (joint.groupby(["scenario", "closed_gate_count"], as_index=False)
             .agg(
                 minimum_retained_frequency=("retained_candidate_draw_frequency", "min"),
                 median_retained_frequency=("retained_candidate_draw_frequency", "median"),
                 mean_retained_frequency=("retained_candidate_draw_frequency", "mean"),
                 maximum_retained_frequency=("retained_candidate_draw_frequency", "max"),
             ))
    depth.to_csv(OUT / f"{VERSION}_gate_closure_depth_response.csv", index=False)

    overlap = load("gate_overlap_summary")
    overlap["multiplicity_class"] = np.select(
        [overlap.gate_failure_count.eq(0), overlap.gate_failure_count.eq(1)],
        ["retained", "single_gate_failure"],
        default="multiple_simultaneous_failures",
    )
    mult = (overlap.groupby(["scenario", "multiplicity_class"], as_index=False)
            .frequency_within_scenario.sum())
    mult.to_csv(OUT / f"{VERSION}_gate_failure_multiplicity_summary.csv", index=False)
    return inter, depth, mult


def action_support_table() -> pd.DataFrame:
    action = load("action_service_scorecard")
    burden = load("action_classification_and_burden_registry")
    eligible = set(burden.loc[burden.action_type.isin(MAIN_ACTION_TYPES), "closure_action"])
    nonzero = action[
        action.closure_action.isin(eligible)
        & action.delta_expected_normalized_service_value.abs().gt(1e-12)
    ].copy()
    nonzero["absolute_service_value_gain"] = nonzero.delta_expected_normalized_service_value.abs()
    nonzero = nonzero.sort_values(
        ["absolute_service_value_gain", "closure_action", "scenario"],
        ascending=[False, True, True],
    )
    nonzero.to_csv(OUT / f"{VERSION}_atomic_action_service_nonzero_scorecard.csv", index=False)
    return nonzero


def write_release_documents() -> None:
    """Write only current-version synthesis metadata.

    Historical package-comparison prose is intentionally excluded from the
    clean release because it is not part of the reproducible scientific
    workflow and can reintroduce obsolete figure counts or method labels.
    """
    payload = {
        "version": VERSION,
        "main_figure_panels": 29,
        "supplementary_figure_panels": 22,
        "main_figure_panel_counts": [5, 5, 4, 5, 5, 5],
        "fixed_scope_transition": [
            "strict_complete_thermophysical",
            "strict_complete_evidence_bounded",
        ],
        "material_selection_threshold": 0.01,
        "research_action_types_in_main_text": sorted(MAIN_ACTION_TYPES),
        "independent_sampling_convergence_location": "Supplementary Fig. 6b",
        "ai_bounded_decision_use": False,
    }
    (QC / f"{VERSION}_SYNTHESIS_STATUS.json").write_text(
        json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8"
    )

def main() -> None:
    route, cred = redirection_support_tables()
    inter, depth, mult = gate_support_tables()
    nonzero = action_support_table()
    write_release_documents()

    flow = load("figure_selection_alluvial_flows")
    burden = load("action_classification_and_burden_registry")
    scope = load("counterfactual_action_scope_audit")
    research = load("research_action_nondominance_assessment")
    checks = [
        {
            "check": "strict_complete_fixed_scope_redirection",
            "passed": set(flow.from_layer.astype(str)) == {"strict_complete_thermophysical"}
                      and set(flow.to_layer.astype(str)) == {"strict_complete_evidence_bounded"},
            "detail": flow[["from_layer", "to_layer"]].drop_duplicates().to_dict("records"),
        },
        {
            "check": "corrosion_action_preserves_independent_burden",
            "passed": not scope[
                scope.closure_action.eq("exact_composition_corrosion_closure")
                & scope.field.eq("burden_index") & scope.changed
            ].shape[0],
            "detail": "No independent burden field changed by exact-composition corrosion closure.",
        },
        {
            "check": "research_nondominance_evidence_actions_only",
            "passed": set(research.loc[research.comparison_eligible, "closure_action"]).issubset(
                set(burden.loc[burden.action_type.isin(MAIN_ACTION_TYPES), "closure_action"])
            ),
            "detail": research.loc[research.comparison_eligible, ["closure_action", "action_type"]].to_dict("records"),
        },
        {
            "check": "nonzero_action_service_main_support",
            "passed": len(nonzero) > 0 and nonzero.delta_expected_normalized_service_value.abs().gt(1e-12).all(),
            "detail": int(len(nonzero)),
        },
        {
            "check": "gate_closure_depth_complete",
            "passed": depth.groupby("scenario").closed_gate_count.nunique().eq(7).all(),
            "detail": depth.groupby("scenario").closed_gate_count.nunique().to_dict(),
        },
        {
            "check": "failure_multiplicity_probability_closure",
            "passed": np.allclose(mult.groupby("scenario").frequency_within_scenario.sum(), 1.0),
            "detail": mult.groupby("scenario").frequency_within_scenario.sum().round(8).to_dict(),
        },
    ]
    for check in checks:
        check["passed"] = bool(check["passed"])
    status = "PASS" if all(c["passed"] for c in checks) else "FAIL"
    summary = {
        "status": status,
        "version": VERSION,
        "checks": checks,
        "redirection_routes": int(len(route)),
        "redirection_credibility_rows": int(len(cred)),
        "gate_intersections": int(len(inter)),
        "gate_closure_depth_rows": int(len(depth)),
        "nonzero_atomic_action_service_rows": int(len(nonzero)),
    }
    (QC / f"{VERSION}_EDITORIAL_SYNTHESIS_STATUS.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))
    if status != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
