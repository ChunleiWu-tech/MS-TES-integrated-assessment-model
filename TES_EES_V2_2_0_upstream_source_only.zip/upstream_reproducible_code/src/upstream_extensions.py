from __future__ import annotations

from pathlib import Path
import os
import io
import json
import re
import zipfile

import numpy as np
import pandas as pd
from decision_model import ATOMIC_DIMS


def _present(value) -> bool:
    if pd.isna(value):
        return False
    text = str(value).strip()
    return text not in {"", "----", "--------", "nan", "None"}


def _parse_float(value):
    if not _present(value):
        return np.nan
    text = str(value).replace(",", "")
    match = re.search(r"[-+]?\d*\.?\d+(?:[Ee][-+]?\d+)?", text)
    return float(match.group(0)) if match else np.nan


def _formula_components(formula: str) -> list[str]:
    return [x.strip() for x in str(formula).split("-") if x.strip()]


def _anion_family(formula: str) -> str:
    anions: set[str] = set()
    for comp in _formula_components(formula):
        if "NO3" in comp:
            anions.add("nitrate")
        if "NO2" in comp:
            anions.add("nitrite")
        if "CO3" in comp:
            anions.add("carbonate")
        # Chloride and fluoride tests intentionally follow the more specific oxyanion tests.
        if re.search(r"Cl(?:\d|$|\(|-)", comp) or comp.endswith("Cl"):
            anions.add("chloride")
        if re.search(r"F(?:\d|$|\(|-)", comp) or comp.endswith("F"):
            anions.add("fluoride")
    if not anions:
        return "other"
    return "–".join(sorted(anions))


def _normalise_by_draw(values: np.ndarray, feasible: np.ndarray, benefit: bool = True) -> np.ndarray:
    mask = feasible & np.isfinite(values)
    out = np.full(values.shape, np.nan, dtype=float)
    valid_rows = mask.any(axis=1)
    if valid_rows.any():
        masked = np.where(mask[valid_rows], values[valid_rows], np.nan)
        lo = np.nanmin(masked, axis=1, keepdims=True)
        hi = np.nanmax(masked, axis=1, keepdims=True)
        span = hi - lo
        local_mask = mask[valid_rows]
        local = np.full(masked.shape, np.nan, dtype=float)
        normal = local_mask & (span > 1e-12)
        constant = local_mask & (span <= 1e-12)
        np.divide(masked - lo, span, out=local, where=normal)
        local[constant] = 0.5
        out[valid_rows] = local
    if benefit:
        return out
    return np.where(mask, 1.0 - out, np.nan)


def _entropy(probabilities: np.ndarray) -> float:
    p = np.asarray(probabilities, dtype=float)
    p = p[np.isfinite(p) & (p > 0)]
    return float(-(p * np.log2(p)).sum()) if len(p) else 0.0


def _non_dominated_flags(df: pd.DataFrame, benefit_cols: list[str], ordered_cost_cols: list[str]) -> np.ndarray:
    if df.empty:
        return np.array([], dtype=bool)
    vals = df[benefit_cols + ordered_cost_cols].fillna(0.0).to_numpy(float)
    n_benefit = len(benefit_cols)
    keep = np.ones(len(df), dtype=bool)
    for i in range(len(df)):
        if not keep[i]:
            continue
        for j in range(len(df)):
            if i == j:
                continue
            weak_b = np.all(vals[j, :n_benefit] >= vals[i, :n_benefit] - 1e-12)
            weak_c = np.all(vals[j, n_benefit:] <= vals[i, n_benefit:] + 1e-12)
            strict = np.any(vals[j, :n_benefit] > vals[i, :n_benefit] + 1e-12) or np.any(
                vals[j, n_benefit:] < vals[i, n_benefit:] - 1e-12
            )
            if weak_b and weak_c and strict:
                keep[i] = False
                break
    return keep


def _load_raw_tp(raw_zip: Path) -> pd.DataFrame:
    with zipfile.ZipFile(raw_zip) as archive:
        target = next(x for x in archive.namelist() if x.endswith("Molten_Salt_Thermophysical_Properties.csv"))
        return pd.read_csv(io.BytesIO(archive.read(target)), dtype=str)


def _database_inventory(root: Path, version: str, out: Path, P: pd.DataFrame, S: pd.DataFrame) -> dict[str, pd.DataFrame]:
    raw = _load_raw_tp(root / "data" / "raw_databases" / "msd-tp-master.zip")
    prop_map = {
        "melting": ("melt", "melt_ref"),
        "density": ("rho_a", "rho_ref"),
        "viscosity": ("mu_a", "mu_ref"),
        "thermal_conductivity": ("k_a", "k_ref"),
        "heat_capacity": ("cp_a", "cp_ref"),
        "surface_tension": ("sigma_a", "sigma_ref"),
    }
    records = []
    for idx, row in raw.iterrows():
        melt_k = _parse_float(row.get("melt"))
        melt_c = melt_k - 273.15 if np.isfinite(melt_k) else np.nan
        family = _anion_family(row.get("formula", ""))
        flags = {name: _present(row.get(value_col)) for name, (value_col, _) in prop_map.items()}
        refs = {name: str(row.get(ref_col, "")) for name, (_, ref_col) in prop_map.items()}
        direct_count = sum(flags.values())
        records.append(
            {
                "record_id": idx + 1,
                "formula": row.get("formula", ""),
                "composition": row.get("comp", ""),
                "formula_family": family,
                "component_count": len(_formula_components(row.get("formula", ""))),
                "melting_temperature_raw_K": melt_k,
                "melting_temperature_C": melt_c,
                "property_count": direct_count,
                **{f"has_{name}": bool(flags[name]) for name in prop_map},
                **{f"{name}_reference": refs[name] for name in prop_map},
            }
        )
    inventory = pd.DataFrame(records)
    inventory.to_csv(out / f"{version}_raw_database_record_inventory.csv", index=False)

    formula_inventory = (
        inventory.groupby(["formula", "formula_family"], as_index=False)
        .agg(
            composition_records=("record_id", "size"),
            median_melting_temperature_C=("melting_temperature_C", "median"),
            max_property_count=("property_count", "max"),
            component_count=("component_count", "max"),
        )
        .sort_values(["formula_family", "formula"])
    )
    formula_inventory.to_csv(out / f"{version}_unique_formula_system_inventory.csv", index=False)

    coverage_rows = []
    for family, group in inventory.groupby("formula_family"):
        for prop in prop_map:
            count = int(group[f"has_{prop}"].sum())
            coverage_rows.append(
                {
                    "formula_family": family,
                    "property_field": prop,
                    "available_records": count,
                    "total_records": len(group),
                    "coverage_ratio": count / len(group) if len(group) else np.nan,
                    "unique_formula_systems": int(group.formula.nunique()),
                }
            )
    family_coverage = pd.DataFrame(coverage_rows)
    family_coverage.to_csv(out / f"{version}_family_property_coverage.csv", index=False)

    # Preliminary database screen. The workflow evaluates the melting/phase lower boundary
    # against each standardized application separately. This is deliberately not
    # called full service compatibility because MSD-TP does not provide a uniform
    # practical upper-temperature or corrosion field for every record.
    parsed = inventory.formula.astype(str).str.len().gt(0)
    tes_family = inventory.formula_family.ne("other")
    melt_available = inventory.has_melting
    freeze_margin_C = 20.0
    compatibility_rows = []
    compatible_record_ids: set[int] = set()
    for inv in inventory.itertuples(index=False):
        for service in S.itertuples(index=False):
            if not bool(inv.has_melting) or not np.isfinite(inv.melting_temperature_C):
                compatible = False
                rule = "melting temperature unavailable"
            elif service.service_mode == "sensible":
                compatible = bool(inv.melting_temperature_C + freeze_margin_C <= float(service.fixed_Tcold_C))
                rule = f"Tm + {freeze_margin_C:.0f} C freeze margin <= service cold boundary"
            else:
                compatible = bool(float(service.phase_target_min_C) <= inv.melting_temperature_C <= float(service.phase_target_max_C))
                rule = "melting/transition temperature within the application phase-target interval"
            if compatible:
                compatible_record_ids.add(int(inv.record_id))
            compatibility_rows.append(
                {
                    "record_id": int(inv.record_id),
                    "formula": inv.formula,
                    "composition": inv.composition,
                    "scenario": service.scenario,
                    "scenario_label": service.scenario_label,
                    "service_mode": service.service_mode,
                    "melting_temperature_C": inv.melting_temperature_C,
                    "lower_boundary_compatible": compatible,
                    "compatibility_rule": rule,
                    "scope_note": "melting/phase lower-bound screen only; upper stability, corrosion and cycling are not inferred",
                }
            )
    compatibility = pd.DataFrame(compatibility_rows)
    compatibility.to_csv(out / f"{version}_database_application_lower_bound_compatibility.csv", index=False)
    application_lower_bound = inventory.record_id.isin(compatible_record_ids)
    minimum_property = inventory.property_count.ge(3) & inventory.has_melting
    # Candidate-to-database linkage is audited explicitly and is not used to
    # imply that the curated engineering shortlist is an automatic subset of
    # the MSD-TP pre-screen.  Exact links require the same unordered component
    # set; partial links are reported only as context.
    inventory_component_sets = {
        formula: frozenset(_formula_components(formula))
        for formula in inventory.formula.dropna().astype(str).unique()
    }
    formula_record_counts = inventory.groupby("formula").size().to_dict()
    linkage_rows = []
    token_pattern = re.compile(r"(?:[A-Z][a-z]?\d*(?:\([A-Za-z0-9]+\)\d*)?)+")
    for row in P.itertuples():
        candidate_components = frozenset(token_pattern.findall(str(row.composition)))
        exact_formulas = sorted([f for f, comp in inventory_component_sets.items() if candidate_components and comp == candidate_components])
        best_formula = "none"
        best_overlap = 0.0
        best_intersection = 0
        for formula, comp in inventory_component_sets.items():
            if not candidate_components or not comp:
                continue
            intersection = len(candidate_components & comp)
            union = len(candidate_components | comp)
            score = intersection / union if union else 0.0
            if score > best_overlap or (np.isclose(score, best_overlap) and intersection > best_intersection):
                best_formula = formula
                best_overlap = score
                best_intersection = intersection
        exact_records = int(sum(formula_record_counts.get(f, 0) for f in exact_formulas))
        linkage_rows.append(
            {
                "system_id": row.system_id,
                "display_system": row.display_system,
                "candidate_components": ";".join(sorted(candidate_components)),
                "exact_formula_system_match": bool(exact_formulas),
                "exact_database_formulas": ";".join(exact_formulas) if exact_formulas else "none",
                "exact_database_record_count": exact_records,
                "best_partial_formula": best_formula,
                "best_component_set_jaccard": best_overlap,
                "best_component_intersection_count": best_intersection,
                "candidate_provenance_class": "database_formula_linked_plus_literature_curated" if exact_formulas else "literature_curated_no_exact_MSD_TP_formula_link",
                "linkage_interpretation": "Exact component-set link; composition and property values still require record-level comparison" if exact_formulas else "No exact MSD-TP formula-system link; candidate enters through the independent literature/evidence registry",
            }
        )
    linkage_df = pd.DataFrame(linkage_rows)
    linkage_df.to_csv(out / f"{version}_candidate_database_linkage_audit.csv", index=False)

    steps = [
        ("Raw MSD-TP composition records", len(inventory), "none"),
        ("Parsed formula records", int(parsed.sum()), "missing or unreadable formula"),
        ("TES-relevant nitrate/nitrite/carbonate/halide chemistry", int((parsed & tes_family).sum()), "other chemistry"),
        ("Melting temperature available", int((parsed & tes_family & melt_available).sum()), "missing melting temperature"),
        ("Application-specific melting/phase lower-bound compatibility", int((parsed & tes_family & application_lower_bound).sum()), "no standardized service passes the melting/phase lower-bound rule"),
        ("Minimum thermophysical coverage (melting + at least two fields)", int((parsed & tes_family & application_lower_bound & minimum_property).sum()), "insufficient thermophysical fields"),
    ]
    transition = []
    prev = steps[0][1]
    for i, (name, retained, reason) in enumerate(steps):
        transition.append(
            {
                "screen_order": i + 1,
                "screen_step": name,
                "retained_count": retained,
                "excluded_since_previous": 0 if i == 0 else max(prev - retained, 0),
                "dominant_exclusion_reason": reason,
                "screen_scope": "raw MSD-TP thermophysical pre-screen",
            }
        )
        prev = retained
    transition_df = pd.DataFrame(transition)
    transition_df.to_csv(out / f"{version}_database_to_shortlist_transition.csv", index=False)
    pd.DataFrame([
        {
            "registry_scope": "independent literature- and engineering-evidence candidate registry",
            "curated_candidate_count": int(len(P)),
            "exact_MSD_TP_formula_linked_candidates": int(linkage_df.exact_formula_system_match.sum()),
            "nonlinked_literature_curated_candidates": int((~linkage_df.exact_formula_system_match).sum()),
            "relationship_to_database_prescreen": "parallel evidence stream; not a seventh attrition step",
        }
    ]).to_csv(out / f"{version}_curated_candidate_registry_summary.csv", index=False)

    family_summary = (
        inventory.groupby("formula_family", as_index=False)
        .agg(raw_records=("record_id", "size"), unique_formula_systems=("formula", "nunique"), median_property_count=("property_count", "median"))
        .sort_values("raw_records", ascending=False)
    )
    family_summary.to_csv(out / f"{version}_database_family_summary.csv", index=False)
    pd.DataFrame(
        [
            {"policy_id": "DB01", "screen_step": "TES chemistry", "rule": "Retain nitrate, nitrite, carbonate, chloride, fluoride and mixed-anion records", "interpretation": "Chemistry pre-screen only; no readiness inference"},
            {"policy_id": "DB02", "screen_step": "Application-specific melting/phase lower boundary", "rule": "For sensible services require Tm + 20 C freeze margin <= service cold boundary; for latent services require Tm inside the phase-target interval", "interpretation": "Lower-bound compatibility only; practical upper temperature, corrosion and cycling are not inferred"},
            {"policy_id": "DB03", "screen_step": "Minimum thermophysical coverage", "rule": "Require melting plus at least two additional database fields", "interpretation": "Database completeness screen; corrosion and cycling remain absent"},
            {"policy_id": "DB04", "screen_step": "Independent curated candidate registry", "rule": "Audit candidate-to-MSD-TP formula links, while retaining literature and engineering evidence as a parallel provenance stream", "interpretation": "The curated candidate registry is not an attrition continuation of the MSD-TP record screen"},
        ]
    ).to_csv(out / f"{version}_database_screening_policy.csv", index=False)

    return {
        "inventory": inventory,
        "formula_inventory": formula_inventory,
        "family_coverage": family_coverage,
        "transition": transition_df,
        "family_summary": family_summary,
        "candidate_linkage": linkage_df,
        "application_lower_bound_compatibility": compatibility,
    }


def _partial_complete_outputs(version: str, out: Path, D: pd.DataFrame) -> None:
    p = D.copy()
    partial = p["partial_overlap_energy_fixed_kWh_m3"]
    complete = p["complete_service_energy_fixed_kWh_m3"]
    p["strict_value_retained_fraction_of_partial"] = np.where(partial > 0, complete.fillna(0) / partial, np.nan)
    p["partial_overlap_overclaim_fraction"] = np.where(partial > 0, 1.0 - p["strict_value_retained_fraction_of_partial"], np.nan)
    p["partial_minus_complete_kWh_m3"] = partial - complete.fillna(0)
    p[[
        "scenario", "scenario_label", "system_id", "display_system", "benchmark_system", "fixed_window_coverage",
        "partial_overlap_energy_fixed_kWh_m3", "complete_service_energy_fixed_kWh_m3",
        "strict_value_retained_fraction_of_partial", "partial_overlap_overclaim_fraction", "partial_minus_complete_kWh_m3"
    ]].to_csv(out / f"{version}_partial_vs_complete_service_penalty.csv", index=False)


def _switch_gate_outputs(version: str, out: Path, D: pd.DataFrame, DEC: pd.DataFrame, TRANS: pd.DataFrame, GATE: pd.DataFrame, MC: pd.DataFrame, COR: pd.DataFrame, VAL: pd.DataFrame, DRAWS: pd.DataFrame) -> None:
    trans = TRANS[TRANS.weight_prior.eq("balanced")].copy()
    trans["transition_class"] = np.select(
        [trans.to_system_id.astype(str).isin(["none", "__NO_SELECTION__"]), trans.from_system_id.astype(str).eq(trans.to_system_id.astype(str))],
        ["no_selection", "retained"],
        default="redirected",
    )
    switch = (
        trans.groupby(["scenario", "transition_class"], as_index=False)["transition_frequency"].sum()
        .pivot(index="scenario", columns="transition_class", values="transition_frequency")
        .fillna(0)
        .reset_index()
    )
    for col in ["retained", "redirected", "no_selection"]:
        if col not in switch:
            switch[col] = 0.0
    switch["decision_sensitivity_index"] = switch["redirected"] + switch["no_selection"]
    switch.to_csv(out / f"{version}_application_switch_sensitivity_summary.csv", index=False)

    rows = []
    for scenario, group in D.groupby("scenario"):
        registered = len(group)
        group_mc = group.merge(MC[["scenario", "system_id", "strict_complete_service_probability"]], on=["scenario", "system_id"], how="left")
        strict = int(group_mc.strict_complete_service_probability.fillna(0).gt(0).sum())
        atomic_gap_cols = ["gap_corrosion", "gap_cycling_phase", "gap_containment", "gap_literature_validation", "gap_data_completeness", "nonclosable_direct_risk"]
        evidence_eligible = int((group_mc.strict_complete_service_probability.fillna(0).gt(0) & ~group_mc[atomic_gap_cols].astype(bool).any(axis=1)).sum())
        observed = int((DEC.loc[DEC.scenario.eq(scenario), "evidence_qualified_selection_frequency"].fillna(0) > 0).sum())
        for order, (stage, count) in enumerate(
            [("Registered", registered), ("Strict complete-service", strict), ("Atomic engineering-gate eligible", evidence_eligible), ("Observed bounded selections", observed)],
            start=1,
        ):
            rows.append({"scenario": scenario, "stage_order": order, "gate_stage": stage, "retained_candidates": count})
    pd.DataFrame(rows).to_csv(out / f"{version}_gate_attrition_summary_extended.csv", index=False)

    # Multi-label failure accounting. Each candidate-draw can fail several gates.
    flag_map = {
        "incomplete_service": "failed_incomplete_service",
        "corrosion_gate": "failed_corrosion_gate",
        "cycling_phase_gate": "failed_cycling_phase_gate",
        "containment_gate": "failed_containment_gate",
        "validation_gate": "failed_validation_gate",
        "data_completeness_gate": "failed_data_completeness_gate",
    }
    required = set(flag_map.values()) | {"gate_failure_count"}
    missing = sorted(required - set(DRAWS.columns))
    if missing:
        raise ValueError(f"Draw-level gate flags missing: {missing}")
    family_map = D[["scenario", "system_id", "family"]].drop_duplicates()
    flagged = DRAWS.merge(family_map, on=["scenario", "system_id"], how="left")
    multi_rows = []
    for (scenario, system_id, display_system, family), group in flagged.groupby(["scenario", "system_id", "display_system", "family"], dropna=False):
        for gate, col in flag_map.items():
            fail = group[col].astype(bool).to_numpy()
            nfail = group.gate_failure_count.to_numpy(int)
            multi_rows.append({
                "scenario": scenario,
                "system_id": system_id,
                "display_system": display_system,
                "family": family,
                "gate_reason": gate,
                "observed_failure_frequency": float(np.mean(fail)),
                "standalone_marginal_unlock_frequency": float(np.mean(fail & (nfail == 1))),
                "overlapping_failure_frequency": float(np.mean(fail & (nfail > 1))),
                "candidate_draws": int(len(group)),
                "attribution_interpretation": "standalone marginal unlock is the share retained if this gate alone were removed; overlapping failures require joint closure",
            })
    multi = pd.DataFrame(multi_rows)
    multi.to_csv(out / f"{version}_gate_multilabel_failure_breakdown.csv", index=False)

    overlap = flagged.groupby(["scenario", "gate_failure_count"], as_index=False).size().rename(columns={"size": "candidate_draw_rows"})
    overlap["frequency_within_scenario"] = overlap.groupby("scenario").candidate_draw_rows.transform(lambda x: x / x.sum())
    overlap["failure_class"] = np.select(
        [overlap.gate_failure_count.eq(0), overlap.gate_failure_count.eq(1)],
        ["retained", "single_gate_failure"],
        default="multiple_simultaneous_failures",
    )
    overlap.to_csv(out / f"{version}_gate_overlap_summary.csv", index=False)

    family_attr = multi.groupby(["scenario", "family", "gate_reason"], as_index=False).agg(
        observed_failure_frequency=("observed_failure_frequency", "mean"),
        standalone_marginal_unlock_frequency=("standalone_marginal_unlock_frequency", "mean"),
        overlapping_failure_frequency=("overlapping_failure_frequency", "mean"),
        candidate_count=("system_id", "nunique"),
    )
    family_attr.to_csv(out / f"{version}_gate_marginal_unlock_attribution.csv", index=False)
    dominant_rows = []
    for (scenario, family), group in family_attr.groupby(["scenario", "family"], dropna=False):
        standalone = group.sort_values(["standalone_marginal_unlock_frequency", "observed_failure_frequency"], ascending=False).iloc[0]
        if standalone.standalone_marginal_unlock_frequency > 0:
            basis = "largest_standalone_marginal_unlock"
            chosen = standalone
        else:
            chosen = group.sort_values("observed_failure_frequency", ascending=False).iloc[0]
            basis = "interaction_only_highest_observed_failure"
        dominant_rows.append({
            "scenario": scenario,
            "family": family,
            "dominant_gate": chosen.gate_reason,
            "dominant_gate_frequency": float(chosen.standalone_marginal_unlock_frequency),
            "observed_failure_frequency": float(chosen.observed_failure_frequency),
            "overlapping_failure_frequency": float(chosen.overlapping_failure_frequency),
            "attribution_basis": basis,
        })
    pd.DataFrame(dominant_rows).to_csv(out / f"{version}_dominant_failure_mechanism_matrix.csv", index=False)

    mc_prob = MC[["scenario", "system_id", "strict_complete_service_probability"]]
    d2 = D.merge(mc_prob, on=["scenario", "system_id"], how="left")
    sweep = []
    thresholds = np.round(np.arange(0.25, 0.96, 0.05), 2)
    gap_cols = ["gap_corrosion", "gap_cycling_phase", "gap_containment", "gap_literature_validation", "gap_data_completeness", "nonclosable_direct_risk"]
    for scenario, group in d2.groupby("scenario"):
        atomic_mid = group[["corrosion_compatibility_score", "cycling_phase_stability_score", "containment_validation_score", "literature_replication_score", "data_completeness_score"]].clip(lower=1e-6)
        credibility_mid = np.exp(np.log(atomic_mid).mean(axis=1))
        for threshold in thresholds:
            keep = credibility_mid.ge(threshold) & ~group[gap_cols].astype(bool).any(axis=1)
            sweep.append({"scenario": scenario, "evidence_threshold": threshold, "threshold_semantics": "deterministic atomic engineering-credibility threshold after non-compensatory gates", "retained_candidate_count": int(keep.sum()), "mean_strict_complete_probability_of_retained": float(group.loc[keep, "strict_complete_service_probability"].mean()) if keep.any() else np.nan, "expected_strict_complete_candidate_count": float(group.loc[keep, "strict_complete_service_probability"].sum())})
    pd.DataFrame(sweep).to_csv(out / f"{version}_threshold_retention_sweep.csv", index=False)

def _scenario_arrays(scenario: str, DRAWS: pd.DataFrame, M: pd.DataFrame, D: pd.DataFrame, ATOMIC: pd.DataFrame):
    from decision_model import scenario_registry
    members = M[M.scenario == scenario].system_id.tolist()
    display = M[M.scenario == scenario].set_index("system_id").display_system.to_dict()
    sub = DRAWS[DRAWS.scenario == scenario]
    draw_ids = np.sort(sub.draw_id.unique())

    def pivot(value, fill=None, dtype=float):
        frame = sub.pivot(index="draw_id", columns="system_id", values=value).reindex(index=draw_ids, columns=members)
        if fill is not None:
            frame = frame.fillna(fill)
        return frame.to_numpy(dtype)

    energy_strict = pivot("complete_service_energy_density_kWh_m3")
    energy_screening = pivot("screening_energy_density_kWh_m3")
    energy_partial = pivot("partial_overlap_energy_density_kWh_m3")
    coverage = pivot("coverage")
    strict = pivot("strict_complete", False, bool)
    screening = pivot("screening_adequate_95pct", False, bool)
    scores = {
        "corrosion_compatibility": pivot("sampled_corrosion_compatibility"),
        "cycling_phase_stability": pivot("sampled_cycling_phase_stability"),
        "containment_validation": pivot("sampled_containment_validation"),
        "literature_replication": pivot("sampled_literature_replication"),
        "data_completeness": pivot("sampled_data_completeness"),
    }
    burden = pivot("sampled_engineering_burden_index")
    reg = scenario_registry(ATOMIC, scenario, members)
    return members, display, draw_ids, energy_strict, energy_screening, energy_partial, coverage, strict, screening, scores, burden, reg


def _selection_metrics(utility: np.ndarray, members: list[str], display: dict[str, str], benchmark: str) -> tuple[dict, np.ndarray, np.ndarray, np.ndarray]:
    no = np.all(~np.isfinite(utility), axis=1)
    winners = np.argmax(utility, axis=1)
    counts = np.array([np.mean((winners == j) & (~no)) for j in range(len(members))])
    order = np.argsort(-counts)
    leader_id = members[order[0]] if len(order) and counts[order[0]] > 0 else "__NO_SELECTION__"
    top1 = float(counts[order[0]]) if len(order) and counts[order[0]] > 0 else 0.0
    top2 = float(counts[order[1]]) if len(order) > 1 else 0.0
    probabilities = np.append(counts, np.mean(no))
    finite_count = np.isfinite(utility).sum(axis=1)
    sorted_u = np.sort(utility, axis=1)
    margin = np.full(len(no), np.nan)
    multi = finite_count >= 2
    margin[multi] = sorted_u[multi, -1] - sorted_u[multi, -2]
    benchmark_idx = next((j for j, m in enumerate(members) if display[m] == benchmark), None)
    leader_idx = next((j for j, m in enumerate(members) if m == leader_id), None)
    if benchmark_idx is not None and leader_idx is not None:
        comparable = np.isfinite(utility[:, benchmark_idx]) & np.isfinite(utility[:, leader_idx])
        surpass = float(np.mean(utility[comparable, leader_idx] > utility[comparable, benchmark_idx])) if comparable.any() else np.nan
    else:
        surpass = np.nan
    summary = {
        "modal_leader": leader_id,
        "modal_leader_label": display.get(leader_id, "No formal selection"),
        "modal_leader_frequency": top1,
        "no_selection_frequency": float(np.mean(no)),
        "selection_entropy": _entropy(probabilities),
        "top1_top2_frequency_gap": top1 - top2,
        "mean_top_two_utility_margin": float(np.nanmean(margin)) if np.isfinite(margin).any() else np.nan,
        "multiple_bounded_candidate_draw_frequency": float(np.mean(finite_count >= 2)),
        "single_bounded_candidate_draw_frequency": float(np.mean(finite_count == 1)),
        "no_bounded_candidate_draw_frequency": float(np.mean(finite_count == 0)),
        "leader_exceeds_benchmark_probability": surpass,
        "bounded_candidate_union_count": int(np.sum(counts > 1e-12)),
    }
    return summary, counts, no, winners


def _continuous_weight_scan(version: str, out: Path, M: pd.DataFrame, D: pd.DataFrame, DRAWS: pd.DataFrame, S: pd.DataFrame, ATOMIC: pd.DataFrame, seed: int) -> dict[str, pd.DataFrame]:
    from decision_model import baseline_allowed, credibility_score, normalise_by_draw
    scan_rows, region_rows, replicate_rows, anchor_rows = [], [], [], []
    n_random_weights = int(os.environ.get("TES_WEIGHT_VECTORS", "10000"))
    n_physical = int(os.environ.get("TES_PHYSICAL_DRAWS", "500"))
    n_replicates = int(os.environ.get("TES_WEIGHT_REPLICATES", "5"))
    anchors = np.array([[1.0, 0.0], [0.5, 0.5], [0.0, 1.0]], dtype=float)

    for service_index, service in S.reset_index(drop=True).iterrows():
        scenario = service.scenario
        members, display, draw_ids, energy_strict, _, _, _, strict, _, scores, burden, reg = _scenario_arrays(scenario, DRAWS, M, D, ATOMIC)
        allowed = baseline_allowed(reg)
        for replicate in range(1, n_replicates + 1):
            draw_rng = np.random.default_rng(seed + 830_000 + service_index * 10_000 + replicate * 977)
            physical_idx = np.sort(draw_rng.choice(len(draw_ids), size=min(n_physical, len(draw_ids)), replace=False))
            feasible = strict[physical_idx] & allowed[None, :]
            qscore = normalise_by_draw(energy_strict[physical_idx], feasible, benefit=True)
            score_sub = {k: v[physical_idx] for k, v in scores.items()}
            cred, _ = credibility_score(score_sub, burden[physical_idx], feasible, "hierarchical_geometric")
            weight_rng = np.random.default_rng(seed + 820_000 + service_index * 10_000 + replicate * 991)
            weights = weight_rng.dirichlet(np.ones(2), n_random_weights)
            counts_by_region = {m: 0 for m in members}; no_region = 0
            replicate_scan = []
            for batch_start in range(0, n_random_weights, 250):
                batch = weights[batch_start:batch_start + 250]
                utility = batch[:, None, [0]] * qscore[None, :, :] + batch[:, None, [1]] * cred[None, :, :]
                utility = np.where(feasible[None, :, :], utility, -np.inf)
                no = np.all(~np.isfinite(utility), axis=2)
                winners = np.argmax(utility, axis=2)
                for bi, w in enumerate(batch):
                    freq = np.array([np.mean((winners[bi] == j) & (~no[bi])) for j in range(len(members))])
                    no_freq = float(np.mean(no[bi]))
                    if freq.max(initial=0) <= 0:
                        leader = "__NO_SELECTION__"; no_region += 1; gap = 0.0
                    else:
                        order = np.argsort(-freq); leader = members[order[0]]; counts_by_region[leader] += 1
                        gap = float(freq[order[0]] - (freq[order[1]] if len(order) > 1 else 0.0))
                    row = {
                        "scenario": scenario, "physical_draw_replicate": replicate,
                        "weight_vector_id": batch_start + bi + 1, "weight_vector_type": "uniform_random",
                        "weight_performance": float(w[0]), "weight_engineering_credibility": float(w[1]),
                        "modal_selection": leader, "modal_selection_label": display.get(leader, "No formal selection"),
                        "modal_selection_frequency_across_physical_draws": float(freq.max(initial=0)),
                        "top1_top2_frequency_gap": gap, "no_selection_frequency": no_freq,
                        "selection_entropy": _entropy(np.append(freq, no_freq)), "physical_draws_per_weight": len(physical_idx),
                    }
                    if replicate == 1: scan_rows.append(row)
                    replicate_scan.append(row)
            shares = []
            for m, count in counts_by_region.items():
                share = count / n_random_weights; shares.append(share)
                region_rows.append({"scenario": scenario, "physical_draw_replicate": replicate, "system_id": m, "display_system": display[m], "decision_region_share": share, "random_weight_vectors": n_random_weights})
            no_share = no_region / n_random_weights; shares.append(no_share)
            region_rows.append({"scenario": scenario, "physical_draw_replicate": replicate, "system_id": "__NO_SELECTION__", "display_system": "No formal selection", "decision_region_share": no_share, "random_weight_vectors": n_random_weights})
            replicate_rows.append({
                "scenario": scenario, "physical_draw_replicate": replicate,
                "mean_no_selection_frequency": float(np.mean([x["no_selection_frequency"] for x in replicate_scan])),
                "mean_selection_entropy": float(np.mean([x["selection_entropy"] for x in replicate_scan])),
                "decision_region_entropy": _entropy(np.asarray(shares)), "largest_decision_region_share": float(max(shares)),
                "mean_top1_top2_frequency_gap": float(np.mean([x["top1_top2_frequency_gap"] for x in replicate_scan])),
                "distinct_modal_outcomes": int(np.sum(np.asarray(shares) > 0)), "random_weight_vectors": n_random_weights,
            })
            if replicate == 1:
                for ai, w in enumerate(anchors, start=1):
                    utility = w[0] * qscore + w[1] * cred
                    utility[~feasible] = -np.inf
                    met, freq, _, _ = _selection_metrics(utility, members, display, str(service.benchmark_system))
                    anchor_rows.append({"scenario": scenario, "anchor_id": ai, "weight_performance": w[0], "weight_engineering_credibility": w[1], **met})

    scan = pd.DataFrame(scan_rows); reps = pd.DataFrame(region_rows); risks = pd.DataFrame(replicate_rows); anchors_df = pd.DataFrame(anchor_rows)
    regions = reps.groupby(["scenario", "system_id", "display_system"], as_index=False).agg(
        decision_region_share=("decision_region_share", "mean"), decision_region_share_sd=("decision_region_share", "std"),
        decision_region_share_min=("decision_region_share", "min"), decision_region_share_max=("decision_region_share", "max"),
        physical_draw_replicates=("physical_draw_replicate", "nunique"), random_weight_vectors=("random_weight_vectors", "max"))
    risk = risks.groupby("scenario", as_index=False).agg(
        mean_no_selection_frequency=("mean_no_selection_frequency", "mean"), mean_no_selection_frequency_sd=("mean_no_selection_frequency", "std"),
        mean_selection_entropy=("mean_selection_entropy", "mean"), mean_selection_entropy_sd=("mean_selection_entropy", "std"),
        decision_region_entropy=("decision_region_entropy", "mean"), largest_decision_region_share=("largest_decision_region_share", "mean"),
        mean_top1_top2_frequency_gap=("mean_top1_top2_frequency_gap", "mean"), mean_top1_top2_frequency_gap_sd=("mean_top1_top2_frequency_gap", "std"),
        distinct_modal_outcomes=("distinct_modal_outcomes", "max"), physical_draw_replicates=("physical_draw_replicate", "nunique"), random_weight_vectors=("random_weight_vectors", "max"))
    scan.to_csv(out / f"{version}_continuous_weight_space_scan.csv", index=False)
    reps.to_csv(out / f"{version}_weight_space_region_replicates.csv", index=False)
    regions.to_csv(out / f"{version}_weight_space_decision_regions.csv", index=False)
    risks.to_csv(out / f"{version}_robustness_risk_replicates.csv", index=False)
    risk.to_csv(out / f"{version}_robustness_risk_summary.csv", index=False)
    anchors_df.to_csv(out / f"{version}_continuous_weight_anchor_results.csv", index=False)
    pd.DataFrame([{
        "sampling_distribution": "10,000 Dirichlet(1,1) random top-level performance-versus-credibility weights; anchors analysed separately",
        "uniform_random_weight_vectors_per_application": n_random_weights, "deterministic_anchor_vectors_per_application": len(anchors),
        "physical_draws_per_weight_vector": n_physical, "independent_physical_and_weight_replicates": n_replicates,
        "utility_hierarchy": "top level: performance vs engineering credibility; credibility: geometric mean of five atomic evidence dimensions plus inverse burden",
        "occupancy_denominator": "uniform random vectors only; deterministic anchors excluded",
        "interpretation": "Conditional decision-region occupancy, not an objective probability of material superiority",
    }]).to_csv(out / f"{version}_continuous_weight_scan_design.csv", index=False)
    return {"scan": scan, "regions": regions, "risk": risk, "region_replicates": reps, "risk_replicates": risks, "anchors": anchors_df}


def _candidate_count(version: str, out: Path, DRAWS: pd.DataFrame) -> pd.DataFrame:
    retained = DRAWS.assign(is_retained=DRAWS.gate_failure_count.eq(0))
    counts = retained.groupby(["scenario", "draw_id"], as_index=False).is_retained.sum().rename(columns={"is_retained": "bounded_candidate_count"})
    counts["bounded_candidate_class"] = pd.cut(counts.bounded_candidate_count, bins=[-0.5, 0.5, 1.5, np.inf], labels=["No bounded candidate", "Single bounded candidate", "Multiple bounded candidates"]).astype(str)
    counts.to_csv(out / f"{version}_bounded_candidate_count_by_draw.csv", index=False)
    summary = counts.groupby(["scenario", "bounded_candidate_class"], as_index=False).size().rename(columns={"size": "draws"})
    summary["frequency"] = summary.groupby("scenario").draws.transform(lambda x: x / x.sum())
    summary.to_csv(out / f"{version}_bounded_candidate_count_summary.csv", index=False)
    return summary


def _action_state(action: str, reg: pd.DataFrame, scores0: dict[str, np.ndarray], burden0: np.ndarray, strict: np.ndarray, screening: np.ndarray, energy_strict: np.ndarray, energy_screening: np.ndarray):
    gaps = {name: reg[col].astype(bool).to_numpy().copy() for name, col in zip(
        ["corrosion", "cycling_phase", "containment", "literature_validation", "data_completeness"],
        ["gap_corrosion", "gap_cycling_phase", "gap_containment", "gap_literature_validation", "gap_data_completeness"])}
    direct = reg.nonclosable_direct_risk.astype(bool).to_numpy()
    scores = {k: v.copy() for k, v in scores0.items()}; burden = burden0.copy()
    feasible = strict.copy(); energy = energy_strict.copy(); basis = "strict_complete_99.9pct"
    if action in {"service_redesign_95pct", "comprehensive_upper_bound"}:
        feasible = screening.copy(); energy = energy_screening.copy(); basis = "screening_adequate_95pct_partial_overlap"
    if action in {"property_measurement_precision_50pct", "comprehensive_upper_bound"}:
        for j in range(energy.shape[1]):
            valid = feasible[:, j] & np.isfinite(energy[:, j]); med = np.nanmedian(energy[valid, j]) if valid.any() else np.nan
            if np.isfinite(med): energy[valid, j] = med + 0.5 * (energy[valid, j] - med)
    if action in {"exact_composition_corrosion_closure", "combined_atomic_evidence_closure", "comprehensive_upper_bound"}:
        mask = gaps["corrosion"] & ~direct; gaps["corrosion"][mask] = False
        scores["corrosion_compatibility"][:, mask] = np.maximum(scores["corrosion_compatibility"][:, mask], 0.75)
    if action in {"pcm_cycling_phase_closure", "combined_atomic_evidence_closure", "comprehensive_upper_bound"}:
        mask = gaps["cycling_phase"]; gaps["cycling_phase"][mask] = False
        scores["cycling_phase_stability"][:, mask] = np.maximum(scores["cycling_phase_stability"][:, mask], 0.75)
    if action in {"containment_validation_closure", "combined_atomic_evidence_closure", "comprehensive_upper_bound"}:
        mask = gaps["containment"]; gaps["containment"][mask] = False
        scores["containment_validation"][:, mask] = np.maximum(scores["containment_validation"][:, mask], 0.75)
    if action in {"literature_replication_closure", "combined_atomic_evidence_closure", "comprehensive_upper_bound"}:
        mask = gaps["literature_validation"]; gaps["literature_validation"][mask] = False
        scores["literature_replication"][:, mask] = np.maximum(scores["literature_replication"][:, mask], 0.80)
    if action in {"data_completeness_closure", "combined_atomic_evidence_closure", "comprehensive_upper_bound"}:
        mask = gaps["data_completeness"]; gaps["data_completeness"][mask] = False
        scores["data_completeness"][:, mask] = np.maximum(scores["data_completeness"][:, mask], 0.75)
    unresolved = direct.copy()
    for arr in gaps.values(): unresolved |= arr
    allowed = ~unresolved
    if np.any(feasible & ~np.isfinite(energy)):
        raise ValueError(f"{action}: feasible action rows lack action-specific energy")
    return scores, burden, feasible, energy, allowed, basis, gaps, direct


def _evidence_closure(version: str, out: Path, M: pd.DataFrame, D: pd.DataFrame, DRAWS: pd.DataFrame, S: pd.DataFrame, ATOMIC: pd.DataFrame, seed: int):
    from decision_model import credibility_score, hierarchical_utility, normalise_by_draw
    actions = [
        "baseline", "property_measurement_precision_50pct", "service_redesign_95pct",
        "exact_composition_corrosion_closure", "pcm_cycling_phase_closure", "containment_validation_closure",
        "literature_replication_closure", "data_completeness_closure", "combined_atomic_evidence_closure", "comprehensive_upper_bound",
    ]
    summaries, selections, baseline_summary, baseline_selection = [], [], {}, {}
    scope_rows = []
    for service_index, service in S.reset_index(drop=True).iterrows():
        scenario = service.scenario
        members, display, draw_ids, es, esc, _, _, strict, screening, scores0, burden0, reg = _scenario_arrays(scenario, DRAWS, M, D, ATOMIC)
        rng = np.random.default_rng(seed + 910_000 + service_index * 10_000)
        weights = rng.dirichlet(np.ones(2), len(draw_ids))
        b_scores, b_burden, b_feasible, b_energy, b_allowed, b_basis, b_gaps, b_direct = _action_state("baseline", reg, scores0, burden0, strict, screening, es, esc)
        for action in actions:
            scores, burden, feasible, energy, allowed, basis, gaps, direct = _action_state(action, reg, scores0, burden0, strict, screening, es, esc)
            # Candidate-field action-scope audit. Scores and burden are summarized
            # over physical draws; gap flags and eligibility are candidate-level.
            for j, m in enumerate(members):
                fields = []
                for dim in ATOMIC_DIMS:
                    fields.append((dim, float(np.nanmean(b_scores[dim][:, j])), float(np.nanmean(scores[dim][:, j]))))
                fields.append(("burden_index", float(np.nanmean(b_burden[:, j])), float(np.nanmean(burden[:, j]))))
                fields.append(("eligible", float(bool(b_allowed[j])), float(bool(allowed[j]))))
                for gap_name in sorted(b_gaps):
                    fields.append((f"gap_{gap_name}", float(bool(b_gaps[gap_name][j])), float(bool(gaps[gap_name][j]))))
                for field, before, after in fields:
                    scope_rows.append({
                        "closure_action": action, "scenario": scenario, "system_id": m,
                        "display_system": display[m], "field": field, "before": before, "after": after,
                        "changed": bool(abs(after-before) > 1e-12),
                        "performance_basis_before": b_basis, "performance_basis_after": basis,
                    })
            decision_feasible = feasible & allowed[None, :]
            qscore = normalise_by_draw(energy, decision_feasible, True)
            cred, _ = credibility_score(scores, burden, decision_feasible, "hierarchical_geometric")
            utility = hierarchical_utility(qscore, cred, weights, decision_feasible)
            met, counts, _, _ = _selection_metrics(utility, members, display, str(service.benchmark_system))
            row = {"closure_action": action, "scenario": scenario, **met,
                   "performance_energy_basis": basis, "finite_action_energy_fraction_among_feasible": float(np.mean(np.isfinite(energy[feasible]))) if feasible.any() else np.nan,
                   "eligible_candidate_count_after_action": int(allowed.sum()), "mc_iterations": len(draw_ids)}
            summaries.append(row)
            if action == "baseline": baseline_summary[scenario] = row; baseline_selection[scenario] = {m: counts[j] for j, m in enumerate(members)}
            for j, m in enumerate(members):
                selections.append({"closure_action": action, "scenario": scenario, "system_id": m, "display_system": display[m],
                                   "selection_frequency": counts[j], "eligible_after_action": bool(allowed[j]), "performance_energy_basis": basis})
    summary_df = pd.DataFrame(summaries); selection_df = pd.DataFrame(selections)
    summary_df.to_csv(out / f"{version}_evidence_closure_counterfactuals.csv", index=False)
    selection_df.to_csv(out / f"{version}_counterfactual_selection_frequencies.csv", index=False)

    changes, candidate_changes = [], []
    for scenario in summary_df.scenario.unique():
        base = baseline_summary[scenario]
        bsel = selection_df[(selection_df.scenario == scenario) & (selection_df.closure_action == "baseline")].set_index("system_id")
        for row in summary_df[summary_df.scenario == scenario].itertuples(index=False):
            cur = selection_df[(selection_df.scenario == scenario) & (selection_df.closure_action == row.closure_action)].set_index("system_id")
            newly_eligible = int((cur.eligible_after_action & ~bsel.eligible_after_action).sum())
            lost_eligible = int((~cur.eligible_after_action & bsel.eligible_after_action).sum())
            newly_selected = int(((cur.selection_frequency >= 0.01) & ~(bsel.selection_frequency >= 0.01)).sum())
            lost_selected = int((~(cur.selection_frequency >= 0.01) & (bsel.selection_frequency >= 0.01)).sum())
            changes.append({
                "closure_action": row.closure_action, "scenario": scenario, "leader_before": base["modal_leader_label"], "leader_after": row.modal_leader_label,
                "leader_switched": row.modal_leader_label != base["modal_leader_label"],
                "delta_no_selection_frequency": base["no_selection_frequency"] - row.no_selection_frequency,
                "delta_selection_entropy": base["selection_entropy"] - row.selection_entropy,
                "delta_top1_top2_frequency_gap": row.top1_top2_frequency_gap - base["top1_top2_frequency_gap"],
                "delta_mean_top_two_utility_margin": row.mean_top_two_utility_margin - base["mean_top_two_utility_margin"] if np.isfinite(row.mean_top_two_utility_margin) and np.isfinite(base["mean_top_two_utility_margin"]) else np.nan,
                "delta_leader_exceeds_benchmark_probability": row.leader_exceeds_benchmark_probability - base["leader_exceeds_benchmark_probability"] if np.isfinite(row.leader_exceeds_benchmark_probability) and np.isfinite(base["leader_exceeds_benchmark_probability"]) else np.nan,
                "newly_eligible_candidate_count": newly_eligible, "lost_eligible_candidate_count": lost_eligible,
                "newly_selected_candidate_count": newly_selected, "lost_selected_candidate_count": lost_selected,
                "substantive_selection_threshold": 0.01,
                "net_selected_candidate_count_change": newly_selected - lost_selected,
            })
            for m in cur.index:
                candidate_changes.append({"closure_action": row.closure_action, "scenario": scenario, "system_id": m, "display_system": cur.loc[m, "display_system"],
                                          "eligible_before": bool(bsel.loc[m, "eligible_after_action"]), "eligible_after": bool(cur.loc[m, "eligible_after_action"]),
                                          "selection_frequency_before": float(bsel.loc[m, "selection_frequency"]), "selection_frequency_after": float(cur.loc[m, "selection_frequency"]),
                                          "delta_selection_frequency": float(cur.loc[m, "selection_frequency"] - bsel.loc[m, "selection_frequency"])})
    changes_df = pd.DataFrame(changes); changes_df.to_csv(out / f"{version}_counterfactual_selection_changes.csv", index=False)
    pd.DataFrame(candidate_changes).to_csv(out / f"{version}_counterfactual_candidate_signed_changes.csv", index=False)
    changes_df[["closure_action", "scenario", "delta_no_selection_frequency"]].to_csv(out / f"{version}_counterfactual_no_selection_reduction.csv", index=False)
    changes_df[["closure_action", "scenario", "delta_selection_entropy", "delta_top1_top2_frequency_gap", "delta_mean_top_two_utility_margin", "delta_leader_exceeds_benchmark_probability"]].to_csv(out / f"{version}_uncertainty_reduction_value.csv", index=False)
    action_desc = {
        "baseline": ("none", "Current atomic-gate hierarchical model"),
        "property_measurement_precision_50pct": ("Reduce within-candidate performance dispersion by 50%", "Prospective property-measurement precision counterfactual"),
        "service_redesign_95pct": ("Use labelled 95% service-adequacy boundary with action-specific partial-overlap energy", "Exploratory service-design counterfactual, not complete service"),
        "exact_composition_corrosion_closure": ("Close only corrosion gaps lacking exact-composition evidence; never override direct severe-risk evidence", "Atomic corrosion evidence counterfactual"),
        "pcm_cycling_phase_closure": ("Close only unresolved PCM cycling and phase-stability gaps", "Atomic PCM cycling counterfactual"),
        "containment_validation_closure": ("Close only containment-compatibility validation gaps", "Atomic containment counterfactual"),
        "literature_replication_closure": ("Close only independent-replication gaps", "Atomic external-validation counterfactual"),
        "data_completeness_closure": ("Close only missing thermophysical/transport data gaps", "Atomic data-completeness counterfactual"),
        "combined_atomic_evidence_closure": ("Close all favourable closable atomic evidence gaps while preserving direct-risk exclusions", "Combined evidence programme"),
        "comprehensive_upper_bound": ("Combined atomic closure plus 95% service redesign and 50% property precision", "Exploratory upper bound, not a forecast"),
    }
    pd.DataFrame([{"closure_action": k, "changed_assumption": v[0], "interpretation": v[1]} for k, v in action_desc.items()]).to_csv(out / f"{version}_counterfactual_assumption_registry.csv", index=False)
    scope_df = pd.DataFrame(scope_rows)
    scope_df.to_csv(out / f"{version}_counterfactual_action_scope_audit.csv", index=False)
    return summary_df, changes_df


def _service_coverage_threshold_sensitivity(version: str, out: Path, M: pd.DataFrame, D: pd.DataFrame, DRAWS: pd.DataFrame, S: pd.DataFrame, ATOMIC: pd.DataFrame, seed: int) -> pd.DataFrame:
    from decision_model import baseline_allowed, credibility_score, hierarchical_utility, normalise_by_draw
    thresholds = [0.95, 0.975, 0.99, 0.995, 0.999, 1.0]
    rows, selection_rows = [], []
    for service_index, service in S.reset_index(drop=True).iterrows():
        scenario = service.scenario
        members, display, draw_ids, _, _, ep, coverage, _, _, scores, burden, reg = _scenario_arrays(scenario, DRAWS, M, D, ATOMIC)
        allowed = baseline_allowed(reg)
        weights = np.random.default_rng(seed + 920_000 + service_index * 10_000).dirichlet(np.ones(2), len(draw_ids))
        for threshold in thresholds:
            feasible = coverage >= threshold; energy = np.where(feasible, ep, np.nan); decision_feasible = feasible & allowed[None, :]
            qscore = normalise_by_draw(energy, decision_feasible, True); cred, _ = credibility_score(scores, burden, decision_feasible, "hierarchical_geometric")
            utility = hierarchical_utility(qscore, cred, weights, decision_feasible)
            met, counts, _, _ = _selection_metrics(utility, members, display, str(service.benchmark_system))
            rows.append({"scenario": scenario, "coverage_threshold": threshold, "coverage_definition": "minimum fraction of standardized service available",
                         "performance_energy_basis": "partial-overlap energy only when threshold is met", **met, "mc_iterations": len(draw_ids)})
            for j, m in enumerate(members): selection_rows.append({"scenario": scenario, "coverage_threshold": threshold, "system_id": m, "display_system": display[m], "selection_frequency": counts[j]})
    summary = pd.DataFrame(rows); summary.to_csv(out / f"{version}_service_coverage_threshold_sensitivity.csv", index=False)
    pd.DataFrame(selection_rows).to_csv(out / f"{version}_service_coverage_threshold_selection_frequencies.csv", index=False)
    return summary


def _model_and_evidence_robustness(version: str, out: Path, M: pd.DataFrame, D: pd.DataFrame, DRAWS: pd.DataFrame, S: pd.DataFrame, ATOMIC: pd.DataFrame, APP: pd.DataFrame, seed: int) -> dict[str, pd.DataFrame]:
    from decision_model import CREDIBILITY_MODELS, baseline_allowed, credibility_score, deterministic_atomic_scores, hierarchical_utility, normalise_by_draw
    model_rows, perturb_rows, loo_rows, source_rows, conv_rows = [], [], [], [], []
    for si, service in S.reset_index(drop=True).iterrows():
        scenario = service.scenario
        members, display, draw_ids, es, _, _, _, strict, _, scores, burden, reg = _scenario_arrays(scenario, DRAWS, M, D, ATOMIC)
        checkpoints = [n for n in [500, 1000, 2000, 5000, 10000, 20000] if n <= len(draw_ids)]
        if len(draw_ids) not in checkpoints:
            checkpoints.append(len(draw_ids))
        checkpoints = sorted(set(checkpoints))
        allowed = baseline_allowed(reg); feasible = strict & allowed[None, :]; qscore = normalise_by_draw(es, feasible, True)
        # Common preference draws isolate aggregation-model effects from Monte
        # Carlo noise when comparing credibility formulations.
        common_model_weights = np.random.default_rng(seed + 930_000 + si * 10_000).dirichlet(np.ones(2), len(draw_ids))
        for mi, model in enumerate(CREDIBILITY_MODELS):
            cred, _ = credibility_score(scores, burden, feasible, model)
            met, _, _, _ = _selection_metrics(hierarchical_utility(qscore, cred, common_model_weights, feasible), members, display, str(service.benchmark_system))
            model_rows.append({"scenario": scenario, "credibility_model": model, "common_preference_draws": True, **met})
        for level in ["low", "mid", "high"]:
            ds = {dim: np.tile(reg[f"{dim}_{level}"].to_numpy(float), (len(draw_ids), 1)) for dim in ATOMIC_DIMS}
            db = np.tile(reg[f"burden_index_{'mid' if level == 'mid' else level}"].to_numpy(float), (len(draw_ids), 1))
            cred, _ = credibility_score(ds, db, feasible, "hierarchical_geometric")
            w = np.random.default_rng(seed + 940_000 + si * 10_000).dirichlet(np.ones(2), len(draw_ids))
            met, _, _, _ = _selection_metrics(hierarchical_utility(qscore, cred, w, feasible), members, display, str(service.benchmark_system))
            perturb_rows.append({"scenario": scenario, "atomic_evidence_level": level, **met})
        # Leave-one-candidate-out.
        cred0, _ = credibility_score(scores, burden, feasible, "hierarchical_geometric")
        base_w = np.random.default_rng(seed + 950_000 + si * 10_000).dirichlet(np.ones(2), len(draw_ids))
        base_met, _, _, _ = _selection_metrics(hierarchical_utility(qscore, cred0, base_w, feasible), members, display, str(service.benchmark_system))
        for j, m in enumerate(members):
            f2 = feasible.copy(); f2[:, j] = False; q2 = normalise_by_draw(es, f2, True); c2, _ = credibility_score(scores, burden, f2, "hierarchical_geometric")
            met, _, _, _ = _selection_metrics(hierarchical_utility(q2, c2, base_w, f2), members, display, str(service.benchmark_system))
            loo_rows.append({"scenario": scenario, "excluded_system_id": m, "excluded_display_system": display[m], "baseline_leader": base_met["modal_leader_label"], **met})
        # Leave-one-source-out conservative low-bound stress test.
        app = APP[APP.scenario.eq(scenario)].set_index("system_id").loc[members]
        sources = sorted({tok.strip() for x in app.source_ids.fillna("").astype(str) for tok in x.split(";") if tok.strip()})
        for source in sources:
            affected = np.array([source in [t.strip() for t in str(app.loc[m, "source_ids"]).split(";")] for m in members])
            ss = {k: v.copy() for k, v in scores.items()}
            for dim in ATOMIC_DIMS:
                low = reg[f"{dim}_low"].to_numpy(float)
                ss[dim][:, affected] = low[None, affected]
            cc, _ = credibility_score(ss, burden, feasible, "hierarchical_geometric")
            met, _, _, _ = _selection_metrics(hierarchical_utility(qscore, cc, base_w, feasible), members, display, str(service.benchmark_system))
            source_rows.append({"scenario": scenario, "omitted_source_id": source, "affected_candidate_count": int(affected.sum()),
                                "stress_method": "set affected candidates to declared atomic-evidence low bounds; candidate not automatically removed", **met})
        # Independent resampling/weight-seed convergence.
        for rep in range(1, 6):
            rr = np.random.default_rng(seed + 960_000 + si * 100_000 + rep * 1009)
            for n in checkpoints:
                idx = rr.choice(len(draw_ids), size=n, replace=True)
                f = feasible[idx]; q = normalise_by_draw(es[idx], f, True); sc = {k: v[idx] for k, v in scores.items()}; b = burden[idx]
                cr, _ = credibility_score(sc, b, f, "hierarchical_geometric"); w = rr.dirichlet(np.ones(2), n)
                met, counts, no, _ = _selection_metrics(hierarchical_utility(q, cr, w, f), members, display, str(service.benchmark_system))
                conv_rows.append({"scenario": scenario, "independent_seed_replicate": rep, "n_draws": n, **met})
    dfs = {
        "models": pd.DataFrame(model_rows), "perturb": pd.DataFrame(perturb_rows), "loo": pd.DataFrame(loo_rows),
        "sources": pd.DataFrame(source_rows), "convergence": pd.DataFrame(conv_rows),
    }
    dfs["models"].to_csv(out / f"{version}_credibility_model_sensitivity.csv", index=False)
    dfs["perturb"].to_csv(out / f"{version}_evidence_score_perturbation_sensitivity.csv", index=False)
    dfs["loo"].to_csv(out / f"{version}_leave_one_candidate_out_sensitivity.csv", index=False)
    dfs["sources"].to_csv(out / f"{version}_leave_one_source_out_sensitivity.csv", index=False)
    dfs["convergence"].to_csv(out / f"{version}_independent_seed_convergence.csv", index=False)
    return dfs


def _gate_shapley(version: str, out: Path, DRAWS: pd.DataFrame) -> dict[str, pd.DataFrame]:
    import itertools, math
    gates = [
        ("incomplete_service", "failed_incomplete_service"), ("corrosion", "failed_corrosion_gate"),
        ("cycling_phase", "failed_cycling_phase_gate"), ("containment", "failed_containment_gate"),
        ("literature_validation", "failed_validation_gate"), ("data_completeness", "failed_data_completeness_gate"),
    ]
    shapley_rows, joint_rows = [], []
    scenario_shapley = []
    for scenario, g in DRAWS.groupby("scenario"):
        flags = g[[c for _, c in gates]].astype(bool).to_numpy()
        masks = np.sum(flags * (1 << np.arange(len(gates))), axis=1).astype(int)
        counts = np.bincount(masks, minlength=1 << len(gates)).astype(float); probs = counts / counts.sum()
        def value(closed_mask: int) -> float:
            remaining = np.arange(1 << len(gates)) & (~closed_mask)
            return float(probs[remaining == 0].sum())
        for closed in range(1 << len(gates)):
            names = [gates[i][0] for i in range(len(gates)) if closed & (1 << i)]
            joint_rows.append({"scenario": scenario, "closed_gate_mask": closed, "closed_gates": ";".join(names) if names else "none", "retained_candidate_draw_frequency": value(closed)})
        for i, (name, _) in enumerate(gates):
            phi = 0.0
            others = [j for j in range(len(gates)) if j != i]
            for r in range(len(others) + 1):
                coef = math.factorial(r) * math.factorial(len(gates) - r - 1) / math.factorial(len(gates))
                for subset in itertools.combinations(others, r):
                    sm = sum(1 << j for j in subset)
                    phi += coef * (value(sm | (1 << i)) - value(sm))
            row = {"scope": "application", "scenario": scenario, "gate": name, "shapley_unlock_contribution": phi,
                   "baseline_retained_frequency": value(0), "all_gates_closed_frequency": value((1 << len(gates)) - 1)}
            shapley_rows.append(row); scenario_shapley.append(row)
    sh = pd.DataFrame(shapley_rows); equal = sh.groupby("gate", as_index=False).agg(shapley_unlock_contribution=("shapley_unlock_contribution", "mean"), baseline_retained_frequency=("baseline_retained_frequency", "mean"), all_gates_closed_frequency=("all_gates_closed_frequency", "mean"))
    equal.insert(0, "scenario", "APPLICATION_EQUAL"); equal.insert(0, "scope", "application_equal")
    sh = pd.concat([sh, equal], ignore_index=True)
    joint = pd.DataFrame(joint_rows)
    sh.to_csv(out / f"{version}_gate_shapley_attribution.csv", index=False); joint.to_csv(out / f"{version}_joint_gate_closure.csv", index=False)
    return {"shapley": sh, "joint": joint}


def _decision_redirection_consequences(version: str, out: Path, M: pd.DataFrame, DRAWS: pd.DataFrame, S: pd.DataFrame) -> dict[str, pd.DataFrame]:
    rows = []
    for service in S.itertuples(index=False):
        scenario = service.scenario; members = M[M.scenario.eq(scenario)].system_id.tolist(); sub = DRAWS[DRAWS.scenario.eq(scenario)]
        screen = sub.pivot(index="draw_id", columns="system_id", values="complete_service_energy_density_kWh_m3").reindex(columns=members).to_numpy(float)
        complete = sub.pivot(index="draw_id", columns="system_id", values="complete_service_energy_density_kWh_m3").reindex(columns=members).to_numpy(float)
        selected = sub.pivot(index="draw_id", columns="system_id", values="is_balanced_winner").reindex(columns=members).fillna(False).to_numpy(bool)
        thermo_no = np.all(~np.isfinite(screen), axis=1); thermo_idx = np.nanargmax(np.where(np.isfinite(screen), screen, -np.inf), axis=1)
        selected_no = ~selected.any(axis=1); selected_idx = np.argmax(selected, axis=1)
        for di in range(len(screen)):
            if thermo_no[di]: cls = "no_thermophysical_option"
            elif selected_no[di]: cls = "no_bounded_selection"
            elif thermo_idx[di] == selected_idx[di]: cls = "retained"
            else: cls = "redirected"
            te = screen[di, thermo_idx[di]] if not thermo_no[di] else np.nan
            se = complete[di, selected_idx[di]] if not selected_no[di] else np.nan
            rows.append({"scenario": scenario, "draw_id": di + 1, "transition_class": cls,
                         "thermophysical_system_id": members[thermo_idx[di]] if not thermo_no[di] else "none",
                         "selected_system_id": members[selected_idx[di]] if not selected_no[di] else "none",
                         "thermophysical_energy_density_kWh_m3": te, "selected_energy_density_kWh_m3": se,
                         "selected_to_thermophysical_energy_ratio": se / te if np.isfinite(se) and np.isfinite(te) and te > 0 else np.nan,
                         "additional_volume_m3_per_MWhth": 1000.0 / se - 1000.0 / te if np.isfinite(se) and np.isfinite(te) and se > 0 and te > 0 else np.nan})
    detail = pd.DataFrame(rows); detail.to_csv(out / f"{version}_decision_redirection_draw_consequences.csv", index=False)
    summary_rows = []
    for scenario, g in detail.groupby("scenario"):
        total = len(g)
        for cls, gg in g.groupby("transition_class"):
            summary_rows.append({"scenario": scenario, "transition_class": cls, "frequency": len(gg) / total,
                                 "energy_ratio_p05": gg.selected_to_thermophysical_energy_ratio.quantile(.05), "energy_ratio_p50": gg.selected_to_thermophysical_energy_ratio.quantile(.50), "energy_ratio_p95": gg.selected_to_thermophysical_energy_ratio.quantile(.95),
                                 "additional_volume_p05_m3_MWh": gg.additional_volume_m3_per_MWhth.quantile(.05), "additional_volume_p50_m3_MWh": gg.additional_volume_m3_per_MWhth.quantile(.50), "additional_volume_p95_m3_MWh": gg.additional_volume_m3_per_MWhth.quantile(.95)})
    summary = pd.DataFrame(summary_rows); summary.to_csv(out / f"{version}_decision_redirection_system_consequences.csv", index=False)
    return {"detail": detail, "summary": summary}


def _research_portfolio(version: str, out: Path, changes: pd.DataFrame) -> pd.DataFrame:
    burden_rows = [
        ("property_measurement_precision_50pct", "targeted thermophysical measurement", 1.5, "low_to_moderate", "measurement_programme"),
        ("service_redesign_95pct", "application service-boundary redesign", 1.0, "low", "engineering_redesign"),
        ("exact_composition_corrosion_closure", "exact-composition long-duration corrosion evidence", 3.5, "high", "evidence_acquisition"),
        ("pcm_cycling_phase_closure", "repeated cycling and phase-separation evidence", 3.5, "high", "evidence_acquisition"),
        ("containment_validation_closure", "container/alloy compatibility validation", 3.0, "moderate_to_high", "evidence_acquisition"),
        ("literature_replication_closure", "independent replication", 2.5, "moderate", "evidence_acquisition"),
        ("data_completeness_closure", "missing transport/property measurements", 2.0, "moderate", "evidence_acquisition"),
        ("combined_atomic_evidence_closure", "coordinated atomic evidence programme", 4.5, "very_high", "evidence_programme"),
        ("comprehensive_upper_bound", "evidence, service and precision programme", 5.0, "very_high", "diagnostic_upper_bound"),
    ]
    burden = pd.DataFrame(
        burden_rows,
        columns=["closure_action", "evidence_action", "burden_ordinal_index", "burden_level", "action_type"],
    )
    burden["burden_semantics"] = (
        "pre-registered ordinal planning index; values encode order only and are not cost, duration, "
        "resource quantity or probability of success"
    )
    burden.to_csv(out / f"{version}_action_classification_and_burden_registry.csv", index=False)

    ch = changes[changes.closure_action.ne("baseline")].copy()
    ch["any_adverse_outcome"] = (
        ch.delta_no_selection_frequency.lt(-1e-9)
        | ch.delta_selection_entropy.lt(-1e-9)
        | ch.delta_top1_top2_frequency_gap.lt(-1e-9)
        | ch.delta_mean_top_two_utility_margin.fillna(0).lt(-1e-9)
        | ch.delta_leader_exceeds_benchmark_probability.fillna(0).lt(-1e-9)
        | ch.lost_eligible_candidate_count.gt(0)
        | ch.lost_selected_candidate_count.gt(0)
    )
    action = ch.groupby("closure_action", as_index=False).agg(
        mean_no_selection_reduction=("delta_no_selection_frequency", "mean"),
        mean_entropy_reduction=("delta_selection_entropy", "mean"),
        mean_top_gap_improvement=("delta_top1_top2_frequency_gap", "mean"),
        mean_utility_margin_improvement=("delta_mean_top_two_utility_margin", "mean"),
        mean_benchmark_surpass_improvement=("delta_leader_exceeds_benchmark_probability", "mean"),
        applications_with_no_selection_reduction=("delta_no_selection_frequency", lambda x: int((np.asarray(x) > 1e-6).sum())),
        applications_with_any_adverse=("any_adverse_outcome", "sum"),
        applications_evaluated=("scenario", "nunique"),
        total_newly_eligible_candidates=("newly_eligible_candidate_count", "sum"),
        total_lost_eligible_candidates=("lost_eligible_candidate_count", "sum"),
        total_newly_selected_candidates=("newly_selected_candidate_count", "sum"),
        total_lost_selected_candidates=("lost_selected_candidate_count", "sum"),
    ).merge(burden, on="closure_action", how="left")
    action["adverse_application_fraction"] = action.applications_with_any_adverse / action.applications_evaluated.clip(lower=1)
    action["largest_positive_decision_benefit"] = action[
        ["mean_no_selection_reduction", "mean_entropy_reduction", "mean_top_gap_improvement", "mean_benchmark_surpass_improvement"]
    ].fillna(0).clip(lower=0).max(axis=1)
    action["comparison_eligible"] = action.action_type.isin(["evidence_acquisition", "evidence_programme"]) & (
        (action.largest_positive_decision_benefit > 1e-4)
        | action.total_newly_eligible_candidates.gt(0)
        | action.total_newly_selected_candidates.gt(0)
    )
    action["non_dominated_under_registered_ordering"] = False
    idx = action.index[action.comparison_eligible]
    if len(idx):
        action.loc[idx, "non_dominated_under_registered_ordering"] = _non_dominated_flags(
            action.loc[idx],
            [
                "mean_no_selection_reduction",
                "mean_entropy_reduction",
                "mean_top_gap_improvement",
                "mean_benchmark_surpass_improvement",
                "total_newly_eligible_candidates",
            ],
            ["burden_ordinal_index", "adverse_application_fraction"],
        )
    action["dominance_rule"] = (
        "weak dominance over the registered action set: no lower value on any benefit criterion, no higher "
        "ordinal burden level or adverse-application fraction, and strict improvement on at least one criterion"
    )
    action["interpretation_boundary"] = (
        "non-dominated under the registered criteria and ordinal burden ordering; not Pareto efficiency on a "
        "cardinal cost, time or resource axis"
    )
    action.to_csv(out / f"{version}_research_action_nondominance_assessment.csv", index=False)
    action[action.action_type.isin(["engineering_redesign", "measurement_programme"])].to_csv(
        out / f"{version}_engineering_and_measurement_sensitivities.csv", index=False
    )
    action[action.action_type.eq("diagnostic_upper_bound")].to_csv(
        out / f"{version}_diagnostic_upper_bound_summary.csv", index=False
    )
    return action


def _evidence_score_audit_tables(
    version: str,
    out: Path,
    deterministic: pd.DataFrame,
    draws: pd.DataFrame,
    atomic: pd.DataFrame,
    application: pd.DataFrame,
) -> dict[str, pd.DataFrame]:
    """Export the exact evidence-score rules and candidate-service numerical ledger.

    The tables are disclosure outputs only. They reproduce the implemented model and do not
    alter eligibility, Monte Carlo draws, utilities or selections.
    """
    rule_rows = [
        {
            "order": 0,
            "symbol": "G",
            "component": "hard eligibility and complete-service qualification",
            "input_fields": "strict_complete_service_feasible|gap_corrosion|gap_cycling_phase|gap_containment|gap_literature_validation|gap_data_completeness|nonclosable_direct_risk",
            "scale": "binary qualification before continuous scoring",
            "sampling_rule": "candidate-service pair is eligible only when strict complete service is satisfied and no registered required gap or non-closable direct risk is present",
            "decision_role": "non-compensatory gate applied before normalization, credibility aggregation and ranking",
            "closure_floor": np.nan,
            "interpretation_boundary": "continuous evidence scores cannot compensate for a failed required criterion",
            "mapping_policy": "not applicable; this row records binary preconditions",
        },
        {
            "order": 1,
            "symbol": "c",
            "component": "corrosion compatibility",
            "input_fields": "corrosion_compatibility_low|mid|high",
            "scale": "0 to 1 bounded source-assessment index",
            "sampling_rule": "triangular(low, mode, high), clipped to [1e-6, 1]",
            "decision_role": "score component after non-compensatory corrosion qualification",
            "closure_floor": 0.75,
            "interpretation_boundary": "structured evidence adequacy, not corrosion rate or failure probability",
            "mapping_policy": "candidate-duty-specific low, modal and high values are disclosed in the Supplementary Data interval ledger; no universal high/medium/low numerical mapping is used",
        },
        {
            "order": 2,
            "symbol": "y",
            "component": "cycling or phase stability",
            "input_fields": "cycling_phase_stability_low|mid|high",
            "scale": "0 to 1 bounded source-assessment index",
            "sampling_rule": "triangular(low, mode, high), clipped to [1e-6, 1]",
            "decision_role": "score component after non-compensatory cycling/phase qualification",
            "closure_floor": 0.75,
            "interpretation_boundary": "structured evidence adequacy, not degradation rate or lifetime probability",
            "mapping_policy": "candidate-duty-specific low, modal and high values are disclosed in the Supplementary Data interval ledger; no universal high/medium/low numerical mapping is used",
        },
        {
            "order": 3,
            "symbol": "t",
            "component": "containment compatibility",
            "input_fields": "containment_validation_low|mid|high",
            "scale": "0 to 1 bounded source-assessment index",
            "sampling_rule": "triangular(low, mode, high), clipped to [1e-6, 1]",
            "decision_role": "score component after non-compensatory containment qualification",
            "closure_floor": 0.75,
            "interpretation_boundary": "structured validation adequacy, not alloy lifetime or installed-system reliability",
            "mapping_policy": "candidate-duty-specific low, modal and high values are disclosed in the Supplementary Data interval ledger; no universal high/medium/low numerical mapping is used",
        },
        {
            "order": 4,
            "symbol": "r",
            "component": "independent replication",
            "input_fields": "literature_replication_low|mid|high",
            "scale": "0 to 1 bounded source-assessment index",
            "sampling_rule": "triangular(low, mode, high), clipped to [1e-6, 1]",
            "decision_role": "score component after non-compensatory replication qualification",
            "closure_floor": 0.80,
            "interpretation_boundary": "source independence and applicability, not a bibliometric score",
            "mapping_policy": "candidate-duty-specific low, modal and high values are disclosed in the Supplementary Data interval ledger; no universal high/medium/low numerical mapping is used",
        },
        {
            "order": 5,
            "symbol": "d",
            "component": "data completeness",
            "input_fields": "data_completeness_low|mid|high",
            "scale": "0 to 1 bounded source-assessment index",
            "sampling_rule": "triangular(low, mode, high), clipped to [1e-6, 1]",
            "decision_role": "score component after non-compensatory data-completeness qualification",
            "closure_floor": 0.75,
            "interpretation_boundary": "coverage of required model inputs, not overall knowledge completeness",
            "mapping_policy": "candidate-duty-specific low, modal and high values are disclosed in the Supplementary Data interval ledger; no universal high/medium/low numerical mapping is used",
        },
        {
            "order": 6,
            "symbol": "b",
            "component": "candidate-specific experimental burden",
            "input_fields": "burden_index_low|mid|high",
            "scale": "positive structured planning index",
            "sampling_rule": "triangular(low, mode, high); fixed transform 1/(1+b/2)",
            "decision_role": "candidate-specific burden component of engineering credibility",
            "closure_floor": np.nan,
            "interpretation_boundary": "sensitivity index; separate from action-program ordering and from cost or duration",
            "mapping_policy": "candidate-service-specific low, modal and high burden inputs; not a universal experimental-cost conversion",
        },
        {
            "order": 7,
            "symbol": "b*",
            "component": "inverse burden",
            "input_fields": "derived from sampled burden among evidence-qualified complete-window candidates",
            "scale": "0 to 1 fixed candidate-independent transform",
            "sampling_rule": "b* = 1/(1+b/2), where BURDEN_HALF_VALUE=2 in decision_model.py",
            "decision_role": "sixth equal-weight component of engineering credibility",
            "closure_floor": np.nan,
            "interpretation_boundary": "assessment transform with an analyst-specified anchor; not cost, duration or a measured probability",
            "mapping_policy": "same transform in every candidate and draw; no competitor-dependent normalization",
        },
        {
            "order": 8,
            "symbol": "C",
            "component": "engineering credibility",
            "input_fields": "c|y|t|r|d|b*",
            "scale": "0 to 1",
            "sampling_rule": "(c*y*t*r*d*b*)^(1/6) for complete-window, evidence-qualified candidates",
            "decision_role": "top-level credibility branch combined with normalized performance",
            "closure_floor": np.nan,
            "interpretation_boundary": "model score conditional on registered rules; not empirical reliability or deployment probability",
            "mapping_policy": "derived exactly from the six disclosed components using equal exponents of 1/6",
        },
        {
            "order": 9,
            "symbol": "P",
            "component": "within-draw performance normalization",
            "input_fields": "complete_service_energy_density_kWh_m3 among eligible candidates",
            "scale": "0 to 1 benefit scale",
            "sampling_rule": "P=(q-min(q))/(max(q)-min(q)) over eligible finite candidates in the same duty and draw; P=0.5 if span<1e-12; otherwise ineligible P is undefined",
            "decision_role": "performance branch of utility after hard qualification",
            "closure_floor": np.nan,
            "interpretation_boundary": "relative to the eligible comparison set; not absolute material efficiency",
            "mapping_policy": "decision_model.normalise_by_draw; comparator-independent normalization is a separate sensitivity",
        },
        {
            "order": 10,
            "symbol": "U",
            "component": "top-level decision utility",
            "input_fields": "normalized_performance_score|engineering_credibility|performance_weight|credibility_weight",
            "scale": "relative ranking utility among eligible candidates within a draw",
            "sampling_rule": "U = w_P*P + w_C*C, with w_P + w_C = 1; ineligible candidates are assigned -infinity",
            "decision_role": "ranks only strict-complete, evidence-qualified candidates after all hard gates",
            "closure_floor": np.nan,
            "interpretation_boundary": "preference-weighted decision utility, not an empirical probability or universal technology score",
            "mapping_policy": "derived from disclosed draw-level performance normalization, credibility and registered preference weights",
        },
    ]
    rules = pd.DataFrame(rule_rows).sort_values("order")
    rules.to_csv(out / f"{version}_evidence_score_rule_registry.csv", index=False)
    rules.to_csv(out / f"{version}_Supplementary_Table_7_Evidence_Scoring_Rubric.csv", index=False)

    strict = deterministic[["scenario", "system_id", "strict_complete_service_feasible"]].drop_duplicates()
    app_cols = [
        "scenario", "system_id", "application_claim_class", "application_evidence_score",
        "application_evidence_basis", "source_ids",
    ]
    ledger = atomic.merge(strict, on=["scenario", "system_id"], how="left", validate="one_to_one").merge(
        application[app_cols], on=["scenario", "system_id"], how="left", validate="one_to_one", suffixes=("_atomic", "_application")
    )
    dims = [
        "corrosion_compatibility", "cycling_phase_stability", "containment_validation",
        "literature_replication", "data_completeness",
    ]
    mid = ledger[[f"{d}_mid" for d in dims]].clip(lower=1e-6, upper=1.0).to_numpy(float)
    ledger["atomic_evidence_geometric_mid"] = np.exp(np.mean(np.log(mid), axis=1))
    gap_cols = ["gap_corrosion", "gap_cycling_phase", "gap_containment", "gap_literature_validation", "gap_data_completeness"]
    ledger["baseline_evidence_qualified"] = ~(
        ledger[gap_cols].astype(bool).any(axis=1) | ledger["nonclosable_direct_risk"].astype(bool)
    )
    ledger["modal_decision_feasible"] = ledger["strict_complete_service_feasible"].fillna(False).astype(bool) & ledger["baseline_evidence_qualified"]
    from decision_model import fixed_inverse_burden_value
    ledger["inverse_burden_mid_fixed_anchor"] = np.nan
    ledger["engineering_credibility_mid"] = np.nan
    for scenario, idx in ledger.groupby("scenario").groups.items():
        rows = ledger.loc[idx]
        feasible = rows["modal_decision_feasible"].to_numpy(bool)
        if not feasible.any():
            continue
        b = rows["burden_index_mid"].to_numpy(float)
        inv = fixed_inverse_burden_value(b, feasible)
        ledger.loc[idx, "inverse_burden_mid_fixed_anchor"] = inv
        comp = rows[[f"{d}_mid" for d in dims]].clip(lower=1e-6, upper=1.0).to_numpy(float)
        cred = np.full(len(rows), np.nan)
        cred[feasible] = np.exp(np.mean(np.log(np.clip(np.column_stack([comp[feasible], inv[feasible]]), 1e-6, 1.0)), axis=1))
        ledger.loc[idx, "engineering_credibility_mid"] = cred
    ledger["score_equation_id"] = "C_GEOM6_FIXED_BURDEN_ANCHOR_2"
    ledger["score_scope_note"] = (
        "modal disclosure calculation; operational Monte Carlo score is recomputed in every draw after complete-window and evidence qualification"
    )
    order_cols = [
        "scenario", "scenario_label", "system_id", "display_system",
        *sum(([f"{d}_low", f"{d}_mid", f"{d}_high"] for d in dims), []),
        "burden_index_low", "burden_index_mid", "burden_index_high",
        "atomic_evidence_geometric_mid", "strict_complete_service_feasible", "baseline_evidence_qualified",
        "modal_decision_feasible", "inverse_burden_mid_fixed_anchor", "engineering_credibility_mid",
        *gap_cols, "nonclosable_direct_risk", "application_claim_class", "application_evidence_score",
        "atomic_evidence_basis", "application_evidence_basis", "source_ids_atomic", "source_ids_application",
        "score_equation_id", "score_scope_note",
    ]
    ledger = ledger[order_cols].sort_values(["scenario", "system_id"])
    ledger.to_csv(out / f"{version}_candidate_service_evidence_score_ledger.csv", index=False)
    ledger.to_csv(out / f"{version}_Supplementary_Table_8_Atomic_Evidence_Registry.csv", index=False)

    group_keys = ["scenario", "scenario_label", "system_id", "display_system"]
    if draws[group_keys].isna().any().any():
        missing = draws[group_keys].isna().sum().to_dict()
        raise RuntimeError(f"Missing grouping labels in draw-level evidence audit: {missing}")

    # ``observed=True`` is release-critical when the caller supplies categorical
    # dtypes.  Without it, pandas 2.2.x materialises the Cartesian product of all
    # category levels although only the registered candidate-service groups are
    # observed, which can trigger a Cartesian-product insertion failure.
    grouped = draws.groupby(
        group_keys, as_index=False, sort=False, observed=True, dropna=False
    )
    draw_summary = grouped.agg(
        monte_carlo_rows=("draw_id", "size"),
        credibility_defined_draws=("sampled_engineering_credibility", lambda x: int(np.isfinite(np.asarray(x, float)).sum())),
        credibility_p05=("sampled_engineering_credibility", lambda x: float(np.nanpercentile(x, 5)) if np.isfinite(np.asarray(x, float)).any() else np.nan),
        credibility_p50=("sampled_engineering_credibility", lambda x: float(np.nanpercentile(x, 50)) if np.isfinite(np.asarray(x, float)).any() else np.nan),
        credibility_p95=("sampled_engineering_credibility", lambda x: float(np.nanpercentile(x, 95)) if np.isfinite(np.asarray(x, float)).any() else np.nan),
        credibility_mean=("sampled_engineering_credibility", "mean"),
    )

    observed_groups = draws[group_keys].drop_duplicates().shape[0]
    if len(draw_summary) != observed_groups:
        raise RuntimeError(
            f"Evidence-score group-count mismatch: summary={len(draw_summary)}, "
            f"observed={observed_groups}"
        )
    if int(draw_summary["monte_carlo_rows"].sum()) != len(draws):
        raise RuntimeError(
            "Evidence-score row conservation failed: grouped rows do not equal "
            f"draw-table rows ({int(draw_summary['monte_carlo_rows'].sum())} != {len(draws)})"
        )
    duplicate_draws = grouped["draw_id"].agg(
        monte_carlo_rows="size", unique_draw_ids="nunique"
    )
    if not duplicate_draws["monte_carlo_rows"].eq(duplicate_draws["unique_draw_ids"]).all():
        bad = duplicate_draws.loc[
            ~duplicate_draws["monte_carlo_rows"].eq(duplicate_draws["unique_draw_ids"])
        ].head(10).to_dict("records")
        raise RuntimeError(f"Duplicate draw IDs within candidate-service groups: {bad}")
    draw_summary["source_table"] = f"{version}_monte_carlo_draws_balanced.csv"
    draw_summary["interpretation_boundary"] = (
        "summary of implemented draw-level engineering credibility; undefined values identify candidates excluded before scoring"
    )
    draw_summary.to_csv(out / f"{version}_candidate_service_evidence_score_draw_summary.csv", index=False)
    return {"rules": rules, "ledger": ledger, "draw_summary": draw_summary}


def _figure_ready_outputs(version: str, out: Path, TRANS: pd.DataFrame, DRAWS: pd.DataFrame, changes: pd.DataFrame, portfolio: pd.DataFrame) -> dict[str, pd.DataFrame]:
    alluvial = TRANS[TRANS.weight_prior.eq("balanced")].copy()
    alluvial["transition_class"] = np.select([alluvial.to_system_id.astype(str).isin(["none", "__NO_SELECTION__"]), alluvial.from_system_id.astype(str).eq(alluvial.to_system_id.astype(str))], ["no_selection", "retained"], default="redirected")
    alluvial.to_csv(out / f"{version}_figure_selection_alluvial_flows.csv", index=False)
    flag_map = {"Incomplete service": "failed_incomplete_service", "Corrosion": "failed_corrosion_gate", "Cycling/phase": "failed_cycling_phase_gate", "Containment": "failed_containment_gate", "Literature validation": "failed_validation_gate", "Data completeness": "failed_data_completeness_gate"}
    rows = []
    for scenario, g in DRAWS.groupby("scenario"):
        active = []
        for label, col in flag_map.items():
            pass
        combo = g[list(flag_map.values())].astype(bool).apply(lambda r: tuple(label for label, col in flag_map.items() if bool(r[col])), axis=1)
        vc = combo.value_counts(); total = len(g)
        for pattern, count in vc.items():
            rows.append({"scenario": scenario, "gate_pattern": ";".join(pattern) if pattern else "Retained", "candidate_draw_rows": int(count), "frequency_within_scope": count / total, **{label: label in pattern for label in flag_map}, "Retained": not pattern})
    intersections = pd.DataFrame(rows); intersections.to_csv(out / f"{version}_figure_gate_intersection_summary.csv", index=False)
    actions = changes[changes.closure_action.ne("baseline")]
    summary = actions.groupby("closure_action", as_index=False).agg(mean_no_selection_reduction=("delta_no_selection_frequency", "mean"), min_no_selection_reduction=("delta_no_selection_frequency", "min"), max_no_selection_reduction=("delta_no_selection_frequency", "max"), applications_with_reduction=("delta_no_selection_frequency", lambda x: int((x > 1e-9).sum())), applications_with_adverse_no_selection=("delta_no_selection_frequency", lambda x: int((x < -1e-9).sum())), leader_switches=("leader_switched", "sum"), newly_eligible_candidates=("newly_eligible_candidate_count", "sum"), lost_eligible_candidates=("lost_eligible_candidate_count", "sum"), newly_selected_candidates=("newly_selected_candidate_count", "sum"), lost_selected_candidates=("lost_selected_candidate_count", "sum"))
    summary = summary.merge(portfolio[["closure_action", "burden_ordinal_index", "burden_level", "action_type", "adverse_application_fraction", "comparison_eligible", "non_dominated_under_registered_ordering"]], on="closure_action", how="left")
    summary.to_csv(out / f"{version}_figure_action_effect_forest_summary.csv", index=False)
    return {"alluvial": alluvial, "intersections": intersections, "action_forest": summary}


def run_extensions(root: Path, version: str, seed: int) -> dict:
    out = root / "outputs" / "tables"; inp = root / "data" / "input"; cfg = root / "config"
    P = pd.read_csv(inp / f"{version}_candidate_property_registry.csv"); M = pd.read_csv(inp / f"{version}_candidate_scenario_membership.csv")
    COR = pd.read_csv(inp / f"{version}_corrosion_evidence_registry.csv"); VAL = pd.read_csv(inp / f"{version}_literature_validation_tiers.csv")
    APP = pd.read_csv(inp / f"{version}_candidate_scenario_evidence_registry.csv"); ATOMIC = pd.read_csv(inp / f"{version}_atomic_engineering_credibility_registry.csv")
    S = pd.read_csv(cfg / f"{version}_system_benchmarks.csv"); D = pd.read_csv(out / f"{version}_candidate_system_metrics_deterministic.csv")
    DEC = pd.read_csv(out / f"{version}_integrated_system_decision_table.csv"); MC = pd.read_csv(out / f"{version}_system_value_monte_carlo_summary.csv")
    TRANS = pd.read_csv(out / f"{version}_selection_transition_matrix.csv"); GATE = pd.read_csv(out / f"{version}_gate_failure_breakdown.csv")
    draw_dtypes = {
        "draw_id": "int32",
        "gate_failure_count": "int8",
        "screening_adequate_95pct": "bool",
        "strict_complete": "bool",
        "is_balanced_winner": "bool",
        "failed_incomplete_service": "bool",
        "failed_no_bounded_selection_policy": "bool",
        "failed_corrosion_gate": "bool",
        "failed_cycling_phase_gate": "bool",
        "failed_containment_gate": "bool",
        "failed_evidence_gate": "bool",
        "failed_validation_gate": "bool",
        "failed_data_completeness_gate": "bool",
        "failed_claim_gate": "bool",
    }
    print("[extensions] loading streamed draw table with bounded dtypes", flush=True)
    DRAWS = pd.read_csv(
        out / f"{version}_monte_carlo_draws_balanced.csv",
        dtype=draw_dtypes,
        low_memory=False,
    )
    expected_rows = int(M.groupby("scenario").size().sum()) * int(DRAWS.draw_id.max())
    if len(DRAWS) != expected_rows:
        raise RuntimeError(
            f"Draw table row count mismatch: found {len(DRAWS):,}, expected {expected_rows:,}"
        )
    score_audit = _evidence_score_audit_tables(version, out, D, DRAWS, ATOMIC, APP)

    print("[extensions] database inventory", flush=True); db = _database_inventory(root, version, out, P, S)
    membership = M.groupby(["system_id", "display_system"], as_index=False).agg(registered_application_count=("scenario", "nunique"), registered_applications=("scenario", lambda x: ";".join(sorted(set(map(str, x))))))
    scope_audit = P[["system_id", "display_system", "family", "composition", "property_data_class", "property_evidence", "source_ids"]].merge(membership, on=["system_id", "display_system"], how="left", validate="one_to_one").merge(COR[["system_id", "claim_class", "corrosion_tier", "evidence_score"]], on="system_id", how="left", validate="one_to_one").merge(VAL[["system_id", "literature_validation_tier", "literature_validation_factor"]], on="system_id", how="left", validate="one_to_one").merge(db["candidate_linkage"][["system_id", "exact_formula_system_match", "exact_database_record_count", "candidate_provenance_class"]], on="system_id", how="left", validate="one_to_one")
    scope_audit["inclusion_status"] = "included_in_bounded_curated_corpus"; scope_audit["inclusion_basis"] = "traceable thermophysical source + explicit service membership + atomic engineering-evidence registry"
    scope_audit["review_scope"] = "single curated evidence review; atomic score intervals are sensitivity assumptions"; scope_audit["claim_boundary"] = "within-corpus comparison only; not exhaustive discovery, experimental qualification or global optimum"
    scope_audit.to_csv(out / f"{version}_candidate_scope_and_inclusion_audit.csv", index=False)
    pd.DataFrame([{
        "model_component": "unsupervised_candidate_archetype_clustering",
        "role": "descriptive opportunity-space organization only",
        "used_in_bounded_eligibility": False,
        "used_in_property_imputation": False,
        "used_in_gate_closure": False,
        "used_in_utility_or_ranking": False,
        "ai_derived_values_entering_bounded_decision": 0,
        "firewall_status": "PASS",
        "claim_boundary": "No supervised AI prediction, imputation or cluster label changes bounded decisions",
    }]).to_csv(out / f"{version}_ai_decision_firewall_policy.csv", index=False)
    _partial_complete_outputs(version, out, D)
    _switch_gate_outputs(version, out, D, DEC, TRANS, GATE, MC, COR, VAL, DRAWS)
    ws = _continuous_weight_scan(version, out, M, D, DRAWS, S, ATOMIC, seed)
    _candidate_count(version, out, DRAWS)
    closure, changes = _evidence_closure(version, out, M, D, DRAWS, S, ATOMIC, seed)
    threshold = _service_coverage_threshold_sensitivity(version, out, M, D, DRAWS, S, ATOMIC, seed)
    robust = _model_and_evidence_robustness(version, out, M, D, DRAWS, S, ATOMIC, APP, seed)
    shapley = _gate_shapley(version, out, DRAWS)
    consequences = _decision_redirection_consequences(version, out, M, DRAWS, S)
    portfolio = _research_portfolio(version, out, changes)
    figure_ready = _figure_ready_outputs(version, out, TRANS, DRAWS, changes, portfolio)
    pd.DataFrame([
        {"check": "Hierarchical decision model", "status": "PASS", "evidence": "Top-level performance versus engineering credibility; atomic evidence dimensions are aggregated once by geometric mean", "remaining_limit": "Weights and analytical evidence intervals remain normative sensitivity assumptions"},
        {"check": "PCM service decomposition", "status": "PASS", "evidence": "Separate 350 °C, 425 °C and 500 °C target duties with ±15 °C phase bands", "remaining_limit": "Standardized scenarios do not represent every industrial duty"},
        {"check": "Evidence uncertainty and structural robustness", "status": "PASS", "evidence": "Triangular atomic score intervals, five credibility models, low/mid/high perturbation, leave-one-candidate/source stress tests", "remaining_limit": "Independent dual-review scoring is not available"},
        {"check": "Continuous preference robustness", "status": "PASS", "evidence": "10,000 random top-level weights; anchors excluded from occupancy denominator; five independent resampling replicates", "remaining_limit": "Conditional on candidate corpus and finite sample"},
        {"check": "Atomic evidence closure", "status": "PASS", "evidence": "Corrosion, cycling/phase, containment, literature replication and data completeness actions are separated; direct severe-risk evidence is preserved", "remaining_limit": "Counterfactuals are prospective, not new experiments"},
        {"check": "Application-equal joint gate attribution", "status": "PASS", "evidence": "Exact Shapley-style unlock attribution over six gates plus all joint closure states", "remaining_limit": "Model attribution, not experimental causality"},
        {"check": "Draw-matched system consequences", "status": "PASS", "evidence": "Energy-density ratio and additional volume are computed for retained/redirected outcomes on matched draws", "remaining_limit": "No installed-cost or process-dynamics model"},
        {"check": "Signed candidate changes", "status": "PASS", "evidence": "New/lost eligible and selected candidates are exported separately without clipping", "remaining_limit": "Selection remains model-conditional"},
    ]).to_csv(out / f"{version}_extension_readiness_audit.csv", index=False)
    summary = {
        "status": "PASS_WITH_DECLARED_SCOPE_LIMITATIONS", "version": version, "raw_database_records": int(len(db["inventory"])),
        "unique_formula_systems": int(len(db["formula_inventory"])), "continuous_random_weight_vectors_per_application": 10000,
        "continuous_weight_physical_replicates": 5, "candidate_exact_database_links": int(db["candidate_linkage"].exact_formula_system_match.sum()),
        "service_scenarios": int(len(S)), "pcm_target_scenarios": int(S.service_mode.eq("latent").sum()),
        "evidence_closure_actions_including_baseline": int(closure.closure_action.nunique()), "counterfactual_application_rows": int(len(changes)),
        "research_actions": int(changes.closure_action.nunique() - 1), "gate_shapley_rows": int(len(shapley["shapley"])),
        "modules": ["hierarchical_decision_model", "atomic_evidence_uncertainty", "pcm_target_service_decomposition", "continuous_weight_space_robustness", "credibility_model_sensitivity", "leave_one_candidate_source_stress", "independent_seed_convergence", "atomic_evidence_closure", "application_equal_gate_shapley", "draw_matched_system_consequences", "signed_candidate_changes"],
    }
    (root / "outputs" / "qc" / f"{version}_EXTENSION_STATUS.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary
