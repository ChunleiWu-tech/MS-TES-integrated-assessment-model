from __future__ import annotations

from pathlib import Path
import os
import json
import csv
from itertools import combinations

import numpy as np
import pandas as pd
from decision_model import BURDEN_HALF_VALUE


def _read(root: Path, version: str, stem: str) -> pd.DataFrame:
    path = root / 'outputs' / 'tables' / f'{version}_{stem}.csv'
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def _write(df: pd.DataFrame, root: Path, version: str, stem: str) -> None:
    df.to_csv(root / 'outputs' / 'tables' / f'{version}_{stem}.csv', index=False)



def _draw_table_path(root: Path, version: str) -> Path:
    path = root / 'outputs' / 'tables' / f'{version}_monte_carlo_draws_balanced.csv'
    if not path.exists():
        raise FileNotFoundError(path)
    return path


def _float_or_nan(value: str) -> float:
    text = value.strip()
    if not text or text.lower() in {'nan', 'na', 'none'}:
        return float('nan')
    return float(text)


def _draw_inventory(path: Path) -> dict[str, dict]:
    """Low-memory first pass over the registered draw table.

    The order of scenarios and systems is the first-occurrence order used by the
    former pandas groupby/drop_duplicates implementation. Only compact identifiers
    are retained; no draw-level DataFrame is constructed.
    """
    inventory: dict[str, dict] = {}
    with path.open('r', encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream)
        header = next(reader)
        pos = {name: header.index(name) for name in (
            'scenario', 'scenario_label', 'draw_id', 'system_id', 'display_system'
        )}
        for row in reader:
            scenario = row[pos['scenario']]
            rec = inventory.get(scenario)
            if rec is None:
                rec = {
                    'label': row[pos['scenario_label']],
                    'systems': [],
                    'system_index': {},
                    'names': {},
                    'draw_id_set': set(),
                }
                inventory[scenario] = rec
            sid = row[pos['system_id']]
            if sid not in rec['system_index']:
                rec['system_index'][sid] = len(rec['systems'])
                rec['systems'].append(sid)
            rec['names'][sid] = row[pos['display_system']]
            rec['draw_id_set'].add(int(float(row[pos['draw_id']])))
    for rec in inventory.values():
        rec['draws'] = np.asarray(sorted(rec.pop('draw_id_set')), dtype=np.int64)
        rec['draw_index'] = {int(draw): i for i, draw in enumerate(rec['draws'])}
    return inventory

def _geometric_credibility(df: pd.DataFrame) -> np.ndarray:
    dims = [
        'corrosion_compatibility_score', 'cycling_phase_stability_score',
        'containment_validation_score', 'literature_replication_score',
        'data_completeness_score'
    ]
    x = np.clip(df[dims].to_numpy(float), 1e-9, 1.0)
    evidence = np.exp(np.mean(np.log(x), axis=1))
    burden = np.clip(df['engineering_burden_index'].to_numpy(float), 0, None)
    inverse_burden = 1.0 / (1.0 + burden / BURDEN_HALF_VALUE)
    return (np.prod(x, axis=1) * inverse_burden) ** (1.0 / 6.0)


def _deployability_contraction(root: Path, version: str) -> pd.DataFrame:
    profile = _read(root, version, 'candidate_readiness_profile')
    layered = _read(root, version, 'layered_selection_frequencies')
    evidence_layer = layered[(layered.ranking_layer == 'evidence_qualified') & (layered.weight_prior == 'balanced')]
    evidence_layer = evidence_layer[['scenario','system_id','eligible_for_layer','selection_frequency']].copy()
    p = profile.merge(evidence_layer, on=['scenario','system_id'], how='left')
    p['eligible_for_layer'] = p.eligible_for_layer.fillna(False).astype(bool)
    p['selection_frequency'] = p.selection_frequency.fillna(0.0)
    rows=[]
    for (scenario,label), g in p.groupby(['scenario','scenario_label']):
        any_complete = g.strict_complete_service_probability > 0
        evidence_complete = any_complete & g.eligible_for_layer
        selected = g.selection_frequency > 1e-12
        stable_selected = g.selection_frequency >= 0.01
        stages = [
            ('Registered candidate–service pairs', len(g)),
            ('Any complete-service support', int(any_complete.sum())),
            ('Complete-service and evidence-qualified', int(evidence_complete.sum())),
            ('Selected in ≥1 Monte Carlo draw', int(selected.sum())),
            ('Material selection frequency ≥1%', int(stable_selected.sum())),
        ]
        total=max(len(g),1)
        for order,(stage,count) in enumerate(stages,1):
            rows.append({'scenario':scenario,'scenario_label':label,'stage_order':order,'deployability_stage':stage,
                         'candidate_service_pairs':count,'share_of_registered':count/total})
    return pd.DataFrame(rows)


def _rank_reversal(root: Path, version: str) -> tuple[pd.DataFrame,pd.DataFrame]:
    path = _draw_table_path(root, version)
    inventory = _draw_inventory(path)
    for rec in inventory.values():
        shape = (len(rec['draws']), len(rec['systems']))
        rec['partial'] = np.full(shape, np.nan, dtype=np.float64)
        rec['complete'] = np.full(shape, np.nan, dtype=np.float64)

    with path.open('r', encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream)
        header = next(reader)
        pos = {name: header.index(name) for name in (
            'scenario', 'draw_id', 'system_id',
            'partial_overlap_energy_density_kWh_m3',
            'complete_service_energy_density_kWh_m3',
        )}
        for row in reader:
            rec = inventory[row[pos['scenario']]]
            i = rec['draw_index'][int(float(row[pos['draw_id']]))]
            j = rec['system_index'][row[pos['system_id']]]
            rec['partial'][i, j] = _float_or_nan(row[pos['partial_overlap_energy_density_kWh_m3']])
            rec['complete'][i, j] = _float_or_nan(row[pos['complete_service_energy_density_kWh_m3']])

    candidate_rows=[]; scenario_rows=[]
    for scenario, rec in inventory.items():
        label=rec['label']; systems=rec['systems']; draws=rec['draws']
        sid_to_idx=rec['system_index']; names=rec['names']
        partial=rec.pop('partial'); complete=rec.pop('complete')
        shape=partial.shape
        partial_rank=np.full(shape,np.nan); complete_rank=np.full(shape,np.nan)
        for arr,out in [(partial,partial_rank),(complete,complete_rank)]:
            for i in range(shape[0]):
                finite=np.isfinite(arr[i])
                if finite.any():
                    idx=np.where(finite)[0]
                    order=idx[np.argsort(-arr[i,idx],kind='mergesort')]
                    out[i,order]=np.arange(1,len(order)+1)
        partial_leader=np.nanargmax(np.where(np.isfinite(partial),partial,-np.inf),axis=1)
        complete_exists=np.isfinite(complete).any(axis=1)
        complete_leader=np.full(len(draws),-1)
        complete_leader[complete_exists]=np.nanargmax(np.where(np.isfinite(complete[complete_exists]),complete[complete_exists],-np.inf),axis=1)
        scenario_rows.append({
            'scenario':scenario,'scenario_label':label,'mc_draws':len(draws),
            'partial_leader_differs_from_complete_leader_probability':float(np.mean((partial_leader!=complete_leader)&complete_exists)),
            'partial_leader_has_no_complete_service_probability':float(np.mean(~np.isfinite(complete[np.arange(len(draws)),partial_leader]))),
            'no_complete_service_candidate_probability':float(np.mean(~complete_exists)),
        })
        for sid,j in sid_to_idx.items():
            both=np.isfinite(partial_rank[:,j]) & np.isfinite(complete_rank[:,j])
            shift=complete_rank[both,j]-partial_rank[both,j]
            candidate_rows.append({
                'scenario':scenario,'scenario_label':label,'system_id':sid,'display_system':names[sid],
                'draws_with_partial_rank':int(np.isfinite(partial_rank[:,j]).sum()),
                'draws_with_complete_rank':int(np.isfinite(complete_rank[:,j]).sum()),
                'draws_with_both_ranks':int(both.sum()),
                'mean_complete_minus_partial_rank_shift':float(np.mean(shift)) if len(shift) else np.nan,
                'median_complete_minus_partial_rank_shift':float(np.median(shift)) if len(shift) else np.nan,
                'probability_rank_worsens_after_complete_service':float(np.mean(shift>0)) if len(shift) else np.nan,
                'probability_rank_improves_after_complete_service':float(np.mean(shift<0)) if len(shift) else np.nan,
                'probability_becomes_unranked_under_complete_service':float(np.mean(np.isfinite(partial_rank[:,j]) & ~np.isfinite(complete_rank[:,j]))),
            })
        del partial, complete, partial_rank, complete_rank
    return pd.DataFrame(candidate_rows),pd.DataFrame(scenario_rows)


def _frontier_and_archetypes(root: Path, version: str, seed: int) -> tuple[pd.DataFrame,pd.DataFrame,pd.DataFrame]:
    from sklearn.cluster import AgglomerativeClustering
    from sklearn.metrics import silhouette_score, adjusted_rand_score
    from sklearn.preprocessing import StandardScaler
    p = _read(root, version, 'candidate_readiness_profile').copy()
    p['engineering_credibility_geometric'] = _geometric_credibility(p)
    p['performance_p50'] = p.energy_density_p50_kWh_m3_conditional_on_adequacy.fillna(0.0)
    p['robustness'] = p.evidence_qualified_selection_frequency.fillna(0.0)
    p['inverse_burden'] = 1/(1+p.engineering_burden_index.clip(lower=0)/BURDEN_HALF_VALUE)
    # within-service normalized performance
    p['performance_normalized']=p.groupby('scenario').performance_p50.transform(lambda s: s/s.max() if s.max()>0 else 0)
    p['gap_penalty']=1-p.closable_gap_count/(p.closable_gap_count.max() if p.closable_gap_count.max()>0 else 1)
    # Pareto status in performance, credibility, robustness, inverse burden (all maximize)
    front=[]
    vals=p[['performance_normalized','engineering_credibility_geometric','robustness','inverse_burden']].to_numpy(float)
    for scenario, idx in p.groupby('scenario').groups.items():
        idx=np.asarray(list(idx),int); x=vals[idx]
        dominated=np.zeros(len(idx),bool)
        for i,j in combinations(range(len(idx)),2):
            if np.all(x[i]>=x[j]) and np.any(x[i]>x[j]): dominated[j]=True
            if np.all(x[j]>=x[i]) and np.any(x[j]>x[i]): dominated[i]=True
        for local,global_idx in enumerate(idx): front.append((global_idx,not dominated[local]))
    flag=pd.Series({i:v for i,v in front})
    p['deployability_frontier']=p.index.map(flag).fillna(False).astype(bool)

    features=['performance_normalized','strict_complete_service_probability','engineering_credibility_geometric','inverse_burden','robustness','gap_penalty']
    X=StandardScaler().fit_transform(p[features].fillna(0.0))
    best=None
    for k in range(2,min(5,len(p))):
        labels=AgglomerativeClustering(n_clusters=k,linkage='ward').fit_predict(X)
        if min(np.bincount(labels))<2: continue
        score=silhouette_score(X,labels)
        if best is None or score>best[0]: best=(score,k,labels)
    if best is None:
        best=(np.nan,2,AgglomerativeClustering(n_clusters=2,linkage='ward').fit_predict(X))
    silhouette,k,labels=best
    p['archetype_cluster_id']=labels+1
    # perturbation stability under 5% standardized-feature noise
    rng=np.random.default_rng(seed+920_220)
    ari=[]
    for _ in range(250):
        pert=X+rng.normal(0,0.05,X.shape)
        lab=AgglomerativeClustering(n_clusters=k,linkage='ward').fit_predict(pert)
        ari.append(adjusted_rand_score(labels,lab))
    stability=float(np.mean(ari))
    cent=p.groupby('archetype_cluster_id')[features].mean()
    # Deterministic one-to-one semantic labels derived from centroid patterns.
    # The former implementation compressed every residual cluster into one label,
    # which could make four distinct unsupervised clusters appear as only three
    # archetypes.  That was both ambiguous and, for a zero-performance residual
    # cluster, semantically incorrect.
    labels_map={}
    remaining=set(int(x) for x in cent.index)

    robust_score=(
        cent['robustness']
        + 0.25*cent['engineering_credibility_geometric']
        + 0.25*cent['strict_complete_service_probability']
    )
    robust_id=int(robust_score.idxmax())
    labels_map[robust_id]='Robust deployability benchmark'
    remaining.discard(robust_id)

    service_support=(
        cent['performance_normalized']
        + cent['strict_complete_service_probability']
    )
    evidence_readiness=(
        cent['engineering_credibility_geometric']
        + cent['inverse_burden']
        + cent['gap_penalty']
    )

    if remaining:
        high_id=max(remaining, key=lambda cid: (float(service_support.loc[cid]), float(evidence_readiness.loc[cid]), -cid))
        labels_map[high_id]='High-performance evidence opportunity'
        remaining.discard(high_id)

    if remaining:
        bounded_id=min(remaining, key=lambda cid: (float(service_support.loc[cid] + 0.25*evidence_readiness.loc[cid]), cid))
        labels_map[bounded_id]='Service-mismatched or bounded-out'
        remaining.discard(bounded_id)

    # With the preregistered k in {2,3,4}, at most one residual cluster remains.
    # It is characterized by absent service performance but comparatively lower
    # evidence/engineering burden than the fully bounded-out cluster.
    for cid in sorted(remaining, key=lambda x: (-float(evidence_readiness.loc[x]), x)):
        labels_map[cid]='Lower-burden service-bounded profile'

    p['archetype_label']=p.archetype_cluster_id.map(labels_map)
    profile=p[['scenario','scenario_label','system_id','display_system']+features+['deployability_frontier','archetype_cluster_id','archetype_label']]
    cluster_summary=(p.groupby(['archetype_cluster_id','archetype_label'])[features]
                     .agg(['mean','min','max']).reset_index())
    cluster_summary.columns=['_'.join([str(x) for x in c if str(x)]) for c in cluster_summary.columns.to_flat_index()]
    method=pd.DataFrame([{'method':'Ward hierarchical clustering on standardized transparent decision features',
                          'candidate_service_pairs':len(p),'selected_cluster_count':k,
                          'silhouette_score':silhouette,'mean_adjusted_rand_under_5pct_feature_perturbation':stability,
                          'labeling_rule':'One unique centroid-derived semantic label per unsupervised cluster; labels do not alter clustering or scores.',
                          'interpretation':'Exploratory unsupervised archetypes; not supervised discovery or experimental validation.'}])
    return profile,cluster_summary,method


def _smaa_rank_acceptability(root: Path, version: str, seed: int) -> tuple[pd.DataFrame,pd.DataFrame,pd.DataFrame]:
    path=_draw_table_path(root,version)
    inventory=_draw_inventory(path)
    rng=np.random.default_rng(seed+92_002)
    n_weights=int(os.environ.get("TES_INNOVATION_WEIGHTS", "1000")); n_draws=int(os.environ.get("TES_INNOVATION_DRAWS", "500"))
    for rec in inventory.values():
        chosen=np.sort(rng.choice(rec['draws'],size=min(n_draws,len(rec['draws'])),replace=False))
        rec['chosen']=chosen
        rec['chosen_index']={int(draw):i for i,draw in enumerate(chosen)}
        rec['weights']=rng.dirichlet(np.ones(2),n_weights)
        shape=(len(chosen),len(rec['systems']))
        rec['energy']=np.full(shape,np.nan,dtype=np.float64)
        rec['cred']=np.full(shape,np.nan,dtype=np.float64)
        rec['feasible']=np.zeros(shape,dtype=bool)

    with path.open('r',encoding='utf-8-sig',newline='') as stream:
        reader=csv.reader(stream); header=next(reader)
        pos={name:header.index(name) for name in (
            'scenario','draw_id','system_id','complete_service_energy_density_kWh_m3',
            'sampled_engineering_credibility','gate_failure_count'
        )}
        for row in reader:
            rec=inventory[row[pos['scenario']]]
            draw=int(float(row[pos['draw_id']]))
            i=rec['chosen_index'].get(draw)
            if i is None:
                continue
            j=rec['system_index'][row[pos['system_id']]]
            energy=_float_or_nan(row[pos['complete_service_energy_density_kWh_m3']])
            rec['energy'][i,j]=energy
            rec['cred'][i,j]=_float_or_nan(row[pos['sampled_engineering_credibility']])
            rec['feasible'][i,j]=(int(float(row[pos['gate_failure_count']]))==0 and np.isfinite(energy))

    rank_rows=[]; central_rows=[]; design=[]
    for scenario,rec in inventory.items():
        label=rec['label']; systems=rec['systems']; names=rec['names']; chosen=rec['chosen']
        energy=rec.pop('energy'); cred=rec.pop('cred'); feasible=rec.pop('feasible')
        shape=energy.shape
        q=np.full(shape,np.nan)
        for i in range(shape[0]):
            f=feasible[i]
            if f.any():
                x=energy[i,f]; lo=x.min(); hi=x.max(); q[i,f]=1.0 if hi<=lo else (x-lo)/(hi-lo)
        weights=rec.pop('weights')
        c=len(systems)
        counts=np.zeros((c,c),dtype=np.int64)
        first_weight_sum=np.zeros((c,2)); first_count=np.zeros(c,dtype=np.int64)
        no_count=0
        for start in range(0,n_weights,100):
            w=weights[start:start+100]
            u=w[:,None,None,0]*q[None,:,:]+w[:,None,None,1]*cred[None,:,:]
            u=np.where(feasible[None,:,:],u,-np.inf)
            valid=np.isfinite(u) & (u>-np.inf)
            no=~valid.any(axis=2); no_count += int(no.sum())
            order=np.argsort(-u,axis=2,kind='stable')
            valid_sorted=np.take_along_axis(valid,order,axis=2)
            for rank in range(c):
                ids=order[:,:,rank][valid_sorted[:,:,rank]]
                if ids.size: counts[:,rank]+=np.bincount(ids,minlength=c)
            winners=order[:,:,0]
            for bi in range(len(w)):
                good=~no[bi]
                wc=np.bincount(winners[bi,good],minlength=c) if good.any() else np.zeros(c,dtype=int)
                first_count += wc
                first_weight_sum += wc[:,None]*w[bi][None,:]
        denom=n_weights*len(chosen)
        for j,sid in enumerate(systems):
            for rank in range(1,c+1):
                rank_rows.append({'scenario':scenario,'scenario_label':label,'system_id':sid,'display_system':names[sid],
                                  'rank':rank,'rank_acceptability':counts[j,rank-1]/denom,
                                  'random_weight_vectors':n_weights,'physical_draws':len(chosen)})
            if first_count[j]>0:
                cw=first_weight_sum[j]/first_count[j]
                util=cw[0]*q+cw[1]*cred; util=np.where(feasible,util,-np.inf)
                finite_any=np.isfinite(util).any(axis=1) & (util.max(axis=1)>-np.inf)
                winners=np.full(len(chosen),-1); winners[finite_any]=np.argmax(util[finite_any],axis=1)
                conf=float(np.mean(winners[finite_any]==j)) if finite_any.any() else 0.0
            else: cw=np.array([np.nan,np.nan]); conf=0.0
            central_rows.append({'scenario':scenario,'scenario_label':label,'system_id':sid,'display_system':names[sid],
                                 'rank1_acceptability':counts[j,0]/denom,'central_weight_performance':cw[0],
                                 'central_weight_engineering_credibility':cw[1],'central_weight_confidence_factor':conf})
        design.append({'scenario':scenario,'random_weight_vectors':n_weights,'physical_draws':len(chosen),
                       'candidate_count':c,'no_selection_probability':no_count/denom,
                       'method':'SMAA-style rank acceptability under Dirichlet(1,1) performance–credibility preferences and sampled physical/evidence uncertainty',
                       'relationship_to_full_scan':'Complementary to the existing 10,000-weight, five-replicate decision-region analysis.'})
        del energy,cred,feasible,q
    return pd.DataFrame(rank_rows),pd.DataFrame(central_rows),pd.DataFrame(design)

def _evidence_value_map(root: Path, version: str) -> tuple[pd.DataFrame,pd.DataFrame]:
    cf=_read(root,version,'counterfactual_selection_frequencies')
    metrics=_read(root,version,'candidate_readiness_profile')
    changes=_read(root,version,'counterfactual_selection_changes')
    portfolio=_read(root,version,'research_action_nondominance_assessment')
    m=metrics[['scenario','system_id','energy_density_p50_kWh_m3_conditional_on_adequacy',
               'corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score',
               'literature_replication_score','data_completeness_score','engineering_burden_index']].copy()
    m['credibility']=_geometric_credibility(m)
    m['energy']=m.energy_density_p50_kWh_m3_conditional_on_adequacy.fillna(0.0)
    m['energy_norm']=m.groupby('scenario').energy.transform(lambda s:s/s.max() if s.max()>0 else 0)
    x=cf.merge(m[['scenario','system_id','energy_norm','credibility']],on=['scenario','system_id'],how='left')
    rows=[]
    for (action,scenario),g in x.groupby(['closure_action','scenario']):
        rows.append({'closure_action':action,'scenario':scenario,
                     'expected_normalized_service_value':float(np.sum(g.selection_frequency*g.energy_norm)),
                     'expected_selected_credibility':float(np.sum(g.selection_frequency*g.credibility)),
                     'selection_probability':float(g.selection_frequency.sum())})
    ev=pd.DataFrame(rows)
    base=ev[ev.closure_action=='baseline'].set_index('scenario')
    ev['delta_expected_normalized_service_value']=ev.apply(lambda r:r.expected_normalized_service_value-base.loc[r.scenario,'expected_normalized_service_value'],axis=1)
    ev['delta_expected_selected_credibility']=ev.apply(lambda r:r.expected_selected_credibility-base.loc[r.scenario,'expected_selected_credibility'],axis=1)
    ev['delta_selection_probability']=ev.apply(lambda r:r.selection_probability-base.loc[r.scenario,'selection_probability'],axis=1)
    ev=ev.merge(changes[['closure_action','scenario','delta_no_selection_frequency','newly_eligible_candidate_count','lost_eligible_candidate_count','newly_selected_candidate_count','lost_selected_candidate_count']],on=['closure_action','scenario'],how='left')
    burden=portfolio[['closure_action','burden_ordinal_index','burden_level','adverse_application_fraction']].drop_duplicates('closure_action')
    ev=ev.merge(burden,on='closure_action',how='left')
    atomic=ev[~ev.closure_action.isin(['baseline','comprehensive_upper_bound'])].copy()
    summary=(atomic.groupby('closure_action',as_index=False)
             .agg(mean_service_value_gain=('delta_expected_normalized_service_value','mean'),
                  mean_selection_probability_gain=('delta_selection_probability','mean'),
                  mean_credibility_gain=('delta_expected_selected_credibility','mean'),
                  services_with_positive_service_value=('delta_expected_normalized_service_value',lambda s:int((s>1e-12).sum())),
                  services_with_adverse_service_value=('delta_expected_normalized_service_value',lambda s:int((s<-1e-12).sum())),
                  total_newly_selected=('newly_selected_candidate_count','sum'),
                  total_lost_selected=('lost_selected_candidate_count','sum'),
                  burden_ordinal_index=('burden_ordinal_index','first'),burden_level=('burden_level','first'),
                  adverse_application_fraction=('adverse_application_fraction','first')))
    # Non-dominance under registered ordering: maximize benefits and minimize ordinal burden/adverse effects
    vals=summary[['mean_service_value_gain','mean_selection_probability_gain','burden_ordinal_index','adverse_application_fraction']].to_numpy(float)
    efficient=np.ones(len(summary),bool)
    for i,j in combinations(range(len(summary)),2):
        # transform first two max, last two min
        a=np.array([vals[i,0],vals[i,1],-vals[i,2],-vals[i,3]])
        b=np.array([vals[j,0],vals[j,1],-vals[j,2],-vals[j,3]])
        if np.all(a>=b) and np.any(a>b): efficient[j]=False
        if np.all(b>=a) and np.any(b>a): efficient[i]=False
    summary['evidence_value_non_dominated_under_registered_ordering']=efficient
    summary['interpretation']='Prospective value-of-evidence proxy. Non-dominance is conditional on the registered criteria and ordinal burden ordering; it is not monetary EVPI, experimental outcome or a cardinal Pareto frontier.'
    return ev,summary


def run_innovation_extensions(root: Path, version: str='core', seed: int=760076) -> dict:
    contraction=_deployability_contraction(root,version); _write(contraction,root,version,'deployability_contraction')
    rankcand,rankscenario=_rank_reversal(root,version); _write(rankcand,root,version,'partial_complete_rank_reversal_candidates'); _write(rankscenario,root,version,'partial_complete_rank_reversal_summary')
    smaa,central,smaa_design=_smaa_rank_acceptability(root,version,seed); _write(smaa,root,version,'smaa_rank_acceptability'); _write(central,root,version,'smaa_central_weights'); _write(smaa_design,root,version,'smaa_design')
    frontier,clusters,cluster_method=_frontier_and_archetypes(root,version,seed); _write(frontier,root,version,'service_conditioned_deployability_frontier'); _write(clusters,root,version,'candidate_archetype_cluster_summary'); _write(cluster_method,root,version,'candidate_archetype_method')
    ev,evsum=_evidence_value_map(root,version); _write(ev,root,version,'prospective_evidence_value_by_service'); _write(evsum,root,version,'prospective_evidence_value_summary')
    status={
        'status':'PASS',
        'deployability_contraction_rows':len(contraction),
        'rank_reversal_candidate_rows':len(rankcand),
        'rank_reversal_scenario_rows':len(rankscenario),
        'deployability_frontier_rows':len(frontier),
        'archetype_clusters':int(frontier.archetype_cluster_id.nunique()),
        'smaa_rank_rows':len(smaa),
        'evidence_value_service_rows':len(ev),
        'evidence_value_action_rows':len(evsum),
        'methodological_scope':[
            'service-conditioned deployability contraction',
            'partial-versus-complete-service rank reversal',
            'transparent unsupervised candidate archetypes',
            'SMAA-style rank acceptability',
            'prospective value-of-evidence mapping'
        ],
        'ai_scope_note':'Unsupervised clustering is exploratory and interpretable; no black-box material discovery or claim of experimental validation.'
    }
    q=root/'outputs'/'qc'; q.mkdir(parents=True,exist_ok=True)
    (q/f'{version}_INNOVATION_EXTENSION_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    return status
