from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'outputs'/'tables'; Q=ROOT/'outputs'/'qc'; V='statistical'
checks=[]
def ck(name,ok,detail=''):
    checks.append({'check':name,'status':'PASS' if bool(ok) else 'FAIL','detail':detail})

def rd(stem): return pd.read_csv(T/f'{V}_{stem}.csv')
required=[
'pareto_joint_uncertainty_and_robustness','pareto_representative_draw_registry',
'continuous_decision_variance_attribution','categorical_selection_information_attribution',
'structural_stochastic_uncertainty_classification','uncertainty_block_activation_design',
'evidence_action_dag_registry','dag_constrained_decision_boundary_states',
'dag_constrained_minimal_action_sets','inadmissible_action_combination_audit','evidence_action_outcome_scenario_registry']
for s in required: ck(f'{s}_exists',(T/f'{V}_{s}.csv').exists())
pareto=rd('pareto_joint_uncertainty_and_robustness')
ck('pareto_frequencies_in_unit_interval',pareto.frontier_membership_frequency.dropna().between(0,1).all())
ck('pareto_bootstrap_order',(pareto.frontier_frequency_bootstrap_p05.dropna()<=pareto.frontier_membership_frequency.dropna()).all() and (pareto.frontier_membership_frequency.dropna()<=pareto.frontier_frequency_bootstrap_p95.dropna()).all())
ck('pareto_common_representative_draw_per_service',pareto.groupby('scenario').representative_draw_id.nunique().le(1).all())
cont=rd('continuous_decision_variance_attribution'); cat=rd('categorical_selection_information_attribution')
ck('continuous_response_not_category',cont.continuous_response.astype(str).str.contains('candidate identity').sum()==0)
ck('categorical_method_rejects_linear_anova',cat.method.astype(str).str.contains('no linear ANOVA').any())
structure=rd('structural_stochastic_uncertainty_classification')
allowed={'service-incomplete','evidence-locked','evidence-variable-single-candidate','deterministic-single-candidate','preference-sensitive','stochastic-multicandidate'}
ck('structural_classes_registered',set(structure.uncertainty_structure_class).issubset(allowed))
dag=rd('evidence_action_dag_registry'); states=rd('dag_constrained_decision_boundary_states'); mins=rd('dag_constrained_minimal_action_sets')
ck('dag_burden_positive',(dag.burden_ordinal>0).all())
ck('dag_outcome_scope_disclosed',dag.outcome_scope.str.contains('no probability').all())
if len(states): ck('dag_states_admissible_only',states.admissible.all())
ck('minimal_sets_scope_disclosed',mins.analysis_scope.str.contains('no expected-value claim').all())
# Check containment prerequisite for any state that uses the system-level containment action.
if len(states):
    bad=[]
    for r in states.itertuples():
        acts=set(str(r.action_set).split(';')); closed=set(str(r.closed_dimensions).split(';'))
        if 'system_containment_qualification' in acts and 'corrosion_compatibility' not in closed: bad.append((r.scenario,r.system_id,r.action_set))
    ck('containment_precedence_respected',len(bad)==0,str(bad[:3]))
status='PASS' if all(x['status']=='PASS' for x in checks) else 'FAIL'
pd.DataFrame(checks).to_csv(Q/f'{V}_VALIDATION_CHECKS.csv',index=False)
summary={'version':V,'status':status,'checks':len(checks),'failures':sum(x['status']=='FAIL' for x in checks)}
(Q/f'{V}_VALIDATION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
if status!='PASS': raise SystemExit('statistical validation failed')
