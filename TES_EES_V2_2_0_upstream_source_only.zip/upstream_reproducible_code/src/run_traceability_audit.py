"""Deterministic disclosure and numerical reconstruction; no decision-rule changes."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd
from decision_model import ATOMIC_DIMS,GAP_COLS,TOP_LEVEL_PRIORS,normalise_by_draw,credibility_score,hierarchical_utility

ROOT=Path(__file__).resolve().parents[1];T=ROOT/'outputs/tables';IN=ROOT/'data/input';Q=ROOT/'outputs/qc'
GATES=[('incomplete_service','failed_incomplete_service'),('corrosion','failed_corrosion_gate'),('cycling_phase','failed_cycling_phase_gate'),('containment','failed_containment_gate'),('literature_validation','failed_validation_gate'),('data_completeness','failed_data_completeness_gate')]
def read(n):return pd.read_csv(T/n)
def out(d,n):d.to_csv(T/('traceability_'+n+'.csv'),index=False)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def run():
    checks=[]
    def check(n,ok,detail=None):checks.append(dict(check=n,passed=bool(ok),detail=detail))
    a=pd.read_csv(IN/'core_atomic_engineering_credibility_registry.csv')
    p=pd.read_csv(IN/'core_candidate_property_registry.csv').set_index('system_id')
    s=pd.read_csv(ROOT/'config/core_system_benchmarks.csv').set_index('scenario')
    d=read('core_candidate_system_metrics_deterministic.csv').set_index(['scenario','system_id'])
    app=pd.read_csv(IN/'core_candidate_scenario_evidence_registry.csv').set_index(['scenario','system_id'])
    corr=pd.read_csv(IN/'core_corrosion_evidence_registry.csv').set_index('system_id')
    lit=pd.read_csv(IN/'core_literature_validation_tiers.csv').set_index('system_id')
    sources=pd.read_csv(IN/'core_authoritative_source_registry.csv').set_index('source_id')
    prop=pd.read_csv(ROOT/'data/provenance/core_property_source_ledger.csv')
    obs=pd.read_csv(IN/'engineering_corrosion_observations.csv')
    transfer=read('engineering_composition_transfer.csv')
    ledger=read('core_candidate_service_evidence_score_ledger.csv').set_index(['scenario','system_id'])
    rows=[];score_rows=[];source_rows=[]
    for r in a.itertuples(index=False):
        key=(r.scenario,r.system_id);v=d.loc[key];sv=s.loc[r.scenario];pr=p.loc[r.system_id];av=app.loc[key]
        common=dict(scenario=r.scenario,system_id=r.system_id,display_system=r.display_system,composition=pr.composition,
                    composition_basis='wt%' if 'wt%' in pr.composition else 'see_exact_composition',
                    service_mode=sv.service_mode,cold_C=sv.fixed_Tcold_C,hot_C=sv.fixed_Thot_C,
                    phase_low_C=sv.phase_target_min_C,phase_high_C=sv.phase_target_max_C,
                    application_assessment=av.application_evidence_basis,source_ids=r.source_ids,
                    modal_complete_duty_pass=bool(v.strict_complete_service_feasible),
                    modal_formal_access=bool(ledger.loc[key].modal_decision_feasible),
                    interval_origin='analyst-specified assessment interval; no empirical rate-to-score calibration',
                    score_rule_table='core_evidence_score_rule_registry.csv',
                    numerical_score_row=f'core_candidate_service_evidence_score_ledger.csv: {r.scenario}|{r.system_id}')
        pp=prop[prop.system_id.eq(r.system_id)]
        phys_reason=(f'Physical coverage={v.physical_window_coverage:.6g}; supported coverage={v.fixed_window_coverage:.6g}; '
                    f'melting={v.Tm_C:g} C; practical upper={v.Tmax_practical_C:g} C; '
                    f'Cp domain={pr.cp_Tmin_C} to {pr.cp_Tmax_C} C; density domain={pr.rho_Tmin_C} to {pr.rho_Tmax_C} C.')
        rows.append({**common,'criterion':'complete_duty','gate_active':not bool(v.strict_complete_service_feasible),
                     'reason_class':'supported_under_declared_rule' if v.strict_complete_service_feasible else ('physical_duty_mismatch' if not v.strict_complete_physical_service_feasible else 'missing_or_out_of_domain_property_evidence'),
                     'judgment_basis':phys_reason,'source_locator':' | '.join(pp.source_locator.dropna().astype(str).unique()),
                     'experimental_conditions':' | '.join(pp.source_condition.dropna().astype(str).unique()),
                     'assumption_boundary':'Duty, freeze margin, practical cap, domain requirement and 0.999 coverage tolerance are declared model conventions.'})
        for dim,gap in zip(ATOMIC_DIMS,GAP_COLS):
            active=bool(getattr(r,gap)); reason='required_evidence_unresolved' if active else 'registered_assessment_acceptance'
            basis=str(av.application_evidence_basis)
            if dim=='corrosion_compatibility':basis=str(corr.loc[r.system_id,'note'])
            if dim=='literature_replication':basis=str(lit.loc[r.system_id,'literature_validation_basis'])+'; '+str(lit.loc[r.system_id,'note'])
            if dim=='cycling_phase_stability' and r.system_id=='tms2':basis='1008 h at 550 C is isothermal aging (Wang 2024 Section 2.9); repeated thermal-cycle retention remains unresolved.'
            bound='This is the frozen registry judgment, not a measured binary compatibility result. A zero gap does not by itself establish a matched-duty experiment.'
            if r.system_id=='nkca' and dim=='corrosion_compatibility':
                reason='adverse_evidence_plus_precautionary_transfer_rule';basis='Direct corrosion evidence at 800 C underlies a nonclosable exclusion applied also to the lower PCM target bands.'
                bound='800 C exposure is outside all three PCM target bands. Transfer of that exclusion is an analyst-set precaution; failure at the lower target is not experimentally demonstrated.'
            matched=transfer[transfer.target_system_id.eq(r.system_id)&transfer.composition_match]
            oo=obs[obs.observation_id.isin(matched.observation_id)] if dim in ['corrosion_compatibility','containment_validation'] else obs.iloc[0:0]
            conditions=' | '.join(f'{z.observation_id}: {z.alloy}; {z.temperature_C:g} C; {z.duration_h:g} h; {z.atmosphere}; {z.flow_regime}; {z.purification}; {z.endpoint}; {z.relation} {z.reported_value} {z.reported_unit}' for z in oo.itertuples())
            locator=' | '.join(f'{z.doi} {z.locator}' for z in oo.itertuples())
            if not locator:locator='Source identifiers and source applicability statements linked in traceability_source_links.csv; no row-specific experimental locator in the frozen scoring record.'
            if not conditions:conditions='No composition-matched condition row in the quantified corrosion dataset for this criterion; retained registry statement is not a newly verified test.'
            if r.system_id=='mgcl_kcl_nacl' and dim in ['corrosion_compatibility','containment_validation']:
                bound+=' Ding 2018 and Gong 2022 have different compositions; their 700 C results do not qualify this exact formulation.'
            rows.append({**common,'criterion':dim,'gate_active':active or (dim=='corrosion_compatibility' and bool(r.nonclosable_direct_risk)),
                         'reason_class':reason,'judgment_basis':basis,'source_locator':locator,'experimental_conditions':conditions,'assumption_boundary':bound})
            score_rows.append({**common,'dimension':dim,'low':getattr(r,dim+'_low'),'mode':getattr(r,dim+'_mid'),'high':getattr(r,dim+'_high'),
                               'assignment_basis':r.atomic_evidence_basis,'calibrated_to_experimental_measurement':False,
                               'sampling':'triangular(low,mode,high); clip to [1e-6,1]','tested_sensitivity':'engineering_score_sensitivity.csv'})
        score_rows.append({**common,'dimension':'burden','low':r.burden_index_low,'mode':r.burden_index_mid,'high':r.burden_index_high,
                           'assignment_basis':r.atomic_evidence_basis,'calibrated_to_experimental_measurement':False,
                           'sampling':'triangular(low,mode,high); inverse value=1/(1+B/2)','tested_sensitivity':'engineering_score_sensitivity.csv'})
        for source in str(r.source_ids).split(';'):
            found=source in sources.index;z=sources.loc[source] if found else None
            source_rows.append({**common,'source_id':source,'source_title':z.title if found else '', 'source_url':z.url if found else '',
                                'source_type':z.source_type if found else '', 'applicability_statement':z.role if found else '',
                                'role_boundary':'A source link is not proof that every score dimension has a matching experiment.'})
    gate=pd.DataFrame(rows);scores=pd.DataFrame(score_rows);links=pd.DataFrame(source_rows)
    out(gate,'candidate_duty_decisions');out(scores,'score_intervals');out(links,'source_links')
    out(prop.merge(a[['scenario','system_id']],on='system_id',validate='many_to_many'),'candidate_duty_property_provenance')
    ex=read('expanded_v3_candidate_service_screen.csv')
    ex['decision_reason_class']=np.select([~ex.physical_window_pass,~ex.quantitative_thermophysical_complete,~ex.service_domain_supported,~ex.engineering_registry_linked],
         ['physical_boundary_not_met_or_unreported','required_numerical_property_missing','property_domain_not_supported','thermophysical_comparable_engineering_unassessed'],default='engineering_registry_linked_see_duty_ledger')
    ex['engineering_ledger']='traceability_candidate_duty_decisions.csv; join current_registry_system_id to system_id and service_id to scenario'
    out(ex,'expanded_994_decisions')
    check('complete 36 memberships by six gates',len(gate)==216 and not gate.duplicated(['scenario','system_id','criterion']).any())
    check('six numerical interval components per membership',len(scores)==216 and (scores.low<=scores['mode']).all() and (scores['mode']<=scores.high).all())
    check('all source identifiers resolved',links.source_url.ne('').all())
    check('expanded trace preserves all 994 pairs',len(ex)==994 and not ex.duplicated(['candidate_key','service_id']).any())

    draws=read('core_monte_carlo_draws_balanced.csv');version_rows=[]
    for scenario,g in draws.groupby('scenario',sort=False):
        flags=g[[c for _,c in GATES]].astype(bool).to_numpy()
        variants={'current':flags.copy(),'counterfactual_previous_tms_cycle_label':flags.copy()}
        variants['counterfactual_previous_tms_cycle_label'][g.system_id.eq('tms2').to_numpy(),2]=False
        for version,ff in variants.items():
            masks=np.sum(ff*(1<<np.arange(6)),axis=1)
            for closed in range(64):
                kept=int(((masks & (63^closed))==0).sum())
                version_rows.append(dict(scenario=scenario,version=version,closed_gate_mask=closed,
                    closed_gates=';'.join(GATES[i][0] for i in range(6) if closed&(1<<i)) or 'none',
                    closed_gate_count=closed.bit_count(),retained_rows=kept,candidate_draw_denominator=len(g),
                    candidate_count=g.system_id.nunique(),draws_per_candidate=g.draw_id.nunique(),retained_frequency=kept/len(g)))
    versions=pd.DataFrame(version_rows);out(versions,'fig5_gate_reconstruction')
    current=versions[versions.version.eq('current')]
    joint=read('core_joint_gate_closure.csv').merge(current,on=['scenario','closed_gate_mask'],validate='one_to_one')
    check('all 448 joint-closure values independently reproduced',np.allclose(joint.retained_candidate_draw_frequency,joint.retained_frequency,rtol=0,atol=1e-12))
    depth=versions.groupby(['scenario','version','closed_gate_count'],as_index=False).agg(median_retained_frequency=('retained_frequency','median'),minimum=('retained_frequency','min'),maximum=('retained_frequency','max'),subsets=('retained_frequency','size'))
    out(depth,'fig5_depth_version_comparison')
    official=read('core_gate_closure_depth_response.csv').merge(depth[depth.version.eq('current')],on=['scenario','closed_gate_count'],suffixes=('_output','_recomputed'))
    check('all Fig5 depth statistics reproduced',np.allclose(official.median_retained_frequency_output,official.median_retained_frequency_recomputed,atol=1e-12))
    coal=depth[depth.scenario.eq('coal_flexibility_storage')&depth.closed_gate_count.eq(5)].set_index('version')
    check('old and current coal values follow only TMS cycle flag',np.isclose(coal.loc['current','median_retained_frequency'],.625) and np.isclose(coal.loc['counterfactual_previous_tms_cycle_label','median_retained_frequency'],.6875),coal.reset_index().to_dict('records'))
    mapping=pd.DataFrame([dict(bit=i,mask=1<<i,gate=n,draw_column=c,source='sampled complete-duty result' if i==0 else 'atomic registry',detail='corrosion gap OR nonclosable direct risk; diagnostic closure includes both' if i==1 else 'same candidate-draw flag as baseline') for i,(n,c) in enumerate(GATES)])
    out(mapping,'fig5_gate_mapping')

    # Reconstruct every finite primary utility from stored sampled components and the registered random stream.
    members=pd.read_csv(IN/'core_candidate_scenario_membership.csv');utility_checks=[]
    for si,scenario in enumerate(s.index):
        ids=members[members.scenario.eq(scenario)].system_id.tolist();g=draws[draws.scenario.eq(scenario)]
        def pivot(col):return g.pivot(index='draw_id',columns='system_id',values=col).reindex(columns=ids).to_numpy()
        feasible=pivot('gate_failure_count')==0
        energy=pivot('complete_service_energy_density_kWh_m3').astype(float)
        q=normalise_by_draw(energy,feasible)
        ss={dim:pivot('sampled_'+dim).astype(float) for dim in ATOMIC_DIMS}
        cc,bb=credibility_score(ss,pivot('sampled_engineering_burden_index').astype(float),feasible)
        w=np.random.default_rng(760076+100000+si*10000+101).dirichlet([1,1],len(q))
        u=hierarchical_utility(q,cc,w,feasible)
        stored=pivot('balanced_utility').astype(float)
        maxerr=float(np.max(np.abs(u[feasible]-stored[feasible]))) if feasible.any() else 0
        cerr=float(np.max(np.abs(cc[feasible]-pivot('sampled_engineering_credibility')[feasible]))) if feasible.any() else 0
        ties=int(((u==np.max(u,axis=1)[:,None]).sum(axis=1)[feasible.any(axis=1)]>1).sum())
        utility_checks.append(dict(scenario=scenario,rows=int(u.size),eligible_rows=int(feasible.sum()),max_utility_error=maxerr,max_credibility_error=cerr,finite_maximum_ties=ties))
        check(scenario+' sampled utility reconstruction',maxerr<1e-12 and cerr<1e-12)
    out(pd.DataFrame(utility_checks),'utility_reconstruction')
    # Modal disclosure must call the very same burden function as the operational score.
    active=ledger[ledger.modal_decision_feasible]
    expected=1/(1+active.burden_index_mid/2)
    check('modal disclosure fixed burden anchor matches operational code',np.allclose(active.inverse_burden_mid_fixed_anchor,expected))
    profile=read('core_candidate_readiness_profile.csv')
    short=read('core_credibility_shortfall_decomposition.csv')
    z=short[short.credibility_dimension.eq('inverse_burden')].merge(profile[['scenario','system_id','engineering_burden_index']],on=['scenario','system_id'],validate='one_to_one')
    check('diagnostic shortfall uses operational burden anchor',np.allclose(z.dimension_score,1/(1+z.engineering_burden_index/2)))
    from run_retrospective_masking import run as run_masking
    masking=run_masking()
    check('retrospective masking calculation executes without independence claim',masking['status']=='PASS' and not masking['source_independent'])
    facts=dict(gate_rows=len(gate),interval_rows=len(scores),source_links=len(links),expanded_pairs=len(ex),utility_rows=len(draws),coal_depth5=coal.reset_index().to_dict('records'))
    inputs=[IN/'core_atomic_engineering_credibility_registry.csv',T/'core_monte_carlo_draws_balanced.csv',T/'core_gate_closure_depth_response.csv',ROOT/'src/decision_model.py',ROOT/'src/run_traceability_audit.py']
    report=dict(status='PASS' if all(c['passed'] for c in checks) else 'FAIL',checks=checks,facts=facts,input_sha256={x.relative_to(ROOT).as_posix():digest(x) for x in inputs},
                scope='Traceability disclosure and deterministic numerical reconstruction. Retained registry acceptance is not upgraded to experimentally established compatibility.')
    Q.mkdir(parents=True,exist_ok=True);(Q/'TRACEABILITY_AUDIT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(report,indent=2,ensure_ascii=False));assert report['status']=='PASS'

if __name__=='__main__':run()
