from pathlib import Path
import pandas as pd
from upstream_extensions import _evidence_score_audit_tables

VERSION='core'
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'/'tables'
IN=ROOT/'data'/'input'
D=pd.read_csv(OUT/f'{VERSION}_candidate_system_metrics_deterministic.csv')
DRAWS=pd.read_csv(
    OUT/f'{VERSION}_monte_carlo_draws_balanced.csv',
    usecols=['scenario','scenario_label','system_id','display_system','draw_id','sampled_engineering_credibility'],
    dtype={'scenario':'category','scenario_label':'category','system_id':'category','display_system':'category','draw_id':'int32','sampled_engineering_credibility':'float64'},
)
ATOMIC=pd.read_csv(IN/f'{VERSION}_atomic_engineering_credibility_registry.csv')
APP=pd.read_csv(IN/f'{VERSION}_candidate_scenario_evidence_registry.csv')
result=_evidence_score_audit_tables(VERSION,OUT,D,DRAWS,ATOMIC,APP)
summary = result["draw_summary"]
expected_groups = D[["scenario", "scenario_label", "system_id", "display_system"]].drop_duplicates().shape[0]
if len(summary) != expected_groups:
    raise RuntimeError(f"Scoring-audit group count mismatch: {len(summary)} != {expected_groups}")
if int(summary["monte_carlo_rows"].sum()) != len(DRAWS):
    raise RuntimeError("Scoring-audit row conservation failed")
print({k:len(v) for k,v in result.items()})
