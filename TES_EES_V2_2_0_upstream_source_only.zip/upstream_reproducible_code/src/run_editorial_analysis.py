from __future__ import annotations
from pathlib import Path
import json, os
import numpy as np
import pandas as pd
from ai_property_model_v2 import run_ai_property_audit

VERSION='core'; ROOT=Path(__file__).resolve().parents[1]
AI_TREES=max(5,int(os.getenv('TES_AI_TREES','80')))
OUT=ROOT/'outputs'/'tables'; QC=ROOT/'outputs'/'qc'; IN=ROOT/'data'/'input'
OUT.mkdir(parents=True,exist_ok=True); QC.mkdir(parents=True,exist_ok=True)

validation, audit, fire = run_ai_property_audit(ROOT, VERSION, AI_TREES)

# Joint coverage × evidence threshold map, recomputed from the current 20,000-draw base.
mc=pd.read_csv(OUT/f'{VERSION}_monte_carlo_draws_balanced.csv',usecols=['scenario','scenario_label','draw_id','system_id','display_system','coverage','sampled_engineering_credibility'])
atomic=pd.read_csv(IN/f'{VERSION}_atomic_engineering_credibility_registry.csv')
direct=atomic.set_index(['scenario','system_id']).nonclosable_direct_risk.astype(bool).to_dict()
regime_rows=[]
coverage_thresholds=[0.95,0.975,0.99,0.995,0.999,1.0]
evidence_thresholds=np.round(np.arange(0.25,0.951,0.05),2)
for (scenario,label),g in mc.groupby(['scenario','scenario_label'],sort=False):
    members=g.system_id.drop_duplicates().tolist(); names=g.drop_duplicates('system_id').set_index('system_id').display_system.to_dict(); draws=np.sort(g.draw_id.unique())
    cov=g.pivot(index='draw_id',columns='system_id',values='coverage').reindex(index=draws,columns=members).to_numpy(float)
    cre=g.pivot(index='draw_id',columns='system_id',values='sampled_engineering_credibility').reindex(index=draws,columns=members).to_numpy(float)
    allowed=np.array([not direct.get((scenario,m),False) for m in members],bool)
    for ct in coverage_thresholds:
        for et in evidence_thresholds:
            avail=(cov>=ct)&(cre>=et)&allowed[None,:]
            count=avail.sum(axis=1); freq=avail.mean(axis=0); j=int(np.argmax(freq)) if len(freq) else 0
            no=float(np.mean(count==0)); expected=float(np.mean(count))
            regime='no bounded access' if no>=1-1e-12 else ('robust access' if no<=0.10 else 'conditional access')
            regime_rows.append({'scenario':scenario,'scenario_label':label,'coverage_threshold':ct,'evidence_threshold':et,'no_selection_frequency':no,'expected_bounded_candidate_count':expected,'single_candidate_frequency':float(np.mean(count==1)),'multiple_candidate_frequency':float(np.mean(count>=2)),'most_available_candidate':members[j],'most_available_candidate_label':names[members[j]],'most_available_candidate_frequency':float(freq[j]),'decision_regime':regime,'scope':'availability regime under joint coverage and sampled engineering-credibility thresholds; candidate utility weights are not re-optimized'})
regime=pd.DataFrame(regime_rows); regime.to_csv(OUT/f'{VERSION}_joint_threshold_regime_map.csv',index=False)
summary=[]
for (scenario,label),g in regime.groupby(['scenario','scenario_label']):
    n=len(g); summary.append({'scenario':scenario,'scenario_label':label,'robust_regime_share':float((g.decision_regime=='robust access').sum()/n),'conditional_regime_share':float((g.decision_regime=='conditional access').sum()/n),'no_access_regime_share':float((g.decision_regime=='no bounded access').sum()/n),'minimum_no_selection_frequency':float(g.no_selection_frequency.min()),'maximum_no_selection_frequency':float(g.no_selection_frequency.max()),'maximum_expected_candidate_count':float(g.expected_bounded_candidate_count.max())})
pd.DataFrame(summary).to_csv(OUT/f'{VERSION}_joint_threshold_regime_summary.csv',index=False)

syn=pd.read_csv(OUT/f'{VERSION}_gate_pair_synergy_summary.csv')
syn=syn[syn.nonzero_service_count.gt(0)].sort_values(['nonzero_service_count','maximum_absolute_synergy'],ascending=[False,False])
syn.to_csv(OUT/f'{VERSION}_nonzero_gate_pair_synergy.csv',index=False)

# Scientific-boundary audit.
trans=pd.read_csv(OUT/f'{VERSION}_figure_selection_alluvial_flows.csv')
portfolio=pd.read_csv(OUT/f'{VERSION}_research_action_nondominance_assessment.csv')
source=(ROOT/'src/upstream_extensions.py').read_text(encoding='utf-8')
block=source[source.index('if action in {"exact_composition_corrosion_closure"'):source.index('if action in {"pcm_cycling_phase_closure"')]
boundary=pd.DataFrame([
{'check':'fixed complete-service redirection','passed':set(trans.from_layer)=={'strict_complete_thermophysical'} and set(trans.to_layer)=={'strict_complete_evidence_bounded'},'detail':str(trans[['from_layer','to_layer']].drop_duplicates().to_dict('records'))},
{'check':'corrosion closure leaves independent burden unchanged','passed':'burden[' not in block,'detail':'exact-composition corrosion action changes only its named gap and compatibility score'},
{'check':'main research-action non-dominance eligibility contains evidence actions only','passed':portfolio.loc[portfolio.comparison_eligible,'action_type'].isin(['evidence_acquisition','evidence_programme']).all(),'detail':str(portfolio.loc[portfolio.comparison_eligible,['closure_action','action_type']].to_dict('records'))},
{'check':'incommensurate adverse composite removed','passed':'adverse_effect_magnitude' not in portfolio.columns,'detail':'adverse outcomes are retained as explicit counts and flags'},
{'check':'AI decision firewall passed','passed':fire.passed.all(),'detail':'current-version AI validation, applicability and firewall tables generated in this run'}])
boundary.to_csv(OUT/f'{VERSION}_scientific_boundary_audit.csv',index=False)
summary={'status':'PASS' if boundary.passed.all() else 'FAIL','ai_validation_rows':len(validation),'ai_candidate_rows':len(audit),'nonzero_synergy_pairs':len(syn),'scientific_boundary_checks':len(boundary),'scientific_boundary_failures':int((~boundary.passed).sum())}
(QC/f'{VERSION}_EDITORIAL_EXTENSION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
