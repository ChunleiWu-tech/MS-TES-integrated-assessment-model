from __future__ import annotations

from collections import Counter
from itertools import combinations, permutations
from math import factorial
from pathlib import Path
import hashlib
import json
import shutil
import warnings

import numpy as np
import pandas as pd

BASE = "core"
PARENT = "decision_boundary"
VERSION = "statistical"
ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
CONFIG = ROOT / "config"
SEED = 135_760_076
N_BOOT = 500
MATERIALITY = 0.01
BLOCKS = ("thermophysical", "evidence", "preference")
ATOMIC_DIMS = (
    "corrosion_compatibility",
    "cycling_phase_stability",
    "containment_validation",
    "literature_replication",
    "data_completeness",
)
GAP_MAP = {
    "corrosion_compatibility": "gap_corrosion",
    "cycling_phase_stability": "gap_cycling_phase",
    "containment_validation": "gap_containment",
    "literature_replication": "gap_literature_validation",
    "data_completeness": "gap_data_completeness",
}
CLOSURE_FLOOR = {
    "corrosion_compatibility": 0.75,
    "cycling_phase_stability": 0.75,
    "containment_validation": 0.75,
    "literature_replication": 0.80,
    "data_completeness": 0.75,
}
EVIDENCE_FAIL_COLS = (
    "failed_no_bounded_selection_policy",
    "failed_corrosion_gate",
    "failed_cycling_phase_gate",
    "failed_containment_gate",
    "failed_validation_gate",
    "failed_data_completeness_gate",
    "failed_claim_gate",
)


def read(stem: str, version: str = BASE, **kwargs) -> pd.DataFrame:
    path = TABLES / f"{version}_{stem}.csv"
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, **kwargs)


def write(frame: pd.DataFrame, stem: str) -> Path:
    path = TABLES / f"{VERSION}_{stem}.csv"
    frame.to_csv(path, index=False)
    return path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def copy_parent_outputs() -> list[Path]:
    copied: list[Path] = []
    for src in TABLES.glob(f"{PARENT}_*.csv"):
        dst = TABLES / src.name.replace(f"{PARENT}_", f"{VERSION}_", 1)
        shutil.copy2(src, dst)
        copied.append(dst)
    return copied


def minmax_rows(values: np.ndarray, valid: np.ndarray) -> np.ndarray:
    masked = np.where(valid & np.isfinite(values), values, np.nan).astype(float)
    row_has_value = np.isfinite(masked).any(axis=1)
    lo = np.full((masked.shape[0], 1), np.nan, dtype=float)
    hi = np.full((masked.shape[0], 1), np.nan, dtype=float)
    if row_has_value.any():
        lo[row_has_value, 0] = np.nanmin(masked[row_has_value], axis=1)
        hi[row_has_value, 0] = np.nanmax(masked[row_has_value], axis=1)
    span = hi - lo
    denom = np.where(span > 1e-12, span, 1.0)
    out = (masked - lo) / denom
    equal = row_has_value & (span[:, 0] <= 1e-12)
    if equal.any():
        out[equal] = np.where(np.isfinite(masked[equal]), 0.5, np.nan)
    out[~valid] = np.nan
    return out


def credibility(scores: dict[str, np.ndarray], burden: np.ndarray, feasible: np.ndarray) -> np.ndarray:
    inv = 1.0 - minmax_rows(burden, feasible)
    stack = np.stack([scores[d] for d in ATOMIC_DIMS] + [inv], axis=2)
    out = np.exp(np.nanmean(np.log(np.clip(stack, 1e-9, 1.0)), axis=2))
    out[~feasible] = np.nan
    return out


def nondominated(x: np.ndarray, y: np.ndarray, valid: np.ndarray) -> np.ndarray:
    out = np.zeros(len(x), dtype=bool)
    ids = np.flatnonzero(valid & np.isfinite(x) & np.isfinite(y))
    for i in ids:
        out[i] = not any(
            x[j] >= x[i] and y[j] >= y[i] and (x[j] > x[i] or y[j] > y[i])
            for j in ids if j != i
        )
    return out


def entropy_labels(labels: np.ndarray) -> float:
    if len(labels) == 0:
        return 0.0
    counts = np.array(list(Counter(labels.tolist()).values()), dtype=float)
    p = counts / counts.sum()
    return float(-(p * np.log2(p)).sum())


def mutual_information_labels(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) == 0:
        return 0.0
    joint = Counter(zip(x.tolist(), y.tolist()))
    cx = Counter(x.tolist()); cy = Counter(y.tolist()); n = float(len(x))
    mi = 0.0
    for (a, b), nij in joint.items():
        pxy = nij / n; px = cx[a] / n; py = cy[b] / n
        mi += pxy * np.log2(pxy / (px * py))
    return float(mi)


def bootstrap_mean_ci(flags: np.ndarray, rng: np.random.Generator, n_boot: int = N_BOOT) -> tuple[float, float]:
    flags = np.asarray(flags, dtype=float)
    if len(flags) == 0:
        return np.nan, np.nan
    n = len(flags)
    vals = np.empty(n_boot, dtype=float)
    for b in range(n_boot):
        vals[b] = flags[rng.integers(0, n, n)].mean()
    return float(np.quantile(vals, 0.05)), float(np.quantile(vals, 0.95))


def scenario_arrays(g: pd.DataFrame) -> tuple[list[int], list[str], dict[str, np.ndarray]]:
    draws = sorted(g.draw_id.unique().tolist())
    systems = g.system_id.drop_duplicates().tolist()
    arrays: dict[str, np.ndarray] = {}
    fields = [
        "coverage", "strict_complete", "partial_overlap_energy_density_kWh_m3",
        "complete_service_energy_density_kWh_m3", "sampled_engineering_burden_index",
        *[f"sampled_{d}" for d in ATOMIC_DIMS], *EVIDENCE_FAIL_COLS,
    ]
    for col in fields:
        arrays[col] = (
            g.pivot(index="draw_id", columns="system_id", values=col)
            .reindex(index=draws, columns=systems).to_numpy()
        )
    return draws, systems, arrays


def robust_pareto_uncertainty() -> tuple[pd.DataFrame, pd.DataFrame]:
    cols = [
        "scenario", "scenario_label", "draw_id", "system_id", "display_system",
        "coverage", "strict_complete", "partial_overlap_energy_density_kWh_m3",
        "complete_service_energy_density_kWh_m3", "sampled_engineering_burden_index",
        *[f"sampled_{d}" for d in ATOMIC_DIMS], *EVIDENCE_FAIL_COLS,
    ]
    mc = read("monte_carlo_draws_balanced", usecols=cols)
    summary_rows: list[dict] = []
    representative_rows: list[dict] = []
    for sidx, ((scenario, label), g) in enumerate(mc.groupby(["scenario", "scenario_label"], sort=False)):
        draws, systems, a = scenario_arrays(g)
        names = g.drop_duplicates("system_id").set_index("system_id").display_system.to_dict()
        physical = (a["coverage"].astype(float) > 0) & np.isfinite(a["partial_overlap_energy_density_kWh_m3"].astype(float))
        pscore = minmax_rows(a["partial_overlap_energy_density_kWh_m3"].astype(float), physical)
        scores = {d: a[f"sampled_{d}"].astype(float) for d in ATOMIC_DIMS}
        cscore = credibility(scores, a["sampled_engineering_burden_index"].astype(float), physical)
        strict = a["strict_complete"].astype(bool) & physical

        opportunity_flags = np.zeros_like(physical, dtype=bool)
        strict_flags = np.zeros_like(strict, dtype=bool)
        for i in range(len(draws)):
            opportunity_flags[i] = nondominated(pscore[i], cscore[i], physical[i])
            strict_flags[i] = nondominated(pscore[i], cscore[i], strict[i])

        # A single common representative draw is selected for each service, avoiding a synthetic
        # combination of separately estimated marginal medians.
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=RuntimeWarning)
            med_p = np.nanmedian(np.where(physical, pscore, np.nan), axis=0)
            med_c = np.nanmedian(np.where(physical, cscore, np.nan), axis=0)
            scale_p = np.nanquantile(np.where(physical, pscore, np.nan), .75, axis=0) - np.nanquantile(np.where(physical, pscore, np.nan), .25, axis=0)
            scale_c = np.nanquantile(np.where(physical, cscore, np.nan), .75, axis=0) - np.nanquantile(np.where(physical, cscore, np.nan), .25, axis=0)
        scale_p = np.where(np.isfinite(scale_p) & (scale_p > 1e-9), scale_p, 1.0)
        scale_c = np.where(np.isfinite(scale_c) & (scale_c > 1e-9), scale_c, 1.0)
        dist = np.zeros(len(draws), dtype=float)
        nterm = np.zeros(len(draws), dtype=float)
        for j in range(len(systems)):
            v = physical[:, j] & np.isfinite(pscore[:, j]) & np.isfinite(cscore[:, j])
            dist[v] += ((pscore[v, j] - med_p[j]) / scale_p[j]) ** 2 + ((cscore[v, j] - med_c[j]) / scale_c[j]) ** 2
            nterm[v] += 2
        mean_dist = np.full(len(draws), np.inf, dtype=float)
        np.divide(dist, nterm, out=mean_dist, where=nterm > 0)
        dist = mean_dist
        rep_i = int(np.argmin(dist))
        rep_opp = nondominated(pscore[rep_i], cscore[rep_i], physical[rep_i])
        rep_strict = nondominated(pscore[rep_i], cscore[rep_i], strict[rep_i])

        rng = np.random.default_rng(SEED + sidx * 1000)
        for j, sid in enumerate(systems):
            for scope_name, valid, flags, repflag in [
                ("opportunity", physical[:, j] & np.isfinite(pscore[:, j]) & np.isfinite(cscore[:, j]), opportunity_flags[:, j], rep_opp[j]),
                ("strict", strict[:, j] & np.isfinite(pscore[:, j]) & np.isfinite(cscore[:, j]), strict_flags[:, j], rep_strict[j]),
            ]:
                xv = pscore[valid, j]
                yv = cscore[valid, j]
                fv = flags[valid]
                if len(xv):
                    cov = np.cov(np.column_stack([xv, yv]), rowvar=False, ddof=1) if len(xv) > 1 else np.full((2, 2), np.nan)
                    if np.isfinite(cov).all():
                        vals, vecs = np.linalg.eigh(cov)
                        order = np.argsort(vals)[::-1]
                        vals, vecs = vals[order], vecs[:, order]
                        chi90 = 4.605170186
                        major, minor = np.sqrt(np.clip(vals, 0, None) * chi90)
                        angle = float(np.degrees(np.arctan2(vecs[1, 0], vecs[0, 0])))
                    else:
                        major = minor = angle = np.nan
                    lo, hi = bootstrap_mean_ci(fv, rng)
                    freq = float(np.mean(fv))
                else:
                    cov = np.full((2, 2), np.nan)
                    major = minor = angle = lo = hi = freq = np.nan
                if np.isfinite(freq):
                    if freq >= .5 and lo >= .5:
                        robust_class = "majority-supported robust frontier member"
                    elif freq >= .5:
                        robust_class = "majority frontier member with interval crossing 0.5"
                    elif freq >= .1:
                        robust_class = "conditional frontier member"
                    elif freq > 0:
                        robust_class = "rare frontier member"
                    else:
                        robust_class = "not observed on frontier"
                else:
                    robust_class = "not evaluable"
                summary_rows.append({
                    "scenario": scenario, "scenario_label": label, "system_id": sid,
                    "display_system": names[sid], "frontier_scope": scope_name,
                    "joint_valid_draws": int(valid.sum()), "representative_draw_id": int(draws[rep_i]),
                    "representative_performance_score": float(pscore[rep_i, j]) if np.isfinite(pscore[rep_i, j]) else np.nan,
                    "representative_credibility_score": float(cscore[rep_i, j]) if np.isfinite(cscore[rep_i, j]) else np.nan,
                    "representative_frontier_member": bool(repflag),
                    "performance_median": float(np.nanmedian(xv)) if len(xv) else np.nan,
                    "credibility_median": float(np.nanmedian(yv)) if len(yv) else np.nan,
                    "performance_q05": float(np.nanquantile(xv, .05)) if len(xv) else np.nan,
                    "performance_q95": float(np.nanquantile(xv, .95)) if len(xv) else np.nan,
                    "credibility_q05": float(np.nanquantile(yv, .05)) if len(yv) else np.nan,
                    "credibility_q95": float(np.nanquantile(yv, .95)) if len(yv) else np.nan,
                    "cov_pp": float(cov[0, 0]), "cov_pc": float(cov[0, 1]), "cov_cc": float(cov[1, 1]),
                    "ellipse90_major_radius": float(major), "ellipse90_minor_radius": float(minor),
                    "ellipse90_angle_deg": float(angle), "frontier_membership_frequency": freq,
                    "frontier_frequency_bootstrap_p05": lo, "frontier_frequency_bootstrap_p95": hi,
                    "frontier_robustness_class": robust_class,
                    "threshold_50_member": bool(np.isfinite(freq) and freq >= .5),
                    "threshold_75_member": bool(np.isfinite(freq) and freq >= .75),
                    "threshold_90_member": bool(np.isfinite(freq) and freq >= .90),
                    "interpretation_boundary": "The representative frontier uses one common joint draw per service. The 90% ellipse is a propagated joint uncertainty region, not a confidence interval for a fixed material constant.",
                })
            representative_rows.append({
                "scenario": scenario, "scenario_label": label, "representative_draw_id": int(draws[rep_i]),
                "joint_distance_to_service_medians": float(dist[rep_i]),
                "selection_rule": "single common draw closest to the service-wide joint median profile after IQR scaling",
            })
    return pd.DataFrame(summary_rows), pd.DataFrame(representative_rows).drop_duplicates()


def evaluate_state(
    performance: np.ndarray,
    strict: np.ndarray,
    evidence_allowed: np.ndarray,
    scores: dict[str, np.ndarray],
    burden: np.ndarray,
    weights: np.ndarray,
    systems: list[str],
    continuous_only_strict: bool = False,
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    # Continuous layer is deliberately upstream of categorical evidence gating. It quantifies the
    # latent top-one–top-two utility margin among strict-complete candidates and is not used to
    # explain candidate identity or no-selection.
    p_strict = minmax_rows(performance, strict)
    c_strict = credibility(scores, burden, strict)
    latent = weights[:, [0]] * p_strict + weights[:, [1]] * c_strict
    latent[~strict] = np.nan
    finite_count = np.isfinite(latent).sum(axis=1)
    work = np.where(np.isfinite(latent), latent, -np.inf)
    if work.shape[1] >= 2:
        top2 = np.partition(work, kth=work.shape[1]-2, axis=1)[:, -2:]
        top2.sort(axis=1)
        margin = np.full(len(top2), np.nan, dtype=float)
        finite_pair = np.isfinite(top2[:, 0]) & np.isfinite(top2[:, 1])
        margin[finite_pair] = top2[finite_pair, 1] - top2[finite_pair, 0]
        margin[finite_count < 2] = np.nan
    else:
        margin = np.full(len(weights), np.nan)

    feasible = strict & evidence_allowed
    p = minmax_rows(performance, feasible)
    c = credibility(scores, burden, feasible)
    utility = weights[:, [0]] * p + weights[:, [1]] * c
    utility[~feasible] = -np.inf
    no = ~np.isfinite(utility).any(axis=1)
    winner = np.argmax(utility, axis=1)
    labels = np.array(["__NO_SELECTION__" if no[i] else systems[int(winner[i])] for i in range(len(no))], dtype=object)
    bounded_count = feasible.sum(axis=1).astype(float)
    return margin, labels, bounded_count


def shapley_from_set_function(values: dict[frozenset[str], float]) -> dict[str, float]:
    n = len(BLOCKS)
    out: dict[str, float] = {}
    for b in BLOCKS:
        phi = 0.0
        others = [x for x in BLOCKS if x != b]
        for k in range(len(others) + 1):
            for comb in combinations(others, k):
                s = frozenset(comb)
                weight = factorial(k) * factorial(n - k - 1) / factorial(n)
                phi += weight * (values[s | {b}] - values[s])
        out[b] = float(phi)
    return out


def blockwise_uncertainty_attribution() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    cols = [
        "scenario", "scenario_label", "draw_id", "system_id", "display_system", "strict_complete",
        "complete_service_energy_density_kWh_m3", "sampled_engineering_burden_index",
        *[f"sampled_{d}" for d in ATOMIC_DIMS], *EVIDENCE_FAIL_COLS,
    ]
    mc = read("monte_carlo_draws_balanced", usecols=cols)
    cont_rows: list[dict] = []
    cat_rows: list[dict] = []
    state_rows: list[dict] = []
    design_rows: list[dict] = []
    subsets = [frozenset(c) for k in range(4) for c in combinations(BLOCKS, k)]

    for sidx, ((scenario, label), g) in enumerate(mc.groupby(["scenario", "scenario_label"], sort=False)):
        draws = sorted(g.draw_id.unique().tolist())
        systems = g.system_id.drop_duplicates().tolist()
        def pivot(col):
            return g.pivot(index="draw_id", columns="system_id", values=col).reindex(index=draws, columns=systems).to_numpy()
        perf = pivot("complete_service_energy_density_kWh_m3").astype(float)
        strict = pivot("strict_complete").astype(bool) & np.isfinite(perf)
        scores = {d: pivot(f"sampled_{d}").astype(float) for d in ATOMIC_DIMS}
        burden = pivot("sampled_engineering_burden_index").astype(float)
        evidence_allowed = np.ones(strict.shape, dtype=bool)
        for c in EVIDENCE_FAIL_COLS:
            evidence_allowed &= ~pivot(c).astype(bool)

        n = len(draws)
        rng = np.random.default_rng(SEED + 20_000 * sidx)
        pA, pB = rng.permutation(n), rng.permutation(n)
        eA, eB = rng.permutation(n), rng.permutation(n)
        wA, wB = rng.dirichlet(np.ones(2), n), rng.dirichlet(np.ones(2), n)

        outputs: dict[frozenset[str], tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
        for subset in subsets:
            pi = pA if "thermophysical" in subset else pB
            ei = eA if "evidence" in subset else eB
            w = wA if "preference" in subset else wB
            sc = {d: scores[d][ei] for d in ATOMIC_DIMS}
            outputs[subset] = evaluate_state(perf[pi], strict[pi], evidence_allowed[ei], sc, burden[ei], w, systems)

        full = frozenset(BLOCKS)
        y_margin, y_label, y_count = outputs[full]
        var_fun: dict[frozenset[str], float] = {}
        info_fun: dict[frozenset[str], float] = {}
        pair_n: dict[frozenset[str], int] = {}
        for subset in subsets:
            margin, labels, bcount = outputs[subset]
            mask = np.isfinite(y_margin) & np.isfinite(margin)
            pair_n[subset] = int(mask.sum())
            if mask.sum() >= 3:
                var_fun[subset] = float(np.cov(y_margin[mask], margin[mask], ddof=1)[0, 1])
            else:
                var_fun[subset] = 0.0
            info_fun[subset] = mutual_information_labels(y_label, labels)
            design_rows.append({
                "scenario": scenario, "scenario_label": label,
                "shared_blocks_with_reference_output": ";".join(sorted(subset)) or "none",
                "continuous_pick_freeze_covariance": var_fun[subset],
                "continuous_paired_valid_draws": pair_n[subset],
                "categorical_mutual_information_bits": info_fun[subset],
                "hybrid_selection_entropy_bits": entropy_labels(labels),
                "hybrid_no_selection_frequency": float(np.mean(labels == "__NO_SELECTION__")),
                "mean_bounded_candidate_count": float(np.mean(bcount)),
                "design_note": "Pick-and-freeze hybrid: listed blocks are shared with reference sample A; remaining blocks come from independent sample B.",
            })

        phi_v = shapley_from_set_function(var_fun)
        phi_i = shapley_from_set_function(info_fun)
        v_total = var_fun[full] - var_fun[frozenset()]
        i_total = info_fun[full] - info_fun[frozenset()]
        for b in BLOCKS:
            cont_rows.append({
                "scenario": scenario, "scenario_label": label, "uncertainty_block": b,
                "shapley_variance_contribution": phi_v[b],
                "normalized_shapley_variance_share": phi_v[b] / v_total if abs(v_total) > 1e-12 else np.nan,
                "full_continuous_margin_variance": var_fun[full],
                "independent_reference_covariance": var_fun[frozenset()],
                "full_continuous_margin_valid_fraction": float(np.isfinite(y_margin).mean()),
                "continuous_response": "latent top-one–top-two utility margin among strict-complete candidates before categorical evidence gating",
                "method": "pick-and-freeze Shapley effects using covariance estimates of Var(E[margin|block subset])",
            })
            cat_rows.append({
                "scenario": scenario, "scenario_label": label, "uncertainty_block": b,
                "shapley_information_contribution_bits": phi_i[b],
                "normalized_shapley_information_share": phi_i[b] / i_total if abs(i_total) > 1e-12 else np.nan,
                "full_selection_entropy_bits": entropy_labels(y_label),
                "independent_reference_mutual_information_bits": info_fun[frozenset()],
                "full_no_selection_frequency": float(np.mean(y_label == "__NO_SELECTION__")),
                "categorical_response": "selected candidate identity including no-selection as a distinct category",
                "method": "pick-and-freeze Shapley allocation of mutual information; no linear ANOVA is applied to category labels",
            })

        # Signed interactions are transparent diagnostics and are not plotted as additive shares.
        for a, b in combinations(BLOCKS, 2):
            cont_rows.append({
                "scenario": scenario, "scenario_label": label, "uncertainty_block": f"interaction:{a}×{b}",
                "shapley_variance_contribution": var_fun[frozenset({a, b})] - var_fun[frozenset({a})] - var_fun[frozenset({b})] + var_fun[frozenset()],
                "normalized_shapley_variance_share": np.nan,
                "full_continuous_margin_variance": var_fun[full],
                "independent_reference_covariance": var_fun[frozenset()],
                "full_continuous_margin_valid_fraction": float(np.isfinite(y_margin).mean()),
                "continuous_response": "signed pairwise interaction diagnostic",
                "method": "pick-and-freeze inclusion-exclusion interaction; not a main-effect share",
            })
            cat_rows.append({
                "scenario": scenario, "scenario_label": label, "uncertainty_block": f"interaction:{a}×{b}",
                "shapley_information_contribution_bits": info_fun[frozenset({a, b})] - info_fun[frozenset({a})] - info_fun[frozenset({b})] + info_fun[frozenset()],
                "normalized_shapley_information_share": np.nan,
                "full_selection_entropy_bits": entropy_labels(y_label),
                "independent_reference_mutual_information_bits": info_fun[frozenset()],
                "full_no_selection_frequency": float(np.mean(y_label == "__NO_SELECTION__")),
                "categorical_response": "signed pairwise interaction diagnostic",
                "method": "pick-and-freeze inclusion-exclusion interaction; not a main-effect share",
            })

        full_entropy = entropy_labels(y_label)
        full_no = float(np.mean(y_label == "__NO_SELECTION__"))
        max_strict = int(np.max(strict.sum(axis=1)))
        unique_non_no = len(set(y_label.tolist()) - {"__NO_SELECTION__"})
        if max_strict == 0:
            cls = "service-incomplete"
        elif full_no >= .999:
            cls = "evidence-locked"
        elif max_strict == 1 and unique_non_no == 1 and full_entropy > 1e-6:
            cls = "evidence-variable-single-candidate"
        elif full_entropy < 1e-6 and unique_non_no <= 1:
            cls = "deterministic-single-candidate"
        elif np.isfinite(phi_i["preference"]) and i_total > 1e-12 and phi_i["preference"] / i_total >= .25:
            cls = "preference-sensitive"
        else:
            cls = "stochastic-multicandidate"
        state_rows.append({
            "scenario": scenario, "scenario_label": label,
            "uncertainty_structure_class": cls,
            "maximum_strict_complete_candidates_per_draw": max_strict,
            "full_selection_entropy_bits": full_entropy,
            "full_no_selection_frequency": full_no,
            "full_continuous_margin_variance": var_fun[full],
            "full_continuous_margin_valid_fraction": float(np.isfinite(y_margin).mean()),
            "distinct_selected_candidates_excluding_no_selection": unique_non_no,
            "interpretation": "Zero variance or zero entropy is classified structurally and is not interpreted as evidence that the service is resolved.",
        })
    return pd.DataFrame(cont_rows), pd.DataFrame(cat_rows), pd.DataFrame(state_rows), pd.DataFrame(design_rows)

def action_registry() -> pd.DataFrame:
    rows = [
        ("exact_composition_corrosion", "corrosion_compatibility", "", 2.0, "Exact-composition corrosion programme; favourable result closes the registered corrosion gap."),
        ("long_duration_cycling", "cycling_phase_stability", "", 2.0, "Cycling/phase-stability programme within a defensible service temperature window."),
        ("system_containment_qualification", "containment_validation", "corrosion_compatibility", 3.0, "System-level containment qualification requires corrosion compatibility to be closed or already adequate."),
        ("independent_replication", "literature_replication", "data_completeness", 2.0, "Independent replication requires a complete enough protocol/data package to reproduce."),
        ("full_interval_data_completion", "data_completeness", "", 2.0, "Exact-composition full-interval property and metadata completion."),
        ("integrated_compatibility_programme", "corrosion_compatibility;containment_validation", "", 3.5, "Joint corrosion and containment screening/qualification programme."),
        ("integrated_reproducibility_programme", "data_completeness;literature_replication", "", 3.0, "Joint data-completion and independent-replication programme."),
        ("comprehensive_evidence_programme", ";".join(ATOMIC_DIMS), "", 5.0, "Prospective upper-bound programme closing all registered atomic evidence gaps."),
    ]
    df = pd.DataFrame(rows, columns=["action_id", "closes_dimensions", "prerequisite_dimensions", "burden_ordinal", "scientific_rationale"])
    df["outcome_scope"] = "favourable-evidence reachability only; no probability of favourable, neutral, adverse or inconclusive outcomes is assumed"
    df["ordinal_warning"] = "burden is ordered, not cardinal cost or duration"
    return df


def admissible(actions: tuple[str, ...], registry: pd.DataFrame, baseline_ok: set[str]) -> tuple[bool, str, set[str], float]:
    r = registry.set_index("action_id")
    closed: set[str] = set()
    burden = 0.0
    for a in actions:
        closed.update(x for x in str(r.loc[a, "closes_dimensions"]).split(";") if x)
        burden += float(r.loc[a, "burden_ordinal"])
    available = baseline_ok | closed
    missing: list[str] = []
    for a in actions:
        prereq = [x for x in str(r.loc[a, "prerequisite_dimensions"]).split(";") if x and x != "nan"]
        for p in prereq:
            if p not in available:
                missing.append(f"{a} requires {p}")
    return len(missing) == 0, "; ".join(missing), closed, burden


def utility_metrics(performance: np.ndarray, scores: dict[str, np.ndarray], burden: np.ndarray,
                    strict: np.ndarray, allowed: np.ndarray, weights: np.ndarray,
                    systems: list[str]) -> tuple[dict[str, float | str], np.ndarray]:
    feasible = strict & allowed[None, :]
    pscore = minmax_rows(performance, feasible)
    cscore = credibility(scores, burden, feasible)
    utility = weights[:, [0]] * pscore + weights[:, [1]] * cscore
    utility[~feasible] = -np.inf
    no = ~np.isfinite(utility).any(axis=1)
    winner = np.argmax(utility, axis=1)
    counts = np.array([np.mean((winner == j) & ~no) for j in range(len(systems))])
    leader = systems[int(np.argmax(counts))] if counts.max(initial=0) > 0 else "__NO_SELECTION__"
    probs = np.append(counts[counts > 0], no.mean())
    probs = probs[probs > 0]
    ent = float(-(probs * np.log2(probs)).sum()) if len(probs) else 0.0
    return {"no_selection_frequency": float(no.mean()), "selection_entropy_bits": ent, "modal_leader_system_id": leader}, counts


def dag_constrained_backtrace() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    registry = action_registry()
    cols = [
        "scenario", "scenario_label", "draw_id", "system_id", "display_system", "strict_complete",
        "complete_service_energy_density_kWh_m3", "sampled_engineering_burden_index",
        *[f"sampled_{d}" for d in ATOMIC_DIMS],
    ]
    mc = read("monte_carlo_draws_balanced", usecols=cols)
    ledger = read("candidate_service_evidence_score_ledger")
    scope = read("decision_scope_matrix", PARENT)
    states: list[dict] = []
    minimal_rows: list[dict] = []
    rejected: list[dict] = []
    action_ids = registry.action_id.tolist()

    # Enumerate the small action catalogue once. Decision calculations are performed once per
    # unique required closure state, not once per syntactic action combination.
    catalogue: list[dict] = []
    for k in range(len(action_ids) + 1):
        for aset in combinations(action_ids, k):
            # Candidate-specific baseline adequacy is handled below; here only action-internal
            # prerequisites are provisionally evaluated with no baseline dimensions.
            closed: set[str] = set()
            burden_value = 0.0
            rr = registry.set_index("action_id")
            for a in aset:
                closed.update(x for x in str(rr.loc[a, "closes_dimensions"]).split(";") if x)
                burden_value += float(rr.loc[a, "burden_ordinal"])
            catalogue.append({"actions": aset, "closed": closed, "burden": burden_value})

    for sidx, ((scenario, label), g) in enumerate(mc.groupby(["scenario", "scenario_label"], sort=False)):
        draws = sorted(g.draw_id.unique().tolist())
        systems = g.system_id.drop_duplicates().tolist()
        def pivot(col):
            return g.pivot(index="draw_id", columns="system_id", values=col).reindex(index=draws, columns=systems).to_numpy()
        performance = pivot("complete_service_energy_density_kWh_m3").astype(float)
        strict = pivot("strict_complete").astype(bool) & np.isfinite(performance)
        scores0 = {d: pivot(f"sampled_{d}").astype(float) for d in ATOMIC_DIMS}
        burden = pivot("sampled_engineering_burden_index").astype(float)
        reg = ledger[ledger.scenario.eq(scenario)].drop_duplicates("system_id").set_index("system_id").reindex(systems)
        direct = reg.nonclosable_direct_risk.fillna(False).astype(bool).to_numpy()
        gaps = {d: reg[GAP_MAP[d]].fillna(False).astype(bool).to_numpy() for d in ATOMIC_DIMS}
        baseline_allowed = ~(np.column_stack(list(gaps.values())).any(axis=1) | direct)
        weights = np.random.default_rng(SEED + 50_000 + sidx).dirichlet(np.ones(2), len(draws))
        base_met, base_counts = utility_metrics(performance, scores0, burden, strict, baseline_allowed, weights, systems)

        for j, sid in enumerate(systems):
            sr = scope[(scope.scenario == scenario) & (scope.system_id == sid)]
            if sr.empty:
                continue
            sr = sr.iloc[0]
            required = {d for d in ATOMIC_DIMS if gaps[d][j]}
            baseline_ok = set(ATOMIC_DIMS) - required
            if direct[j] or float(sr.strict_complete_service_probability) <= 0:
                minimal_rows.append({
                    "scenario": scenario, "scenario_label": label, "system_id": sid,
                    "display_system": sr.display_system, "target": "reach_1pct_selection",
                    "admissible_minimal_action_set": "not reachable",
                    "closed_dimensions": ";".join(sorted(required)) or "none",
                    "action_count": np.nan, "burden_ordinal": np.nan,
                    "selection_frequency_after_action": np.nan,
                    "no_selection_reduction": np.nan,
                    "leader_changed": False,
                    "reachability_class": "direct-risk excluded" if direct[j] else str(sr.decision_scope_class),
                    "analysis_scope": "favourable-evidence reachability; no expected-value claim",
                })
                continue

            admissible_sets: list[dict] = []
            for item in catalogue:
                aset = item["actions"]
                ok, why, closed, research_burden = admissible(aset, registry, baseline_ok)
                if not ok:
                    rejected.append({
                        "scenario": scenario,
                        "system_id": sid,
                        "action_set": ";".join(aset) or "none",
                        "rejection_reason": why,
                        "covers_all_required_dimensions": bool(required.issubset(closed)),
                        "audit_scope": "candidate-specific DAG admissibility; a rejected route is never evaluated as a decision-changing path",
                    })
                    continue
                if required.issubset(closed):
                    admissible_sets.append({"actions": aset, "closed": closed, "burden": research_burden})

            # Keep only action-count/burden non-dominated routes, then remove closure-equivalent
            # duplicates. The physical decision effect is evaluated once because all retained
            # routes close the same registered target gaps under the favourable-evidence bound.
            keep: list[dict] = []
            for item in admissible_sets:
                dominated = any(
                    other["burden"] <= item["burden"] and len(other["actions"]) <= len(item["actions"]) and
                    (other["burden"] < item["burden"] or len(other["actions"]) < len(item["actions"]))
                    for other in admissible_sets
                )
                if not dominated:
                    keep.append(item)
            uniq: dict[tuple, dict] = {}
            for item in sorted(keep, key=lambda z: (z["burden"], len(z["actions"]), z["actions"])):
                key = (tuple(sorted(item["closed"])), item["burden"], len(item["actions"]))
                uniq.setdefault(key, item)
            keep = list(uniq.values())

            allowed = baseline_allowed.copy()
            allowed[j] = True
            scores = {d: x.copy() for d, x in scores0.items()}
            for d in required:
                scores[d][:, j] = np.maximum(scores[d][:, j], CLOSURE_FLOOR[d])
            met, counts = utility_metrics(performance, scores, burden, strict, allowed, weights, systems)
            freq = float(counts[j])
            delta_no = float(base_met["no_selection_frequency"] - met["no_selection_frequency"])
            leader_changed = met["modal_leader_system_id"] != base_met["modal_leader_system_id"]

            for item in keep:
                rec = {
                    "scenario": scenario, "scenario_label": label, "system_id": sid,
                    "display_system": sr.display_system,
                    "action_set": ";".join(item["actions"]) or "none",
                    "closed_dimensions": ";".join(sorted(item["closed"])) or "none",
                    "unresolved_required_dimensions": "none",
                    "admissible": True, "action_count": len(item["actions"]),
                    "burden_ordinal": float(item["burden"]),
                    "target_selection_frequency": freq,
                    "delta_target_selection_frequency": float(freq - base_counts[j]),
                    "no_selection_frequency": met["no_selection_frequency"],
                    "delta_no_selection_frequency": delta_no,
                    "selection_entropy_bits": met["selection_entropy_bits"],
                    "modal_leader_system_id": met["modal_leader_system_id"],
                    "leader_changed": leader_changed,
                    "outcome_assumption": "favourable evidence reaches the registered closure floor; neutral/adverse/inconclusive outcomes are not assigned probabilities",
                }
                states.append(rec)

            target_status = {
                "become_bounded": True,
                "reach_1pct_selection": freq >= MATERIALITY,
                "alter_top_choice": leader_changed,
            }
            for target, reached in target_status.items():
                if not reached or not keep:
                    minimal_rows.append({
                        "scenario": scenario, "scenario_label": label, "system_id": sid,
                        "display_system": sr.display_system, "target": target,
                        "admissible_minimal_action_set": "not reachable",
                        "closed_dimensions": ";".join(sorted(required)) or "none",
                        "action_count": np.nan, "burden_ordinal": np.nan,
                        "selection_frequency_after_action": np.nan,
                        "no_selection_reduction": np.nan, "leader_changed": False,
                        "reachability_class": "not reachable under registered favourable-evidence actions",
                        "analysis_scope": "favourable-evidence reachability; no expected-value claim",
                    })
                else:
                    for item in keep:
                        minimal_rows.append({
                            "scenario": scenario, "scenario_label": label, "system_id": sid,
                            "display_system": sr.display_system, "target": target,
                            "admissible_minimal_action_set": ";".join(item["actions"]) or "none",
                            "closed_dimensions": ";".join(sorted(item["closed"])) or "none",
                            "action_count": len(item["actions"]), "burden_ordinal": float(item["burden"]),
                            "selection_frequency_after_action": freq,
                            "no_selection_reduction": delta_no,
                            "leader_changed": leader_changed,
                            "reachability_class": "reachable under favourable evidence",
                            "analysis_scope": "favourable-evidence reachability; no expected-value claim",
                        })
    rejected_df = pd.DataFrame(rejected, columns=[
        "scenario", "system_id", "action_set", "rejection_reason",
        "covers_all_required_dimensions", "audit_scope",
    ])
    return pd.DataFrame(states), pd.DataFrame(minimal_rows), rejected_df

def main() -> None:
    TABLES.mkdir(parents=True, exist_ok=True)
    QC.mkdir(parents=True, exist_ok=True)
    copied = copy_parent_outputs()
    baseline_files = [
        TABLES / f"{BASE}_integrated_system_decision_table.csv",
        TABLES / f"{BASE}_monte_carlo_draws_balanced.csv",
        TABLES / f"{BASE}_layered_selection_frequencies.csv",
    ]
    before = {p.name: sha256(p) for p in baseline_files}

    pareto, rep = robust_pareto_uncertainty()
    cont, cat, structure, design = blockwise_uncertainty_attribution()
    dag = action_registry()
    states, minima, rejected = dag_constrained_backtrace()
    outcome = pd.DataFrame([
        {"outcome_scenario": "favourable", "score_update": "raise closed dimensions to registered closure floor", "probability_assigned": False, "use": "decision-boundary reachability upper bound"},
        {"outcome_scenario": "neutral", "score_update": "no decision-relevant change", "probability_assigned": False, "use": "scenario bound only"},
        {"outcome_scenario": "adverse", "score_update": "candidate may remain excluded or acquire a direct-risk flag", "probability_assigned": False, "use": "scenario bound only"},
        {"outcome_scenario": "inconclusive", "score_update": "evidence gap remains open", "probability_assigned": False, "use": "scenario bound only"},
    ])

    outputs = {
        "pareto_joint_uncertainty_and_robustness": pareto,
        "pareto_representative_draw_registry": rep,
        "continuous_decision_variance_attribution": cont,
        "categorical_selection_information_attribution": cat,
        "structural_stochastic_uncertainty_classification": structure,
        "uncertainty_block_activation_design": design,
        "evidence_action_dag_registry": dag,
        "dag_constrained_decision_boundary_states": states,
        "dag_constrained_minimal_action_sets": minima,
        "inadmissible_action_combination_audit": rejected,
        "evidence_action_outcome_scenario_registry": outcome,
    }
    paths = [write(df, stem) for stem, df in outputs.items()]
    after = {p.name: sha256(p) for p in baseline_files}
    invariant = before == after
    status = {
        "version": VERSION,
        "status": "PASS" if invariant else "FAIL",
        "parent_version": PARENT,
        "strict_baseline_unchanged": invariant,
        "parent_diagnostic_tables_copied": len(copied),
        "generated_or_corrected_tables": {p.name: int(pd.read_csv(p).shape[0]) for p in paths},
        "methodological_corrections": [
            "continuous latent utility margins use variance/Shapley attribution",
            "candidate identity and no-selection use entropy/information attribution rather than linear ANOVA",
            "Pareto analysis uses a single common representative draw, joint uncertainty ellipses and bootstrap frontier frequencies",
            "decision-boundary paths are filtered through an auditable evidence-action DAG",
            "favourable-evidence reachability is separated from expected research value",
        ],
    }
    (QC / f"{VERSION}_STATISTICAL_EXTENSION_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))
    if not invariant:
        raise SystemExit("Frozen strict baseline changed")


if __name__ == "__main__":
    main()
