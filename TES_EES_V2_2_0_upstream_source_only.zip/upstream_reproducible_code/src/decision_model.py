from __future__ import annotations

from dataclasses import dataclass
import numpy as np
import pandas as pd

ATOMIC_DIMS = (
    "corrosion_compatibility",
    "cycling_phase_stability",
    "containment_validation",
    "literature_replication",
    "data_completeness",
)
GAP_COLS = (
    "gap_corrosion",
    "gap_cycling_phase",
    "gap_containment",
    "gap_literature_validation",
    "gap_data_completeness",
)

TOP_LEVEL_PRIORS = {
    "performance_emphasis": np.array([3.0, 1.0]),
    "balanced": np.array([1.0, 1.0]),
    "credibility_emphasis": np.array([1.0, 3.0]),
    "engineering_conservative": np.array([1.0, 2.0]),
}

CREDIBILITY_MODELS = (
    "hierarchical_geometric",
    "hierarchical_arithmetic",
    "no_literature_replication",
    "no_data_completeness",
    "bottleneck_minimum",
)

# A fixed, candidate-independent burden anchor removes the former dependence
# of a candidate's credibility on which competitors happened to be present.
# A burden index of 2 maps to a value of 0.5.
BURDEN_HALF_VALUE = 2.0


def normalise_by_draw(values: np.ndarray, feasible: np.ndarray, benefit: bool = True) -> np.ndarray:
    output = np.full_like(values, np.nan, dtype=float)
    for i in range(values.shape[0]):
        mask = feasible[i] & np.isfinite(values[i])
        if not mask.any():
            continue
        v = values[i, mask]
        lo = float(np.min(v)); hi = float(np.max(v))
        if hi - lo < 1e-12:
            output[i, mask] = 0.5
        else:
            output[i, mask] = (v - lo) / (hi - lo)
    return output if benefit else 1.0 - output


def fixed_inverse_burden_value(burden_index: np.ndarray, feasible: np.ndarray) -> np.ndarray:
    value = 1.0 / (1.0 + np.asarray(burden_index, dtype=float) / BURDEN_HALF_VALUE)
    value[~feasible] = np.nan
    return value


def scenario_registry(registry: pd.DataFrame, scenario: str, members: list[str]) -> pd.DataFrame:
    sub = registry[registry.scenario.eq(scenario)].drop_duplicates("system_id").set_index("system_id")
    missing = sorted(set(members) - set(sub.index))
    if missing:
        raise ValueError(f"{scenario}: missing atomic credibility rows for {missing}")
    return sub.loc[members].reset_index()


def sample_atomic_scores(reg: pd.DataFrame, n_draws: int, rng: np.random.Generator) -> tuple[dict[str, np.ndarray], np.ndarray]:
    sampled: dict[str, np.ndarray] = {}
    for dim in ATOMIC_DIMS:
        lo = reg[f"{dim}_low"].to_numpy(float)
        mid = reg[f"{dim}_mid"].to_numpy(float)
        hi = reg[f"{dim}_high"].to_numpy(float)
        arr = np.column_stack([rng.triangular(lo[j], mid[j], hi[j], n_draws) for j in range(len(reg))])
        sampled[dim] = np.clip(arr, 1e-6, 1.0)
    blo = reg["burden_index_low"].to_numpy(float)
    bmid = reg["burden_index_mid"].to_numpy(float)
    bhi = reg["burden_index_high"].to_numpy(float)
    burden = np.column_stack([rng.triangular(blo[j], bmid[j], bhi[j], n_draws) for j in range(len(reg))])
    return sampled, burden


def deterministic_atomic_scores(reg: pd.DataFrame, n_draws: int) -> tuple[dict[str, np.ndarray], np.ndarray]:
    scores = {dim: np.tile(reg[f"{dim}_mid"].to_numpy(float), (n_draws, 1)) for dim in ATOMIC_DIMS}
    burden = np.tile(reg["burden_index_mid"].to_numpy(float), (n_draws, 1))
    return scores, burden


def unresolved_gaps(reg: pd.DataFrame) -> np.ndarray:
    gaps = reg[list(GAP_COLS)].astype(bool).to_numpy()
    direct = reg["nonclosable_direct_risk"].astype(bool).to_numpy()[:, None]
    return np.column_stack([gaps, direct])


def baseline_allowed(reg: pd.DataFrame) -> np.ndarray:
    return ~(reg[list(GAP_COLS)].astype(bool).any(axis=1).to_numpy() | reg["nonclosable_direct_risk"].astype(bool).to_numpy())


def credibility_score(
    scores: dict[str, np.ndarray],
    burden_index: np.ndarray,
    feasible: np.ndarray,
    model: str = "hierarchical_geometric",
) -> tuple[np.ndarray, np.ndarray]:
    if model not in CREDIBILITY_MODELS:
        raise ValueError(f"Unknown credibility model: {model}")
    inverse_burden = fixed_inverse_burden_value(burden_index, feasible)
    dims = list(ATOMIC_DIMS)
    if model == "no_literature_replication":
        dims.remove("literature_replication")
    if model == "no_data_completeness":
        dims.remove("data_completeness")
    stack = np.stack([scores[d] for d in dims] + [inverse_burden], axis=2)
    valid = feasible & np.all(np.isfinite(stack), axis=2)
    if model == "bottleneck_minimum":
        cred = np.nanmin(stack, axis=2)
    elif model == "hierarchical_arithmetic":
        cred = np.nanmean(stack, axis=2)
    else:
        # Equal-weight geometric aggregation: no single weak engineering dimension
        # can be fully compensated by repeatedly counting correlated evidence signals.
        cred = np.exp(np.nanmean(np.log(np.clip(stack, 1e-6, 1.0)), axis=2))
    cred[~valid] = np.nan
    return cred, inverse_burden


def hierarchical_utility(
    performance_score: np.ndarray,
    credibility: np.ndarray,
    top_weights: np.ndarray,
    feasible: np.ndarray,
) -> np.ndarray:
    utility = top_weights[:, [0]] * performance_score + top_weights[:, [1]] * credibility
    utility[~feasible] = -np.inf
    return utility


def draw_outcomes(utility: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    no = np.all(~np.isfinite(utility), axis=1)
    winners = np.argmax(utility, axis=1)
    counts = np.array([np.mean((winners == j) & (~no)) for j in range(utility.shape[1])])
    return no, winners, counts
