from __future__ import annotations
from pathlib import Path
import json

from release_paths import ENVIRONMENT_STATUS, ENVIRONMENT_STATUS_COMPAT, first_existing

VERSION = 'core'
ROOT = Path(__file__).resolve().parents[1]
QC = ROOT / 'outputs' / 'qc'


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))


base = read_json(QC / f'{VERSION}_FINAL_VALIDATION_SUMMARY.json')
innovation = read_json(QC / f'{VERSION}_INNOVATION_VALIDATION_SUMMARY.json')
high = read_json(QC / f'{VERSION}_HIGH_DENSITY_VALIDATION_SUMMARY.json')
presentation = read_json(QC / f'{VERSION}_PRESENTATION_EXTENSION_STATUS.json')
env_path = first_existing(QC, ENVIRONMENT_STATUS, ENVIRONMENT_STATUS_COMPAT)
if env_path is None:
    raise FileNotFoundError(
        f'Missing environment status. Expected {ENVIRONMENT_STATUS} '
        f'(canonical) or {ENVIRONMENT_STATUS_COMPAT} (compatibility alias).'
    )
env = read_json(env_path)

status = 'PASS' if all(x.get('status') == 'PASS' for x in [base, innovation, high, presentation, env]) else 'FAIL'
summary = {
    'status': status,
    'version': VERSION,
    'base_scientific_checks': base.get('critical_checks', len(base.get('checks', []))),
    'base_critical_failures': base.get('critical_failures'),
    'innovation_checks': innovation.get('checks'),
    'innovation_critical_failures': innovation.get('critical_failures'),
    'high_density_checks': high.get('critical_checks'),
    'high_density_critical_failures': high.get('critical_failures'),
    'presentation_dedup_checks': len(presentation.get('checks', [])),
    'presentation_dedup_status': presentation.get('status'),
    'combined_scientific_checks': (
        base.get('critical_checks', len(base.get('checks', [])))
        + innovation.get('checks', 0)
        + high.get('critical_checks', 0)
        + len(presentation.get('checks', []))
    ),
    'environment_status': env.get('status'),
    'environment_status_file': env_path.name,
    'scope': 'Base thermophysical/evidence decision model plus service-conditioned contraction, rank reversal, transparent archetypes, SMAA-style acceptability, prospective evidence value, rank ladders, credibility-shortfall decomposition, stress-case scorecards and high-density figure support, exact-profile deduplication, structural-zero control and grouped presentation support.',
}
failures = sum(
    int(x or 0)
    for x in [
        summary['base_critical_failures'],
        summary['innovation_critical_failures'],
        summary['high_density_critical_failures'],
    ]
)
(QC / f'{VERSION}_RELEASE_VALIDATION_SUMMARY.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
(QC / f'{VERSION}_RELEASE_QC_STATUS.json').write_text(
    json.dumps({'status': status, 'critical_failures': failures}, indent=2),
    encoding='utf-8',
)
print(json.dumps(summary, indent=2))
if status != 'PASS':
    raise SystemExit(1)
