from __future__ import annotations
from pathlib import Path

# Canonical, version-free release-contract filenames.  Semantic table prefixes
# such as core/submission/statistical are scientific namespaces, not package
# version identifiers.
ENVIRONMENT_STATUS = "environment_status.json"
ENVIRONMENT_STATUS_COMPAT = "core_ENVIRONMENT_STATUS.json"
UPSTREAM_RELEASE_STATUS = "UPSTREAM_RELEASE_STATUS.json"
UPSTREAM_RELEASE_STATUS_COMPAT = "submission_UPSTREAM_STATUS.json"
UPSTREAM_RELEASE_CONTRACT_AUDIT = "UPSTREAM_RELEASE_CONTRACT_AUDIT.json"


def first_existing(folder: Path, *names: str) -> Path | None:
    for name in names:
        path = folder / name
        if path.exists():
            return path
    return None
