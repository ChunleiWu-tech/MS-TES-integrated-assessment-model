"""Condition-resolved corrosion evidence and paired decision-model sensitivity.

Observed corrosion endpoints are kept separate from analyst-defined evidence
indices. Missing condition matches never become zero corrosion or successful
qualification. Annualized measurements do not constitute lifetime predictions.
"""
from __future__ import annotations
import hashlib
import json
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
from decision_model import ATOMIC_DIMS, credibility_score, normalise_by_draw

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/input"
OUT = ROOT / "outputs/tables"
QC = ROOT / "outputs/qc"


def standardized_observations(source: pd.DataFrame) -> pd.DataFrame:
    data = source.copy()
    factors = {"mm/year": 1000.0, "um/year": 1.0}
    if not data.reported_unit.isin(factors).all():
        raise ValueError("Unknown corrosion unit")
    if not data.relation.isin(["point", "less_than"]).all():
        raise ValueError("Unknown censoring relation")
    data["rate_or_upper_bound_um_per_year"] = data.reported_value * data.reported_unit.map(factors)
    data["spread_um_per_year"] = data.reported_spread * data.reported_unit.map(factors)
    data["sampling_error_model"] = "not_assigned"
    data["independent_study_unit"] = data.study_id
    return data


def threshold_table(data: pd.DataFrame, rules: dict) -> pd.DataFrame:
    rows = []
    for obs in data.itertuples(index=False):
        for threshold in rules["rate_thresholds_um_per_year"]:
            rate = obs.rate_or_upper_bound_um_per_year
            # A reported r < B establishes r <= threshold only when B <= threshold.
            if obs.relation == "less_than":
                classification = "below_threshold" if rate <= threshold else "indeterminate"
                margin_relation = "greater_than"
            else:
                classification = "at_or_below_threshold" if rate <= threshold else "above_threshold"
                margin_relation = "point"
            rows.append(dict(observation_id=obs.observation_id, study_id=obs.study_id,
                             endpoint=obs.endpoint, threshold_um_per_year=threshold,
                             margin=threshold/rate, margin_relation=margin_relation,
                             classification=classification,
                             uncertainty_interpretation="reported_endpoint_not_confidence_bound"))
    return pd.DataFrame(rows)


def composition_transfer(data: pd.DataFrame, rules: dict) -> pd.DataFrame:
    # Explicit comparison targets transcribed from the frozen property registry.
    targets = {
        "knc": ("mol_pct", {"KNO2":25.9,"KNO3":68.7,"K2CO3":5.4}),
        "mgcl_kcl_nacl": ("wt_pct", {"MgCl2":45.98,"KCl":38.91,"NaCl":15.11}),
        "linak_carbonate": ("wt_pct", {"Li2CO3":32.12,"Na2CO3":33.36,"K2CO3":34.52}),
    }
    molecular_mass = {"MgCl2":95.211,"NaCl":58.443,"KCl":74.5513}
    rows = []
    for obs in data.itertuples(index=False):
        reported = json.loads(obs.composition_json)
        for target, (basis, composition) in targets.items():
            same_components = set(reported) == set(composition)
            values = reported.copy()
            if same_components and obs.basis != basis:
                masses = {k:v*molecular_mass[k] for k,v in reported.items()}
                values = {k:100*v/sum(masses.values()) for k,v in masses.items()}
            delta = max(abs(values[k]-composition[k]) for k in values) if same_components else np.nan
            matched = same_components and delta <= rules["composition_max_component_tolerance_pct_points"]
            rows.append(dict(observation_id=obs.observation_id, target_system_id=target,
                             same_components=same_components, composition_match=matched,
                             max_component_difference_pct_points=delta,
                             additive=obs.additive, alloy=obs.alloy, temperature_C=obs.temperature_C,
                             duration_h=obs.duration_h, atmosphere=obs.atmosphere,
                             flow_regime=obs.flow_regime,
                             automatic_service_qualification=False,
                             transfer_status="composition_matched_condition_specific" if matched else "not_composition_matched"))
    return pd.DataFrame(rows)


def matched_comparisons(data: pd.DataFrame) -> pd.DataFrame:
    rows = []
    knc = data[data.system_id.eq("knc")]
    for alloy, group in knc.groupby("alloy"):
        rates = group.set_index("temperature_C").rate_or_upper_bound_um_per_year
        rows.append(dict(comparison="KNC_700C_over_500C", study_id="HUANG_KNC_2026", alloy=alloy,
                         numerator=rates[700], denominator=rates[500], ratio=rates[700]/rates[500],
                         endpoint="mass_loss_rate", shared_condition="same_alloy_composition_480h_air"))
    ding = data[data.study_id.eq("DING_2018")]
    for alloy, group in ding.groupby("alloy"):
        rates = group.set_index("endpoint").rate_or_upper_bound_um_per_year
        rows.append(dict(comparison="penetration_over_mass_loss", study_id="DING_2018", alloy=alloy,
                         numerator=rates.penetration_depth_rate, denominator=rates.mass_loss_rate,
                         ratio=rates.penetration_depth_rate/rates.mass_loss_rate,
                         endpoint="paired_distinct_measurement_methods", shared_condition="same_alloy_composition_700C_500h_Ar"))
    rows.append(dict(comparison="EG10wtpct_over_base_300C", study_id="WANG_EG_2021", alloy="316",
                     numerator=2.6, denominator=3.2, ratio=2.6/3.2, endpoint="reported_mean_rate",
                     shared_condition="same_base_composition_300C_1440h_air_published_numeric_endpoints"))
    return pd.DataFrame(rows)


def ranking_sensitivity(rules: dict) -> tuple[pd.DataFrame, pd.DataFrame]:
    columns = ["scenario","draw_id","system_id","strict_complete",
               "complete_service_energy_density_kWh_m3", "sampled_engineering_burden_index",
               "gate_failure_count"] + ["sampled_"+d for d in ATOMIC_DIMS]
    draws = pd.read_csv(OUT/"core_monte_carlo_draws_balanced.csv", usecols=columns)
    ranking, summary = [], []
    for scenario, sub in draws.groupby("scenario", sort=True):
        if sub.duplicated(["draw_id","system_id"]).any():
            raise ValueError("Duplicate candidate-draw key")
        def matrix(column):
            return sub.pivot(index="draw_id",columns="system_id",values=column).sort_index(axis=1)
        energy_df = matrix("complete_service_energy_density_kWh_m3")
        energy = energy_df.to_numpy(float)
        systems = list(energy_df.columns)
        feasible = matrix("strict_complete").to_numpy(bool) & (matrix("gate_failure_count").to_numpy(float) == 0)
        feasible &= np.isfinite(energy)
        scores = {d:matrix("sampled_"+d).to_numpy(float) for d in ATOMIC_DIMS}
        burden = matrix("sampled_engineering_burden_index").to_numpy(float)
        q = normalise_by_draw(energy, feasible, True)
        n = len(energy)
        for model in rules["aggregation_models"]:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", RuntimeWarning)
                cred, _ = credibility_score(scores, burden, feasible, model)
            for weight in rules["credibility_weight_grid"]:
                utility = (1-weight)*q + weight*cred
                utility[~feasible] = -np.inf
                no_selection = ~feasible.any(axis=1)
                max_u = utility.max(axis=1)
                ties = np.isclose(utility, max_u[:,None], rtol=0, atol=1e-12) & feasible
                count = ties.sum(axis=1)
                # Split numerical ties; candidate ordering must not determine the result.
                shares = ties / np.maximum(count,1)[:,None]
                probabilities = shares.mean(axis=0)
                half_diff = np.max(abs(shares[:n//2].mean(axis=0)-shares[n//2:].mean(axis=0)))
                for j, system in enumerate(systems):
                    ranking.append(dict(scenario=scenario,aggregation=model,credibility_weight=weight,
                                        system_id=system,selection_frequency=probabilities[j],
                                        numerical_mc_se=float(shares[:,j].std(ddof=1)/np.sqrt(n)),
                                        mc_draws=n))
                leader = systems[int(np.argmax(probabilities))] if probabilities.max()>0 else "none"
                summary.append(dict(scenario=scenario,aggregation=model,credibility_weight=weight,
                                    modal_leader=leader,leader_selection_frequency=probabilities.max(),
                                    no_selection_frequency=no_selection.mean(),
                                    tie_frequency=np.mean(count>1),mc_draws=n,
                                    half_sample_max_abs_frequency_difference=half_diff,
                                    probability_sum=float(probabilities.sum()+no_selection.mean())))
    return pd.DataFrame(ranking),pd.DataFrame(summary)


def main():
    OUT.mkdir(parents=True,exist_ok=True); QC.mkdir(parents=True,exist_ok=True)
    source_path = INPUT/"engineering_corrosion_observations.csv"
    rule_path = ROOT/"config/engineering_evidence_rules.json"
    rules = json.loads(rule_path.read_text(encoding="utf-8"))
    raw = pd.read_csv(source_path)
    data = standardized_observations(raw)
    if not data.observation_id.is_unique or not (data.reported_value>0).all():
        raise ValueError("Invalid observation key or nonpositive corrosion rate")
    products = {
        "engineering_corrosion_endpoints":data,
        "engineering_rate_threshold_sensitivity":threshold_table(data,rules),
        "engineering_composition_transfer":composition_transfer(data,rules),
        "engineering_matched_comparisons":matched_comparisons(data),
    }
    ranks, settings = ranking_sensitivity(rules)
    products["engineering_score_sensitivity"] = ranks
    products["engineering_score_sensitivity_summary"] = settings
    for name, table in products.items(): table.to_csv(OUT/(name+".csv"),index=False)
    payload = dict(status="PASS", observations=len(data),studies=data.study_id.nunique(),
                   comparison_targets=3,settings=len(settings),mc_draws=sorted(settings.mc_draws.unique().tolist()),
                   source_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest(),
                   rules_sha256=hashlib.sha256(rule_path.read_bytes()).hexdigest(),
                   quantitative_probability_calibration=False,
                   interpretation="Conditional observed rate margins and decision-model sensitivity; evidence indices are not measured reliability probabilities.")
    (QC/"engineering_evidence_status.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
    print(json.dumps(payload,indent=2))


if __name__ == "__main__": main()
