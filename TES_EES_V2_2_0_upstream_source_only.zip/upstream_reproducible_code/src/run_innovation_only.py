from __future__ import annotations
from pathlib import Path
import json
from innovation_extensions import run_innovation_extensions
ROOT=Path(__file__).resolve().parents[1]
innovation=run_innovation_extensions(ROOT,'core',760076)
print(json.dumps({'innovation':innovation},indent=2))
