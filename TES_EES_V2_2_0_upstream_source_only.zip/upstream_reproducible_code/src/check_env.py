from __future__ import annotations
from pathlib import Path
import json, os, platform, sys
from importlib.metadata import version, PackageNotFoundError
from matplotlib import font_manager
from release_paths import ENVIRONMENT_STATUS, ENVIRONMENT_STATUS_COMPAT

ROOT = Path(__file__).resolve().parents[1]
QC = ROOT / "outputs" / "qc"
QC.mkdir(parents=True, exist_ok=True)
REQUIRED = {
    "numpy": "2.3.5",
    "pandas": "2.2.3",
    "matplotlib": "3.10.8",
    "Pillow": "12.3.0",
    "PyMuPDF": "1.26.7",
    "scipy": "1.17.0",
    "scikit-learn": "1.8.0",
}
versions, errors, warnings = {}, [], []
for package, expected in REQUIRED.items():
    try:
        actual = version(package)
    except PackageNotFoundError:
        actual = "NOT INSTALLED"
    versions[package] = actual
    if actual != expected:
        message = f"{package}: expected {expected}, found {actual}"
        if os.environ.get("ALLOW_VERSION_MISMATCH", "0") == "1":
            warnings.append(message)
        else:
            errors.append(message)
try:
    font_manager.findfont("Arial", fallback_to_default=False)
    arial_available = True
except Exception:
    arial_available = False
try:
    font_manager.findfont("STIXGeneral", fallback_to_default=False)
    stix_available = True
except Exception:
    stix_available = False
    errors.append("STIXGeneral is required as the mathtext fallback for subscripts and superscripts")
if sys.version_info[:2] != (3, 12) and os.environ.get("ALLOW_UNSUPPORTED_PYTHON", "0") != "1":
    errors.append(f"CPython 3.12 required, found {platform.python_version()}")
if sys.maxsize <= 2**32:
    errors.append("64-bit CPython is required for the registered 20,000-draw run")
out = {
    "status": "PASS" if not errors else "FAIL",
    "python": platform.python_version(),
    "platform": platform.platform(),
    "packages": versions,
    "font": {
        "text": "Arial",
        "arial_available": arial_available,
        "font_location_disclosed": False,
        "mathtext_fallback": "STIX Sans",
        "stix_available": stix_available,
    },
    "errors": errors,
    "warnings": warnings,
    "runtime": {
        "architecture_bits": 64 if sys.maxsize > 2**32 else 32,
        "monte_carlo_memory_policy": "draw-level rows are streamed to CSV; extension reload uses bounded dtypes",
    },
    "policy": "Exact Python/package versions and 64-bit CPython are required. Arial availability is reported for handoff to the post-processing package, where it is mandatory.",
}
payload = json.dumps(out, indent=2)
(QC / ENVIRONMENT_STATUS).write_text(payload, encoding="utf-8")
(QC / ENVIRONMENT_STATUS_COMPAT).write_text(payload, encoding="utf-8")
print(payload)
if errors:
    sys.exit(2)
