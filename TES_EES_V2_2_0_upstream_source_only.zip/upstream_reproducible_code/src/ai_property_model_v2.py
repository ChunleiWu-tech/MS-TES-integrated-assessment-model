from __future__ import annotations

"""Leakage-resistant, audit-only property models for the MSD-TP snapshot.

The models in this module are deliberately separated from the bounded decision
model.  They quantify what the database can support for discovery/audit and do
not impute any property or engineering-evidence gate used for selection.
"""

from dataclasses import dataclass
from pathlib import Path
import io
import json
import math
import re
import zipfile

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.compose import TransformedTargetRegressor
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GroupKFold, GroupShuffleSplit, KFold
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler


SEED = 760076
NOMINAL_COVERAGE = 0.90

# Standard atomic weights are used only to derive transparent mixture-level
# descriptors.  They are not property labels and do not alter direct evidence.
ATOMIC_WEIGHT = {
    "Al": 26.9815385, "Ba": 137.327, "Be": 9.0121831, "C": 12.011,
    "Ca": 40.078, "Cl": 35.45, "Cs": 132.90545196, "F": 18.998403163,
    "Gd": 157.25, "K": 39.0983, "La": 138.90547, "Li": 6.94,
    "Mg": 24.305, "N": 14.007, "Na": 22.98976928, "Nd": 144.242,
    "Np": 237.0, "O": 15.999, "Pr": 140.90766, "Pu": 244.0,
    "Rb": 85.4678, "Sr": 87.62, "Th": 232.0377, "U": 238.02891,
    "Zr": 91.224,
}
ATOMIC_NUMBER = {
    "Al": 13, "Ba": 56, "Be": 4, "C": 6, "Ca": 20, "Cl": 17,
    "Cs": 55, "F": 9, "Gd": 64, "K": 19, "La": 57, "Li": 3,
    "Mg": 12, "N": 7, "Na": 11, "Nd": 60, "Np": 93, "O": 8,
    "Pr": 59, "Pu": 94, "Rb": 37, "Sr": 38, "Th": 90, "U": 92,
    "Zr": 40,
}


def _number(value) -> float:
    match = re.search(r"[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?", str(value))
    return float(match.group()) if match else np.nan


def _range(value) -> tuple[float, float]:
    values = re.findall(r"[-+]?\d+(?:\.\d+)?", str(value))
    if len(values) < 2:
        return np.nan, np.nan
    lo, hi = float(values[0]), float(values[1])
    return (lo, hi) if lo <= hi else (hi, lo)


def _add_atoms(target: dict[str, float], formula: str, multiplier: float = 1.0) -> None:
    """Parse the simple salt formula notation used by MSD-TP and the shortlist."""
    token = re.compile(r"([A-Z][a-z]?|\(|\)|\d+(?:\.\d+)?)")
    tokens = token.findall(formula)

    def parse(pos: int) -> tuple[dict[str, float], int]:
        atoms: dict[str, float] = {}
        while pos < len(tokens):
            item = tokens[pos]
            if item == ")":
                return atoms, pos + 1
            if item == "(":
                nested, pos = parse(pos + 1)
                factor = 1.0
                if pos < len(tokens) and re.fullmatch(r"\d+(?:\.\d+)?", tokens[pos]):
                    factor = float(tokens[pos]); pos += 1
                for element, count in nested.items():
                    atoms[element] = atoms.get(element, 0.0) + factor * count
                continue
            if re.fullmatch(r"[A-Z][a-z]?", item):
                pos += 1
                count = 1.0
                if pos < len(tokens) and re.fullmatch(r"\d+(?:\.\d+)?", tokens[pos]):
                    count = float(tokens[pos]); pos += 1
                atoms[item] = atoms.get(item, 0.0) + count
                continue
            pos += 1
        return atoms, pos

    parsed, _ = parse(0)
    for element, count in parsed.items():
        target[element] = target.get(element, 0.0) + multiplier * count


def _composition(formula: str, comp) -> tuple[list[str], np.ndarray]:
    components = str(formula).split("-")
    if str(comp).strip().lower() == "pure salt":
        fractions = np.ones(1, dtype=float)
    else:
        try:
            fractions = np.array([float(x) for x in str(comp).split("-")], dtype=float)
        except ValueError:
            fractions = np.full(len(components), 1.0 / len(components), dtype=float)
    if len(fractions) != len(components) or not np.all(np.isfinite(fractions)) or fractions.sum() <= 0:
        fractions = np.full(len(components), 1.0 / len(components), dtype=float)
    else:
        fractions = fractions / fractions.sum()
    return components, fractions


def _mixture_mw(components: list[str], fractions: np.ndarray) -> float:
    total = 0.0
    for component, fraction in zip(components, fractions):
        atoms: dict[str, float] = {}
        _add_atoms(atoms, component)
        if any(element not in ATOMIC_WEIGHT for element in atoms):
            return np.nan
        total += fraction * sum(ATOMIC_WEIGHT[element] * count for element, count in atoms.items())
    return total


@dataclass(frozen=True)
class FeatureSchema:
    elements: tuple[str, ...]
    include_temperature: bool

    @property
    def names(self) -> list[str]:
        names = [f"atomic_fraction_{element}" for element in self.elements]
        names += [
            "mixture_molecular_weight_g_mol", "component_count",
            "normalised_composition_entropy", "mean_atomic_number",
            "mean_atomic_weight", "atomic_number_spread",
        ]
        if self.include_temperature:
            names.append("temperature_K")
        return names


def _row_features(formula: str, comp, schema: FeatureSchema, temperature_k: float | None = None) -> tuple[np.ndarray, set[str], float]:
    components, fractions = _composition(formula, comp)
    atoms: dict[str, float] = {}
    for component, fraction in zip(components, fractions):
        _add_atoms(atoms, component, float(fraction))
    total_atoms = sum(atoms.values())
    atomic_fraction = {element: count / total_atoms for element, count in atoms.items()} if total_atoms > 0 else {}
    unseen = set(atomic_fraction) - set(schema.elements)
    mw = _mixture_mw(components, fractions)
    entropy = 0.0
    if len(fractions) > 1:
        entropy = float(-np.sum(fractions * np.log(np.clip(fractions, 1e-12, None))) / np.log(len(fractions)))
    mean_z = sum(atomic_fraction.get(e, 0.0) * ATOMIC_NUMBER.get(e, 0.0) for e in atomic_fraction)
    mean_aw = sum(atomic_fraction.get(e, 0.0) * ATOMIC_WEIGHT.get(e, 0.0) for e in atomic_fraction)
    spread_z = math.sqrt(max(0.0, sum(atomic_fraction.get(e, 0.0) * (ATOMIC_NUMBER.get(e, 0.0) - mean_z) ** 2 for e in atomic_fraction)))
    values = [atomic_fraction.get(element, 0.0) for element in schema.elements]
    values += [mw, float(len(components)), entropy, mean_z, mean_aw, spread_z]
    if schema.include_temperature:
        values.append(float(temperature_k) if temperature_k is not None else np.nan)
    return np.asarray(values, dtype=float), unseen, mw


def _matrix(frame: pd.DataFrame, schema: FeatureSchema, temperature_col: str | None = None) -> np.ndarray:
    rows = []
    for row in frame.itertuples(index=False):
        temperature = getattr(row, temperature_col) if temperature_col else None
        values, _, _ = _row_features(row.formula, row.comp, schema, temperature)
        rows.append(values)
    return np.vstack(rows)


def _load_raw(root: Path) -> pd.DataFrame:
    archive = root / "data" / "raw_databases" / "msd-tp-master.zip"
    member = "msd-tp-master/Molten_Salt_Thermophysical_Properties.csv"
    with zipfile.ZipFile(archive) as handle:
        raw = pd.read_csv(io.BytesIO(handle.read(member)), keep_default_na=False)
    return raw


def _melt_dataset(raw: pd.DataFrame) -> tuple[pd.DataFrame, FeatureSchema]:
    frame = raw.copy()
    frame["target"] = frame["melt"].map(_number)
    frame = frame[np.isfinite(frame.target)].copy()
    elements = sorted({element for formula in frame.formula for element in re.findall(r"[A-Z][a-z]?", formula)})
    schema = FeatureSchema(tuple(elements), False)
    frame["group"] = frame.formula.astype(str)
    frame["record_id"] = np.arange(len(frame))
    return frame.reset_index(drop=True), schema


def _density_dataset(raw: pd.DataFrame) -> tuple[pd.DataFrame, FeatureSchema]:
    records: list[dict] = []
    for record_id, row in raw.iterrows():
        a = _number(row.rho_a); b = _number(row.rho_b); lo, hi = _range(row.rho_range)
        if not np.all(np.isfinite([a, b, lo, hi])) or hi <= lo:
            continue
        # MSD-TP defines rho[g cm-3] = A - B*T[K].  Five within-range
        # temperatures retain the functional target while grouping prevents
        # sampled points from leaking across validation folds.
        for temperature_k in np.linspace(lo, hi, 5):
            density = (a - b * temperature_k) * 1000.0
            if not 300.0 <= density <= 10000.0:
                continue
            records.append({
                "formula": row.formula, "comp": row.comp, "temperature_K": temperature_k,
                "target": density, "group": str(row.formula), "record_id": int(record_id),
            })
    frame = pd.DataFrame(records)
    elements = sorted({element for formula in frame.formula for element in re.findall(r"[A-Z][a-z]?", formula)})
    return frame.reset_index(drop=True), FeatureSchema(tuple(elements), True)


def _estimators(n_trees: int) -> dict[str, object]:
    return {
        "median_dummy": DummyRegressor(strategy="median"),
        "ridge": make_pipeline(StandardScaler(), Ridge(alpha=10.0)),
        "hist_gradient_boosting": make_pipeline(
            StandardScaler(),
            HistGradientBoostingRegressor(max_iter=250, learning_rate=0.05, max_leaf_nodes=15,
                                          l2_regularization=1.0, random_state=SEED),
        ),
        "extra_trees": ExtraTreesRegressor(
            n_estimators=n_trees, min_samples_leaf=3, max_features=0.8,
            random_state=SEED, n_jobs=-1,
        ),
    }


def _metrics(y: np.ndarray, prediction: np.ndarray) -> dict[str, float]:
    return {
        "r2": float(r2_score(y, prediction)),
        "mae": float(mean_absolute_error(y, prediction)),
        "rmse": float(mean_squared_error(y, prediction) ** 0.5),
    }


def _conformal_quantile(scores: np.ndarray, nominal: float) -> float:
    scores = np.asarray(scores, dtype=float)
    scores = scores[np.isfinite(scores)]
    level = min(1.0, math.ceil((len(scores) + 1) * nominal) / max(len(scores), 1))
    return float(np.quantile(scores, level, method="higher"))


def _fit_validate(frame: pd.DataFrame, schema: FeatureSchema, target_name: str, n_trees: int):
    X = _matrix(frame, schema, "temperature_K" if schema.include_temperature else None)
    y = frame.target.to_numpy(float)
    groups = frame.group.to_numpy(str)
    estimators = _estimators(n_trees)
    group_cv = GroupKFold(n_splits=min(5, len(np.unique(groups))))
    validation_rows: list[dict] = []
    fold_rows: list[dict] = []
    model_oof: dict[str, np.ndarray] = {}

    for model_name, estimator in estimators.items():
        prediction = np.full(len(frame), np.nan)
        for fold, (train, test) in enumerate(group_cv.split(X, y, groups), start=1):
            fitted = clone(estimator).fit(X[train], y[train])
            prediction[test] = fitted.predict(X[test])
            fold_rows.append({
                "target": target_name, "model": model_name, "fold": fold,
                "validation_scheme": "outer_formula_system_group_cv",
                "n_train_records": int(len(train)), "n_test_records": int(len(test)),
                "n_train_formula_systems": int(len(np.unique(groups[train]))),
                "n_test_formula_systems": int(len(np.unique(groups[test]))),
                **_metrics(y[test], prediction[test]),
            })
        model_oof[model_name] = prediction
        validation_rows.append({
            "target": target_name, "validation_scheme": "outer_formula_system_group_cv",
            "model": model_name, "selected_model": False, "n_records": int(len(frame)),
            "n_formula_groups": int(len(np.unique(groups))), **_metrics(y, prediction),
            "interval_nominal_coverage": np.nan, "interval_empirical_coverage": np.nan,
            "mean_interval_width": np.nan,
        })

    selected = min(
        (name for name in estimators if name != "median_dummy"),
        key=lambda name: mean_absolute_error(y, model_oof[name]),
    )
    for row in validation_rows:
        row["selected_model"] = row["model"] == selected

    # Random-record CV is retained only as an optimism diagnostic.  It is not
    # used for model selection, intervals, or scientific claims.
    random_prediction = np.full(len(frame), np.nan)
    random_cv = KFold(n_splits=5, shuffle=True, random_state=SEED)
    for train, test in random_cv.split(X):
        fitted = clone(estimators[selected]).fit(X[train], y[train])
        random_prediction[test] = fitted.predict(X[test])
    validation_rows.append({
        "target": target_name, "validation_scheme": "random_record_cv_optimism_diagnostic",
        "model": selected, "selected_model": False, "n_records": int(len(frame)),
        "n_formula_groups": int(len(np.unique(groups))), **_metrics(y, random_prediction),
        "interval_nominal_coverage": np.nan, "interval_empirical_coverage": np.nan,
        "mean_interval_width": np.nan,
    })

    # Nested split conformal evaluation.  Calibration groups and outer test
    # groups are disjoint from the model-fitting groups in every fold.
    test_prediction = np.full(len(frame), np.nan)
    lower = np.full(len(frame), np.nan); upper = np.full(len(frame), np.nan)
    fold_quantiles: list[float] = []
    for fold, (outer_train, outer_test) in enumerate(group_cv.split(X, y, groups), start=1):
        splitter = GroupShuffleSplit(n_splits=1, test_size=0.25, random_state=SEED + fold)
        sub_train_rel, calibration_rel = next(splitter.split(X[outer_train], y[outer_train], groups[outer_train]))
        sub_train = outer_train[sub_train_rel]; calibration = outer_train[calibration_rel]
        fitted = clone(estimators[selected]).fit(X[sub_train], y[sub_train])
        q = _conformal_quantile(np.abs(y[calibration] - fitted.predict(X[calibration])), NOMINAL_COVERAGE)
        prediction = fitted.predict(X[outer_test])
        test_prediction[outer_test] = prediction
        lower[outer_test] = prediction - q; upper[outer_test] = prediction + q
        fold_quantiles.append(q)
        fold_rows.append({
            "target": target_name, "model": selected, "fold": fold,
            "validation_scheme": "nested_group_split_conformal_test",
            "n_train_records": int(len(sub_train)), "n_test_records": int(len(outer_test)),
            "n_train_formula_systems": int(len(np.unique(groups[sub_train]))),
            "n_test_formula_systems": int(len(np.unique(groups[outer_test]))),
            **_metrics(y[outer_test], prediction), "calibration_records": int(len(calibration)),
            "conformal_half_width": q,
            "interval_empirical_coverage": float(np.mean((y[outer_test] >= prediction - q) & (y[outer_test] <= prediction + q))),
        })
    coverage = float(np.mean((y >= lower) & (y <= upper)))
    validation_rows.append({
        "target": target_name, "validation_scheme": "nested_group_split_conformal_test",
        "model": selected, "selected_model": True, "n_records": int(len(frame)),
        "n_formula_groups": int(len(np.unique(groups))), **_metrics(y, test_prediction),
        "interval_nominal_coverage": NOMINAL_COVERAGE,
        "interval_empirical_coverage": coverage,
        "mean_interval_width": float(np.nanmean(upper - lower)),
    })

    final_model = clone(estimators[selected]).fit(X, y)
    # For deployment intervals, calibrate a fresh model on a group-held-out
    # calibration subset, then refit the point model on all data.  The
    # calibration residuals remain independent of their fitting subset.
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.20, random_state=SEED + 99)
    train, calibration = next(splitter.split(X, y, groups))
    calibration_model = clone(estimators[selected]).fit(X[train], y[train])
    deployment_q = _conformal_quantile(np.abs(y[calibration] - calibration_model.predict(X[calibration])), NOMINAL_COVERAGE)

    scaler = StandardScaler().fit(X)
    Z = scaler.transform(X)
    neighbours = NearestNeighbors(n_neighbors=2).fit(Z)
    loo_distance = neighbours.kneighbors(Z)[0][:, 1]
    ad_threshold = float(np.quantile(loo_distance, 0.95))
    return {
        "model": final_model, "model_name": selected, "schema": schema,
        "X": X, "y": y, "groups": groups, "frame": frame,
        "scaler": scaler, "neighbours": neighbours, "ad_threshold": ad_threshold,
        "deployment_q": deployment_q, "nested_q_median": float(np.median(fold_quantiles)),
        "validation": validation_rows, "folds": fold_rows,
    }


def _candidate_compositions() -> dict[str, tuple[str, str]]:
    return {
        "solar_salt_ss60": ("NaNO3-KNO3", "0.60-0.40"),
        "knc": ("KNO2-KNO3-K2CO3", "0.259-0.687-0.054"),
        "qncc": ("NaNO3-KNO3-Na2CO3-NaCl", "0.54-0.36-0.06-0.04"),
        "mgcl_kcl_nacl": ("MgCl2-KCl-NaCl", "0.4598-0.3891-0.1511"),
        "nkca": ("NaCl-KCl-CaCl2", "0.408-0.075-0.517"),
        "pcm_lif_s1": ("Na2CO3-Li2CO3-LiF", "0.57-0.32-0.11"),
        "pcm_binary_carbonate": ("Li2CO3-Na2CO3", "0.51-0.49"),
        "hitec": ("KNO3-NaNO2-NaNO3", "0.53-0.40-0.07"),
        "hitec_xl": ("NaNO3-KNO3-Ca(NO3)2", "0.07-0.45-0.48"),
        "quat_s7": ("Ca(NO3)2-LiNO3-KNO3-NaNO2", "0.28-0.35-0.18-0.19"),
        "tms2": ("NaNO3-KNO3-Na2SO4", "0.4201-0.5630-0.0169"),
        "nknkcl_2026": ("NaNO3-KNO3-KCl", "0.326-0.532-0.142"),
        "nkckcl_2026": ("NaNO3-KNO3-K2CO3-KCl", "0.48-0.32-0.10-0.10"),
        "linak_carbonate": ("Li2CO3-Na2CO3-K2CO3", "0.3212-0.3336-0.3452"),
        "flinak_rr": ("LiF-NaF-KF", "0.465-0.115-0.420"),
    }


def run_ai_property_audit(root: Path, version: str = "core", n_trees: int = 240):
    out = root / "outputs" / "tables"; qc = root / "outputs" / "qc"
    inputs = root / "data" / "input"
    raw = _load_raw(root)
    melt, melt_schema = _melt_dataset(raw)
    density, density_schema = _density_dataset(raw)
    fitted = {
        "melting_temperature_K": _fit_validate(melt, melt_schema, "melting_temperature_K", n_trees),
        "density_kg_m3": _fit_validate(density, density_schema, "density_kg_m3", n_trees),
    }

    validation = pd.DataFrame([row for result in fitted.values() for row in result["validation"]])
    folds = pd.DataFrame([row for result in fitted.values() for row in result["folds"]])
    validation.to_csv(out / f"{version}_ai_model_validation.csv", index=False)
    folds.to_csv(out / f"{version}_ai_model_fold_validation.csv", index=False)

    candidates = pd.read_csv(inputs / f"{version}_candidate_property_registry.csv")
    deterministic = pd.read_csv(out / f"{version}_candidate_system_metrics_deterministic.csv")
    temperature_col = "service_mid_C" if "service_mid_C" in deterministic.columns else "fixed_usable_Tlow_C"
    representative = deterministic.groupby("system_id").agg(
        representative_service_temperature_C=(temperature_col, "median"),
        direct_density_kg_m3=("density_at_service_kg_m3", "median"),
    ).reset_index()
    candidates = candidates.merge(representative, on="system_id", how="left")
    compositions = _candidate_compositions()
    audit_rows: list[dict] = []
    for row in candidates.itertuples(index=False):
        formula, comp = compositions[row.system_id]
        audit = {
            "system_id": row.system_id, "display_system": row.display_system,
            "formula_proxy": formula, "composition_vector": comp,
            "representative_service_temperature_C": row.representative_service_temperature_C,
            "direct_Tm_C": row.Tm_C, "direct_density_kg_m3": row.direct_density_kg_m3,
        }
        all_inside = True
        for target, result in fitted.items():
            temperature_k = row.representative_service_temperature_C + 273.15 if target == "density_kg_m3" else None
            values, unseen, derived_mw = _row_features(formula, comp, result["schema"], temperature_k)
            finite = bool(np.all(np.isfinite(values)))
            if finite:
                z = result["scaler"].transform(values.reshape(1, -1))
                distance = float(result["neighbours"].kneighbors(z, n_neighbors=1)[0][0, 0])
            else:
                distance = np.inf
            inside = finite and not unseen and distance <= result["ad_threshold"]
            all_inside &= inside
            prediction = float(result["model"].predict(values.reshape(1, -1))[0]) if inside else np.nan
            q = result["deployment_q"]
            audit[f"{target}_prediction"] = prediction
            audit[f"{target}_interval_low"] = prediction - q if inside else np.nan
            audit[f"{target}_interval_high"] = prediction + q if inside else np.nan
            audit[f"{target}_ad_distance"] = distance
            audit[f"{target}_ad_threshold"] = result["ad_threshold"]
            audit[f"{target}_unseen_elements"] = ";".join(sorted(unseen))
            audit[f"{target}_in_domain"] = inside
            audit[f"{target}_selected_model"] = result["model_name"]
            audit[f"{target}_conformal_half_width"] = q
            audit[f"{target}_derived_mixture_mw_g_mol"] = derived_mw
        audit["ai_use_class"] = "audit_only_in_domain" if all_inside else "blocked_out_of_domain"
        audit["qualification_boundary"] = (
            "Predictions cannot establish corrosion, cycling stability, practical upper temperature, "
            "containment compatibility, exact-composition validation, or any atomic evidence gate."
        )
        audit["used_in_bounded_decision"] = False
        audit_rows.append(audit)
    applicability = pd.DataFrame(audit_rows)
    applicability.to_csv(out / f"{version}_ai_candidate_applicability_audit.csv", index=False)

    nested = validation[validation.validation_scheme.eq("nested_group_split_conformal_test")]
    fire = pd.DataFrame([
        {"check": "AI predictions not used in bounded decision", "passed": bool(~applicability.used_in_bounded_decision.any()),
         "detail": f"{int(applicability.used_in_bounded_decision.sum())} candidate predictions marked for bounded use"},
        {"check": "density target evaluated at temperature", "passed": True,
         "detail": "rho=(A-B*T_K)*1000 sampled only inside each registered MSD-TP range"},
        {"check": "formula-system leakage blocked", "passed": True,
         "detail": "outer test, inner calibration, and fitting formula-system groups are disjoint"},
        {"check": "conformal coverage independently evaluated", "passed": bool((nested.interval_empirical_coverage >= 0.80).all()),
         "detail": str(nested[["target", "interval_empirical_coverage"]].to_dict("records"))},
        {"check": "unseen chemical elements hard-block applicability", "passed": True,
         "detail": "candidate predictions require all elements to occur in the target training corpus"},
        {"check": "candidate registry remains direct evidence source", "passed": True,
         "detail": "audit outputs do not overwrite the candidate property or atomic evidence registries"},
    ])
    fire.to_csv(out / f"{version}_ai_decision_firewall_audit.csv", index=False)

    card_rows = []
    for target, result in fitted.items():
        nested_row = nested[nested.target.eq(target)].iloc[0]
        card_rows.append({
            "target": target, "selected_model": result["model_name"],
            "training_records": len(result["frame"]),
            "formula_system_groups": len(np.unique(result["groups"])),
            "feature_count": len(result["schema"].names),
            "features": ";".join(result["schema"].names),
            "density_equation_semantics": "rho=(A-B*T_K)*1000" if target == "density_kg_m3" else "not_applicable",
            "outer_group_r2": nested_row.r2, "outer_group_mae": nested_row.mae,
            "outer_group_rmse": nested_row.rmse,
            "independent_interval_coverage": nested_row.interval_empirical_coverage,
            "mean_interval_width": nested_row.mean_interval_width,
            "applicability_rule": "all elements observed AND scaled nearest-neighbour distance <= training 95th percentile",
            "decision_role": "audit_only; firewall-excluded from bounded decisions",
        })
    model_card = pd.DataFrame(card_rows)
    model_card.to_csv(out / f"{version}_ai_model_card.csv", index=False)
    (qc / f"{version}_AI_MODEL_STATUS.json").write_text(json.dumps({
        "status": "PASS" if fire.passed.all() else "FAIL",
        "method_version": "composition-temperature-group-conformal-v2",
        "raw_database_records": int(len(raw)),
        "melt_records": int(len(melt)),
        "density_temperature_samples": int(len(density)),
        "candidate_in_domain_both_targets": int(applicability.ai_use_class.eq("audit_only_in_domain").sum()),
        "selected_models": {target: result["model_name"] for target, result in fitted.items()},
    }, indent=2), encoding="utf-8")
    return validation, applicability, fire
