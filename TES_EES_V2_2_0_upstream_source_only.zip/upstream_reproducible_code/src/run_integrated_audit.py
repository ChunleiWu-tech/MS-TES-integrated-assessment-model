from __future__ import annotations
from pathlib import Path
import hashlib, json, re, zipfile
import numpy as np
import pandas as pd

VERSION='core'
ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'outputs'/'tables'; Q=ROOT/'outputs'/'qc'; D=ROOT/'docs'
Q.mkdir(parents=True,exist_ok=True)
checks=[]
def ck(name, passed, detail, severity='critical'):
    checks.append({'check':name,'passed':bool(passed),'severity':severity,'detail':detail})
def load(stem): return pd.read_csv(T/f'{VERSION}_{stem}.csv')
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def entropy_bits(v):
    a=np.asarray(v,float); a=a[np.isfinite(a)&(a>0)]
    return float(-(a*np.log2(a)).sum()) if len(a) else 0.0

def main():
    # Complete offline release: numerical tables are bundled as the authoritative
    # frozen result layer and remain fully regenerable from registered inputs.
    generated_tables=sorted(T.glob(f'{VERSION}_*.csv'))
    ck('registered_full_recompute_mode',not (ROOT/'data'/'certified_base').exists(),
       {'bundled_certified_results':False,'generated_table_count':len(generated_tables)})
    ck('recomputed_tables_are_versioned',bool(generated_tables) and all(p.name.startswith(VERSION+'_') for p in generated_tables),
       [p.name for p in generated_tables[:5]])

    # Strict fixed-scope uncertainty, explicitly in bits.
    trans=load('strict_complete_selection_transition_matrix')
    ck('strict_transition_balanced_prior_only',('weight_prior' not in trans.columns) or set(trans.weight_prior.astype(str))=={'balanced'},trans.get('weight_prior',pd.Series(dtype=str)).astype(str).unique().tolist())
    strict_sums=trans.groupby('scenario').transition_frequency.sum()
    ck('strict_transition_frequency_sums_one',np.allclose(strict_sums.to_numpy(float),1.0,atol=1e-12,rtol=0.0),strict_sums.to_dict())
    unc=load('uncertainty_source_decomposition')
    strict=unc[unc.source.eq('strict_complete_thermophysical')].set_index('scenario')
    expected={s:entropy_bits(g.groupby('from_system_id').transition_frequency.sum().to_numpy()) for s,g in trans.groupby('scenario')}
    ck('strict_source_present_for_all_services',len(strict)==7 and set(strict.index)==set(expected),strict.reset_index()[['scenario','source']].to_dict('records'))
    ck('entropy_unit_is_bits','entropy_unit' in unc.columns and set(unc.entropy_unit.astype(str))=={'bits'},unc.get('entropy_unit',pd.Series(dtype=str)).astype(str).unique().tolist())
    ck('strict_entropy_exact_bits',all(abs(float(strict.loc[s,'selection_entropy'])-v)<1e-10 for s,v in expected.items()),{'released':strict.selection_entropy.to_dict(),'recomputed_bits':expected})
    ck('strict_entropy_nonnegative',all(v>=-1e-12 for v in expected.values()),expected)
    nats={s:(v*np.log(2.0)) for s,v in expected.items()}
    ck('natural_log_entropy_not_released',any(abs(expected[s]-nats[s])>1e-3 for s in expected) and all(abs(float(strict.loc[s,'selection_entropy'])-nats[s])>1e-3 for s in expected if abs(expected[s]-nats[s])>1e-3),nats)
    ut=load('selection_uncertainty_transition')
    ck('fixed_scope_transition',set(ut.from_layer)=={'strict_complete_thermophysical'} and set(ut.to_layer)=={'strict_complete_evidence_bounded'} and ut.fixed_scope_comparison.astype(bool).all(),ut[['from_layer','to_layer']].drop_duplicates().to_dict('records'))
    ck('strict_entropy_transition_match',all(abs(float(ut.set_index('scenario').loc[s,'strict_complete_thermophysical_selection_entropy'])-expected[s])<1e-10 for s in expected),ut[['scenario','strict_complete_thermophysical_selection_entropy']].to_dict('records'))

    # Threshold and contraction semantics.
    contr=load('deployability_contraction')
    c5=contr[contr.stage_order.eq(5)]
    ck('main_material_threshold_1pct',len(c5)==7 and set(c5.deployability_stage)=={'Material selection frequency ≥1%'},c5[['scenario','deployability_stage','candidate_service_pairs']].to_dict('records'))
    consensus=load('cross_scenario_candidate_consensus')
    ck('consensus_uses_1pct_field','services_materially_selected_1pct' in consensus.columns and not any('10pct' in c.lower() for c in consensus.columns),consensus.columns.tolist())

    # Omission consistency and no main/supplement overlap.
    omission=load('omission_influence')
    ck('omission_single_baseline',set(omission.baseline_model.astype(str))=={'hierarchical_geometric'},omission.baseline_model.unique().tolist())
    ck('omission_leader_id_logic',(omission.leader_changed.astype(bool)==(omission.modal_leader_id.astype(str)!=omission.baseline_leader_id.astype(str))).all(),int(omission.leader_changed.astype(bool).sum()))
    main_om=load('omission_influence_summary')
    supp_om=load('supplementary_candidate_omission_residuals')
    main_pairs=set(zip(main_om.loc[main_om.omission_type.eq('candidate'),'scenario'],main_om.loc[main_om.omission_type.eq('candidate'),'omitted_id']))
    supp_pairs=set(zip(supp_om.scenario,supp_om.omitted_id))
    ck('main_supp_candidate_omissions_disjoint',not (main_pairs & supp_pairs),sorted(main_pairs & supp_pairs))
    ck('supp_omission_exclusion_flag',len(supp_om)>0 and supp_om.excluded_from_main_figure.astype(bool).all(),int(len(supp_om)))

    # Panel-level profile deduplication and programme grouping.
    atom=load('atomic_interval_profiles_by_dimension')
    ck('atomic_profiles_unique_within_dimension',atom.groupby('dimension').profile_signature.apply(lambda s:s.nunique()==len(s)).all(),atom.groupby('dimension').size().to_dict())
    nag=load('evidence_programme_nonadditivity_groups')
    ck('programme_profiles_exactly_grouped',nag.profile_signature.nunique()==len(nag) and nag.member_count.sum()==7,{'groups':len(nag),'members':int(nag.member_count.sum())})
    sog=load('source_omission_effect_groups')
    ck('source_omission_complete_vector_rule',sog.grouping_rule.astype(str).str.contains('complete displayed outcome vector|all displayed decision outcomes',case=False,regex=True).all(),sog.grouping_rule.unique().tolist())

    # Model-output boundary and scope.
    ai=load('ai_model_validation'); app=load('ai_candidate_applicability_audit')
    ck('ai_external_validation_not_claimed',set(ai.external_validation_status.astype(str))=={'not_performed'},ai[['target','validation_scheme','external_validation_status']].to_dict('records'))
    ck('ai_zero_bounded_decision_use',not app.used_in_bounded_decision.astype(bool).any(),int(app.used_in_bounded_decision.astype(bool).sum()))
    dual_expected=app['melting_temperature_K_in_domain'].fillna(False).astype(bool) & app['density_kg_m3_in_domain'].fillna(False).astype(bool)
    ck('ai_dual_domain_disclosed','dual_target_in_domain' in app.columns and np.array_equal(app.dual_target_in_domain.astype(bool).to_numpy(),dual_expected.to_numpy()),{'n':len(app),'dual':int(app.get('dual_target_in_domain',pd.Series(False,index=app.index)).astype(bool).sum())})
    ready=load('candidate_readiness_profile')
    candidate_registry=pd.read_csv(ROOT/'data'/'input'/f'{VERSION}_candidate_property_registry.csv')
    membership_registry=pd.read_csv(ROOT/'data'/'input'/f'{VERSION}_candidate_scenario_membership.csv')
    ck('candidate_scope_matches_registered_library',ready.system_id.nunique()==candidate_registry.system_id.nunique() and len(ready)==len(membership_registry),{'systems':ready.system_id.nunique(),'registered_systems':candidate_registry.system_id.nunique(),'pairs':len(ready),'registered_pairs':len(membership_registry)})

    # Research action boundary and independent burden.
    pareto=load('research_action_nondominance_assessment'); burden=load('action_classification_and_burden_registry')
    allowed=set(burden.loc[burden.action_type.isin(['evidence_acquisition','evidence_programme']),'closure_action'])
    ck('main_nondominance_research_actions_only',set(pareto.loc[pareto.comparison_eligible,'closure_action']).issubset(allowed),pareto.loc[pareto.comparison_eligible,['closure_action','action_type']].to_dict('records'))
    ck('burden_semantics_ordinal',pareto.burden_semantics.astype(str).str.contains('ordinal',case=False).all(),pareto[['closure_action','burden_semantics']].drop_duplicates().to_dict('records'))
    scope=load('counterfactual_action_scope_audit')
    bad=scope[scope.closure_action.eq('exact_composition_corrosion_closure') & scope.field.eq('burden_index') & scope.changed.astype(bool)]
    ck('counterfactual_preserves_independent_burden',bad.empty,bad.to_dict('records'))

    # Clean version identity in authoritative text/code and output headers.
    legacy=[]; version_token_re=re.compile(r'(?<![A-Za-z0-9])V{1,2}\d+tes(?![A-Za-z0-9])',re.I); allowed_versions={VERSION.lower()}
    for base in [ROOT/'README.md',ROOT/'README_ZH.md',ROOT/'docs',ROOT/'src',ROOT/'config']:
        paths=[base] if base.is_file() else list(base.rglob('*'))
        for p in paths:
            if not p.is_file() or p.suffix.lower() in {'.png','.jpg','.pdf','.zip','.pyc'}: continue
            if p.name == f'{VERSION}_PREDECESSOR_COMPARISON_AND_MERGE_ZH.md': continue
            txt=p.read_text(encoding='utf-8',errors='ignore')
            tokens=version_token_re.findall(txt+' '+p.name)
            if any(t.lower() not in allowed_versions for t in tokens): legacy.append(str(p.relative_to(ROOT)))
    for p in T.glob('*.csv'):
        tokens=version_token_re.findall(p.name+' '+p.open(encoding='utf-8',errors='ignore').readline())
        if any(t.lower() not in allowed_versions for t in tokens): legacy.append(str(p.relative_to(ROOT)))
    ck('no_legacy_version_residue',not legacy,sorted(set(legacy)))

    # Export exact table hashes for postprocess synchronization.
    hashes=[]
    excluded={f'{VERSION}_UPSTREAM_TABLE_HASHES.csv',f'{VERSION}_generation_provenance.csv'}
    for p in sorted(T.glob(f'{VERSION}_*.csv')):
        if p.name in excluded: continue
        hashes.append({'table':p.name,'size_bytes':p.stat().st_size,'sha256':sha(p)})
    pd.DataFrame(hashes).to_csv(T/f'{VERSION}_UPSTREAM_TABLE_HASHES.csv',index=False)

    status='PASS' if all(c['passed'] or c['severity']!='critical' for c in checks) else 'FAIL'
    payload={'status':status,'version':VERSION,'critical_checks':sum(c['severity']=='critical' for c in checks),'critical_failures':sum(c['severity']=='critical' and not c['passed'] for c in checks),'checks':checks}
    (Q/f'{VERSION}_INTEGRATED_RELEASE_AUDIT.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
    pd.DataFrame(checks).to_csv(Q/f'{VERSION}_INTEGRATED_RELEASE_CHECKS.csv',index=False)
    print(json.dumps({'status':status,'checks':len(checks),'failures':payload['critical_failures']},indent=2))
    if status!='PASS':
        for c in checks:
            if c['severity']=='critical' and not c['passed']: print('FAIL',c['check'],c['detail'])
        raise SystemExit(1)

if __name__=='__main__': main()
