from __future__ import annotations

"""Resume a full release after the expensive core Monte Carlo table was written.

This recovery entry point is intentionally narrow. It validates the frozen core
outputs, rebuilds all deterministic extension products, and writes the same core
QC status emitted by ``run_upstream.py``. It is safe to use after an external
process interruption that occurs after the streamed 20,000-draw table has been
fully written but before extension generation finishes.
"""

from pathlib import Path
import json
import subprocess
import sys

import pandas as pd

from upstream_extensions import run_extensions
from editorial_extensions import run_editorial_extensions

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
IN = ROOT / "data" / "input"
CFG = ROOT / "config"
OUT = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
SEED = 760076
EXPECTED_MC = 20_000
SCREENING_ADEQUACY = 0.95
STRICT_COMPLETE = 0.999


def _split_ids(series: pd.Series) -> set[str]:
    result: set[str] = set()
    for value in series.fillna("").astype(str):
        for token in value.split(";"):
            token = token.strip()
            if token:
                result.add(token)
    return result


def _require_full_core() -> tuple[pd.DataFrame, pd.DataFrame]:
    required = [
        "candidate_system_metrics_deterministic",
        "integrated_system_decision_table",
        "system_value_monte_carlo_summary",
        "monte_carlo_draws_balanced",
        "selection_transition_matrix",
        "gate_failure_breakdown",
        "benchmark_inclusion_plausibility_check",
    ]
    missing = [name for name in required if not (OUT / f"{VERSION}_{name}.csv").is_file()]
    if missing:
        raise FileNotFoundError(f"Cannot resume: missing core tables: {missing}")

    summary = pd.read_csv(OUT / f"{VERSION}_system_value_monte_carlo_summary.csv")
    if summary.empty or set(summary["mc_iterations"].astype(int)) != {EXPECTED_MC}:
        raise RuntimeError("Cannot resume: core summary is not a frozen 20,000-draw result")

    draws_path = OUT / f"{VERSION}_monte_carlo_draws_balanced.csv"
    # Read only the draw identifier to validate completeness without materialising
    # all columns a second time.
    draw_ids = pd.read_csv(draws_path, usecols=["draw_id"], dtype={"draw_id": "int32"})
    if int(draw_ids["draw_id"].max()) != EXPECTED_MC:
        raise RuntimeError("Cannot resume: streamed core draw table does not reach draw 20,000")

    membership = pd.read_csv(IN / f"{VERSION}_candidate_scenario_membership.csv")
    expected_rows = len(membership) * EXPECTED_MC
    if len(draw_ids) != expected_rows:
        raise RuntimeError(
            f"Cannot resume: draw table rows={len(draw_ids):,}; expected={expected_rows:,}"
        )
    return summary, membership


def main() -> None:
    _, membership = _require_full_core()
    print("[resume] frozen 20,000-draw core verified", flush=True)

    extension_summary = run_extensions(ROOT, VERSION, SEED)
    editorial_extension_summary = run_editorial_extensions(ROOT, VERSION)

    subprocess.run([sys.executable, str(ROOT / "src" / "run_innovation_only.py")], check=True)
    innovation_extension_summary = json.loads(
        (QC / f"{VERSION}_INNOVATION_EXTENSION_STATUS.json").read_text(encoding="utf-8")
    )
    subprocess.run([sys.executable, str(ROOT / "src" / "run_high_density.py")], check=True)
    high_density_extension_summary = json.loads(
        (QC / f"{VERSION}_HIGH_DENSITY_VALIDATION_SUMMARY.json").read_text(encoding="utf-8")
    )
    subprocess.run([sys.executable, str(ROOT / "src" / "information_extensions.py")], check=True)
    subprocess.run([sys.executable, str(ROOT / "src" / "presentation_extensions.py")], check=True)
    presentation_extension_summary = json.loads(
        (QC / f"{VERSION}_PRESENTATION_EXTENSION_STATUS.json").read_text(encoding="utf-8")
    )

    P = pd.read_csv(IN / f"{VERSION}_candidate_property_registry.csv")
    M = membership
    COR = pd.read_csv(IN / f"{VERSION}_corrosion_evidence_registry.csv")
    SRC = pd.read_csv(IN / f"{VERSION}_authoritative_source_registry.csv")
    VAL = pd.read_csv(IN / f"{VERSION}_literature_validation_tiers.csv")
    APP = pd.read_csv(IN / f"{VERSION}_candidate_scenario_evidence_registry.csv")
    ATOMIC = pd.read_csv(IN / f"{VERSION}_atomic_engineering_credibility_registry.csv")
    OVR = pd.read_csv(IN / f"{VERSION}_mixture_cost_overrides.csv")
    S = pd.read_csv(CFG / f"{VERSION}_system_benchmarks.csv")
    ASMP = pd.read_csv(CFG / f"{VERSION}_methodological_assumption_registry.csv")
    BR = pd.read_csv(OUT / f"{VERSION}_benchmark_inclusion_plausibility_check.csv")

    property_names = P.set_index("system_id")["display_system"].to_dict()
    membership_mismatches = M[
        M.apply(lambda x: property_names.get(x.system_id) != x.display_system, axis=1)
    ].copy()

    used_source_ids: set[str] = set()
    for series in (
        P["source_ids"], COR["source_ids"], VAL["source_ids"], APP["source_ids"],
        ATOMIC["source_ids"], OVR["source_id"], S["basis_ids"],
    ):
        used_source_ids |= _split_ids(series)
    registry_ids = set(SRC["source_id"].astype(str))
    missing_source_ids = sorted(used_source_ids - registry_ids)

    used_assumption_ids = _split_ids(S["assumption_ids"])
    used_assumption_ids.update({
        "ASMP_SCREENING_ADEQUACY_95", "ASMP_STRICT_COMPLETE_999",
        "ASMP_WEIGHT_PRIORS", "ASMP_HIERARCHICAL_UTILITY",
        "ASMP_EVIDENCE_SCORE_UNCERTAINTY", "ASMP_ATOMIC_EVIDENCE_CLOSURE",
    })
    assumption_registry_ids = set(ASMP["assumption_id"].astype(str))
    missing_assumption_ids = sorted(used_assumption_ids - assumption_registry_ids)

    qc_status = "PASS"
    if missing_source_ids or missing_assumption_ids or len(membership_mismatches):
        qc_status = "REVIEW"

    qc = {
        "status": qc_status,
        "release_id": "TES-EES-V2.2.0-20260909",
        "version": VERSION,
        "n_candidates": int(len(P)),
        "n_scenario_candidate_rows": int(len(M)),
        "mc_iterations": EXPECTED_MC,
        "screening_service_adequacy_threshold": SCREENING_ADEQUACY,
        "strict_complete_service_threshold": STRICT_COMPLETE,
        "authoritative_source_ids_missing": missing_source_ids,
        "assumption_ids_missing": missing_assumption_ids,
        "membership_label_mismatches": int(len(membership_mismatches)),
        "benchmark_inclusion_plausibility_passes": int((BR["plausibility_status"] == "PASS").sum()),
        "primary_ranking_uses_price": False,
        "legacy_context_merged": False,
        "raw_database_snapshots_included": True,
        "extension_modules_status": extension_summary.get("status"),
        "raw_database_records": extension_summary.get("raw_database_records"),
        "unique_formula_systems": extension_summary.get("unique_formula_systems"),
        "continuous_weight_vectors_per_application": extension_summary.get(
            "continuous_random_weight_vectors_per_application"
        ),
        "counterfactual_application_rows": extension_summary.get("counterfactual_application_rows"),
        "editorial_extensions_status": editorial_extension_summary.get("status"),
        "innovation_extensions_status": innovation_extension_summary.get("status"),
        "high_density_extensions_status": high_density_extension_summary.get("status"),
        "presentation_extensions_status": presentation_extension_summary.get("status"),
        "literature_source_candidate_links": editorial_extension_summary.get(
            "literature_source_candidate_links"
        ),
        "resumed_after_verified_core_monte_carlo": True,
    }
    (QC / f"{VERSION}_QC_STATUS.json").write_text(
        json.dumps(qc, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    if len(membership_mismatches):
        membership_mismatches.to_csv(QC / f"{VERSION}_membership_label_mismatches.csv", index=False)
    print(json.dumps(qc, indent=2, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
