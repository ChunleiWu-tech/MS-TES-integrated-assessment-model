"""Material-architecture-duty assessment with explicit empirical boundaries."""
from __future__ import annotations
from pathlib import Path
from hashlib import sha256
import json
import numpy as np
import pandas as pd
from scipy.optimize import linprog

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'outputs/tables'
QC = ROOT / 'outputs/qc'


def required_volume(charge_power, discharge_power, charge_h, discharge_h, energy=1., ratio=1., capacity=None):
    terms = [energy * ratio / (charge_power * charge_h), energy / (discharge_power * discharge_h)]
    if capacity is not None:
        terms.append(energy / capacity)
    return max(terms), ['charge', 'discharge', 'capacity'][int(np.argmax(terms))]


def dispatch_lp(pc, pd_, capacity, tc, td, dt, energy=1.):
    """Minimize volume over a chronological, lossless equivalent-envelope cycle.

    Variables are volume, step charging, step discharge, and N+1 state energies.
    Endpoint states are zero, preventing free initial or residual terminal energy.
    This verifies the discretized model, not the physical validity of constant power.
    """
    nc, nd = int(round(tc/dt)), int(round(td/dt))
    n = nc + nd
    size = 1 + 2*n + n+1
    c = np.zeros(size); c[0] = 1.
    eq, beq, ub, bub = [], [], [], []
    bounds = [(0,None)]
    bounds += [(0, None) if i < nc else (0,0) for i in range(n)]
    bounds += [(0, 0) if i < nc else (0, None) for i in range(n)]
    bounds += [(0,0)] + [(0,None)]*(n-1) + [(0,0)]
    for i in range(n):
        a = np.zeros(size); a[1+2*n+i+1] = 1; a[1+2*n+i] = -1
        a[1+i] = -dt; a[1+n+i] = dt
        eq.append(a); beq.append(0.)
        for ix, p in [(1+i, pc),(1+n+i,pd_)]:
            a = np.zeros(size); a[ix] = 1; a[0] = -p
            ub.append(a); bub.append(0.)
        a = np.zeros(size); a[1+2*n+i+1] = 1; a[0] = -capacity
        ub.append(a); bub.append(0.)
    a = np.zeros(size); a[1+n:1+2*n] = dt
    eq.append(a); beq.append(energy)
    result = linprog(c,A_ub=ub,b_ub=bub,A_eq=eq,b_eq=beq,bounds=bounds,method='highs')
    if not result.success:
        raise RuntimeError(result.message)
    state = result.x[1+2*n:]
    residual = np.max(np.abs(np.array(eq)@result.x-np.array(beq)))
    return result.x[0], residual, state, result.x[1:1+n], result.x[1+n:1+2*n]


def run():
    TABLES.mkdir(parents=True, exist_ok=True); QC.mkdir(parents=True, exist_ok=True)
    inp=ROOT/'data/input/application_experiments.json'
    conf=ROOT/'config/application_assessment.json'
    data=json.loads(inp.read_text(encoding='utf-8'))
    cfg=json.loads(conf.read_text(encoding='utf-8'))
    powers, paired, conditions, scenarios, grids, chronological, traces=[],[],[],[],[],[],[]
    for study in data['studies']:
        ch=np.array(study['charge_power']); dis=np.array(study['discharge_power'])
        for j, hot in enumerate(study['hot_C']):
            for m, material in enumerate(data['material_order']):
                powers.append(dict(source_id=study['source_id'],chemistry=study['chemistry'],material=material,direction='charge',hot_C=hot,cold_C=study['charge_initial_C'],power_kW_m3=ch[j,m],uncertainty_fraction=.0236,doi=study['doi'],locator=study['locator']))
                for k,cold in enumerate(study['cold_C']):
                    powers.append(dict(source_id=study['source_id'],chemistry=study['chemistry'],material=material,direction='discharge',hot_C=hot,cold_C=cold,power_kW_m3=dis[k,j,m],uncertainty_fraction=.0236,doi=study['doi'],locator=study['locator']))
                    ec=study['device_energy']
                    capacity=None if ec is None else ec['discharge'][k][j][m]/3600/(ec['fill_fraction']*np.pi*(ec['diameter_m']**2-ec['inner_pipe_diameter_m']**2)/4*ec['height_m'])
                    meta=dict(source_id=study['source_id'],chemistry=study['chemistry'],material=material,hot_C=hot,cold_C=cold)
                    conditions.append(dict(**meta,charge_power_kW_m3=ch[j,m],discharge_power_kW_m3=dis[k,j,m],capacity_kWh_m3=capacity))
                    for archetype in cfg['application_archetypes']:
                        for ratio in cfg['charge_to_delivery_energy_ratios']:
                            vb, ab=required_volume(ch[j,0],dis[k,j,0],archetype['charge_h'],archetype['discharge_h'],ratio=ratio)
                            vc, ac=required_volume(ch[j,m],dis[k,j,m],archetype['charge_h'],archetype['discharge_h'],ratio=ratio)
                            scenarios.append(dict(**meta,archetype=archetype['id'],charge_to_delivery_energy_ratio=ratio,transfer_volume_m3_per_kWh=vc,volume_ratio=vc/vb,volume_saving_fraction=1-vc/vb,base_constraint=ab,material_constraint=ac,equal_volume_cost_premium_ceiling=vb/vc-1))
                        if capacity is not None:
                            closed, active=required_volume(ch[j,m],dis[k,j,m],archetype['charge_h'],archetype['discharge_h'],capacity=capacity)
                            for dt in cfg['chronological_dt_h']:
                                vlp, residual, state, qc, qd=dispatch_lp(ch[j,m],dis[k,j,m],capacity,archetype['charge_h'],archetype['discharge_h'],dt)
                                chronological.append(dict(**meta,archetype=archetype['id'],dt_h=dt,analytical_volume=closed,lp_volume=vlp,relative_error=abs(vlp/closed-1),energy_residual_kWh=residual,active_constraint=active))
                                if hot==180 and cold==50 and dt==.25 and archetype['id']=='short_charge':
                                    for it in range(len(qc)):
                                        traces.append(dict(**meta,time_h=it*dt,state_kWh=state[it],charge_kW=qc[it],discharge_kW=qd[it],volume_m3=vlp))
                    if m==0: continue
                    rc=ch[j,m]/ch[j,0]; rd=dis[k,j,m]/dis[k,j,0]
                    uncertainty=study['reported_power_uncertainty_fraction']
                    # When rc>1 and rd<1, equality occurs between base charge and composite discharge constraints.
                    crossover=dis[k,j,m]/ch[j,0] if rc>1 and rd<1 else np.nan
                    paired.append(dict(**meta,charge_ratio=rc,discharge_ratio=rd,charge_ratio_low=rc*(1-uncertainty)/(1+uncertainty),charge_ratio_high=rc*(1+uncertainty)/(1-uncertainty),discharge_ratio_low=rd*(1-uncertainty)/(1+uncertainty),discharge_ratio_high=rd*(1+uncertainty)/(1-uncertainty),crossover_tc_over_td=crossover,crossover_low=crossover*(1-uncertainty)/(1+uncertainty),crossover_high=crossover*(1+uncertainty)/(1-uncertainty),doi=study['doi']))
                    for ratio in np.geomspace(cfg['duration_ratio_min'],cfg['duration_ratio_max'],cfg['duration_ratio_points']):
                        vb,ab=required_volume(ch[j,0],dis[k,j,0],ratio,1.)
                        vc,ac=required_volume(ch[j,m],dis[k,j,m],ratio,1.)
                        grids.append(dict(**meta,tc_over_td=ratio,volume_ratio=vc/vb,base_constraint=ab,material_constraint=ac,charge_only_volume_ratio=1/rc))
    hydraulics=[]
    evidence=pd.read_csv(ROOT/'data/input/core_composite_evidence_registry.csv')
    for r in evidence[evidence.viscosity_ratio.notna() & evidence.capacity_ratio_reported.notna()].itertuples():
        cp, mu=float(r.capacity_ratio_reported),float(r.viscosity_ratio)
        critical=3*np.log(cp)/(np.log(mu)+np.log(cp))
        for beta in np.linspace(.25,1.,151):
            rp=mu**beta/cp**(3-beta)
            for f in cfg['hydraulic_pump_energy_fractions']:
                hydraulics.append(dict(record_id=r.record_id,capacity_ratio=cp,viscosity_ratio=mu,beta=beta,pump_power_ratio=rp,critical_beta=critical,baseline_pump_kWh_per_kWhth=f,incremental_pumping_kWh_per_MWhth=1000*f*(rp-1),common_grid_operational_emissions_ratio=(1+f*rp)/(1+f)))
    frames={'power_measurements':powers,'paired_response':paired,'device_conditions':conditions,'application_scenarios':scenarios,'duty_frontiers':grids,'chronological_checks':chronological,'chronological_traces':traces,'equal_duty_hydraulics':hydraulics}
    for name,rows in frames.items():
        pd.DataFrame(rows).to_csv(TABLES/f'application_{name}.csv',index=False)
    response=pd.DataFrame(paired); chronology=pd.DataFrame(chronological)
    foam=response[response.material.eq('alumina_copper_foam')]
    checks=[]
    def check(name, value): checks.append({'check':name,'passed':bool(value)})
    check('72 individually traceable mean powers',len(powers)==72)
    check('54 chemistry-material-temperature conditions',len(conditions)==54)
    check('36 paired composite conditions',len(paired)==36)
    check('all measured powers positive',all(x['power_kW_m3']>0 for x in powers))
    check('no duplicate power observations',not pd.DataFrame(powers).duplicated(['source_id','material','direction','hot_C','cold_C']).any())
    check('charge gains exceed measurement envelope for all foam conditions',foam.charge_ratio_low.gt(1).all())
    check('all 18 foam discharge midpoints lower than matched base',foam.discharge_ratio.lt(1).all())
    check('all foam crossover values positive',foam.crossover_tc_over_td.gt(0).all())
    check('independent chronological LP agrees with closed form',chronology.relative_error.max()<1e-8)
    check('chronological energy balance',chronology.energy_residual_kWh.max()<1e-8)
    check('162 chronological scenarios evaluated',len(chronology)==162)
    check('capacity constraint becomes active in long delivery cases',chronology.active_constraint.eq('capacity').any())
    for study in data['studies']:
        ec=study['device_energy']
        if ec is None: continue
        volume=ec['fill_fraction']*np.pi*(ec['diameter_m']**2-ec['inner_pipe_diameter_m']**2)/4*ec['height_m']
        for obs in ec['reported_duration_checks']:
            j=study['hot_C'].index(obs['hot_C']); m=data['material_order'].index(obs['material'])
            if obs['direction']=='charge':
                energy=ec['charge'][j][m]; power=study['charge_power'][j][m]
            else:
                k=study['cold_C'].index(obs['cold_C']); energy=ec['discharge'][k][j][m]; power=study['discharge_power'][k][j][m]
            predicted=energy/(power*volume)
            check(f'filled-volume reconstruction {obs["direction"]} {obs["hot_C"]}',abs(predicted/obs['time_s']-1)<.002)
    for r in response[response.crossover_tc_over_td.notna()].itertuples():
        d=pd.DataFrame(conditions); d=d[(d.source_id==r.source_id)&(d.hot_C==r.hot_C)&(d.cold_C==r.cold_C)]
        b=d[d.material=='base'].iloc[0]; a=d[d.material==r.material].iloc[0]
        vb,_=required_volume(b.charge_power_kW_m3,b.discharge_power_kW_m3,r.crossover_tc_over_td,1.)
        va,_=required_volume(a.charge_power_kW_m3,a.discharge_power_kW_m3,r.crossover_tc_over_td,1.)
        check(f'analytical crossover {r.source_id} {r.material} {r.hot_C} {r.cold_C}',abs(va/vb-1)<1e-10)
    # Direct pipe equations check the equal-duty scaling independently.
    for beta in [.25,1.]:
        for cp,mu in [(1.,1.),(1.15,1.41),(1.15,5.29),(1.07,1.35)]:
            rho,D,L,v,visc=1800.,.05,100.,1.,.003
            def power(velocity, viscosity):
                re=rho*velocity*D/viscosity
                friction=64/re if beta==1 else .3164/re**.25
                return friction*L/D*rho*velocity**2/2*(np.pi*D**2/4*velocity)
            direct=power(v/cp,visc*mu)/power(v,visc)
            check(f'Darcy scaling algebra beta={beta} cp={cp} mu={mu}',np.isclose(direct,mu**beta/cp**(3-beta),rtol=1e-12))
    result={'status':'PASS' if all(x['passed'] for x in checks) else 'FAIL','version':cfg['version'],'checks':len(checks),'checks_passed':sum(x['passed'] for x in checks),'counts':{k:len(v) for k,v in frames.items()},'foam_charge_ratio_range':[foam.charge_ratio.min(),foam.charge_ratio.max()],'foam_discharge_ratio_range':[foam.discharge_ratio.min(),foam.discharge_ratio.max()],'foam_discharge_penalty_outside_measurement_envelope':int(foam.discharge_ratio_high.lt(1).sum()),'foam_crossover_range':[foam.crossover_tc_over_td.min(),foam.crossover_tc_over_td.max()],'input_sha256':sha256(inp.read_bytes()).hexdigest(),'config_sha256':sha256(conf.read_bytes()).hexdigest(),'scope':cfg['scope']}
    (QC/'APPLICATION_ASSESSMENT_STATUS.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    pd.DataFrame(checks).to_csv(TABLES/'application_validation_checks.csv',index=False)
    print(json.dumps(result,indent=2))
    if result['status']!='PASS': raise SystemExit(1)

if __name__=='__main__': run()
