from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "external_validation" / "botejara_2026_nitrate_formulations.csv"
BENCHMARKS = ROOT / "config" / "core_system_benchmarks.csv"
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"

RELEASE_ID = "TES-EES-V2.2.0-20260909"
FREEZE_MARGIN_C = 20.0
LATENT_STABILITY_MARGIN_C = 40.0


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def physical_status(candidate: pd.Series, service: pd.Series) -> tuple[bool, str]:
    melting = float(candidate.melting_temperature_C)
    degradation = float(candidate.degradation_temperature_C)
    if service.service_mode == "sensible":
        cold_limit = float(service.fixed_Tcold_C) - FREEZE_MARGIN_C
        pass_window = melting <= cold_limit and degradation >= float(service.fixed_Thot_C)
        reason = "passes_phase_and_upper_temperature_gates" if pass_window else "outside_registered_sensible_window"
        return bool(pass_window), reason
    phase_pass = float(service.phase_target_min_C) <= melting <= float(service.phase_target_max_C)
    upper_pass = degradation >= melting + LATENT_STABILITY_MARGIN_C
    pass_window = phase_pass and upper_pass
    reason = "passes_phase_and_upper_temperature_gates" if pass_window else "outside_registered_phase_change_window"
    return bool(pass_window), reason


def main() -> None:
    TABLES.mkdir(parents=True, exist_ok=True)
    QC.mkdir(parents=True, exist_ok=True)
    candidates = pd.read_csv(INPUT)
    services = pd.read_csv(BENCHMARKS)

    composition_columns = ["NaNO3_wt_pct", "KNO3_wt_pct", "CaNO3_2_wt_pct", "LiNO3_wt_pct"]
    candidates["composition_sum_wt_pct"] = candidates[composition_columns].sum(axis=1)
    candidates["composition_closed"] = np.isclose(candidates.composition_sum_wt_pct, 100.0, atol=1e-9)
    candidates["volumetric_heat_capacity_MJ_m3K_at_300C"] = (
        candidates.cp_J_gK_at_300C * candidates.density_g_cm3_at_300C
    )
    candidates["volumetric_heat_capacity_relative_to_solar_salt"] = (
        candidates.volumetric_heat_capacity_MJ_m3K_at_300C / (1.50 * 1.90)
    )
    candidates["viscosity_relative_to_solar_salt"] = candidates.viscosity_mPa_s_at_300C / 3.27
    candidates["source_file_sha256"] = sha256(INPUT)
    candidates.to_csv(TABLES / "joule_external_candidate_registry.csv", index=False)

    rows: list[dict] = []
    for _, candidate in candidates.iterrows():
        for _, service in services.iterrows():
            physical_pass, physical_reason = physical_status(candidate, service)
            quantitative = bool(physical_pass)
            full_domain = False
            rows.append(
                {
                    "candidate_id": candidate.candidate_id,
                    "display_name": candidate.display_name,
                    "service_id": service.scenario,
                    "service_label": service.scenario_label,
                    "service_mode": service.service_mode,
                    "physical_window_pass": physical_pass,
                    "physical_status": physical_reason,
                    "quantitative_scalar_available": quantitative,
                    "measurement_temperature_C": float(candidate.measurement_temperature_C),
                    "scalar_volumetric_heat_capacity_MJ_m3K": float(candidate.volumetric_heat_capacity_MJ_m3K_at_300C),
                    "service_domain_supported": full_domain,
                    "support_tier": "C_scalar_single_temperature",
                    "support_reason": "single_temperature_cp_and_density_do_not_span_registered_service_window",
                    "engineering_registry_linked": False,
                    "formal_assessment_completed": False,
                    "formal_assessment_status": "not_assigned_external_rule_transfer_set",
                    "source_doi": candidate.source_doi,
                }
            )
    screen = pd.DataFrame(rows)
    screen.to_csv(TABLES / "joule_external_rule_transfer_screen.csv", index=False)

    by_service = (
        screen.groupby(["service_id", "service_label"], as_index=False)
        .agg(
            candidates_screened=("candidate_id", "nunique"),
            physical_window_pairs=("physical_window_pass", "sum"),
            quantitative_scalar_pairs=("quantitative_scalar_available", "sum"),
            service_domain_supported_pairs=("service_domain_supported", "sum"),
            formal_assessment_pairs=("formal_assessment_completed", "sum"),
        )
    )
    by_service.to_csv(TABLES / "joule_external_validation_by_service.csv", index=False)

    scalar = candidates[
        [
            "candidate_id",
            "display_name",
            "cp_J_gK_at_300C",
            "density_g_cm3_at_300C",
            "volumetric_heat_capacity_MJ_m3K_at_300C",
            "volumetric_heat_capacity_relative_to_solar_salt",
            "viscosity_mPa_s_at_300C",
            "viscosity_relative_to_solar_salt",
            "thermal_conductivity_W_mK_at_300C",
            "measurement_temperature_C",
            "source_doi",
        ]
    ].sort_values("volumetric_heat_capacity_MJ_m3K_at_300C", ascending=False)
    scalar.to_csv(TABLES / "joule_external_scalar_performance.csv", index=False)

    summary = pd.DataFrame(
        [
            ("external_candidates", int(candidates.candidate_id.nunique()), "exact formulations"),
            ("candidate_service_pairs", int(len(screen)), "nine candidates by seven registered services"),
            ("physical_window_pairs", int(screen.physical_window_pass.sum()), "phase and upper-temperature gates"),
            ("quantitative_scalar_pairs", int(screen.quantitative_scalar_available.sum()), "cp and density reported at 300 C"),
            ("service_domain_supported_pairs", int(screen.service_domain_supported.sum()), "complete registered duty interval"),
            ("formal_assessment_pairs", int(screen.formal_assessment_completed.sum()), "engineering-registry outcomes"),
        ],
        columns=["metric", "value", "definition"],
    )
    summary.to_csv(TABLES / "joule_external_validation_summary.csv", index=False)

    checks = {
        "nine_exact_compositions": int(candidates.candidate_id.nunique()) == 9,
        "composition_closure": bool(candidates.composition_closed.all()),
        "sixty_three_candidate_service_pairs": len(screen) == 63,
        "twenty_seven_physical_pairs": int(screen.physical_window_pass.sum()) == 27,
        "twenty_seven_scalar_quantitative_pairs": int(screen.quantitative_scalar_available.sum()) == 27,
        "no_full_service_domain_support": int(screen.service_domain_supported.sum()) == 0,
        "no_formal_outcomes": int(screen.formal_assessment_completed.sum()) == 0,
        "salt_7_has_highest_scalar_volumetric_heat_capacity": scalar.iloc[0].candidate_id == "botejara_salt_7",
        "salt_7_scalar_value_is_8_085": bool(np.isclose(
            float(scalar.iloc[0].volumetric_heat_capacity_MJ_m3K_at_300C), 8.085, atol=1e-12
        )),
    }
    checks = {key: bool(value) for key, value in checks.items()}
    status = {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "release_id": RELEASE_ID,
        "purpose": "independent rule-transfer test without recalibration",
        "baseline_candidate_count_unchanged": 142,
        "external_candidates": 9,
        "source_doi": "10.1016/j.applthermaleng.2026.131694",
        "checks": checks,
        "input_sha256": sha256(INPUT),
    }
    (QC / "JOULE_EXTERNAL_VALIDATION_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    if status["status"] != "PASS":
        raise SystemExit(json.dumps(status, indent=2))
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
