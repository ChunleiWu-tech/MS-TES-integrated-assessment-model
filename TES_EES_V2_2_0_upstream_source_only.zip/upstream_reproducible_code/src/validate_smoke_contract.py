from __future__ import annotations

import csv
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
N_MC = int(os.environ.get("TES_N_MC", "500"))

checks: list[dict[str, object]] = []

def add(name: str, passed: bool, detail: object) -> None:
    checks.append({"check": name, "passed": bool(passed), "detail": detail})

metrics = pd.read_csv(TABLES / f"{VERSION}_candidate_system_metrics_deterministic.csv")
expected_groups = metrics[["scenario", "system_id"]].drop_duplicates().shape[0]

draw_path = TABLES / f"{VERSION}_monte_carlo_draws_balanced.csv"
with draw_path.open("r", newline="", encoding="utf-8") as handle:
    draw_rows = sum(1 for _ in csv.reader(handle)) - 1
add("draw_row_count", draw_rows == expected_groups * N_MC, {"rows": draw_rows, "expected": expected_groups * N_MC})

score = pd.read_csv(TABLES / f"{VERSION}_candidate_service_evidence_score_draw_summary.csv")
add("score_summary_group_count", len(score) == expected_groups, {"rows": len(score), "expected": expected_groups})
add("score_summary_draw_count", score.monte_carlo_rows.eq(N_MC).all(), sorted(score.monte_carlo_rows.unique().tolist()))
add("score_summary_row_conservation", int(score.monte_carlo_rows.sum()) == draw_rows, {"summary_rows": int(score.monte_carlo_rows.sum()), "draw_rows": draw_rows})

pathways = pd.read_csv(TABLES / f"{VERSION}_ranking_pathway_summary.csv")
frequency = pathways.groupby("scenario", sort=False).frequency.sum()
add("ranking_probability_conservation", np.allclose(frequency, 1.0, atol=1e-12), frequency.to_dict())

status_path = QC / f"{VERSION}_QC_STATUS.json"
status = json.loads(status_path.read_text(encoding="utf-8"))
for field in ("editorial_extensions_status", "innovation_extensions_status", "high_density_extensions_status", "presentation_extensions_status"):
    add(field, str(status.get(field, "")).startswith("PASS"), status.get(field))

passed = all(item["passed"] for item in checks)
report = {
    "status": "PASS" if passed else "FAIL",
    "version": VERSION,
    "mc_iterations": N_MC,
    "publication_eligible": False,
    "checks": checks,
    "note": "Smoke-test outputs are diagnostic only and are rejected by the post-processing synchronisation contract.",
}
QC.mkdir(parents=True, exist_ok=True)
(QC / "SMOKE_TEST_STATUS.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
raise SystemExit(0 if passed else 1)
