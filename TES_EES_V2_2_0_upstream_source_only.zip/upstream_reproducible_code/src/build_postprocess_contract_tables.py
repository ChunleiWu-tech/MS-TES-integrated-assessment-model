from __future__ import annotations

from pathlib import Path
import json
import numpy as np
import pandas as pd

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
INPUTS = ROOT / "data" / "input"
TABLES.mkdir(parents=True, exist_ok=True)
QC.mkdir(parents=True, exist_ok=True)


def read_table(name: str) -> pd.DataFrame:
    path = TABLES / f"{VERSION}_{name}.csv"
    if not path.exists():
        raise FileNotFoundError(
            f"Required upstream table is missing: {path}. "
            "Run RUN_FULL_RECOMPUTE before building the postprocess contract tables."
        )
    return pd.read_csv(path)


def require_columns(frame: pd.DataFrame, columns: list[str], table: str) -> None:
    missing = [column for column in columns if column not in frame.columns]
    if missing:
        raise KeyError(f"{table} is missing required columns: {missing}")


def build_thermal_transport_frontier() -> pd.DataFrame:
    deterministic = read_table("candidate_system_metrics_deterministic")
    readiness = read_table("candidate_readiness_profile")
    shortfall = read_table("credibility_shortfall_decomposition")

    deterministic_columns = [
        "scenario", "system_id", "display_system",
        "thermal_k_at_service_W_mK",
        "complete_service_energy_fixed_kWh_m3",
    ]
    readiness_columns = [
        "scenario", "system_id",
        "strict_complete_service_probability",
        "energy_density_p05_kWh_m3_conditional_on_adequacy",
        "energy_density_p50_kWh_m3_conditional_on_adequacy",
        "energy_density_p95_kWh_m3_conditional_on_adequacy",
        "evidence_qualified_selection_frequency",
        "all_noncompensatory_gate_count",
    ]
    credibility_columns = [
        "scenario", "system_id", "engineering_credibility_geometric"
    ]
    require_columns(deterministic, deterministic_columns, "candidate_system_metrics_deterministic")
    require_columns(readiness, readiness_columns, "candidate_readiness_profile")
    require_columns(shortfall, credibility_columns, "credibility_shortfall_decomposition")

    credibility = (
        shortfall[credibility_columns]
        .drop_duplicates(["scenario", "system_id"])
    )
    frontier = (
        deterministic[deterministic_columns]
        .merge(
            readiness[readiness_columns],
            on=["scenario", "system_id"],
            how="left",
            validate="one_to_one",
        )
        .merge(
            credibility,
            on=["scenario", "system_id"],
            how="left",
            validate="one_to_one",
        )
    )
    frontier["substantively_selected"] = (
        frontier["evidence_qualified_selection_frequency"] >= 0.01
    )
    ordered_columns = [
        "scenario", "system_id", "display_system",
        "thermal_k_at_service_W_mK",
        "complete_service_energy_fixed_kWh_m3",
        "strict_complete_service_probability",
        "energy_density_p05_kWh_m3_conditional_on_adequacy",
        "energy_density_p50_kWh_m3_conditional_on_adequacy",
        "energy_density_p95_kWh_m3_conditional_on_adequacy",
        "evidence_qualified_selection_frequency",
        "engineering_credibility_geometric",
        "all_noncompensatory_gate_count",
        "substantively_selected",
    ]
    frontier = frontier[ordered_columns]
    expected_pairs = len(pd.read_csv(INPUTS / f"{VERSION}_candidate_scenario_membership.csv"))
    if len(frontier) != expected_pairs:
        raise RuntimeError(
            f"Thermal-transport frontier must contain {expected_pairs} candidate-service rows; found {len(frontier)}."
        )
    return frontier


def build_ranking_pathway_summary() -> pd.DataFrame:
    ladder = read_table("rank_ladder_by_draw")
    required = [
        "scenario", "draw_id", "partial_leader_id",
        "complete_leader_id", "bounded_leader_id",
    ]
    require_columns(ladder, required, "rank_ladder_by_draw")

    partial = ladder["partial_leader_id"].astype(str)
    complete = ladder["complete_leader_id"].astype(str)
    bounded = ladder["bounded_leader_id"].astype(str)
    no_bounded = bounded.eq("__NO_SELECTION__") | bounded.eq("none")

    pathway = np.select(
        [
            no_bounded,
            partial.eq(complete) & complete.eq(bounded),
            partial.eq(complete) & complete.ne(bounded),
            partial.ne(complete) & complete.eq(bounded),
            partial.ne(complete) & complete.ne(bounded),
        ],
        [
            "No formal selection",
            "Stable leader",
            "Evidence-only change",
            "Service-only change",
            "Service + evidence change",
        ],
        default="Unclassified",
    )
    if np.any(pathway == "Unclassified"):
        raise RuntimeError(
            f"Ranking-pathway classification left {(pathway == 'Unclassified').sum()} draws unclassified."
        )

    summary = (
        pd.DataFrame({"scenario": ladder["scenario"], "pathway": pathway})
        .groupby(["scenario", "pathway"], as_index=False)
        .size()
        .rename(columns={"size": "draws"})
    )
    totals = summary.groupby("scenario")["draws"].transform("sum")
    summary["frequency"] = summary["draws"] / totals

    scenario_totals = summary.groupby("scenario")["draws"].sum()
    unique_totals = sorted(scenario_totals.unique().tolist())
    if len(unique_totals) != 1 or unique_totals[0] <= 0:
        raise RuntimeError(
            f"Each service must contain the same positive number of ranking-pathway draws; found {scenario_totals.to_dict()}."
        )
    # Contract construction checks shape consistency. The release validator
    # separately enforces 20,000 draws per service for the frozen analysis.
    frequency_totals = summary.groupby("scenario")["frequency"].sum()
    if not np.allclose(frequency_totals.to_numpy(float), 1.0):
        raise RuntimeError(
            f"Ranking-pathway frequencies do not conserve probability: {frequency_totals.to_dict()}."
        )
    return summary


def main() -> None:
    thermal = build_thermal_transport_frontier()
    pathways = build_ranking_pathway_summary()

    thermal_path = TABLES / f"{VERSION}_thermal_transport_frontier.csv"
    pathway_path = TABLES / f"{VERSION}_ranking_pathway_summary.csv"
    thermal.to_csv(thermal_path, index=False)
    pathways.to_csv(pathway_path, index=False)

    checks = [
        {
            "check": "thermal_transport_frontier_complete",
            "passed": len(thermal) == len(pd.read_csv(INPUTS / f"{VERSION}_candidate_scenario_membership.csv")),
            "detail": {"rows": int(len(thermal)), "columns": int(len(thermal.columns))},
        },
        {
            "check": "ranking_pathways_cover_all_services",
            "passed": pathways["scenario"].nunique() == 7,
            "detail": int(pathways["scenario"].nunique()),
        },
        {
            "check": "ranking_pathway_probability_conservation",
            "passed": bool(np.allclose(pathways.groupby("scenario")["frequency"].sum(), 1.0)),
            "detail": pathways.groupby("scenario")["frequency"].sum().to_dict(),
        },
    ]
    status = "PASS" if all(item["passed"] for item in checks) else "FAIL"
    payload = {
        "status": status,
        "version": VERSION,
        "checks": checks,
        "tables": {
            "thermal_transport_frontier": int(len(thermal)),
            "ranking_pathway_summary": int(len(pathways)),
        },
    }
    (QC / f"{VERSION}_POSTPROCESS_INPUT_CONTRACT_STATUS.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2))
    if status != "PASS":
        raise RuntimeError("Postprocess input-contract table generation failed.")


if __name__ == "__main__":
    main()
