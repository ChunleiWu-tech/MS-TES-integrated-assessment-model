from __future__ import annotations

from pathlib import Path
import os
import json
import zipfile
import subprocess
import sys
import csv
import gc

import numpy as np
import pandas as pd

from upstream_extensions import run_extensions
from editorial_extensions import run_editorial_extensions
from decision_model import (
    TOP_LEVEL_PRIORS, baseline_allowed, credibility_score, hierarchical_utility,
    sample_atomic_scores, scenario_registry,
)

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
IN = ROOT / "data" / "input"
CFG = ROOT / "config"
OUT = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
RAW = ROOT / "data" / "raw_databases"
OUT.mkdir(parents=True, exist_ok=True)
QC.mkdir(parents=True, exist_ok=True)

SEED = 760076
N_MC = int(os.environ.get("TES_N_MC", "20000"))
if N_MC < 100:
    raise ValueError("TES_N_MC must be at least 100")
SCREENING_ADEQUACY = 0.95
STRICT_COMPLETE = 0.999

P = pd.read_csv(IN / f"{VERSION}_candidate_property_registry.csv")
S = pd.read_csv(CFG / f"{VERSION}_system_benchmarks.csv")
M = pd.read_csv(IN / f"{VERSION}_candidate_scenario_membership.csv")
COST = pd.read_csv(IN / f"{VERSION}_component_cost_supply_safety_proxy.csv")
OVR = pd.read_csv(IN / f"{VERSION}_mixture_cost_overrides.csv")
COR = pd.read_csv(IN / f"{VERSION}_corrosion_evidence_registry.csv")
SRC = pd.read_csv(IN / f"{VERSION}_authoritative_source_registry.csv")
VAL = pd.read_csv(IN / f"{VERSION}_literature_validation_tiers.csv")
APP = pd.read_csv(IN / f"{VERSION}_candidate_scenario_evidence_registry.csv")
ATOMIC = pd.read_csv(IN / f"{VERSION}_atomic_engineering_credibility_registry.csv")
ASMP = pd.read_csv(CFG / f"{VERSION}_methodological_assumption_registry.csv")

MW = {
    "KNO2": 85.103,
    "KNO3": 101.103,
    "K2CO3": 138.205,
    "MgCl2": 95.211,
    "KCl": 74.551,
    "NaCl": 58.443,
    "NaNO3": 84.995,
    "Na2CO3": 105.988,
    "Li2CO3": 73.891,
    "LiF": 25.939,
    "NaNO2": 68.995,
    "Ca(NO3)2": 164.086,
    "LiNO3": 68.946,
    "CaCl2": 110.98,
    "Na2SO4": 142.04,
    "NaF": 41.988,
    "KF": 58.096,
}
COMPOSITIONS = {
    "solar_salt_ss60": ("mass", {"NaNO3": 0.60, "KNO3": 0.40}),
    "knc": ("mole", {"KNO2": 0.259, "KNO3": 0.687, "K2CO3": 0.054}),
    "qncc": ("mass", {"NaNO3": 0.54, "KNO3": 0.36, "Na2CO3": 0.06, "NaCl": 0.04}),
    "mgcl_kcl_nacl": ("mass", {"MgCl2": 0.4598, "KCl": 0.3891, "NaCl": 0.1511}),
    "nkca": ("mole", {"NaCl": 0.408, "KCl": 0.075, "CaCl2": 0.517}),
    "pcm_lif_s1": ("mass", {"Na2CO3": 0.57, "Li2CO3": 0.32, "LiF": 0.11}),
    "pcm_binary_carbonate": ("mole", {"Li2CO3": 0.51, "Na2CO3": 0.49}),
    "hitec": ("mass", {"KNO3": 0.53, "NaNO2": 0.40, "NaNO3": 0.07}),
    "hitec_xl": ("mass", {"NaNO3": 0.07, "KNO3": 0.45, "Ca(NO3)2": 0.48}),
    "quat_s7": ("mass", {"Ca(NO3)2": 0.28, "LiNO3": 0.35, "KNO3": 0.18, "NaNO2": 0.19}),
    "tms2": ("mass", {"NaNO3": 0.4201, "KNO3": 0.5630, "Na2SO4": 0.0169}),
    "nknkcl_2026": ("mole", {"NaNO3": 0.326, "KNO3": 0.532, "KCl": 0.142}),
    "nkckcl_2026": ("mass", {"NaNO3": 0.48, "KNO3": 0.32, "K2CO3": 0.10, "KCl": 0.10}),
    "linak_carbonate": ("mass", {"Li2CO3": 0.3212, "Na2CO3": 0.3336, "K2CO3": 0.3452}),
    "flinak_rr": ("mole", {"LiF": 0.465, "NaF": 0.115, "KF": 0.420}),
}


def mass_fracs(system_id: str) -> dict[str, float]:
    basis, comp = COMPOSITIONS[system_id]
    if basis == "mass":
        z = sum(comp.values())
        return {k: v / z for k, v in comp.items()}
    masses = {k: v * MW[k] for k, v in comp.items()}
    z = sum(masses.values())
    return {k: v / z for k, v in masses.items()}


cost_map = COST.set_index("component").to_dict("index")
override_map = OVR.set_index("system_id").to_dict("index") if len(OVR) else {}


def mixture_cost_triplet(system_id: str):
    mf = mass_fracs(system_id)
    vals = {x: 0.0 for x in ["low", "mid", "high"]}
    classes: list[str] = []
    missing: list[str] = []
    for component, weight in mf.items():
        if component not in cost_map:
            missing.append(component)
            continue
        vals["low"] += weight * cost_map[component]["cost_low_usd_kg"]
        vals["mid"] += weight * cost_map[component]["cost_mid_usd_kg"]
        vals["high"] += weight * cost_map[component]["cost_high_usd_kg"]
        classes.append(cost_map[component]["price_evidence_class"])
    if system_id in override_map:
        o = override_map[system_id]
        vals["low"] = min(vals["low"], o["cost_low_usd_kg"])
        vals["mid"] = o["cost_mid_usd_kg"]
        vals["high"] = max(vals["high"], o["cost_high_usd_kg"])
        basis = o["basis"]
    else:
        basis = "mass-fraction component proxy; " + ";".join(sorted(set(classes)))
    return vals["low"], vals["mid"], vals["high"], basis, mf, missing


def cp_coefficients(row):
    """Return Cp(T_C) = c0 + c1*T_C in J g-1 K-1."""
    if row.cp_model == "linear_molar_K":
        return (
            (float(row.cp_a) + float(row.cp_b) * 273.15) / float(row.cp_mw_g_mol),
            float(row.cp_b) / float(row.cp_mw_g_mol),
        )
    return float(row.cp_a), 0.0


def rho_coefficients(row):
    """Return rho(T_C) = d0 + d1*T_C in kg m-3."""
    if row.rho_model == "linear_K":
        return (
            (float(row.rho_a) + float(row.rho_b) * 273.15) * 1000.0,
            float(row.rho_b) * 1000.0,
        )
    if row.rho_model == "linear_C":
        return float(row.rho_a) * 1000.0, float(row.rho_b) * 1000.0
    return float(row.rho_a), 0.0


def cp_value(row, temperature_c):
    c0, c1 = cp_coefficients(row)
    return c0 + c1 * temperature_c


def rho_value(row, temperature_c):
    d0, d1 = rho_coefficients(row)
    return d0 + d1 * temperature_c


def k_value(row, temperature_c):
    if pd.isna(row.k_a):
        return np.nan
    if row.k_model == "linear_K":
        return row.k_a + row.k_b * (temperature_c + 273.15)
    return row.k_a


def property_domain(row, prefix):
    low = getattr(row, f"{prefix}_Tmin_C", np.nan)
    high = getattr(row, f"{prefix}_Tmax_C", np.nan)
    if pd.isna(low) or pd.isna(high):
        return np.nan, np.nan
    return float(low), float(high)


def sensible_property_interval(row, physical_low, physical_high):
    cp_low, cp_high = property_domain(row, "cp")
    rho_low, rho_high = property_domain(row, "rho")
    if not all(np.isfinite([cp_low, cp_high, rho_low, rho_high])):
        low = np.asarray(physical_low, dtype=float)
        return low, low
    return (
        np.maximum(np.asarray(physical_low, dtype=float), max(cp_low, rho_low)),
        np.minimum(np.asarray(physical_high, dtype=float), min(cp_high, rho_high)),
    )


def integrate_sensible(row, low_c, high_c):
    """Integrate fixed-mass enthalpy and normalize by hot-end salt volume.

    Cp in J g-1 K-1 is numerically equal to kJ kg-1 K-1. Results are
    kWh kg-1 and kWh per hot-end m3. Thermal expansion changes occupied
    volume, not salt inventory. Arrays and scalars are both supported.
    """
    lo = np.asarray(low_c, dtype=float)
    hi = np.asarray(high_c, dtype=float)
    valid_hi = np.maximum(hi, lo)
    c0, c1 = cp_coefficients(row)
    d0, d1 = rho_coefficients(row)
    i_cp = c0 * (valid_hi - lo) + 0.5 * c1 * (valid_hi**2 - lo**2)
    hot_density = d0 + d1 * valid_hi
    return i_cp / 3600.0, hot_density * i_cp / 3600.0


def k_in_domain(row, temperature_c):
    low, high = property_domain(row, "k")
    return bool(np.isfinite(low) and np.isfinite(high) and low <= temperature_c <= high)


cor_map = COR.set_index("system_id")
val_map = VAL.set_index("system_id")
app_map = APP.set_index(["scenario", "system_id"])
atomic_map = ATOMIC.set_index(["scenario", "system_id"])


def deterministic_row(service, row):
    cor = cor_map.loc[row.system_id]
    validation = val_map.loc[row.system_id]
    application = app_map.loc[(service.scenario, row.system_id)]
    atomic = atomic_map.loc[(service.scenario, row.system_id)]
    c_low, c_mid, c_high, cost_basis, mf, missing = mixture_cost_triplet(row.system_id)
    base = {
        "scenario": service.scenario,
        "scenario_label": service.scenario_label,
        "service_mode": service.service_mode,
        "system_id": row.system_id,
        "display_system": row.display_system,
        "family": row.family,
        "operation_mode": row.operation_mode,
        "benchmark_system": service.benchmark_system,
        "capacity_MWhth": service.capacity_MWhth,
        "duration_h": service.duration_h,
        "service_basis_type": service.basis_type,
        "service_basis_ids": service.basis_ids,
        "service_assumption_ids": service.assumption_ids,
        "source_ids": row.source_ids,
        "property_data_class": row.property_data_class,
        "candidate_global_literature_validation_tier": validation.literature_validation_tier,
        "candidate_global_literature_validation_factor": validation.literature_validation_factor,
        "candidate_global_claim_class": cor.claim_class,
        "candidate_global_evidence_score": cor.evidence_score,
        "candidate_global_corrosion_processing_burden_index": cor.risk_multiplier_mid,
        "literature_validation_tier": application.application_literature_validation_tier,
        "literature_validation_factor": application.application_literature_validation_factor,
        "corrosion_tier": cor.corrosion_tier,
        "claim_class": application.application_claim_class,
        "evidence_score": application.application_evidence_score,
        "corrosion_processing_burden_index": application.application_corrosion_processing_burden_index,
        "application_evidence_basis": application.application_evidence_basis,
        "application_evidence_override_from_candidate_global": bool(application.override_from_candidate_global),
        "corrosion_compatibility_score": atomic.corrosion_compatibility_mid,
        "cycling_phase_stability_score": atomic.cycling_phase_stability_mid,
        "containment_validation_score": atomic.containment_validation_mid,
        "literature_replication_score": atomic.literature_replication_mid,
        "data_completeness_score": atomic.data_completeness_mid,
        "engineering_burden_index": atomic.burden_index_mid,
        "gap_corrosion": bool(atomic.gap_corrosion),
        "gap_cycling_phase": bool(atomic.gap_cycling_phase),
        "gap_containment": bool(atomic.gap_containment),
        "gap_literature_validation": bool(atomic.gap_literature_validation),
        "gap_data_completeness": bool(atomic.gap_data_completeness),
        "nonclosable_direct_risk": bool(atomic.nonclosable_direct_risk),
        "mixture_cost_low_usd_kg": c_low,
        "mixture_cost_mid_usd_kg": c_mid,
        "mixture_cost_high_usd_kg": c_high,
        "cost_basis": cost_basis,
        "cost_missing_components": ";".join(missing) if missing else "none",
        "composition_mass_fraction_json": json.dumps(mf, sort_keys=True),
        "interpretation": service.interpretation,
    }

    if service.service_mode == "sensible":
        freeze_margin = 20.0
        physical_low = max(service.fixed_Tcold_C, row.Tm_C + freeze_margin)
        physical_high = min(service.fixed_Thot_C, row.Tmax_practical_C)
        full_delta = service.fixed_Thot_C - service.fixed_Tcold_C
        physical_delta = max(0.0, physical_high - physical_low)
        physical_coverage = physical_delta / full_delta
        usable_low_arr, usable_high_arr = sensible_property_interval(row, physical_low, physical_high)
        usable_low = float(np.asarray(usable_low_arr))
        usable_high = float(np.asarray(usable_high_arr))
        overlap_delta = max(0.0, usable_high - usable_low)
        coverage = overlap_delta / full_delta
        if overlap_delta > 0:
            service_mean = (usable_low + usable_high) / 2
            cp = cp_value(row, service_mean)
            density = rho_value(row, service_mean)
        else:
            # Do not report a property value evaluated outside its registered
            # source-valid interval. Zero supported overlap means the strict
            # thermophysical route is infeasible and the representative
            # property values are intentionally undefined.
            service_mean = np.nan
            cp = np.nan
            density = np.nan
        overlap_q, overlap_qv = integrate_sensible(row, usable_low, usable_high)
        overlap_q = float(np.asarray(overlap_q))
        overlap_qv = float(np.asarray(overlap_qv))

        physical_opp_low = max(service.opportunity_Tmin_C, row.Tm_C + freeze_margin)
        physical_opp_high = min(service.opportunity_Tmax_C, row.Tmax_practical_C)
        opp_low_arr, opp_high_arr = sensible_property_interval(row, physical_opp_low, physical_opp_high)
        opp_low = float(np.asarray(opp_low_arr))
        opp_high = float(np.asarray(opp_high_arr))
        opp_delta = max(0.0, opp_high - opp_low)
        if opp_delta > 0:
            opp_mean = (opp_low + opp_high) / 2
            opp_cp = cp_value(row, opp_mean)
            opp_density = rho_value(row, opp_mean)
        else:
            opp_mean = np.nan
            opp_cp = np.nan
            opp_density = np.nan
        opportunity_q, opportunity_qv = integrate_sensible(row, opp_low, opp_high)
        opportunity_q = float(np.asarray(opportunity_q))
        opportunity_qv = float(np.asarray(opportunity_qv))
        phase_match = np.nan
        latent_only = np.nan
        optional_sensible = np.nan
        conductivity_temperature = service_mean
        physical_usable_low = physical_low
        physical_usable_high = physical_high
    else:
        density_reference = (
            float(row.latent_density_reference_C)
            if hasattr(row, "latent_density_reference_C") and pd.notna(row.latent_density_reference_C)
            else float(row.Tm_C)
        )
        cp = cp_value(row, row.Tm_C)
        density = rho_value(row, density_reference)
        coverage = float(service.phase_target_min_C <= row.Tm_C <= service.phase_target_max_C)
        physical_coverage = coverage
        latent_only = row.latent_J_g / 3600.0
        optional_sensible = (row.latent_J_g + cp * 50.0) / 3600.0
        overlap_q = latent_only
        overlap_qv = overlap_q * density
        opportunity_q = optional_sensible
        opportunity_qv = opportunity_q * density
        usable_low = usable_high = opp_low = opp_high = np.nan
        physical_usable_low = physical_usable_high = np.nan
        phase_match = coverage
        conductivity_temperature = row.Tm_C

    strict_complete = coverage >= STRICT_COMPLETE
    strict_physical = physical_coverage >= STRICT_COMPLETE
    screening_adequate = coverage >= SCREENING_ADEQUACY
    complete_q = overlap_q if strict_complete else np.nan
    complete_qv = overlap_qv if strict_complete else np.nan
    mass_per_mwh = 1.0 / complete_q if complete_q > 0 else np.nan
    volume_per_mwh = 1000.0 / complete_qv if complete_qv > 0 else np.nan
    total_mass = mass_per_mwh * service.capacity_MWhth if pd.notna(mass_per_mwh) else np.nan
    total_volume = volume_per_mwh * service.capacity_MWhth if pd.notna(volume_per_mwh) else np.nan
    raw_low = c_low / complete_q if complete_q > 0 else np.nan
    raw_mid = c_mid / complete_q if complete_q > 0 else np.nan
    raw_high = c_high / complete_q if complete_q > 0 else np.nan

    base.update(
        {
            "Tm_C": row.Tm_C,
            "Tmax_practical_C": row.Tmax_practical_C,
            "physical_window_coverage": physical_coverage,
            "fixed_window_coverage": coverage,
            "strict_complete_physical_service_feasible": strict_physical,
            "strict_complete_service_feasible": strict_complete,
            "strict_complete_thermophysical_feasible": strict_complete,
            "property_domain_extrapolation_required": bool(physical_coverage > coverage + 1e-12),
            "physical_usable_Tlow_C": physical_usable_low,
            "physical_usable_Thigh_C": physical_usable_high,
            "screening_service_adequacy_95pct": screening_adequate,
            "fixed_usable_Tlow_C": usable_low,
            "fixed_usable_Thigh_C": usable_high,
            "opportunity_usable_Tlow_C": opp_low,
            "opportunity_usable_Thigh_C": opp_high,
            "cp_at_service_J_gK": cp,
            "density_at_service_kg_m3": density,
            "thermal_k_at_service_W_mK": (
                k_value(row, conductivity_temperature)
                if k_in_domain(row, conductivity_temperature)
                else np.nan
            ),
            "thermal_k_domain_valid_at_service": k_in_domain(row, conductivity_temperature),
            "partial_overlap_energy_fixed_kWh_kg": overlap_q,
            "partial_overlap_energy_fixed_kWh_m3": overlap_qv,
            "complete_service_energy_fixed_kWh_kg": complete_q,
            "complete_service_energy_fixed_kWh_m3": complete_qv,
            "opportunity_envelope_energy_kWh_kg": opportunity_q,
            "opportunity_envelope_energy_kWh_m3": opportunity_qv,
            "opportunity_gain_vs_complete_fixed_pct": (
                (opportunity_q / complete_q - 1.0) * 100.0 if complete_q > 0 else np.nan
            ),
            "latent_only_kWh_kg": latent_only,
            "latent_plus_optional_50K_kWh_kg": optional_sensible,
            "phase_temperature_match": phase_match,
            "required_salt_mass_t_per_MWhth": mass_per_mwh,
            "required_salt_volume_m3_per_MWhth": volume_per_mwh,
            "required_salt_mass_t_for_case": total_mass,
            "required_salt_volume_m3_for_case": total_volume,
            "raw_material_cost_proxy_low_usd_kWhth": raw_low,
            "raw_material_cost_proxy_mid_usd_kWhth": raw_mid,
            "raw_material_cost_proxy_high_usd_kWhth": raw_high,
        }
    )
    return base


# Validate that scenario membership labels are not stale aliases.
property_names = P.set_index("system_id")["display_system"].to_dict()
membership_mismatches = M[
    M.apply(lambda x: property_names.get(x.system_id) != x.display_system, axis=1)
].copy()

D = pd.DataFrame(
    [
        deterministic_row(
            S[S.scenario == member.scenario].iloc[0],
            P[P.system_id == member.system_id].iloc[0],
        )
        for _, member in M.iterrows()
    ]
)

# Benchmark-relative values are calculated only when both values represent strict complete service.
for scenario, group in D.groupby("scenario"):
    benchmark = group[group.display_system == group.benchmark_system.iloc[0]]
    if benchmark.empty:
        continue
    benchmark = benchmark.iloc[0]
    idx = D.scenario == scenario
    for col, outcol in [
        ("complete_service_energy_fixed_kWh_m3", "energy_density_change_vs_benchmark_pct"),
        ("required_salt_volume_m3_per_MWhth", "volume_change_vs_benchmark_pct"),
        ("raw_material_cost_proxy_mid_usd_kWhth", "raw_cost_change_vs_benchmark_pct"),
    ]:
        if pd.notna(benchmark[col]) and benchmark[col] != 0:
            valid = idx & D[col].notna()
            D.loc[valid, outcol] = (D.loc[valid, col] / benchmark[col] - 1.0) * 100.0
D.to_csv(OUT / f"{VERSION}_candidate_system_metrics_deterministic.csv", index=False)

# Registered deterministic model-form and provenance sensitivities. These rows
# do not replace the primary model; they expose the effect of legacy
# extrapolation, the QNCC temperature-dependent Cp fit, and the alternate
# MSD-TP melting value for the MgCl2-KCl-NaCl system.
sensitivity_rows = []
for _, drow in D.iterrows():
    prow = P[P.system_id.eq(drow.system_id)].iloc[0]
    service = S[S.scenario.eq(drow.scenario)].iloc[0]
    if service.service_mode == "sensible":
        physical_low = float(drow.physical_usable_Tlow_C)
        physical_high = float(drow.physical_usable_Thigh_C)
        physical_delta = max(0.0, physical_high - physical_low)
        physical_mean = (physical_low + physical_high) / 2.0 if physical_delta > 0 else np.nan
        legacy_qv = (
            cp_value(prow, physical_mean) * rho_value(prow, physical_mean) * physical_delta / 3600.0
            if physical_delta > 0 else 0.0
        )
        sensitivity_rows.append({
            "scenario": drow.scenario,
            "system_id": drow.system_id,
            "display_system": drow.display_system,
            "sensitivity_case": "legacy_physical_window_property_extrapolation",
            "primary_fixed_window_coverage": drow.fixed_window_coverage,
            "variant_fixed_window_coverage": drow.physical_window_coverage,
            "primary_energy_kWh_m3": drow.partial_overlap_energy_fixed_kWh_m3,
            "variant_energy_kWh_m3": legacy_qv,
            "variant_minus_primary_pct": ((legacy_qv / drow.partial_overlap_energy_fixed_kWh_m3 - 1.0) * 100.0
                if drow.partial_overlap_energy_fixed_kWh_m3 > 0 else np.nan),
            "interpretation": "Diagnostic only: quantifies the overstatement produced when phase stability is incorrectly used to extrapolate Cp and density beyond their registered validity domains.",
        })
        if drow.system_id == "qncc":
            lo = float(drow.fixed_usable_Tlow_C)
            hi = float(drow.fixed_usable_Thigh_C)
            d0, d1 = rho_coefficients(prow)
            c0, c1 = 1.7061, -5.5826e-4
            p0 = c0*d0; p1 = c0*d1+c1*d0; p2 = c1*d1
            alt_qv = (p0*(hi-lo)+0.5*p1*(hi**2-lo**2)+(p2/3.0)*(hi**3-lo**3))/3600.0 if hi>lo else 0.0
            sensitivity_rows.append({
                "scenario": drow.scenario, "system_id": drow.system_id, "display_system": drow.display_system,
                "sensitivity_case": "qncc_temperature_dependent_cp_equation",
                "primary_fixed_window_coverage": drow.fixed_window_coverage,
                "variant_fixed_window_coverage": drow.fixed_window_coverage,
                "primary_energy_kWh_m3": drow.partial_overlap_energy_fixed_kWh_m3,
                "variant_energy_kWh_m3": alt_qv,
                "variant_minus_primary_pct": ((alt_qv/drow.partial_overlap_energy_fixed_kWh_m3-1)*100 if drow.partial_overlap_energy_fixed_kWh_m3>0 else np.nan),
                "interpretation": "Model-form sensitivity only; the primary input remains the article-reported average liquid Cp of 1.56 J g-1 K-1.",
            })
        if drow.system_id == "mgcl_kcl_nacl":
            alt_tm = 382.85
            alt_physical_low = max(float(service.fixed_Tcold_C), alt_tm + 20.0)
            alt_physical_high = min(float(service.fixed_Thot_C), float(prow.Tmax_practical_C))
            alt_low, alt_high = sensible_property_interval(prow, alt_physical_low, alt_physical_high)
            alt_low=float(np.asarray(alt_low)); alt_high=float(np.asarray(alt_high))
            _, alt_qv = integrate_sensible(prow, alt_low, alt_high); alt_qv=float(np.asarray(alt_qv))
            alt_cov=max(0.0,alt_high-alt_low)/(float(service.fixed_Thot_C)-float(service.fixed_Tcold_C))
            sensitivity_rows.append({
                "scenario": drow.scenario, "system_id": drow.system_id, "display_system": drow.display_system,
                "sensitivity_case": "mgcl_msd_tp_alternate_melting_temperature",
                "primary_fixed_window_coverage": drow.fixed_window_coverage,
                "variant_fixed_window_coverage": alt_cov,
                "primary_energy_kWh_m3": drow.partial_overlap_energy_fixed_kWh_m3,
                "variant_energy_kWh_m3": alt_qv,
                "variant_minus_primary_pct": ((alt_qv/drow.partial_overlap_energy_fixed_kWh_m3-1)*100 if drow.partial_overlap_energy_fixed_kWh_m3>0 else np.nan),
                "interpretation": "Sensitivity only; the direct exact-composition DSC mean of 401.4 C is the primary input.",
            })
    elif drow.system_id == "nkca":
        sensitivity_rows.append({
            "scenario": drow.scenario, "system_id": drow.system_id, "display_system": drow.display_system,
            "sensitivity_case": "nkca_rejected_near_composition_latent",
            "primary_fixed_window_coverage": drow.fixed_window_coverage,
            "variant_fixed_window_coverage": drow.fixed_window_coverage,
            "primary_energy_kWh_m3": drow.partial_overlap_energy_fixed_kWh_m3,
            "variant_energy_kWh_m3": (156.7/3600.0)*rho_value(prow, float(prow.latent_density_reference_C)),
            "variant_minus_primary_pct": (((156.7/171.5)-1.0)*100.0),
            "interpretation": "Rejected main-input route: 156.7 J g-1 belongs to a nearby composition and is retained only to disclose the magnitude of the former composition-property mismatch.",
        })
pd.DataFrame(sensitivity_rows).to_csv(OUT / f"{VERSION}_property_model_sensitivity_deterministic.csv", index=False)
property_domain_audit = D[["scenario","system_id","display_system","physical_window_coverage","fixed_window_coverage","strict_complete_physical_service_feasible","strict_complete_thermophysical_feasible","property_domain_extrapolation_required","cp_at_service_J_gK","density_at_service_kg_m3","thermal_k_domain_valid_at_service"]].copy()
property_domain_audit["thermophysical_window_coverage"] = property_domain_audit["fixed_window_coverage"]
property_domain_audit.to_csv(OUT / f"{VERSION}_property_domain_coverage_audit.csv", index=False)


def nondominated(group, cols, maximize):
    values = group[cols].to_numpy(float)
    flags = []
    for i, candidate in enumerate(values):
        dominated = False
        for j, alternative in enumerate(values):
            if i == j:
                continue
            weak = []
            strict = []
            for k, is_max in enumerate(maximize):
                weak.append(alternative[k] >= candidate[k] if is_max else alternative[k] <= candidate[k])
                strict.append(alternative[k] > candidate[k] if is_max else alternative[k] < candidate[k])
            if all(weak) and any(strict):
                dominated = True
                break
        flags.append(not dominated)
    return flags


pareto_frames = []
for scenario, group in D[D.strict_complete_service_feasible].groupby("scenario"):
    group = group.copy()
    group["primary_pareto"] = nondominated(
        group,
        [
            "complete_service_energy_fixed_kWh_m3",
            "evidence_score",
            "literature_validation_factor",
            "corrosion_processing_burden_index",
        ],
        [True, True, True, False],
    )
    group["cost_sensitivity_pareto"] = nondominated(
        group,
        [
            "complete_service_energy_fixed_kWh_m3",
            "evidence_score",
            "raw_material_cost_proxy_mid_usd_kWhth",
        ],
        [True, True, False],
    )
    pareto_frames.append(group)
PF = pd.concat(pareto_frames, ignore_index=True) if pareto_frames else pd.DataFrame()
PF.to_csv(OUT / f"{VERSION}_system_value_pareto_fronts.csv", index=False)

# Benchmark inclusion and plausibility checks: presence, strict deterministic service and a bounded evidence base.
benchmark_rows = []
for _, service in S.iterrows():
    group = D[D.scenario == service.scenario]
    benchmark = group[group.display_system == service.benchmark_system]
    if benchmark.empty:
        benchmark_rows.append(
            {"scenario": service.scenario, "benchmark": service.benchmark_system, "plausibility_status": "MISSING"}
        )
        continue
    row = benchmark.iloc[0]
    pf = PF[(PF.scenario == service.scenario) & (PF.display_system == service.benchmark_system)]
    role = "commercial_benchmark" if service.service_mode != "latent" else "literature_reference_pcm"
    status = "PASS" if bool(row.strict_complete_service_feasible) and row.evidence_score >= 0.35 else "REVIEW"
    benchmark_rows.append(
        {
            "scenario": service.scenario,
            "scenario_label": service.scenario_label,
            "benchmark": service.benchmark_system,
            "benchmark_role": role,
            "strict_complete_service_feasible": bool(row.strict_complete_service_feasible),
            "primary_pareto": bool(len(pf) and pf.iloc[0].primary_pareto),
            "evidence_score": row.evidence_score,
            "plausibility_status": status,
        }
    )
BR = pd.DataFrame(benchmark_rows)
BR.to_csv(OUT / f"{VERSION}_benchmark_inclusion_plausibility_check.csv", index=False)
VAL.to_csv(OUT / f"{VERSION}_literature_reported_validation_evidence.csv", index=False)
APP.to_csv(OUT / f"{VERSION}_candidate_scenario_evidence_registry.csv", index=False)


def normalized_by_draw(values, feasible, benefit=True):
    output = np.full_like(values, np.nan, dtype=float)
    for i in range(values.shape[0]):
        mask = feasible[i] & np.isfinite(values[i])
        if not mask.any():
            continue
        v = values[i, mask]
        lo = np.min(v)
        hi = np.max(v)
        if hi - lo < 1e-12:
            output[i, mask] = 0.5
        else:
            output[i, mask] = (v - lo) / (hi - lo)
    return output if benefit else 1.0 - output


def conditional_percentile(values, mask, percentile):
    valid = values[mask & np.isfinite(values)]
    return float(np.percentile(valid, percentile)) if valid.size else np.nan


# Preference-conditioned selection frequencies: physical uncertainty is combined with explicit, named decision-weight priors after non-compensatory gates.
# These are model selection frequencies, not objective probabilities of material superiority or a universal comprehensive score.
weight_priors = TOP_LEVEL_PRIORS
mc_summary_rows = []
selection_rows = []
weight_sensitivity_rows = []
no_selection_rows = []
transition_rows = []
rank_prob_rows = []
pairwise_rows = []
gate_rows = []
convergence_rows = []
uncertainty_rows = []
margin_rows = []
normalization_audit_rows = []

# Draw-level Monte Carlo rows are streamed with Python's standard CSV writer.
# This bypasses pandas' native get_values_for_csv conversion path, which caused
# Windows heap-corruption failures during registered 20,000-draw runs.
DRAWS_PATH = OUT / f"{VERSION}_monte_carlo_draws_balanced.csv"
if DRAWS_PATH.exists():
    DRAWS_PATH.unlink()
_DRAW_FILE_HAS_HEADER = False


def append_draw_candidate(
    *, service, system_id, display_system, j, coverage, screening_adequate,
    strict_complete, qv_overlap, qv_screening, qv_complete, raw_cost,
    cost_complete, balanced_primary, ranks_balanced, balanced_winner,
    no_balanced, top_margin, atomic_scores, burden_samples, credibility,
    failed_incomplete, failed_corrosion_const, failed_cycling_const,
    failed_containment_const, failed_evidence_const, failed_validation_const,
    failed_data_const, failure_count, base_reason, chunk_size=2000,
) -> None:
    """Append one candidate's draw-level rows without pandas CSV formatting.

    Windows reported native heap corruption inside pandas ``get_values_for_csv``
    even when the DataFrame was manually limited to 2,000 rows.  This exporter
    therefore bypasses pandas' BlockManager/string-conversion path entirely and
    streams rows with Python's standard-library ``csv`` writer.  Only output
    serialization changes; all sampled arrays and scientific calculations are
    unchanged.
    """
    global _DRAW_FILE_HAS_HEADER
    fieldnames = [
        "scenario", "scenario_label", "draw_id", "system_id", "display_system",
        "benchmark_system", "coverage", "screening_adequate_95pct",
        "strict_complete", "partial_overlap_energy_density_kWh_m3",
        "screening_energy_density_kWh_m3", "complete_service_energy_density_kWh_m3",
        "partial_overlap_raw_cost_usd_kWhth", "screening_raw_cost_usd_kWhth",
        "raw_cost_usd_kWhth", "balanced_utility", "balanced_rank",
        "is_balanced_winner", "top_two_margin", "sampled_corrosion_compatibility",
        "sampled_cycling_phase_stability", "sampled_containment_validation",
        "sampled_literature_replication", "sampled_data_completeness",
        "sampled_engineering_burden_index", "sampled_engineering_credibility",
        "failed_incomplete_service", "failed_no_bounded_selection_policy",
        "failed_corrosion_gate", "failed_cycling_phase_gate",
        "failed_containment_gate", "failed_evidence_gate", "failed_validation_gate",
        "failed_data_completeness_gate", "failed_claim_gate", "gate_failure_count",
        "gate_reason_first_assigned", "gate_reason",
    ]

    with DRAWS_PATH.open("a", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        if not _DRAW_FILE_HAS_HEADER:
            writer.writerow(fieldnames)
            _DRAW_FILE_HAS_HEADER = True

        for start in range(0, N_MC, chunk_size):
            stop = min(start + chunk_size, N_MC)
            sl = slice(start, stop)
            n_rows = stop - start
            reasons = np.where(failed_incomplete[sl], "incomplete_service", base_reason)

            columns = [
                [service.scenario] * n_rows,
                [service.scenario_label] * n_rows,
                np.arange(start + 1, stop + 1, dtype=np.int32),
                [system_id] * n_rows,
                [display_system] * n_rows,
                [service.benchmark_system] * n_rows,
                coverage[sl, j],
                screening_adequate[sl, j],
                strict_complete[sl, j],
                qv_overlap[sl, j],
                qv_screening[sl, j],
                qv_complete[sl, j],
                raw_cost[sl, j],
                np.where(screening_adequate[sl, j], raw_cost[sl, j], np.nan),
                cost_complete[sl, j],
                np.where(np.isfinite(balanced_primary[sl, j]), balanced_primary[sl, j], np.nan),
                ranks_balanced[sl, j],
                (balanced_winner[sl] == j) & (~no_balanced[sl]),
                top_margin[sl],
                atomic_scores["corrosion_compatibility"][sl, j],
                atomic_scores["cycling_phase_stability"][sl, j],
                atomic_scores["containment_validation"][sl, j],
                atomic_scores["literature_replication"][sl, j],
                atomic_scores["data_completeness"][sl, j],
                burden_samples[sl, j],
                credibility[sl, j],
                failed_incomplete[sl],
                [False] * n_rows,
                [failed_corrosion_const] * n_rows,
                [failed_cycling_const] * n_rows,
                [failed_containment_const] * n_rows,
                [failed_evidence_const] * n_rows,
                [failed_validation_const] * n_rows,
                [failed_data_const] * n_rows,
                [False] * n_rows,
                failure_count[sl],
                reasons,
                reasons,
            ]
            writer.writerows(zip(*columns))
            del columns, reasons

    gc.collect()


prop = P.set_index("system_id")
cor = COR.set_index("system_id")
validation = VAL.set_index("system_id")

for service_index, service in S.reset_index(drop=True).iterrows():
    print(f"[upstream] Monte Carlo service {service_index + 1}/{len(S)}: {service.scenario} ({N_MC:,} draws)", flush=True)
    members = M[M.scenario == service.scenario].system_id.tolist()
    n_candidates = len(members)
    rng = np.random.default_rng(SEED + service_index * 1009)
    qv_overlap = np.full((N_MC, n_candidates), np.nan)
    raw_cost = np.full((N_MC, n_candidates), np.nan)
    coverage = np.full((N_MC, n_candidates), np.nan)
    physical_coverage = np.full((N_MC, n_candidates), np.nan)
    app_group = APP[APP.scenario.eq(service.scenario)].set_index("system_id")
    atomic_group = scenario_registry(ATOMIC, service.scenario, members)
    evidence = np.array([app_group.loc[m].application_evidence_score for m in members], dtype=float)  # descriptive legacy field only
    external = np.array([app_group.loc[m].application_literature_validation_factor for m in members], dtype=float)  # descriptive only
    burden = atomic_group.burden_index_mid.to_numpy(float)
    # Freeze margin is a service-level operating assumption, so each physical
    # draw uses one common value across candidates (common random numbers).
    shared_freeze_margin = (
        rng.triangular(10.0, 20.0, 30.0, N_MC)
        if service.service_mode == "sensible" else None
    )

    for j, system_id in enumerate(members):
        row = prop.loc[system_id]
        c_low, c_mid, c_high, _, _, _ = mixture_cost_triplet(system_id)
        sampled_component_cost = rng.triangular(c_low, c_mid, c_high, N_MC)
        tm = rng.normal(row.Tm_C, max(row.Tm_unc_C, 0.1), N_MC)
        tmax = rng.normal(row.Tmax_practical_C, max(row.Tmax_unc_C, 0.1), N_MC)
        if service.service_mode == "sensible":
            physical_low = np.maximum(service.fixed_Tcold_C, tm + shared_freeze_margin)
            physical_high = np.minimum(service.fixed_Thot_C, tmax)
            physical_delta = np.maximum(0.0, physical_high - physical_low)
            physical_coverage[:, j] = physical_delta / (service.fixed_Thot_C - service.fixed_Tcold_C)
            usable_low, usable_high = sensible_property_interval(row, physical_low, physical_high)
            delta = np.maximum(0.0, usable_high - usable_low)
            coverage[:, j] = delta / (service.fixed_Thot_C - service.fixed_Tcold_C)
            base_q, base_qv = integrate_sensible(row, usable_low, usable_high)
            cp_factor = np.clip(rng.normal(1.0, abs(row.cp_rel_unc), N_MC), 0.2, None)
            density_factor = np.clip(rng.normal(1.0, abs(row.rho_rel_unc), N_MC), 0.2, None)
            q = base_q * cp_factor
            qv_overlap[:, j] = base_qv * cp_factor * density_factor
        else:
            latent = np.clip(
                rng.normal(row.latent_J_g, abs(row.latent_J_g * row.latent_rel_unc), N_MC),
                1.0,
                None,
            )
            density_reference = (
                np.maximum(tm, float(row.latent_density_reference_C))
                if hasattr(row, "latent_density_reference_C") and pd.notna(row.latent_density_reference_C)
                else tm
            )
            rho0 = rho_value(row, density_reference)
            density = np.clip(rng.normal(rho0, np.abs(rho0 * row.rho_rel_unc), N_MC), 500.0, None)
            q = latent / 3600.0
            coverage[:, j] = ((tm >= service.phase_target_min_C) & (tm <= service.phase_target_max_C)).astype(float)
            physical_coverage[:, j] = coverage[:, j]
            qv_overlap[:, j] = q * density
        raw_cost[:, j] = sampled_component_cost / np.where(q > 0, q, np.nan)

    strict_complete = coverage >= STRICT_COMPLETE
    screening_adequate = coverage >= SCREENING_ADEQUACY
    # The 95% threshold is retained only for exploratory thermophysical screening.
    # All bounded decision and price-sensitivity selections require strict complete service.
    qv_screening = np.where(screening_adequate, qv_overlap, np.nan)
    qv_complete = np.where(strict_complete, qv_overlap, np.nan)
    cost_complete = np.where(strict_complete, raw_cost, np.nan)
    # Strict thermophysical normalization is retained for the separate price sensitivity.
    qscore_strict = normalized_by_draw(qv_complete, strict_complete, benefit=True)
    cscore_strict = normalized_by_draw(cost_complete, strict_complete, benefit=False)
    # Sample atomic engineering-evidence dimensions and keep them inside a
    # single engineering-credibility branch of the hierarchy. This avoids the
    # former repeated counting of evidence, literature validation and burden.
    evidence_rng = np.random.default_rng(SEED + 70_000 + service_index * 1009)
    atomic_scores, burden_samples = sample_atomic_scores(atomic_group, N_MC, evidence_rng)
    eligible = baseline_allowed(atomic_group)
    decision_feasible = strict_complete & eligible[None, :]
    qscore = normalized_by_draw(qv_complete, decision_feasible, benefit=True)
    credibility, bscore = credibility_score(
        atomic_scores, burden_samples, decision_feasible, model="hierarchical_geometric"
    )
    normalization_audit_rows.append(
        {
            "scenario": service.scenario,
            "registered_candidates": n_candidates,
            "atomic_gate_eligible_candidates": int(eligible.sum()),
            "normalization_scope": "strict_complete_and_atomic_engineering_gates_within_draw",
            "gates_applied_before_normalization": True,
            "pcm_policy_override_applied": False,
        }
    )

    # Strict complete-service thermophysical reference layer.
    # The 95% adequacy threshold is retained only for exploratory diagnostics;
    # evidence-only redirection must compare identical strict service scope.
    thermophysical = np.where(strict_complete, qv_overlap, -np.inf)
    no_thermo = np.all(~np.isfinite(thermophysical), axis=1)
    thermo_winner = np.argmax(thermophysical, axis=1)

    # Secondary price-inclusive sensitivity, kept separate from the primary decision.
    cost_rng = np.random.default_rng(SEED + 50_000 + service_index * 1009)
    cost_weights = cost_rng.dirichlet([3.0, 2.0, 2.0], N_MC)
    # Price remains a secondary sensitivity and uses the same atomic eligibility.
    secondary = (
        cost_weights[:, [0]] * qscore
        + cost_weights[:, [1]] * cscore_strict
        + cost_weights[:, [2]] * credibility
    )
    secondary[~decision_feasible] = -np.inf
    no_cost = np.all(~np.isfinite(secondary), axis=1)
    cost_winner = np.argmax(secondary, axis=1)

    prior_no_frequency = {}
    for prior_index, (prior_name, alpha) in enumerate(weight_priors.items()):
        prior_rng = np.random.default_rng(SEED + 100_000 + service_index * 10_000 + prior_index * 101)
        weights = prior_rng.dirichlet(alpha, N_MC)
        primary = hierarchical_utility(qscore, credibility, weights, decision_feasible)
        no_primary = np.all(~np.isfinite(primary), axis=1)
        prior_no_frequency[prior_name] = float(np.mean(no_primary))
        primary_winner = np.argmax(primary, axis=1)

        # Joint, draw-matched transition matrix for scientifically valid alluvial plots.
        # Each row links the thermophysical winner and the evidence-qualified outcome
        # from the same Monte Carlo draw; "none" denotes no qualified selection.
        from_state = np.where(no_thermo, -1, thermo_winner)
        to_state = np.where(no_primary, -1, primary_winner)
        pairs, counts = np.unique(np.column_stack([from_state, to_state]), axis=0, return_counts=True)
        for (from_index, to_index), count in zip(pairs, counts):
            from_id = "none" if from_index < 0 else members[int(from_index)]
            to_id = "none" if to_index < 0 else members[int(to_index)]
            transition_rows.append(
                {
                    "scenario": service.scenario,
                    "scenario_label": service.scenario_label,
                    "weight_prior": prior_name,
                    "from_layer": "strict_complete_thermophysical",
                    "from_system_id": from_id,
                    "from_display_system": "none" if from_id == "none" else prop.loc[from_id].display_system,
                    "to_layer": "strict_complete_evidence_bounded",
                    "to_system_id": to_id,
                    "to_display_system": "none" if to_id == "none" else prop.loc[to_id].display_system,
                    "transition_draws": int(count),
                    "transition_frequency": float(count / N_MC),
                    "mc_iterations": N_MC,
                }
            )

        no_selection_rows.append(
            {
                "scenario": service.scenario,
                "scenario_label": service.scenario_label,
                "ranking_layer": "evidence_qualified",
                "weight_prior": prior_name,
                "no_selection_frequency": float(np.mean(no_primary)),
                "mc_iterations": N_MC,
            }
        )
        for j, system_id in enumerate(members):
            row_out = {
                "scenario": service.scenario,
                "scenario_label": service.scenario_label,
                "weight_prior": prior_name,
                "system_id": system_id,
                "display_system": prop.loc[system_id].display_system,
                "selection_frequency": float(np.mean((primary_winner == j) & (~no_primary))),
                "eligible_for_evidence_layer": bool(eligible[j]),
                "mean_weight_performance": float(weights[:, 0].mean()),
                "mean_weight_engineering_credibility": float(weights[:, 1].mean()),
                "credibility_aggregation": "equal_weight_geometric_atomic_dimensions",
                "mc_iterations": N_MC,
            }
            weight_sensitivity_rows.append(row_out)
            if prior_name == "balanced":
                selection_rows.append(
                    {
                        "scenario": service.scenario,
                        "scenario_label": service.scenario_label,
                        "ranking_layer": "evidence_qualified",
                        "weight_prior": prior_name,
                        "system_id": system_id,
                        "display_system": prop.loc[system_id].display_system,
                        "selection_frequency": row_out["selection_frequency"],
                        "eligible_for_layer": bool(eligible[j]),
                        "mc_iterations": N_MC,
                    }
                )

    # Balanced-prior draw-level diagnostics and audit outputs.
    balanced_prior_index = list(weight_priors.keys()).index("balanced")
    balanced_rng = np.random.default_rng(SEED + 100_000 + service_index * 10_000 + balanced_prior_index * 101)
    balanced_weights = balanced_rng.dirichlet(weight_priors["balanced"], N_MC)
    balanced_primary = hierarchical_utility(qscore, credibility, balanced_weights, decision_feasible)
    no_balanced = np.all(~np.isfinite(balanced_primary), axis=1)
    balanced_winner = np.argmax(balanced_primary, axis=1)
    valid_balanced = np.isfinite(balanced_primary)
    ranks_balanced = np.full_like(balanced_primary, np.nan, dtype=float)
    for di in range(N_MC):
        vals = balanced_primary[di]
        finite = np.isfinite(vals)
        if finite.any():
            order = np.argsort(-vals[finite], kind="mergesort")
            idx = np.where(finite)[0][order]
            ranks_balanced[di, idx] = np.arange(1, len(idx) + 1)
    eligible_count_per_draw = valid_balanced.sum(axis=1)
    sorted_vals = np.sort(balanced_primary, axis=1)
    top_margin = np.full(N_MC, np.nan, dtype=float)
    if n_candidates > 1:
        multi_mask = eligible_count_per_draw >= 2
        top_margin[multi_mask] = sorted_vals[multi_mask, -1] - sorted_vals[multi_mask, -2]

    # Draw-level outputs preserve partial/screening/strict energy separately and
    # retain simultaneous gate failures. Rows are vectorized and appended to
    # disk candidate by candidate to avoid the large Python-object peak that
    # caused Windows access-violation crashes at 20,000 draws.
    for j, system_id in enumerate(members):
        ar = atomic_group.iloc[j]
        failed_incomplete = ~strict_complete[:, j]
        failed_policy = np.zeros(N_MC, dtype=bool)
        failed_corrosion_const = bool(ar.gap_corrosion or ar.nonclosable_direct_risk)
        failed_cycling_const = bool(ar.gap_cycling_phase)
        failed_containment_const = bool(ar.gap_containment)
        failed_validation_const = bool(ar.gap_literature_validation)
        failed_data_const = bool(ar.gap_data_completeness)
        failed_evidence_const = bool(failed_cycling_const or failed_containment_const or failed_data_const)
        failed_claim = np.zeros(N_MC, dtype=bool)

        constant_failure_count = int(
            failed_corrosion_const
            + failed_cycling_const
            + failed_containment_const
            + failed_validation_const
            + failed_data_const
        )
        failure_count = failed_incomplete.astype(np.int8) + constant_failure_count

        if failed_corrosion_const:
            base_reason = "corrosion_gate"
        elif failed_cycling_const:
            base_reason = "cycling_phase_gate"
        elif failed_containment_const:
            base_reason = "containment_gate"
        elif failed_validation_const:
            base_reason = "validation_gate"
        elif failed_data_const:
            base_reason = "data_completeness_gate"
        else:
            base_reason = "retained"
        display_system = prop.loc[system_id].display_system
        append_draw_candidate(
            service=service,
            system_id=system_id,
            display_system=display_system,
            j=j,
            coverage=coverage,
            screening_adequate=screening_adequate,
            strict_complete=strict_complete,
            qv_overlap=qv_overlap,
            qv_screening=qv_screening,
            qv_complete=qv_complete,
            raw_cost=raw_cost,
            cost_complete=cost_complete,
            balanced_primary=balanced_primary,
            ranks_balanced=ranks_balanced,
            balanced_winner=balanced_winner,
            no_balanced=no_balanced,
            top_margin=top_margin,
            atomic_scores=atomic_scores,
            burden_samples=burden_samples,
            credibility=credibility,
            failed_incomplete=failed_incomplete,
            failed_corrosion_const=failed_corrosion_const,
            failed_cycling_const=failed_cycling_const,
            failed_containment_const=failed_containment_const,
            failed_evidence_const=failed_evidence_const,
            failed_validation_const=failed_validation_const,
            failed_data_const=failed_data_const,
            failure_count=failure_count,
            base_reason=base_reason,
        )

        # There can be only two first-assigned outcomes for a candidate:
        # incomplete service, or the candidate's constant evidence/gate state.
        # Count them directly; do not construct a pandas string Series.
        incomplete_count = int(np.count_nonzero(failed_incomplete))
        retained_or_gate_count = int(N_MC - incomplete_count)
        reason_counts = [("incomplete_service", incomplete_count), (base_reason, retained_or_gate_count)]
        reason_counts.sort(key=lambda item: item[1], reverse=True)
        for reason, count in reason_counts:
            if count == 0:
                continue
            gate_rows.append(
                {
                    "scenario": service.scenario,
                    "scenario_label": service.scenario_label,
                    "system_id": system_id,
                    "display_system": display_system,
                    "gate_reason": reason,
                    "draws": count,
                    "frequency": float(count / N_MC),
                }
            )

        finite_rank = ranks_balanced[:, j]
        finite_rank = finite_rank[np.isfinite(finite_rank)].astype(np.int16, copy=False)
        if finite_rank.size:
            rank_values, rank_counts = np.unique(finite_rank, return_counts=True)
            for rank, count in zip(rank_values, rank_counts):
                rank_prob_rows.append(
                    {
                        "scenario": service.scenario,
                        "scenario_label": service.scenario_label,
                        "system_id": system_id,
                        "display_system": display_system,
                        "rank": int(rank),
                        "rank_frequency": float(int(count) / N_MC),
                    }
                )
        del finite_rank

    # Pairwise superiority probabilities and top-two margin summaries.
    for j in range(n_candidates):
        for k in range(j + 1, n_candidates):
            e_mask = np.isfinite(qv_complete[:, j]) & np.isfinite(qv_complete[:, k])
            u_mask = np.isfinite(balanced_primary[:, j]) & np.isfinite(balanced_primary[:, k])
            pairwise_rows.append(
                {
                    "scenario": service.scenario,
                    "scenario_label": service.scenario_label,
                    "system_i": members[j],
                    "display_i": prop.loc[members[j]].display_system,
                    "system_j": members[k],
                    "display_j": prop.loc[members[k]].display_system,
                    "energy_comparable_draws": int(e_mask.sum()),
                    "energy_superiority_i_gt_j": float(np.mean(qv_complete[e_mask, j] > qv_complete[e_mask, k])) if e_mask.any() else np.nan,
                    "energy_superiority_j_gt_i": float(np.mean(qv_complete[e_mask, k] > qv_complete[e_mask, j])) if e_mask.any() else np.nan,
                    "utility_comparable_draws": int(u_mask.sum()),
                    "utility_superiority_i_gt_j": float(np.mean(balanced_primary[u_mask, j] > balanced_primary[u_mask, k])) if u_mask.any() else np.nan,
                    "utility_superiority_j_gt_i": float(np.mean(balanced_primary[u_mask, k] > balanced_primary[u_mask, j])) if u_mask.any() else np.nan,
                }
            )

    finite_margin = np.isfinite(top_margin)
    margin_rows.append(
        {
            "scenario": service.scenario,
            "scenario_label": service.scenario_label,
            "margin_status": "defined" if finite_margin.any() else ("no_bounded_candidate" if np.all(eligible_count_per_draw == 0) else "single_bounded_candidate_only"),
            "margin_p05": float(np.nanpercentile(top_margin, 5)) if finite_margin.any() else np.nan,
            "margin_p50": float(np.nanpercentile(top_margin, 50)) if finite_margin.any() else np.nan,
            "margin_p95": float(np.nanpercentile(top_margin, 95)) if finite_margin.any() else np.nan,
            "margin_mean": float(np.nanmean(top_margin)) if finite_margin.any() else np.nan,
            "nonmissing_draws": int(finite_margin.sum()),
            "multiple_candidate_draw_frequency": float(np.mean(eligible_count_per_draw >= 2)),
            "single_candidate_draw_frequency": float(np.mean(eligible_count_per_draw == 1)),
            "no_candidate_draw_frequency": float(np.mean(eligible_count_per_draw == 0)),
            "mc_iterations": N_MC,
        }
    )

    # Monte Carlo convergence diagnostics at increasing sample counts.
    checkpoints = [n for n in [500, 1000, 2000, 5000, 10000, 20000] if n <= N_MC]
    if N_MC not in checkpoints:
        checkpoints.append(N_MC)
    checkpoints = sorted(set(checkpoints))
    for n in checkpoints:
        sub_no = no_balanced[:n]
        sub_win = balanced_winner[:n]
        convergence_rows.append(
            {
                "scenario": service.scenario,
                "scenario_label": service.scenario_label,
                "n_draws": n,
                "display_system": "__NO_SELECTION__",
                "selection_frequency": float(np.mean(sub_no)),
            }
        )
        for j, system_id in enumerate(members):
            convergence_rows.append(
                {
                    "scenario": service.scenario,
                    "scenario_label": service.scenario_label,
                    "n_draws": n,
                    "display_system": prop.loc[system_id].display_system,
                    "selection_frequency": float(np.mean((sub_win == j) & (~sub_no))),
                }
            )

    # Uncertainty-source decomposition using existing layers and priors.
    thermo_freq = np.array([np.mean((thermo_winner == j) & (~no_thermo)) for j in range(n_candidates)], dtype=float)
    cost_freq = np.array([np.mean((cost_winner == j) & (~no_cost)) for j in range(n_candidates)], dtype=float)
    balanced_rows = [r for r in weight_sensitivity_rows if r["scenario"] == service.scenario and r["weight_prior"] == "balanced"]
    balanced_freq = np.array([r["selection_frequency"] for r in balanced_rows], dtype=float) if balanced_rows else np.zeros(n_candidates)
    perf_rows = [r for r in weight_sensitivity_rows if r["scenario"] == service.scenario and r["weight_prior"] == "performance_emphasis"]
    perf_freq = np.array([r["selection_frequency"] for r in perf_rows], dtype=float) if perf_rows else np.zeros(n_candidates)
    eng_rows = [r for r in weight_sensitivity_rows if r["scenario"] == service.scenario and r["weight_prior"] == "engineering_conservative"]
    eng_freq = np.array([r["selection_frequency"] for r in eng_rows], dtype=float) if eng_rows else np.zeros(n_candidates)
    def outcome_entropy(candidate_frequencies, no_selection_frequency):
        outcomes = np.append(np.asarray(candidate_frequencies, dtype=float), float(no_selection_frequency))
        outcomes = outcomes[np.isfinite(outcomes) & (outcomes > 0)]
        return float(-(outcomes * np.log2(outcomes)).sum()) if len(outcomes) else 0.0
    uncertainty_rows.extend([
        {"scenario": service.scenario, "scenario_label": service.scenario_label, "source": "strict_complete_thermophysical", "selection_entropy": outcome_entropy(thermo_freq, np.mean(no_thermo)), "entropy_scope": "candidates_plus_no_selection", "no_selection_frequency": float(np.mean(no_thermo))},
        {"scenario": service.scenario, "scenario_label": service.scenario_label, "source": "balanced_primary", "selection_entropy": outcome_entropy(balanced_freq, np.mean(no_balanced)), "entropy_scope": "candidates_plus_no_selection", "no_selection_frequency": float(np.mean(no_balanced))},
        {"scenario": service.scenario, "scenario_label": service.scenario_label, "source": "price_inclusive_sensitivity", "selection_entropy": outcome_entropy(cost_freq, np.mean(no_cost)), "entropy_scope": "candidates_plus_no_selection", "no_selection_frequency": float(np.mean(no_cost))},
        {"scenario": service.scenario, "scenario_label": service.scenario_label, "source": "performance_prior_shift", "selection_entropy": outcome_entropy(perf_freq, prior_no_frequency["performance_emphasis"]), "entropy_scope": "candidates_plus_no_selection", "no_selection_frequency": prior_no_frequency["performance_emphasis"]},
        {"scenario": service.scenario, "scenario_label": service.scenario_label, "source": "engineering_prior_shift", "selection_entropy": outcome_entropy(eng_freq, prior_no_frequency["engineering_conservative"]), "entropy_scope": "candidates_plus_no_selection", "no_selection_frequency": prior_no_frequency["engineering_conservative"]},
    ])

    no_selection_rows.extend(
        [
            {
                "scenario": service.scenario,
                "scenario_label": service.scenario_label,
                "ranking_layer": "strict_complete_thermophysical",
                "weight_prior": "not_applicable",
                "no_selection_frequency": float(np.mean(no_thermo)),
                "mc_iterations": N_MC,
            },
            {
                "scenario": service.scenario,
                "scenario_label": service.scenario_label,
                "ranking_layer": "cost_sensitivity",
                "weight_prior": "price_inclusive_sensitivity",
                "no_selection_frequency": float(np.mean(no_cost)),
                "mc_iterations": N_MC,
            },
        ]
    )

    for j, system_id in enumerate(members):
        selection_rows.extend(
            [
                {
                    "scenario": service.scenario,
                    "scenario_label": service.scenario_label,
                    "ranking_layer": "strict_complete_thermophysical",
                    "weight_prior": "not_applicable",
                    "system_id": system_id,
                    "display_system": prop.loc[system_id].display_system,
                    "selection_frequency": float(np.mean((thermo_winner == j) & (~no_thermo))),
                    "eligible_for_layer": True,
                    "mc_iterations": N_MC,
                },
                {
                    "scenario": service.scenario,
                    "scenario_label": service.scenario_label,
                    "ranking_layer": "cost_sensitivity",
                    "weight_prior": "price_inclusive_sensitivity",
                    "system_id": system_id,
                    "display_system": prop.loc[system_id].display_system,
                    "selection_frequency": float(np.mean((cost_winner == j) & (~no_cost))),
                    "eligible_for_layer": True,
                    "mc_iterations": N_MC,
                },
            ]
        )
        adequate = screening_adequate[:, j]
        strict = strict_complete[:, j]
        mc_summary_rows.append(
            {
                "scenario": service.scenario,
                "scenario_label": service.scenario_label,
                "system_id": system_id,
                "display_system": prop.loc[system_id].display_system,
                "screening_adequacy_probability_95pct": float(np.mean(adequate)),
                "physical_complete_service_probability": float(np.mean(physical_coverage[:, j] >= STRICT_COMPLETE)),
                "strict_complete_service_probability": float(np.mean(strict)),
                "strict_complete_thermophysical_probability": float(np.mean(strict)),
                "adequate_draws": int(adequate.sum()),
                "strict_complete_draws": int(strict.sum()),
                "mc_iterations": N_MC,
                "energy_density_p05_kWh_m3_conditional_on_adequacy": conditional_percentile(qv_overlap[:, j], adequate, 5),
                "energy_density_p50_kWh_m3_conditional_on_adequacy": conditional_percentile(qv_overlap[:, j], adequate, 50),
                "energy_density_p95_kWh_m3_conditional_on_adequacy": conditional_percentile(qv_overlap[:, j], adequate, 95),
                "raw_cost_p05_usd_kWhth_conditional_on_adequacy": conditional_percentile(raw_cost[:, j], adequate, 5),
                "raw_cost_p50_usd_kWhth_conditional_on_adequacy": conditional_percentile(raw_cost[:, j], adequate, 50),
                "raw_cost_p95_usd_kWhth_conditional_on_adequacy": conditional_percentile(raw_cost[:, j], adequate, 95),
            }
        )

    # Release every service-sized array before allocating the next service.
    # CPython does not guarantee immediate return of native buffers to Windows,
    # but deleting references plus an explicit collection prevents cumulative
    # heap pressure and makes the 20,000-draw run stable across services.
    del (
        qv_overlap, raw_cost, coverage, physical_coverage, strict_complete,
        screening_adequate, qv_screening, qv_complete, cost_complete,
        qscore_strict, cscore_strict, atomic_scores, burden_samples,
        decision_feasible, qscore, credibility, bscore, thermophysical,
        no_thermo, thermo_winner, cost_weights, secondary, no_cost,
        cost_winner, balanced_weights, balanced_primary, no_balanced,
        balanced_winner, valid_balanced, ranks_balanced,
        eligible_count_per_draw, sorted_vals, top_margin,
    )
    gc.collect()

MC = pd.DataFrame(mc_summary_rows)
SEL = pd.DataFrame(selection_rows)
WS = pd.DataFrame(weight_sensitivity_rows)
NOSEL = pd.DataFrame(no_selection_rows)
TRANS = pd.DataFrame(transition_rows)
RANKP = pd.DataFrame(rank_prob_rows)
PAIR = pd.DataFrame(pairwise_rows)
GATE = pd.DataFrame(gate_rows)
CONV = pd.DataFrame(convergence_rows)
UNCT = pd.DataFrame(uncertainty_rows)
MARG = pd.DataFrame(margin_rows)

# Scenario-level robustness summaries designed for complete, non-misleading Fig. 5 panels.
prior_summary_rows = []
for scenario in S.scenario:
    group = WS[WS.scenario == scenario]
    benchmark = S.loc[S.scenario == scenario, "benchmark_system"].iloc[0]
    benchmark_name = benchmark
    for prior_name in weight_priors:
        ss = group[group.weight_prior == prior_name].sort_values("selection_frequency", ascending=False)
        no_freq = float(NOSEL[(NOSEL.scenario == scenario) & (NOSEL.ranking_layer == "evidence_qualified") & (NOSEL.weight_prior == prior_name)].no_selection_frequency.iloc[0])
        candidate_freqs = ss.selection_frequency.to_numpy(dtype=float)
        outcomes = np.append(candidate_freqs, no_freq)
        outcomes = outcomes[outcomes > 0]
        selection_entropy = float(-(outcomes * np.log2(outcomes)).sum()) if len(outcomes) else 0.0
        top1_freq = float(ss.selection_frequency.iloc[0]) if len(ss) else 0.0
        top2_freq = float(ss.selection_frequency.iloc[1]) if len(ss) > 1 else 0.0
        leader = ss.display_system.iloc[0] if len(ss) and top1_freq > 0 else "none"
        prior_summary_rows.append(
            {
                "scenario": scenario,
                "scenario_label": S.loc[S.scenario == scenario, "scenario_label"].iloc[0],
                "weight_prior": prior_name,
                "leader": leader,
                "leader_selection_frequency": top1_freq,
                "second_selection_frequency": top2_freq,
                "top1_top2_frequency_gap": top1_freq - top2_freq,
                "no_selection_frequency": no_freq,
                "selection_entropy_bits": selection_entropy,
                "effective_outcome_count": float(2 ** selection_entropy),
                "benchmark_system": benchmark_name,
                "benchmark_selection_frequency": float(ss.loc[ss.display_system == benchmark_name, "selection_frequency"].iloc[0]) if (ss.display_system == benchmark_name).any() else 0.0,
            }
        )
PRIOR = pd.DataFrame(prior_summary_rows)

robust_rows = []
for scenario in S.scenario:
    pri = PRIOR[PRIOR.scenario == scenario].copy()
    bal = pri[pri.weight_prior == "balanced"].iloc[0]
    balanced_leader = bal.leader
    agreement = float(np.mean(pri.leader == balanced_leader))
    distinct_leaders = int(pri.leader.nunique())
    margin = MARG[MARG.scenario == scenario].iloc[0]
    robust_rows.append(
        {
            "scenario": scenario,
            "scenario_label": bal.scenario_label,
            "balanced_leader": balanced_leader,
            "benchmark_system": bal.benchmark_system,
            "balanced_leader_frequency": bal.leader_selection_frequency,
            "balanced_second_frequency": bal.second_selection_frequency,
            "balanced_top1_top2_gap": bal.top1_top2_frequency_gap,
            "balanced_no_selection_frequency": bal.no_selection_frequency,
            "balanced_selection_entropy_bits": bal.selection_entropy_bits,
            "balanced_effective_outcome_count": bal.effective_outcome_count,
            "balanced_benchmark_selection_frequency": bal.benchmark_selection_frequency,
            "prior_leader_agreement_fraction": agreement,
            "distinct_prior_leaders": distinct_leaders,
            "margin_status": margin.margin_status,
            "top_two_margin_p50": margin.margin_p50,
            "multiple_candidate_draw_frequency": margin.multiple_candidate_draw_frequency,
            "single_candidate_draw_frequency": margin.single_candidate_draw_frequency,
            "no_candidate_draw_frequency": margin.no_candidate_draw_frequency,
        }
    )
ROBUST = pd.DataFrame(robust_rows)

# Draw-matched transition accounting for a compact switch-sensitivity panel.
switch_rows = []
for scenario in S.scenario:
    ss = TRANS[(TRANS.scenario == scenario) & (TRANS.weight_prior == "balanced")].copy()
    retained = ss[(ss.from_system_id == ss.to_system_id) & (ss.to_system_id != "none")].transition_frequency.sum()
    redirected = ss[(ss.to_system_id != "none") & (ss.from_system_id != ss.to_system_id)].transition_frequency.sum()
    unresolved = ss[ss.to_system_id == "none"].transition_frequency.sum()
    switch_rows.append(
        {
            "scenario": scenario,
            "scenario_label": S.loc[S.scenario == scenario, "scenario_label"].iloc[0],
            "retained_frequency": float(retained),
            "redirected_frequency": float(redirected),
            "no_bounded_selection_frequency": float(unresolved),
            "switch_intensity": float(redirected + unresolved),
        }
    )
SWITCH = pd.DataFrame(switch_rows)

# Deterministic gate attrition and dominant draw-level gate reasons.
bounded_claims = {"commercial_benchmark_bounded", "strong_bounded_candidate", "conditional_only"}
attrition_rows = []
for scenario in S.scenario:
    dd = D[D.scenario == scenario]
    attrition_rows.extend(
        [
            {"scenario": scenario, "stage": "registered", "candidate_count": int(len(dd)), "stage_order": 1},
            {"scenario": scenario, "stage": "strict_complete", "candidate_count": int(dd.strict_complete_service_feasible.sum()), "stage_order": 2},
            {"scenario": scenario, "stage": "atomic_engineering_gates", "candidate_count": int((dd.strict_complete_service_feasible & ~dd[["gap_corrosion","gap_cycling_phase","gap_containment","gap_literature_validation","gap_data_completeness","nonclosable_direct_risk"]].any(axis=1)).sum()), "stage_order": 3},
        ]
    )
ATTRITION = pd.DataFrame(attrition_rows)

family_map = D[["scenario", "system_id", "family"]].drop_duplicates()
gate_family = GATE.merge(family_map, on=["scenario", "system_id"], how="left")
dom_rows = []
for (scenario, family), gg in gate_family.groupby(["scenario", "family"], dropna=False):
    agg = gg.groupby("gate_reason", as_index=False).frequency.sum().sort_values("frequency", ascending=False)
    dom_rows.append(
        {
            "scenario": scenario,
            "family": family,
            "dominant_gate_reason": agg.gate_reason.iloc[0],
            "dominant_gate_frequency": float(agg.frequency.iloc[0]),
            "second_gate_reason": agg.gate_reason.iloc[1] if len(agg) > 1 else "none",
            "second_gate_frequency": float(agg.frequency.iloc[1]) if len(agg) > 1 else 0.0,
        }
    )
DOMGATE = pd.DataFrame(dom_rows)

# Evidence leverage: count explicit uses rather than assigning an arbitrary leverage score.
leverage_rows = []
def register_ids(values, use_type):
    for value in values.fillna("").astype(str):
        for token in value.split(";"):
            token = token.strip()
            if token:
                leverage_rows.append({"source_id": token, "use_type": use_type})
register_ids(P["source_ids"], "thermophysical_properties")
register_ids(COR["source_ids"], "corrosion_and_claim_gate")
register_ids(VAL["source_ids"], "literature_validation")
register_ids(S["basis_ids"], "service_boundary")
LEVERAGE = pd.DataFrame(leverage_rows).groupby(["source_id", "use_type"], as_index=False).size().rename(columns={"size": "explicit_use_count"})

MC.to_csv(OUT / f"{VERSION}_system_value_monte_carlo_summary.csv", index=False)
SEL.to_csv(OUT / f"{VERSION}_layered_selection_frequencies.csv", index=False)
WS.to_csv(OUT / f"{VERSION}_weight_prior_sensitivity.csv", index=False)
NOSEL.to_csv(OUT / f"{VERSION}_no_selection_frequencies.csv", index=False)
TRANS.to_csv(OUT / f"{VERSION}_selection_transition_matrix.csv", index=False)
# Fixed-scope transition used by the uncertainty decomposition. The source
# layer is strict-complete thermophysical selection. A draw with no complete
# service is distinguished from downstream evidence-bounded no selection.
STRICT_TRANS = TRANS.loc[TRANS["weight_prior"].eq("balanced")].copy()
STRICT_TRANS.loc[STRICT_TRANS["from_system_id"].eq("__NO_SELECTION__"), "from_system_id"] = "__NO_COMPLETE_SERVICE__"
STRICT_TRANS.loc[STRICT_TRANS["from_display_system"].eq("No formal selection"), "from_display_system"] = "No complete-service option"
_strict_frequency_sums = STRICT_TRANS.groupby("scenario")["transition_frequency"].sum()
if not np.allclose(_strict_frequency_sums.to_numpy(float), 1.0, atol=1e-12, rtol=0.0):
    raise RuntimeError(f"Strict-complete transition frequencies must sum to one per scenario: {_strict_frequency_sums.to_dict()}")
STRICT_TRANS.to_csv(OUT / f"{VERSION}_strict_complete_selection_transition_matrix.csv", index=False)
RANKP.to_csv(OUT / f"{VERSION}_rank_probability_matrix.csv", index=False)
PAIR.to_csv(OUT / f"{VERSION}_pairwise_superiority_matrix.csv", index=False)
GATE.to_csv(OUT / f"{VERSION}_gate_failure_breakdown.csv", index=False)
CONV.to_csv(OUT / f"{VERSION}_mc_convergence_summary.csv", index=False)
UNCT.to_csv(OUT / f"{VERSION}_uncertainty_source_decomposition.csv", index=False)
MARG.to_csv(OUT / f"{VERSION}_top_two_margin_summary.csv", index=False)
PRIOR.to_csv(OUT / f"{VERSION}_prior_outcome_summary.csv", index=False)
ROBUST.to_csv(OUT / f"{VERSION}_scenario_robustness_summary.csv", index=False)
SWITCH.to_csv(OUT / f"{VERSION}_switch_sensitivity_summary.csv", index=False)
ATTRITION.to_csv(OUT / f"{VERSION}_gate_attrition_summary.csv", index=False)
DOMGATE.to_csv(OUT / f"{VERSION}_dominant_gate_matrix.csv", index=False)
LEVERAGE.to_csv(OUT / f"{VERSION}_evidence_leverage_summary.csv", index=False)
pd.DataFrame(normalization_audit_rows).to_csv(OUT / f"{VERSION}_normalization_scope_audit.csv", index=False)

# Integrated decision table. No legacy score or legacy recommendation is imported.
DEC = D.merge(MC, on=["scenario", "scenario_label", "system_id", "display_system"], how="left")
for layer in SEL.ranking_layer.unique():
    subset = SEL[SEL.ranking_layer == layer][["scenario", "display_system", "selection_frequency"]]
    subset = subset.rename(columns={"selection_frequency": f"{layer}_selection_frequency"})
    DEC = DEC.merge(subset, on=["scenario", "display_system"], how="left")

required_selection_columns = {
    "strict_complete_thermophysical_selection_frequency",
    "evidence_qualified_selection_frequency",
    "cost_sensitivity_selection_frequency",
}
missing_selection_columns = sorted(required_selection_columns - set(DEC.columns))
if missing_selection_columns:
    raise RuntimeError(
        "Integrated decision table is missing ranking-layer selection columns: "
        f"{missing_selection_columns}. Available ranking layers: {sorted(SEL.ranking_layer.unique())}"
    )

# Primary selected candidate is defined by the largest evidence-qualified selection frequency, without an arbitrary probability cutoff.
primary_max = DEC.groupby("scenario")["evidence_qualified_selection_frequency"].transform("max")
DEC["is_primary_evidence_qualified_selection"] = (
    (DEC.evidence_qualified_selection_frequency == primary_max)
    & (DEC.evidence_qualified_selection_frequency > 0)
)

decision_classes = []
for _, row in DEC.iterrows():
    if not row.strict_complete_service_feasible:
        decision_class = "not_strictly_complete_service"
    elif row.claim_class == "corrosion_gated":
        decision_class = "thermophysical_opportunity_corrosion_gated"
    elif row.claim_class in {"thermophysical_candidate_exact_corrosion_unknown", "thermophysical_candidate_corrosion_limited"}:
        decision_class = "thermophysical_opportunity_evidence_gap"
    elif row.is_primary_evidence_qualified_selection and row.display_system == row.benchmark_system:
        decision_class = "benchmark_retained"
    elif row.is_primary_evidence_qualified_selection and row.claim_class == "conditional_only":
        decision_class = "conditional_evidence_qualified_selection"
    elif row.is_primary_evidence_qualified_selection:
        decision_class = "evidence_qualified_selection"
    elif row.display_system == row.benchmark_system:
        decision_class = "benchmark_reference_not_selected"
    elif row.claim_class == "conditional_only":
        decision_class = "conditional_alternative"
    else:
        decision_class = "bounded_alternative"
    decision_classes.append(decision_class)
DEC[f"{VERSION}_decision_class"] = decision_classes

claim_map = {
    "not_strictly_complete_service": "Only partial overlap with the standardized service is available; its energy value is not reported as complete-service usable energy.",
    "thermophysical_opportunity_corrosion_gated": "Thermophysical potential is retained, but direct corrosion evidence prevents an evidence-qualified recommendation.",
    "thermophysical_opportunity_evidence_gap": "Thermophysical opportunity is supported, while exact or long-duration compatibility evidence remains an unresolved gate.",
    "benchmark_retained": "The deployment/reference benchmark is retained under the stated uncertainty and evidence gates; this is not a global-optimum claim.",
    "conditional_evidence_qualified_selection": "A conditional evidence-qualified selection emerges only under the stated salt-purification, chemistry-control and containment boundaries.",
    "evidence_qualified_selection": "An evidence-qualified selection emerges within the curated corpus and standardized service; this is not a deployment-ready or global-optimum claim.",
    "benchmark_reference_not_selected": "The benchmark remains a valid reference but is not the most frequently selected evidence-qualified option under the stated model.",
    "conditional_alternative": "The option remains conditional on purification, inhibitor control and the tested containment-material boundary.",
    "bounded_alternative": "The option remains a bounded alternative within the curated evidence base.",
}
DEC[f"{VERSION}_claim_sentence"] = DEC[f"{VERSION}_decision_class"].map(claim_map)
DEC.to_csv(OUT / f"{VERSION}_integrated_system_decision_table.csv", index=False)

story_rows = []
for scenario, group in DEC.groupby("scenario"):
    benchmark = group[group.display_system == group.benchmark_system.iloc[0]].iloc[0]
    thermo = group.sort_values("strict_complete_thermophysical_selection_frequency", ascending=False).iloc[0]
    evidence_candidates = group[group.evidence_qualified_selection_frequency > 0].sort_values(
        "evidence_qualified_selection_frequency", ascending=False
    )
    evidence_leader = evidence_candidates.iloc[0] if len(evidence_candidates) else None
    cost_leader = group.sort_values("cost_sensitivity_selection_frequency", ascending=False).iloc[0]
    novel = group[
        (group.display_system != group.benchmark_system)
        & group.strict_complete_service_feasible
        & (~group.claim_class.str.contains("commercial_benchmark"))
    ].sort_values("strict_complete_thermophysical_selection_frequency", ascending=False)
    novel_leader = novel.iloc[0] if len(novel) else None
    no_selection = NOSEL[
        (NOSEL.scenario == scenario)
        & (NOSEL.ranking_layer == "evidence_qualified")
        & (NOSEL.weight_prior == "balanced")
    ].iloc[0].no_selection_frequency

    if evidence_leader is None:
        conclusion = "No evidence-qualified selection is available; candidates remain thermophysical opportunities or evidence-limited references."
    elif evidence_leader.display_system == benchmark.display_system:
        conclusion = "The reference system is retained after service, uncertainty and evidence gates; thermophysical leaders do not automatically become deployment choices."
    elif evidence_leader.claim_class == "conditional_only":
        conclusion = "A non-benchmark option is selected only conditionally, with salt chemistry and containment controls retained as decision boundaries."
    else:
        conclusion = "A non-benchmark evidence-qualified selection emerges within the standardized service and curated evidence corpus."

    story_rows.append(
        {
            "scenario": scenario,
            "scenario_label": group.scenario_label.iloc[0],
            "deployment_reference": benchmark.display_system,
            "thermophysical_leader": thermo.display_system,
            "thermophysical_selection_frequency": thermo.strict_complete_thermophysical_selection_frequency,
            "evidence_qualified_leader": evidence_leader.display_system if evidence_leader is not None else "none",
            "evidence_qualified_selection_frequency": (
                evidence_leader.evidence_qualified_selection_frequency if evidence_leader is not None else 0.0
            ),
            "evidence_qualified_no_selection_frequency": no_selection,
            "cost_sensitivity_leader": cost_leader.display_system,
            "cost_sensitivity_selection_frequency": cost_leader.cost_sensitivity_selection_frequency,
            "highest_ranked_novel_candidate": novel_leader.display_system if novel_leader is not None else "none",
            "novel_candidate_claim_class": novel_leader.claim_class if novel_leader is not None else "none",
            "main_conclusion": conclusion,
        }
    )
SYN = pd.DataFrame(story_rows)
SYN.to_csv(OUT / f"{VERSION}_energy_system_storyline_synthesis.csv", index=False)

limitations = pd.DataFrame(
    [
        {
            "gap": "Exact QNCC corrosion",
            "status": "not publicly resolved",
            "effect": "No corrosion-pass or replacement claim for QNCC.",
            "allowed_resolution": "Adjacent chemistry constrains a risk envelope only; exact testing is required for qualification.",
        },
        {
            "gap": "High-temperature PCM cyclic phase and containment evidence",
            "status": "insufficient for all screened PCMs",
            "effect": "No evidence-qualified PCM selection.",
            "allowed_resolution": "Retain thermophysical opportunity only; prediction cannot upgrade readiness.",
        },
        {
            "gap": "Installed TES project cost",
            "status": "outside current evidence boundary",
            "effect": "Raw-material price cannot be interpreted as installed USD/kWhth.",
            "allowed_resolution": "Add tank, heat exchanger, pump, purification, EPC, lifetime and replacement models.",
        },
        {
            "gap": "Procurement-grade component prices",
            "status": "broad industrial proxies for several components",
            "effect": "Cost results remain secondary sensitivity only.",
            "allowed_resolution": "Use dated quotations with purity, quantity, location and delivery basis.",
        },
        {
            "gap": "Additional primary experiment",
            "status": "not performed",
            "effect": "The study is evidence-qualified comparative analysis, not material qualification.",
            "allowed_resolution": "Additional primary experimental or field evidence, if pursued in future work.",
        },
    ]
)
limitations.to_csv(OUT / f"{VERSION}_remaining_limitations_and_resolution_policy.csv", index=False)

# Raw database snapshot audit.
raw_rows = []
for filename in ["msd-tp-master.zip", "msd-tc-master.zip"]:
    path = RAW / filename
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
    raw_rows.append(
        {
            "file": filename,
            "size_bytes": path.stat().st_size,
            "n_members": len(names),
            "contains_csv": any(x.lower().endswith(".csv") for x in names),
            "contains_json": any(x.lower().endswith(".json") for x in names),
            "role": "thermophysical validation" if "tp" in filename else "thermochemical/phase context only",
        }
    )
pd.DataFrame(raw_rows).to_csv(OUT / f"{VERSION}_raw_database_snapshot_audit.csv", index=False)


def split_ids(series) -> set[str]:
    result: set[str] = set()
    for value in series.fillna("").astype(str):
        for token in value.split(";"):
            token = token.strip()
            if token:
                result.add(token)
    return result


# Strict trace audit: every declared source token and every analytical assumption token must resolve.
used_source_ids = set()
used_source_ids |= split_ids(P["source_ids"])
used_source_ids |= split_ids(COR["source_ids"])
used_source_ids |= split_ids(VAL["source_ids"])
used_source_ids |= split_ids(APP["source_ids"])
used_source_ids |= split_ids(ATOMIC["source_ids"])
used_source_ids |= split_ids(OVR["source_id"])
used_source_ids |= split_ids(S["basis_ids"])
registry_ids = set(SRC.source_id.astype(str))
missing_source_ids = sorted(used_source_ids - registry_ids)

used_assumption_ids = split_ids(S["assumption_ids"])
used_assumption_ids.update({"ASMP_SCREENING_ADEQUACY_95", "ASMP_STRICT_COMPLETE_999", "ASMP_WEIGHT_PRIORS", "ASMP_HIERARCHICAL_UTILITY", "ASMP_EVIDENCE_SCORE_UNCERTAINTY", "ASMP_ATOMIC_EVIDENCE_CLOSURE"})
assumption_registry_ids = set(ASMP.assumption_id.astype(str))
missing_assumption_ids = sorted(used_assumption_ids - assumption_registry_ids)

excluded_price_tokens = sorted(
    {
        x
        for x in COST.price_source_id.fillna("").astype(str)
        if x and x not in registry_ids
    }
)
source_trace = pd.DataFrame(
    [
        {"metric": "declared_authoritative_source_ids", "value": len(used_source_ids)},
        {"metric": "authoritative_registry_matches", "value": len(used_source_ids) - len(missing_source_ids)},
        {"metric": "missing_authoritative_source_ids", "value": ";".join(missing_source_ids) if missing_source_ids else "none"},
        {"metric": "declared_methodological_assumption_ids", "value": len(used_assumption_ids)},
        {"metric": "assumption_registry_matches", "value": len(used_assumption_ids) - len(missing_assumption_ids)},
        {"metric": "missing_assumption_ids", "value": ";".join(missing_assumption_ids) if missing_assumption_ids else "none"},
        {
            "metric": "non_authoritative_price_tokens_excluded_from_primary_trace",
            "value": ";".join(excluded_price_tokens) if excluded_price_tokens else "none",
        },
    ]
)
source_trace.to_csv(OUT / f"{VERSION}_source_trace_audit.csv", index=False)

readiness = [
    (
        "Relative paths and one-command execution",
        "PASS",
        "All paths resolve from the package root.",
        "",
    ),
    (
        "Version identity",
        "PASS",
        "Inputs, outputs, script and documentation use core consistently.",
        "",
    ),
    (
        "Complete versus partial service",
        "PASS",
        "Strict complete-service energy is blank when coverage is below 99.9%; partial overlap is retained in separately named columns.",
        "The 95% criterion is used only for labelled exploratory thermophysical screening; bounded decision selection requires at least 99.9% complete-service coverage and all evidence gates.",
    ),
    (
        "Selection-frequency semantics",
        "PASS",
        "Outputs use selection frequency under stated uncertainty and weight priors, not winner probability.",
        "Frequencies are conditional model outputs, not objective material-superiority probabilities.",
    ),
    (
        "Decision-weight sensitivity",
        "PASS",
        "Four named two-level performance-versus-credibility priors are exported with no-selection frequencies.",
        "Top-level performance-versus-credibility weights and within-credibility aggregation remain normative modelling choices; structural alternatives are exported.",
    ),
    (
        "Raw MSD-TP/MSD-TC snapshots",
        "PASS",
        "Original database snapshots are included.",
        "MSD-TC is thermochemical context, not a corrosion source.",
    ),
    (
        "Primary versus price sensitivity",
        "PASS",
        "Price is excluded from the primary evidence-qualified selection.",
        "Raw-material price is a secondary sensitivity only.",
    ),
    (
        "Corrosion evidence specificity",
        "PASS",
        "Corrosion, cycling/phase stability, containment, literature replication and data completeness are represented as separate atomic dimensions and gates.",
        "Adjacent evidence never upgrades an exact corrosion pass.",
    ),
    (
        "Source and assumption trace",
        "PASS" if not missing_source_ids and not missing_assumption_ids else "REVIEW",
        "Every declared source and analytical-assumption token is checked against an explicit registry.",
        "",
    ),
    (
        "Benchmark inclusion and plausibility check",
        "PASS" if (BR.plausibility_status == "PASS").all() else "REVIEW",
        f"{(BR.plausibility_status == 'PASS').sum()} of {len(BR)} reference cases pass inclusion, strict-service and evidence-plausibility checks.",
        "This is not an independent hold-out recovery test and supports plausibility only.",
    ),
    (
        "Installed TES cost",
        "LIMITED",
        "No installed-cost model is claimed.",
        "Tank, heat exchanger, pump, trace heating, EPC and lifetime replacement remain outside the quantified result.",
    ),
    (
        "Literature-reported validation coverage",
        "LIMITED",
        "All validation evidence is literature-reported; no new experiment is claimed or implied.",
        "The work should be positioned as comparative evidence-qualified analysis with limitations stated for literature coverage and without implying new experiments.",
    ),
    (
        "Global optimum claim",
        "PASS",
        "Language is restricted to the curated corpus and standardized services.",
        "",
    ),
]
pd.DataFrame(readiness, columns=["check", "status", "evidence", "remaining_limit"]).to_csv(
    OUT / f"{VERSION}_submission_readiness_audit.csv", index=False
)

# Extension modules: full database inventory, continuous weight-space scan,
# evidence-closure counterfactuals, and research-action non-dominance analysis under registered ordinal burden ordering.
# Release memory held by draw-level Python dictionaries and in-memory tables
# before the extension module reloads the validated CSVs. This avoids avoidable
# swapping on ordinary workstations while preserving deterministic outputs.
import gc
for _name in (
    "selection_rows", "weight_sensitivity_rows", "transition_rows",
    "gate_rows", "rank_prob_rows", "pairwise_rows", "convergence_rows",
    "uncertainty_rows", "margin_rows", "mc_summary_rows", "no_selection_rows",
    "TRANS", "GATE", "MC", "SEL", "WS", "NOSEL", "DEC", "PF", "APP",
    "qv_overlap", "raw_cost", "coverage", "qv_complete", "qv_screening",
    "cost_complete", "balanced_primary", "ranks_balanced",
):
    globals().pop(_name, None)
gc.collect()
extension_summary = run_extensions(ROOT, VERSION, SEED)
editorial_extension_summary = run_editorial_extensions(ROOT, VERSION)
subprocess.run([sys.executable, str(ROOT / 'src' / 'run_innovation_only.py')], check=True)
innovation_extension_summary = json.loads((QC / f'{VERSION}_INNOVATION_EXTENSION_STATUS.json').read_text(encoding='utf-8'))
subprocess.run([sys.executable, str(ROOT / 'src' / 'run_high_density.py')], check=True)
high_density_extension_summary = json.loads((QC / f'{VERSION}_HIGH_DENSITY_VALIDATION_SUMMARY.json').read_text(encoding='utf-8'))
# Information-derived presentation tables must exist before the presentation module is called.
# This explicit ordering keeps a clean full recompute runnable from registered inputs.
subprocess.run([sys.executable, str(ROOT / "src" / "information_extensions.py")], check=True)
subprocess.run([sys.executable, str(ROOT / "src" / "presentation_extensions.py")], check=True)
presentation_extension_summary = json.loads((QC / f"{VERSION}_PRESENTATION_EXTENSION_STATUS.json").read_text(encoding="utf-8"))


qc_status = "PASS"
if missing_source_ids or missing_assumption_ids or len(membership_mismatches) or len(D) != len(M):
    qc_status = "REVIEW"
qc = {
    "status": qc_status,
    "version": VERSION,
    "n_candidates": len(P),
    "n_scenario_candidate_rows": len(D),
    "mc_iterations": N_MC,
    "screening_service_adequacy_threshold": SCREENING_ADEQUACY,
    "strict_complete_service_threshold": STRICT_COMPLETE,
    "authoritative_source_ids_missing": missing_source_ids,
    "assumption_ids_missing": missing_assumption_ids,
    "membership_label_mismatches": len(membership_mismatches),
    "benchmark_inclusion_plausibility_passes": int((BR.plausibility_status == "PASS").sum()),
    "primary_ranking_uses_price": False,
    "legacy_context_merged": False,
    "raw_database_snapshots_included": True,
    "extension_modules_status": extension_summary.get("status"),
    "raw_database_records": extension_summary.get("raw_database_records"),
    "unique_formula_systems": extension_summary.get("unique_formula_systems"),
    "continuous_weight_vectors_per_application": extension_summary.get("continuous_random_weight_vectors_per_application"),
    "counterfactual_application_rows": extension_summary.get("counterfactual_application_rows"),
    "editorial_extensions_status": editorial_extension_summary.get("status"),
    "innovation_extensions_status": innovation_extension_summary.get("status"),
    "high_density_extensions_status": high_density_extension_summary.get("status"),
    "presentation_extensions_status": presentation_extension_summary.get("status"),
    "literature_source_candidate_links": editorial_extension_summary.get("literature_source_candidate_links"),
}
(QC / f"{VERSION}_QC_STATUS.json").write_text(json.dumps(qc, indent=2), encoding="utf-8")
if len(membership_mismatches):
    membership_mismatches.to_csv(QC / f"{VERSION}_membership_label_mismatches.csv", index=False)

print(json.dumps(qc, indent=2))
