from __future__ import annotations

from pathlib import Path
import os
import json
import numpy as np
import pandas as pd
from decision_model import BURDEN_HALF_VALUE

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
DOCS = ROOT / "docs"
for d in (OUT, QC, DOCS):
    d.mkdir(parents=True, exist_ok=True)

SCENARIOS = [
    "coal_flexibility_storage",
    "csp_sensible_storage",
    "industrial_medium_heat",
    "sco2_high_temperature_storage",
    "pcm_target_350C",
    "pcm_target_425C",
    "pcm_target_500C",
]
GATES = [
    "incomplete_service", "corrosion", "cycling_phase", "containment",
    "literature_validation", "data_completeness",
]
GATE_DISPLAY = {
    "incomplete_service": "Incomplete service",
    "corrosion": "Corrosion",
    "cycling_phase": "Cycling/phase",
    "containment": "Containment",
    "literature_validation": "Literature validation",
    "data_completeness": "Data completeness",
}
ATOMIC_ACTIONS = [
    "exact_composition_corrosion_closure",
    "pcm_cycling_phase_closure",
    "containment_validation_closure",
    "literature_replication_closure",
    "data_completeness_closure",
]
COMBINED_ACTION = "combined_atomic_evidence_closure"


def read(name: str) -> pd.DataFrame:
    return pd.read_csv(OUT / f"{VERSION}_{name}.csv")


def write(df: pd.DataFrame, name: str) -> None:
    df.to_csv(OUT / f"{VERSION}_{name}.csv", index=False)


def displaced_leader_shortfall() -> pd.DataFrame:
    flow = read("figure_selection_alluvial_flows")
    short = read("credibility_shortfall_decomposition")
    displaced = flow[flow.transition_class.isin(["redirected", "no_selection"])].copy()
    displaced = displaced[~displaced.from_display_system.astype(str).str.contains("No selection|No complete-service", case=False, regex=True)]
    base = short[["scenario", "display_system", "credibility_dimension", "share_of_total_log_shortfall", "dimension_score"]].copy()
    merged = displaced.merge(
        base,
        left_on=["scenario", "from_display_system"],
        right_on=["scenario", "display_system"],
        how="left",
    )
    merged = merged.dropna(subset=["share_of_total_log_shortfall"])
    merged["weighted_shortfall_mass"] = merged.transition_draws * merged.share_of_total_log_shortfall
    merged["weighted_score_mass"] = merged.transition_draws * merged.dimension_score
    rows = []
    for (scenario, dim), g in merged.groupby(["scenario", "credibility_dimension"], sort=False):
        total_draws = float(displaced.loc[displaced.scenario.eq(scenario), "transition_draws"].sum())
        weighted_total = float(merged.loc[merged.scenario.eq(scenario), "weighted_shortfall_mass"].sum())
        rows.append({
            "scenario": scenario,
            "credibility_dimension": dim,
            "weighted_shortfall_share": float(g.weighted_shortfall_mass.sum() / weighted_total) if weighted_total > 0 else 0.0,
            "draw_weighted_dimension_score": float(g.weighted_score_mass.sum() / g.transition_draws.sum()) if g.transition_draws.sum() > 0 else np.nan,
            "displaced_draws": int(total_draws),
            "candidate_routes": int(g[["from_display_system", "to_display_system"]].drop_duplicates().shape[0]),
            "interpretation": "Composition of log-credibility shortfall among thermophysical leaders that are redirected or lose bounded selection; not a causal Shapley attribution.",
        })
    out = pd.DataFrame(rows)
    if len(out):
        out["scenario_order"] = out.scenario.map({s:i for i,s in enumerate(SCENARIOS)})
        out = out.sort_values(["scenario_order", "credibility_dimension"]).drop(columns="scenario_order")
    return out


def engineering_credibility(ready: pd.DataFrame) -> pd.Series:
    scorecols = [
        "corrosion_compatibility_score", "cycling_phase_stability_score",
        "containment_validation_score", "literature_replication_score",
        "data_completeness_score",
    ]
    return (
        ready[scorecols].clip(lower=1e-12).prod(axis=1)
        * (1.0 / (1.0 + ready.engineering_burden_index.clip(lower=0) / BURDEN_HALF_VALUE))
    ).pow(1.0 / 6.0)


def redirection_tradeoff_routes() -> pd.DataFrame:
    flow = read("figure_selection_alluvial_flows")
    ready = read("candidate_readiness_profile").copy()
    mc = read("system_value_monte_carlo_summary")
    ready["engineering_credibility"] = engineering_credibility(ready)
    ready = ready.merge(
        mc[["scenario", "system_id", "raw_cost_p50_usd_kWhth_conditional_on_adequacy"]],
        on=["scenario", "system_id"], how="left"
    )
    cols = [
        "scenario", "system_id", "display_system", "engineering_credibility",
        "energy_density_p50_kWh_m3_conditional_on_adequacy",
        "raw_cost_p50_usd_kWhth_conditional_on_adequacy",
    ]
    rmap = ready[cols].copy()
    redirected = flow[flow.transition_class.eq("redirected")].copy()
    left = rmap.add_prefix("from_").rename(columns={"from_scenario":"scenario", "from_system_id":"from_system_id", "from_display_system":"from_display_system"})
    right = rmap.add_prefix("to_").rename(columns={"to_scenario":"scenario", "to_system_id":"to_system_id", "to_display_system":"to_display_system"})
    z = redirected.merge(left, on=["scenario", "from_system_id", "from_display_system"], how="left")
    z = z.merge(right, on=["scenario", "to_system_id", "to_display_system"], how="left")
    z["route"] = z.from_display_system.astype(str) + " → " + z.to_display_system.astype(str)
    z["additional_volume_p50_m3_MWh"] = (
        1000.0 / z.to_energy_density_p50_kWh_m3_conditional_on_adequacy
        - 1000.0 / z.from_energy_density_p50_kWh_m3_conditional_on_adequacy
    )
    z["engineering_credibility_change"] = z.to_engineering_credibility - z.from_engineering_credibility
    z["raw_cost_change_usd_kWhth"] = z.to_raw_cost_p50_usd_kWhth_conditional_on_adequacy - z.from_raw_cost_p50_usd_kWhth_conditional_on_adequacy
    denom = float(flow.groupby("scenario").mc_iterations.max().sum())
    z["application_equal_route_frequency"] = z.transition_draws / denom
    keep = [
        "scenario", "route", "from_display_system", "to_display_system", "transition_draws",
        "application_equal_route_frequency", "additional_volume_p50_m3_MWh",
        "engineering_credibility_change", "raw_cost_change_usd_kWhth",
    ]
    z = z[keep].dropna(subset=["additional_volume_p50_m3_MWh", "engineering_credibility_change"])
    return z.sort_values("transition_draws", ascending=False).reset_index(drop=True)


def gate_bottleneck_transfer() -> pd.DataFrame:
    patterns = read("figure_gate_intersection_summary")
    shap = read("gate_shapley_attribution")
    rows = []
    for scenario in SCENARIOS:
        ps = patterns[patterns.scenario.eq(scenario)].copy()
        ss = shap[(shap.scope.eq("application")) & (shap.scenario.eq(scenario))].copy()
        if ps.empty or ss.empty:
            continue
        top = ss.sort_values("shapley_unlock_contribution", ascending=False).iloc[0]
        closed_gate = str(top.gate)
        closed_display = GATE_DISPLAY[closed_gate]
        baseline_retained = float(ps.loc[ps["Retained"].astype(bool), "frequency_within_scope"].sum())
        gate_cols = {g:GATE_DISPLAY[g] for g in GATES}
        residual_freq = {}
        post_retained = 0.0
        for r in ps.itertuples(index=False):
            freq = float(r.frequency_within_scope)
            active = []
            for gate, display in gate_cols.items():
                if gate == closed_gate:
                    continue
                if bool(getattr(r, display.replace("/", "_").replace(" ", "_"), False)):
                    active.append(gate)
            # itertuples sanitisation is awkward for slash/space names; use row lookup below when needed
        post_retained = 0.0
        residual_freq = {g:0.0 for g in GATES if g != closed_gate}
        for _, r in ps.iterrows():
            freq = float(r["frequency_within_scope"])
            active = [g for g,d in gate_cols.items() if g != closed_gate and bool(r[d])]
            if not active:
                post_retained += freq
            for g in active:
                residual_freq[g] += freq
        residual_gate = max(residual_freq, key=residual_freq.get) if residual_freq else "none"
        residual_value = float(residual_freq.get(residual_gate, 0.0))
        rows.append({
            "scenario": scenario,
            "closed_gate": closed_gate,
            "closed_gate_label": closed_display,
            "closed_gate_shapley_contribution": float(top.shapley_unlock_contribution),
            "baseline_retained_frequency": baseline_retained,
            "retained_frequency_after_top_gate_closure": post_retained,
            "retained_frequency_gain": post_retained - baseline_retained,
            "residual_dominant_gate": residual_gate,
            "residual_dominant_gate_label": GATE_DISPLAY.get(residual_gate, "None"),
            "residual_dominant_failure_frequency": residual_value,
            "bottleneck_transfer": residual_value > 1e-12,
            "interpretation": "Close only the largest application-level Shapley gate, then recompute residual gate prevalence; this diagnoses bottleneck substitution rather than additive gate importance.",
        })
    return pd.DataFrame(rows)


def selection_uncertainty_transition() -> pd.DataFrame:
    u = read("uncertainty_source_decomposition")
    a = u[u.source.eq("strict_complete_thermophysical")].set_index("scenario")
    b = u[u.source.eq("balanced_primary")].set_index("scenario")
    rows = []
    for s in SCENARIOS:
        if s not in a.index or s not in b.index:
            continue
        rows.append({
            "scenario": s,
            "from_layer": "strict_complete_thermophysical",
            "to_layer": "strict_complete_evidence_bounded",
            "strict_complete_thermophysical_selection_entropy": float(a.loc[s, "selection_entropy"]),
            "strict_complete_evidence_bounded_selection_entropy": float(b.loc[s, "selection_entropy"]),
            "delta_selection_entropy": float(b.loc[s, "selection_entropy"] - a.loc[s, "selection_entropy"]),
            "strict_complete_thermophysical_no_selection_frequency": float(a.loc[s, "no_selection_frequency"]),
            "strict_complete_evidence_bounded_no_selection_frequency": float(b.loc[s, "no_selection_frequency"]),
            "delta_no_selection_frequency": float(b.loc[s, "no_selection_frequency"] - a.loc[s, "no_selection_frequency"]),
            "collapse_to_no_selection": bool(b.loc[s, "no_selection_frequency"] >= 0.999),
            "fixed_scope_comparison": True,
            "entropy_unit": "bits",
            "entropy_log_base": 2,
            "interpretation": "Draw-matched strict-complete thermophysical versus strict-complete evidence-bounded outcomes; service scope is fixed before evidence gating. Joint entropy and no-selection changes are reported together so collapse to universal no-selection is not misread as improved robustness.",
        })
    return pd.DataFrame(rows)


def evidence_programme_nonadditivity() -> pd.DataFrame:
    evi = read("prospective_evidence_value_by_service")
    metrics = [
        "delta_expected_normalized_service_value",
        "delta_selection_probability",
        "delta_expected_selected_credibility",
        "delta_no_selection_frequency",
    ]
    rows = []
    for s in SCENARIOS:
        g = evi[evi.scenario.eq(s)].set_index("closure_action")
        if COMBINED_ACTION not in g.index:
            continue
        combined = g.loc[COMBINED_ACTION]
        singles = g.reindex(ATOMIC_ACTIONS).fillna(0)
        rec = {"scenario": s}
        for m in metrics:
            single_sum = float(singles[m].sum())
            combined_value = float(combined[m])
            rec[f"combined_{m}"] = combined_value
            rec[f"sum_single_{m}"] = single_sum
            rec[f"nonadditivity_{m}"] = combined_value - single_sum
        nv = rec["nonadditivity_delta_expected_normalized_service_value"]
        rec["interaction_class"] = "complementary" if nv > 1e-12 else ("overlapping" if nv < -1e-12 else "additive")
        rec["interpretation"] = "Combined closure minus the sum of single-gate closures; positive values indicate threshold complementarity, negative values indicate overlapping recovered decisions, and zero indicates additivity."
        rows.append(rec)
    return pd.DataFrame(rows)


def write_audit_documents(new_tables: list[str]) -> None:
    report = f"""# {VERSION} independent information and data-lineage audit

The audit covers 29 main-text panels and 22 supplementary panels, giving 1,275 pairwise comparisons.

The audit does not compare derived-table names alone. It traces known parent and ancestor tables and classifies relationships as:

- direct duplicate (not permitted);
- deterministic re-expression (not permitted);
- shared-root independent claim (permitted only when the observational unit, filter, transformation, aggregation and claim axis differ);
- independent source (permitted).

The fixed-scope evidence-redirection and uncertainty-transition analyses both compare `strict_complete_thermophysical` with `strict_complete_evidence_bounded`. For example, Fig. 2c and Fig. 2d can both be traced to candidate-readiness source data, but Fig. 2c evaluates the transition from strict-service probability to bounded selection, whereas Fig. 2d evaluates the thermal-transport and energy-density frontier. Shared source ancestry is disclosed explicitly and is not described as source independence.

New upstream outputs:
""" + "\n".join(f"- `{VERSION}_{x}.csv`" for x in new_tables) + "\n"
    (DOCS / f"{VERSION}_INDEPENDENT_INFORMATION_AUDIT.md").write_text(report, encoding="utf-8")

def run() -> dict:
    outputs = {
        "displaced_leader_shortfall_composition": displaced_leader_shortfall(),
        "redirection_tradeoff_routes": redirection_tradeoff_routes(),
        "gate_bottleneck_transfer": gate_bottleneck_transfer(),
        "selection_uncertainty_transition": selection_uncertainty_transition(),
        "evidence_programme_nonadditivity": evidence_programme_nonadditivity(),
    }
    for name, df in outputs.items():
        write(df, name)
    checks = []
    def add(name: str, passed: bool, detail, severity: str = "critical"):
        checks.append({
            "check": name,
            "passed": bool(passed),
            "severity": severity,
            "release_blocking": severity == "critical",
            "detail": detail,
        })
    ds = outputs["displaced_leader_shortfall_composition"]
    sums = ds.groupby("scenario").weighted_shortfall_share.sum()
    add("shortfall_composition_sums_to_one", bool(np.allclose(sums, 1.0)), sums.round(8).to_dict())
    rt = outputs["redirection_tradeoff_routes"]
    min_routes = 1 if int(os.environ.get("TES_N_MC", "20000")) < 20000 else 6
    add(
        "redirection_tradeoff_has_nonzero_routes",
        len(rt) >= min_routes,
        {"actual": len(rt), "descriptive_target": min_routes, "interpretation": "Route count is an observed result, not a validity condition."},
        severity="advisory",
    )
    gt = outputs["gate_bottleneck_transfer"]
    add("gate_transfer_covers_seven_services", len(gt) == 7, len(gt))
    add("top_gate_closure_never_reduces_retention", bool((gt.retained_frequency_gain >= -1e-12).all()), gt.retained_frequency_gain.min())
    ut = outputs["selection_uncertainty_transition"]
    add("uncertainty_transition_covers_seven_services", len(ut) == 7, len(ut))
    add("uncertainty_transition_is_fixed_scope", bool(len(ut) == 7 and ut.fixed_scope_comparison.astype(bool).all()), int(ut.fixed_scope_comparison.astype(bool).sum()) if "fixed_scope_comparison" in ut else 0)
    na = outputs["evidence_programme_nonadditivity"]
    add("programme_nonadditivity_covers_seven_services", len(na) == 7, len(na))
    add(
        "programme_interaction_has_multiple_classes",
        na.interaction_class.nunique() >= 2,
        {"classes": na.interaction_class.value_counts().to_dict(), "interpretation": "The number of observed interaction classes is a result and must not be forced by validation."},
        severity="advisory",
    )
    critical_failures = [c for c in checks if c["severity"] == "critical" and not c["passed"]]
    advisory_findings = [c for c in checks if c["severity"] != "critical" and not c["passed"]]
    status = "PASS" if not critical_failures else "FAIL"
    summary = {
        "status": status,
        "critical_failures": len(critical_failures),
        "advisory_findings": len(advisory_findings),
        "checks": checks,
        "new_tables": list(outputs),
        "validation_policy": "Only structural, conservation, scope and direction checks are release-blocking. Observed route counts and interaction-class diversity are descriptive outcomes.",
    }
    (QC / f"{VERSION}_INFORMATION_EXTENSION_STATUS.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(checks).to_csv(QC / f"{VERSION}_INFORMATION_EXTENSION_CHECKS.csv", index=False)
    write_audit_documents(list(outputs))
    if status != "PASS":
        raise RuntimeError("core information extension validation failed")
    return summary


if __name__ == "__main__":
    print(json.dumps(run(), ensure_ascii=False, indent=2))
