from __future__ import annotations

from pathlib import Path
import csv
import json
import math
import sys

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
IN = ROOT / "data" / "input"
PROV = ROOT / "data" / "provenance"
QC = ROOT / "outputs" / "qc"
QC.mkdir(parents=True, exist_ok=True)

EXPECTED_GROUPS = {
    "composition", "melting_temperature", "practical_upper_temperature",
    "specific_heat", "density", "thermal_conductivity", "viscosity",
    "latent_heat", "reported_energy_density",
}
REQUIRED = {
    "ledger_id", "system_id", "property_group", "implementation_fields",
    "implementation_value_or_equation", "primary_source_id", "source_locator",
    "evidence_origin", "model_validity_range", "strict_model_role",
    "article_claim_boundary", "review_status",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def f(value: str) -> float:
    return float(value)


def close(a: str, b: float, tol: float = 1e-9) -> bool:
    return math.isclose(f(a), b, rel_tol=tol, abs_tol=tol)

checks: list[dict] = []
def check(name: str, passed: bool, detail) -> None:
    checks.append({"check": name, "passed": bool(passed), "detail": str(detail)})

candidate_path = IN / f"{VERSION}_candidate_property_registry.csv"
source_path = IN / f"{VERSION}_authoritative_source_registry.csv"
ledger_path = PROV / f"{VERSION}_property_source_ledger.csv"
for p in (candidate_path, source_path, ledger_path):
    check(f"file::{p.name}", p.exists(), p.relative_to(ROOT) if p.exists() else "missing")
if not all(p.exists() for p in (candidate_path, source_path, ledger_path)):
    raise SystemExit(2)

candidates = read_csv(candidate_path)
sources = read_csv(source_path)
ledger = read_csv(ledger_path)
source_ids = {r["source_id"] for r in sources}
candidate_ids = {r["system_id"] for r in candidates}

check("ledger_required_columns", REQUIRED.issubset(ledger[0]), sorted(REQUIRED - set(ledger[0])))
check("candidate_registry_unique", len(candidates) == len(candidate_ids), len(candidates))
check("nine_property_rows_per_candidate", len(ledger) == len(candidates) * len(EXPECTED_GROUPS), {"ledger":len(ledger),"expected":len(candidates)*len(EXPECTED_GROUPS)})
check("unique_ledger_ids", len({r["ledger_id"] for r in ledger}) == len(ledger), len(ledger))
check("candidate_set_alignment", {r["system_id"] for r in ledger} == candidate_ids, sorted({r["system_id"] for r in ledger} ^ candidate_ids))
for cid in sorted(candidate_ids):
    groups = {r["property_group"] for r in ledger if r["system_id"] == cid}
    check(f"property_coverage::{cid}", groups == EXPECTED_GROUPS, {"missing": sorted(EXPECTED_GROUPS-groups), "extra": sorted(groups-EXPECTED_GROUPS)})

external_primary = {r["primary_source_id"] for r in ledger if r["primary_source_id"] != "TES_INTERNAL"}
check("primary_source_referential_integrity", external_primary.issubset(source_ids), sorted(external_primary-source_ids))
declared = {tok.strip() for r in candidates for tok in r["source_ids"].split(";") if tok.strip()}
check("candidate_source_referential_integrity", declared.issubset(source_ids), sorted(declared-source_ids))
check("all_source_locators_nonblank", all(r["source_locator"].strip() for r in ledger), [r["ledger_id"] for r in ledger if not r["source_locator"].strip()])
check("all_rows_scientifically_closed", all(r["review_status"] == "CLOSED" for r in ledger), [r["ledger_id"] for r in ledger if r["review_status"] != "CLOSED"])

C = {r["system_id"]: r for r in candidates}
# Frozen scientific decisions.
check("qncc_reported_average_cp_retained", close(C["qncc"]["cp_a"], 1.56) and C["qncc"]["cp_model"] == "constant", C["qncc"]["cp_a"])
check("qncc_direct_latent_retained", close(C["qncc"]["latent_J_g"], 111.9), C["qncc"]["latent_J_g"])
check("lif_s1_direct_latent_retained", close(C["pcm_lif_s1"]["latent_J_g"], 413.0), C["pcm_lif_s1"]["latent_J_g"])
check("nkca_exact_composition_latent", close(C["nkca"]["latent_J_g"], 171.5) and "40.8 mol%" in C["nkca"]["composition"], {k:C["nkca"][k] for k in ["composition","latent_J_g"]})
check("nkca_near_composition_energy_removed", not C["nkca"]["reported_energy_density_MJ_m3"].strip(), C["nkca"]["reported_energy_density_MJ_m3"])
check("binary_carbonate_source_corrected", C["pcm_binary_carbonate"]["source_ids"] == "GE_BINARY_CARBONATE_2018", C["pcm_binary_carbonate"]["source_ids"])
check("binary_carbonate_molar_composition", "51 mol% Li2CO3" in C["pcm_binary_carbonate"]["composition"], C["pcm_binary_carbonate"]["composition"])
check("mgcl_direct_dsc_primary", close(C["mgcl_kcl_nacl"]["Tm_C"], 401.4) and close(C["mgcl_kcl_nacl"]["Tm_unc_C"], 1.3), {k:C["mgcl_kcl_nacl"][k] for k in ["Tm_C","Tm_unc_C"]})
check("hitec_density_temperature_correlation", C["hitec"]["rho_model"] == "linear_K" and close(C["hitec"]["rho_a"], 2.279799) and close(C["hitec"]["rho_b"], -0.0007324), {k:C["hitec"][k] for k in ["rho_model","rho_a","rho_b"]})
check("hitec_xl_review_cp", C["hitec_xl"]["cp_model"] == "constant" and close(C["hitec_xl"]["cp_a"], 1.45), C["hitec_xl"]["cp_a"])

# Property-domain controls: measured stability never expands Cp/rho/k validity.
for cid, prefix, lo, hi in [
    ("knc","cp",400.0,450.0), ("knc","rho",400.0,600.0),
    ("quat_s7","cp",50.0,280.0), ("quat_s7","k",80.0,280.0),
    ("qncc","cp",250.0,450.0), ("qncc","rho",300.0,600.0),
    ("mgcl_kcl_nacl","cp",450.0,625.0), ("mgcl_kcl_nacl","rho",430.0,700.0),
    ("hitec_xl","cp",100.0,400.0),
]:
    r=C[cid]
    ok=close(r[f"{prefix}_Tmin_C"],lo) and close(r[f"{prefix}_Tmax_C"],hi)
    check(f"property_domain::{cid}::{prefix}",ok,(r[f"{prefix}_Tmin_C"],r[f"{prefix}_Tmax_C"]))

for r in candidates:
    for prefix in ("cp","rho","k","mu"):
        lo, hi = r.get(f"{prefix}_Tmin_C", ""), r.get(f"{prefix}_Tmax_C", "")
        if lo or hi:
            check(f"domain_pair::{r['system_id']}::{prefix}", bool(lo and hi and f(lo) <= f(hi)), (lo,hi))

# Ledger rows must explicitly prevent the two historical high-temperature extrapolations.
L={(r["system_id"],r["property_group"]):r for r in ledger}
check("knc_cp_claim_boundary_blocks_sco2_extrapolation", "not be extrapolated" in L[("knc","specific_heat")]["article_claim_boundary"].lower(), L[("knc","specific_heat")]["article_claim_boundary"])
check("s7_cp_claim_boundary_blocks_coal_extrapolation", "not extrapolated" in L[("quat_s7","specific_heat")]["article_claim_boundary"].lower(), L[("quat_s7","specific_heat")]["article_claim_boundary"])
check("lif_cp_claim_is_diagnostic_only", "+50 k" in L[("pcm_lif_s1","specific_heat")]["article_claim_boundary"].lower(), L[("pcm_lif_s1","specific_heat")]["article_claim_boundary"])

failures=[x for x in checks if not x["passed"]]
summary={
    "status":"PASS" if not failures else "FAIL",
    "version":VERSION,
    "checks":len(checks),
    "failures":len(failures),
    "ledger_rows":len(ledger),
    "scientific_freeze":"property domains, exact-composition alignment, energy integration inputs and evidence roles",
    "records":checks,
}
(QC/f"{VERSION}_PROPERTY_SOURCE_LEDGER_VALIDATION.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
with (QC/f"{VERSION}_PROPERTY_SOURCE_LEDGER_CHECKS.csv").open("w",encoding="utf-8-sig",newline="") as fobj:
    w=csv.DictWriter(fobj,fieldnames=["check","passed","detail"]);w.writeheader();w.writerows(checks)
print(json.dumps({k:v for k,v in summary.items() if k!="records"},indent=2))
if failures:
    for row in failures: print("FAIL",row)
    sys.exit(2)
