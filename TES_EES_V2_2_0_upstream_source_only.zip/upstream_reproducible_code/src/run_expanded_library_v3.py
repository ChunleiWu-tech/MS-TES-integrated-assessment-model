from __future__ import annotations

import hashlib
import json
import math
import os
import re
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "expanded_library_v3"
INPUT = ROOT / "data" / "input"
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"

RECORDS_FILE = DATA / "v18_normalized_property_records_snapshot.csv"
ADDITIONS_FILE = DATA / "expanded_library_v3_additions.csv"
SOURCES_FILE = DATA / "expanded_library_v3_source_registry.csv"
CURRENT_REGISTRY = INPUT / "core_candidate_property_registry.csv"
CURRENT_MEMBERSHIP = INPUT / "core_candidate_scenario_membership.csv"
CURRENT_RANKS = TABLES / "core_rank_probability_matrix.csv"
CURRENT_ROBUSTNESS = TABLES / "core_scenario_robustness_summary.csv"

TARGETS = [
    "melting_temperature_C",
    "stability_temperature_C",
    "latent_heat_J_g",
    "cp_J_gK",
    "density_kg_m3",
    "thermal_conductivity_W_mK",
    "viscosity_mPa_s",
    "cycle_count",
]

PLAUSIBLE = {
    "melting_temperature_C": (-100.0, 1300.0),
    "stability_temperature_C": (50.0, 1300.0),
    "latent_heat_J_g": (1.0, 800.0),
    "cp_J_gK": (0.2, 5.0),
    "density_kg_m3": (500.0, 5000.0),
    "thermal_conductivity_W_mK": (0.02, 5.0),
    "viscosity_mPa_s": (0.05, 200.0),
    "cycle_count": (1.0, 100000.0),
}

# These duties were frozen in the current V2 model. The expanded library is routed
# into them without changing a window after seeing candidate performance.
SERVICES = {
    "coal_flexibility_storage": {
        "label": "Coal-power flexibility thermal buffer",
        "mode": "sensible",
        "cold_C": 380.0,
        "hot_C": 550.0,
        "freeze_margin_C": 20.0,
    },
    "csp_sensible_storage": {
        "label": "Current/advanced CSP sensible storage",
        "mode": "sensible",
        "cold_C": 290.0,
        "hot_C": 565.0,
        "freeze_margin_C": 20.0,
    },
    "industrial_medium_heat": {
        "label": "Industrial medium-temperature heat",
        "mode": "sensible",
        "cold_C": 250.0,
        "hot_C": 450.0,
        "freeze_margin_C": 20.0,
    },
    "sco2_high_temperature_storage": {
        "label": "Gen3/sCO2 high-temperature TES",
        "mode": "sensible",
        "cold_C": 500.0,
        "hot_C": 700.0,
        "freeze_margin_C": 20.0,
    },
    "pcm_target_350C": {
        "label": "PCM target 350 C",
        "mode": "latent",
        "phase_min_C": 335.0,
        "phase_max_C": 365.0,
        "stability_margin_C": 40.0,
    },
    "pcm_target_425C": {
        "label": "PCM target 425 C",
        "mode": "latent",
        "phase_min_C": 410.0,
        "phase_max_C": 440.0,
        "stability_margin_C": 40.0,
    },
    "pcm_target_500C": {
        "label": "PCM target 500 C",
        "mode": "latent",
        "phase_min_C": 485.0,
        "phase_max_C": 515.0,
        "stability_margin_C": 40.0,
    },
}

FAMILY_PATTERNS = [
    ("nitrate", "NO3"),
    ("nitrite", "NO2"),
    ("chloride", "Cl"),
    ("fluoride", "F"),
    ("carbonate", "CO3"),
    ("sulfate", "SO4"),
    ("bromide", "Br"),
    ("hydroxide", "OH"),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def clean_text(value) -> str:
    if pd.isna(value):
        return ""
    return re.sub(r"\s+", " ", str(value)).strip()


def split_components(value) -> list[str]:
    text = clean_text(value)
    if not text:
        return []
    return [x.strip() for x in re.split(r"[;,]", text) if x.strip()]


def normalize_basis(value) -> str:
    text = clean_text(value).lower().replace("_", " ")
    if text in {"pure", "single salt", "single", "1", "1.0"}:
        return "pure"
    wt_pos = min([p for p in [text.find("wt"), text.find("mass")] if p >= 0], default=10_000)
    mol_pos = min([p for p in [text.find("mol"), text.find("mole")] if p >= 0], default=10_000)
    # Some registry strings report a primary mole composition followed by an
    # equivalent mass composition in parentheses. The first explicit basis is
    # the identity basis; selecting wt% merely because it also appears later
    # would silently relabel the candidate.
    if wt_pos < mol_pos:
        if any(x in text for x in ["range", "unspecified", "pending", "not reported"]):
            return "unresolved"
        return "wt"
    if mol_pos < wt_pos:
        if any(x in text for x in ["range", "unspecified", "pending", "not reported"]):
            return "unresolved"
        return "mol"
    if "pure" in text:
        return "pure"
    return "unresolved"


def appearance_order(system: str, components: list[str]) -> list[str]:
    text = clean_text(system)
    positions = []
    for component in components:
        pos = text.find(component)
        positions.append((pos if pos >= 0 else 10_000, component))
    ordered = [component for pos, component in sorted(positions) if pos < 10_000]
    if len(ordered) == len(components):
        return ordered
    return components


def parse_composition(
    system: str, components_value, composition_value, basis_value
) -> tuple[bool, str, dict[str, float], str]:
    components = split_components(components_value)
    basis = normalize_basis(basis_value)
    comp_text = clean_text(composition_value)
    if not components:
        return False, basis, {}, "missing_components"
    if basis == "pure" or (len(components) == 1 and comp_text.lower() in {"1", "1.0", "pure", "100"}):
        return True, "pure", {components[0]: 1.0}, "pure"
    if basis == "unresolved" or not comp_text:
        return False, basis, {}, "unresolved_basis_or_composition"

    labelled: dict[str, float] = {}
    for component in components:
        escaped = re.escape(component)
        patterns = [
            rf"(?<![A-Za-z0-9])([-+]?\d*\.?\d+)\s*(?:wt%|mol%|mass%|%)?\s*{escaped}(?![A-Za-z0-9])",
            rf"{escaped}(?![A-Za-z0-9])\s*[:=]?\s*([-+]?\d*\.?\d+)",
        ]
        for pattern in patterns:
            match = re.search(pattern, comp_text, flags=re.IGNORECASE)
            if match:
                labelled[component] = float(match.group(1))
                break
    values: dict[str, float] = {}
    if len(labelled) == len(components):
        values = labelled
        parser = "labelled"
    else:
        # Use a bare numeric list only when formula digits cannot be mistaken for fractions.
        stripped = comp_text
        for component in sorted(components, key=len, reverse=True):
            stripped = re.sub(re.escape(component), "", stripped, flags=re.IGNORECASE)
        nums = [float(x) for x in re.findall(r"[-+]?\d*\.?\d+", stripped)]
        if len(nums) != len(components):
            nums = [float(x) for x in re.findall(r"[-+]?\d*\.?\d+", comp_text)]
        if len(nums) != len(components):
            return False, basis, {}, "fraction_count_mismatch"
        order = appearance_order(system, components)
        values = dict(zip(order, nums))
        parser = "ordered_numeric"

    if any((not np.isfinite(v)) or v < 0 for v in values.values()):
        return False, basis, {}, "invalid_fraction"
    total = float(sum(values.values()))
    if total <= 0:
        return False, basis, {}, "zero_fraction_sum"
    fractions = {component: value / total for component, value in values.items()}
    if abs(sum(fractions.values()) - 1.0) > 1e-8:
        return False, basis, {}, "normalization_failure"
    return True, basis, fractions, parser


def candidate_key(basis: str, fractions: dict[str, float]) -> str:
    pairs = [f"{component}={fractions[component]:.6f}" for component in sorted(fractions)]
    return f"{basis}|" + "|".join(pairs)


def composition_signature(fractions: dict[str, float]) -> str:
    return "; ".join(f"{component} {100.0 * fractions[component]:.3f}%" for component in sorted(fractions))


def inferred_family(components_value, fallback="") -> str:
    components = split_components(components_value)
    joined = ";".join(components)
    families = []
    for name, token in FAMILY_PATTERNS:
        if token == "F":
            if any(re.search(r"F(?:\d|$)", comp) for comp in components):
                families.append(name)
        elif token in joined:
            families.append(name)
    if families:
        return "-".join(dict.fromkeys(families))
    text = clean_text(fallback).lower().replace("_", "-")
    return text or "unknown"


def boundary_flags(components_value) -> tuple[str, str]:
    text = clean_text(components_value)
    high_hazard = any(x in text for x in ["UF", "PuF", "ThF", "UCl", "PuCl", "ThCl", "BeF2"])
    reactive = any(x in text for x in ["FeCl3", "AlCl3", "ZnCl2", "ZrF4", "BeF2"])
    if high_hazard:
        return "outside_stationary_TES_material_boundary", "actinide_or_beryllium_chemistry"
    if reactive:
        return "conditional_material_boundary", "volatile_or_reactive_halide_component"
    return "inside_thermophysical_boundary", "none"


def weighted_median(values: Iterable[float], weights: Iterable[float]) -> float:
    v = np.asarray(list(values), dtype=float)
    w = np.asarray(list(weights), dtype=float)
    good = np.isfinite(v) & np.isfinite(w) & (w > 0)
    if not good.any():
        return float("nan")
    v, w = v[good], w[good]
    order = np.argsort(v)
    v, w = v[order], w[order]
    return float(v[np.searchsorted(np.cumsum(w) / np.sum(w), 0.5)])


def best_text(series: pd.Series) -> str:
    values = series.dropna().astype(str)
    values = values[~values.str.lower().isin(["", "nan", "none"])]
    return values.value_counts().index[0] if len(values) else ""


def load_records() -> tuple[pd.DataFrame, pd.DataFrame]:
    base = pd.read_csv(RECORDS_FILE)
    base = base[base["target"].isin(TARGETS)].copy()
    base["source_id"] = base.get("source_short", base.get("source", "")).fillna("")
    base["measurement_class"] = base.get("method", "").fillna("")
    base["formal_numeric_use"] = base.get("v18_value_plausible", True).fillna(False).astype(bool)
    additions = pd.read_csv(ADDITIONS_FILE)
    additions["source_sheet"] = "expanded_library_v3_additions"
    additions["candidate_variant_id"] = ""
    additions["authoritative_overlay"] = True
    additions["v18_value_plausible"] = True
    additions["source_short"] = additions["source_id"]
    additions["source"] = additions["source_id"]
    additions["system"] = additions["system"].astype(str)
    additions["target_value"] = pd.to_numeric(additions["target_value"], errors="coerce")
    additions["temperature_or_condition"] = additions["temperature_or_condition"].fillna("")
    additions["method"] = additions["measurement_class"]
    additions["training_allowed"] = False
    additions["v18_origin"] = "expanded_library_v3_web_or_local_primary"
    for column in set(base.columns).difference(additions.columns):
        additions[column] = np.nan
    for column in set(additions.columns).difference(base.columns):
        base[column] = np.nan
    records = pd.concat([base, additions[base.columns]], ignore_index=True)
    records["target_value"] = pd.to_numeric(records["target_value"], errors="coerce")
    records["quality_weight"] = pd.to_numeric(records["quality_weight"], errors="coerce").fillna(0.5)
    records["formal_numeric_use"] = records["formal_numeric_use"].fillna(False).astype(bool)
    plausible = pd.Series(True, index=records.index)
    for target, (low, high) in PLAUSIBLE.items():
        mask = records["target"].eq(target)
        plausible.loc[mask] = records.loc[mask, "target_value"].between(low, high, inclusive="both")
    records["expanded_v3_value_plausible"] = plausible

    parsed_rows = []
    for idx, row in records.iterrows():
        exact, basis, fractions, parser = parse_composition(
            row.get("system", ""),
            row.get("components", ""),
            row.get("composition", ""),
            row.get("composition_basis", ""),
        )
        key = candidate_key(basis, fractions) if exact else f"unresolved|{idx:05d}"
        parsed_rows.append(
            {
                "exact_composition": bool(exact),
                "normalized_basis": basis,
                "composition_parser": parser,
                "candidate_key": key,
                "normalized_composition": composition_signature(fractions) if exact else "",
                "normalized_family": inferred_family(row.get("components", ""), row.get("family", "")),
            }
        )
    parsed = pd.DataFrame(parsed_rows, index=records.index)
    records = pd.concat([records, parsed], axis=1)
    records["dedupe_key"] = (
        records["candidate_key"].astype(str)
        + "|"
        + records["target"].astype(str)
        + "|"
        + records["target_value"].round(8).astype(str)
        + "|"
        + records["source_id"].fillna("").astype(str)
        + "|"
        + records["temperature_or_condition"].fillna("").astype(str)
    )
    records["duplicate_property_record"] = records.duplicated("dedupe_key", keep="first")
    used = records[
        records["exact_composition"]
        & records["expanded_v3_value_plausible"]
        & records["formal_numeric_use"]
        & ~records["duplicate_property_record"]
    ].copy()
    return records, used


def summarize_candidates(used: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for key, group in used.groupby("candidate_key", sort=True):
        boundary, reason = boundary_flags(best_text(group["components"]))
        row = {
            "candidate_key": key,
            "display_system": best_text(group["system"]),
            "components": best_text(group["components"]),
            "composition_basis": best_text(group["normalized_basis"]),
            "normalized_composition": best_text(group["normalized_composition"]),
            "family": best_text(group["normalized_family"]),
            "source_count": int(group["source_id"].fillna("").astype(str).replace("", np.nan).nunique()),
            "property_record_count": int(len(group)),
            "quality_weight_median": float(group["quality_weight"].median()),
            "source_ids": ";".join(sorted(set(group["source_id"].dropna().astype(str))))[:1500],
            "material_boundary": boundary,
            "material_boundary_reason": reason,
        }
        for target in TARGETS:
            sub = group[group["target"].eq(target)]
            row[target] = weighted_median(sub["target_value"], sub["quality_weight"]) if len(sub) else np.nan
            row[f"{target}_evidence_count"] = int(len(sub))
            row[f"{target}_quality_weight"] = float(sub["quality_weight"].max()) if len(sub) else np.nan
            row[f"{target}_conditions"] = "; ".join(sorted(set(sub["temperature_or_condition"].dropna().astype(str))))[:1200]
        rows.append(row)
    return pd.DataFrame(rows)


def infer_registry_components(composition: str, known_components: list[str]) -> list[str]:
    text = clean_text(composition)
    found = [component for component in sorted(known_components, key=len, reverse=True) if component in text]
    return appearance_order(text, found)


def attach_current_registry(candidates: pd.DataFrame) -> tuple[pd.DataFrame, dict[tuple[str, str], bool]]:
    registry = pd.read_csv(CURRENT_REGISTRY)
    known_components = sorted(set(sum([split_components(v) for v in candidates["components"].dropna()], [])))
    current_key_to_id: dict[str, str] = {}
    current_key_to_row: dict[str, dict] = {}
    for _, row in registry.iterrows():
        components = infer_registry_components(row["composition"], known_components)
        exact, basis, fractions, _ = parse_composition(
            row["display_system"], ";".join(components), row["composition"], row["composition"]
        )
        if exact:
            key = candidate_key(basis, fractions)
            current_key_to_id[key] = row["system_id"]
            current_key_to_row[key] = row.to_dict()
    out = candidates.copy()
    out["current_registry_system_id"] = out["candidate_key"].map(current_key_to_id).fillna("")
    out["atomic_engineering_registry_available"] = out["current_registry_system_id"].ne("")
    registry_columns = [
        "Tm_C", "Tm_unc_C", "Tmax_practical_C", "Tmax_unc_C",
        "cp_model", "cp_a", "cp_b", "cp_mw_g_mol", "cp_rel_unc",
        "rho_model", "rho_a", "rho_b", "rho_rel_unc",
        "latent_J_g", "latent_rel_unc",
        "cp_Tmin_C", "cp_Tmax_C", "rho_Tmin_C", "rho_Tmax_C",
        "property_data_class",
    ]
    for column in registry_columns:
        out[f"current_{column}"] = out["candidate_key"].map(
            lambda key: current_key_to_row.get(key, {}).get(column, np.nan)
        )
    membership = pd.read_csv(CURRENT_MEMBERSHIP)
    member = {(row["system_id"], row["scenario"]): True for _, row in membership.iterrows()}
    return out, member


def current_property_value(candidate: pd.Series, property_name: str, temperature_C: np.ndarray) -> np.ndarray:
    model = clean_text(candidate.get(f"current_{property_name}_model", ""))
    a = pd.to_numeric(pd.Series([candidate.get(f"current_{property_name}_a", np.nan)]), errors="coerce").iloc[0]
    b = pd.to_numeric(pd.Series([candidate.get(f"current_{property_name}_b", np.nan)]), errors="coerce").iloc[0]
    if not model or pd.isna(a):
        return np.full_like(temperature_C, np.nan, dtype=float)
    temperature_K = temperature_C + 273.15
    if model == "constant":
        value = np.full_like(temperature_C, float(a), dtype=float)
    elif model == "linear_K":
        value = float(a) + float(b) * temperature_K
    elif model == "linear_C":
        value = float(a) + float(b) * temperature_C
    elif model == "linear_molar_K":
        mw = float(candidate.get("current_cp_mw_g_mol", np.nan))
        value = (float(a) + float(b) * temperature_K) / mw
    else:
        return np.full_like(temperature_C, np.nan, dtype=float)
    if property_name == "rho" and np.nanmedian(value) < 20.0:
        value = value * 1000.0
    return value


def domain_covers(candidate: pd.Series, property_name: str, low_C: float, high_C: float) -> bool:
    low = candidate.get(f"current_{property_name}_Tmin_C", np.nan)
    high = candidate.get(f"current_{property_name}_Tmax_C", np.nan)
    return bool(pd.notna(low) and pd.notna(high) and float(low) <= low_C and float(high) >= high_C)


def _temperature_values_C(text: str) -> list[float]:
    """Extract explicit temperatures from condition text without using formula digits.

    Only numbers adjacent to a temperature unit, or numbers inside an explicit
    range followed by a unit, are accepted. This deliberately rejects vague
    strings such as ``reported`` and avoids treating chemical stoichiometry as
    a temperature range.
    """
    raw = clean_text(text).replace("−", "-").replace("–", "-").replace("—", "-")
    if not raw:
        return []
    values: list[float] = []
    range_pattern = re.compile(
        r"(-?\d+(?:\.\d+)?)\s*(?:-|to|~)\s*(-?\d+(?:\.\d+)?)\s*(K|°\s*C|deg\s*C|C)\b",
        flags=re.IGNORECASE,
    )
    consumed: list[tuple[int, int]] = []
    for match in range_pattern.finditer(raw):
        unit = match.group(3).upper().replace(" ", "")
        pair = [float(match.group(1)), float(match.group(2))]
        if unit == "K":
            pair = [value - 273.15 for value in pair]
        values.extend(pair)
        consumed.append(match.span())
    scalar_pattern = re.compile(r"(-?\d+(?:\.\d+)?)\s*(K|°\s*C|deg\s*C|C)\b", flags=re.IGNORECASE)
    for match in scalar_pattern.finditer(raw):
        if any(lo <= match.start() and match.end() <= hi for lo, hi in consumed):
            continue
        value = float(match.group(1))
        unit = match.group(2).upper().replace(" ", "")
        values.append(value - 273.15 if unit == "K" else value)
    return values


def conditions_cover(conditions: str, low_C: float, high_C: float, tolerance_C: float = 1.0) -> bool:
    values = _temperature_values_C(conditions)
    return bool(values and min(values) <= low_C + tolerance_C and max(values) >= high_C - tolerance_C)


def sensible_performance(candidate: pd.Series, service: dict) -> tuple[float, str, str, str]:
    """Return performance and a transparent service-domain evidence class.

    Tier A uses registered temperature-dependent equations over the complete
    duty. Tier B uses explicitly reported interval-average/scalar properties
    whose source conditions span the complete duty. Tier C is retained only as
    an opportunity-screening approximation and is not called full-domain
    support.
    """
    low_C, high_C = float(service["cold_C"]), float(service["hot_C"])
    if clean_text(candidate.get("current_registry_system_id", "")):
        temperature = np.linspace(low_C, high_C, 257)
        cp = current_property_value(candidate, "cp", temperature)
        rho = current_property_value(candidate, "rho", temperature)
        if np.isfinite(cp).all() and np.isfinite(rho).all():
            performance = float(rho[-1] * np.trapezoid(cp, temperature) / 3600.0)
            complete_domain = domain_covers(candidate, "cp", low_C, high_C) and domain_covers(candidate, "rho", low_C, high_C)
            if complete_domain:
                return (
                    performance,
                    "registered_temperature_equation_integral",
                    "A_equation_integrated_full_service_domain",
                    "registered_cp_and_density_equations_cover_complete_service",
                )
            return (
                performance,
                "registered_temperature_equation_partial_domain",
                "C_scalar_or_partial_screening_only",
                "registered_equation_domain_does_not_cover_complete_service",
            )
    cp = candidate.get("cp_J_gK", np.nan)
    rho = candidate.get("density_kg_m3", np.nan)
    if pd.isna(cp) or pd.isna(rho):
        return (
            float("nan"),
            "scalar_screening_approximation",
            "C_scalar_or_partial_screening_only",
            "cp_or_density_missing",
        )
    performance = float(cp) * float(rho) * (high_C - low_C) / 3600.0
    cp_cover = conditions_cover(candidate.get("cp_J_gK_conditions", ""), low_C, high_C)
    rho_cover = conditions_cover(candidate.get("density_kg_m3_conditions", ""), low_C, high_C)
    if cp_cover and rho_cover:
        return (
            performance,
            "reported_interval_average_full_domain",
            "B_reported_interval_full_service_domain",
            "reported_cp_and_density_conditions_span_complete_service_without_temperature_equations",
        )
    missing = []
    if not cp_cover:
        missing.append("cp_full_domain_not_demonstrated")
    if not rho_cover:
        missing.append("density_full_domain_not_demonstrated")
    return (
        performance,
        "scalar_screening_approximation",
        "C_scalar_or_partial_screening_only",
        ";".join(missing),
    )


def latent_support_class(candidate: pd.Series, linked: bool, performance: float, stability: float) -> tuple[str, str]:
    if pd.isna(performance):
        return "C_scalar_or_partial_screening_only", "latent_heat_missing"
    if pd.isna(stability):
        return "C_scalar_or_partial_screening_only", "condition_specific_upper_boundary_missing"
    if linked and pd.notna(candidate.get("current_latent_J_g", np.nan)):
        return (
            "A_measured_phase_property_with_registered_upper_boundary",
            "registered_measured_latent_heat_and_practical_upper_boundary",
        )
    latent_count = int(pd.to_numeric(pd.Series([candidate.get("latent_heat_J_g_evidence_count", 0)]), errors="coerce").fillna(0).iloc[0])
    upper_count = int(pd.to_numeric(pd.Series([candidate.get("stability_temperature_C_evidence_count", 0)]), errors="coerce").fillna(0).iloc[0])
    if latent_count > 0 and upper_count > 0:
        return (
            "B_measured_phase_property_with_reported_upper_boundary",
            "exact_composition_measured_latent_heat_and_reported_upper_boundary",
        )
    return (
        "C_scalar_or_partial_screening_only",
        "phase_property_or_upper_boundary_evidence_not_complete",
    )


def screen_services(
    candidates: pd.DataFrame, membership: dict[tuple[str, str], bool]
) -> pd.DataFrame:
    rows = []
    for _, candidate in candidates.iterrows():
        linked = bool(clean_text(candidate.get("current_registry_system_id", "")))
        tm = candidate.get("current_Tm_C", np.nan) if linked else candidate.get("melting_temperature_C", np.nan)
        stability = candidate.get("current_Tmax_practical_C", np.nan) if linked else candidate.get("stability_temperature_C", np.nan)
        tm_unc = candidate.get("current_Tm_unc_C", np.nan) if linked else np.nan
        stability_unc = candidate.get("current_Tmax_unc_C", np.nan) if linked else np.nan
        for service_id, service in SERVICES.items():
            reasons = []
            if pd.isna(tm):
                reasons.append("missing_melting_or_liquidus")
            if pd.isna(stability):
                reasons.append("missing_condition_specific_upper_boundary")
            if service["mode"] == "sensible":
                tm_limit = service["cold_C"] - service["freeze_margin_C"]
                phase_pass = pd.notna(tm) and float(tm) <= tm_limit
                upper_pass = pd.notna(stability) and float(stability) >= service["hot_C"]
                if pd.notna(tm) and not phase_pass:
                    reasons.append("melting_above_cold_side_margin")
                if pd.notna(stability) and not upper_pass:
                    reasons.append("upper_boundary_below_hot_side")
                performance, performance_basis, support_class, support_detail = sensible_performance(candidate, service)
                performance_unit = "kWh/m3"
            else:
                phase_pass = pd.notna(tm) and service["phase_min_C"] <= float(tm) <= service["phase_max_C"]
                upper_pass = pd.notna(tm) and pd.notna(stability) and float(stability) >= float(tm) + service["stability_margin_C"]
                if pd.notna(tm) and not phase_pass:
                    reasons.append("phase_temperature_outside_target_band")
                if pd.notna(tm) and pd.notna(stability) and not upper_pass:
                    reasons.append("upper_boundary_margin_below_40C")
                current_latent = candidate.get("current_latent_J_g", np.nan)
                performance = current_latent if linked and pd.notna(current_latent) else candidate.get("latent_heat_J_g", np.nan)
                performance_basis = "measured_mass_specific_latent_heat"
                support_class, support_detail = latent_support_class(candidate, linked, performance, stability)
                performance_unit = "MJ/t"
            physical_pass = bool(phase_pass and upper_pass)
            quantitative_complete = bool(physical_pass and pd.notna(performance))
            service_domain_supported = bool(quantitative_complete and not support_class.startswith("C_"))
            current_id = clean_text(candidate.get("current_registry_system_id", ""))
            atomic_member = bool(current_id and membership.get((current_id, service_id), False))
            boundary_ok = candidate["material_boundary"] != "outside_stationary_TES_material_boundary"
            if not boundary_ok:
                engineering_status = "outside_stationary_TES_material_boundary"
                formal_status = "excluded_outside_material_boundary"
            elif atomic_member:
                engineering_status = "atomic_registry_and_service_membership_available"
                formal_status = "evaluated_within_frozen_engineering_registry"
            elif current_id:
                engineering_status = "registered_candidate_not_assigned_to_service"
                formal_status = "not_formally_evaluated_no_registered_service_membership"
            else:
                engineering_status = "atomic_engineering_evidence_unresolved"
                formal_status = "not_formally_evaluated_outside_frozen_registry"
            rows.append(
                {
                    "service_id": service_id,
                    "service_label": service["label"],
                    "service_mode": service["mode"],
                    "candidate_key": candidate["candidate_key"],
                    "display_system": candidate["display_system"],
                    "family": candidate["family"],
                    "composition_basis": candidate["composition_basis"],
                    "normalized_composition": candidate["normalized_composition"],
                    "melting_temperature_C": tm,
                    "stability_temperature_C": stability,
                    "melting_uncertainty_C": tm_unc,
                    "upper_boundary_uncertainty_C": stability_unc,
                    "phase_gate_pass": bool(phase_pass),
                    "upper_boundary_gate_pass": bool(upper_pass),
                    "physical_window_pass": physical_pass,
                    "quantitative_thermophysical_complete": quantitative_complete,
                    "service_domain_supported": service_domain_supported,
                    "quantitative_domain_validated": service_domain_supported,
                    "service_domain_support_class": support_class,
                    "service_domain_support_detail": support_detail,
                    "tier_A_equation_or_phase_resolved": support_class.startswith("A_"),
                    "tier_B_reported_interval_or_phase_supported": support_class.startswith("B_"),
                    "tier_C_scalar_or_partial_screening_only": support_class.startswith("C_"),
                    "opportunity_performance": performance,
                    "opportunity_performance_unit": performance_unit,
                    "opportunity_performance_basis": performance_basis,
                    "property_domain_status": support_class,
                    "current_registry_system_id": current_id,
                    "engineering_registry_linked": atomic_member,
                    "engineering_evidence_status": engineering_status,
                    "formal_assessment_completed": atomic_member,
                    "formal_assessment_status": formal_status,
                    "formal_assessment_scope": "frozen_15_candidate_engineering_registry_only",
                    "material_boundary": candidate["material_boundary"],
                    "exclusion_or_limitation_reason": ";".join(sorted(set(reasons))),
                }
            )
    return pd.DataFrame(rows)

def normal_sigma(weight, target: str) -> float:
    weight = 0.5 if pd.isna(weight) else float(weight)
    if target in {"melting_temperature_C", "stability_temperature_C"}:
        return 4.0 + 20.0 * (1.0 - weight)
    return max(0.03, 0.03 + 0.20 * (1.0 - weight))


def deterministic_substream(base_seed: int, *parts: str) -> np.random.Generator:
    payload = "|".join([str(base_seed), *map(str, parts)]).encode("utf-8")
    seed = int.from_bytes(hashlib.sha256(payload).digest()[:8], "little", signed=False)
    return np.random.default_rng(seed)


def monte_carlo_opportunity(
    candidates: pd.DataFrame,
    screen: pd.DataFrame,
    iterations: int = 20_000,
    seed: int = 20260815,
    domain_validated_only: bool = False,
) -> pd.DataFrame:
    """Candidate-keyed matched Monte Carlo opportunity analysis.

    Each candidate/service/variable receives a deterministic substream. The
    same candidate therefore receives identical draws in the all-candidate and
    service-domain-supported analyses, independent of row order or candidate
    removal.
    """
    by_key = candidates.set_index("candidate_key")
    rows = []
    for service_id, service in SERVICES.items():
        eligible = screen[
            screen["service_id"].eq(service_id)
            & screen["quantitative_thermophysical_complete"]
            & ~screen["material_boundary"].eq("outside_stationary_TES_material_boundary")
        ].copy()
        if domain_validated_only:
            eligible = eligible[eligible["service_domain_supported"]].copy()
        eligible = eligible.sort_values("candidate_key").reset_index(drop=True)
        scope = (
            "service_domain_supported_thermophysical_opportunity_not_formal_selection"
            if domain_validated_only
            else "all_quantitative_thermophysical_opportunity_not_formal_selection"
        )
        if eligible.empty:
            rows.append(
                {
                    "service_id": service_id,
                    "service_label": service["label"],
                    "candidate_key": "none",
                    "display_system": "none",
                    "thermophysical_rank1_frequency": 0.0,
                    "robust_physical_pass_probability": 0.0,
                    "performance_p05": np.nan,
                    "performance_median": np.nan,
                    "performance_p95": np.nan,
                    "performance_unit": "kWh/m3" if service["mode"] == "sensible" else "MJ/t",
                    "iterations": iterations,
                    "scope": scope,
                    "seed_strategy": "candidate_keyed_sha256_substreams",
                }
            )
            continue
        keys = eligible["candidate_key"].tolist()
        performance_draws = np.full((iterations, len(keys)), -np.inf)
        pass_probs = []
        raw_perf = []
        for j, key in enumerate(keys):
            candidate = by_key.loc[key]
            screen_row = eligible[eligible["candidate_key"].eq(key)].iloc[0]
            tm_sigma = screen_row.get("melting_uncertainty_C", np.nan)
            if pd.isna(tm_sigma):
                tm_sigma = normal_sigma(candidate.get("melting_temperature_C_quality_weight"), "melting_temperature_C")
            stability_sigma = screen_row.get("upper_boundary_uncertainty_C", np.nan)
            if pd.isna(stability_sigma):
                stability_sigma = normal_sigma(candidate.get("stability_temperature_C_quality_weight"), "stability_temperature_C")
            tm = deterministic_substream(seed, service_id, key, "melting").normal(
                screen_row["melting_temperature_C"], float(tm_sigma), iterations
            )
            stability = deterministic_substream(seed, service_id, key, "upper_boundary").normal(
                screen_row["stability_temperature_C"], float(stability_sigma), iterations
            )
            if service["mode"] == "sensible":
                physical = (tm <= service["cold_C"] - service["freeze_margin_C"]) & (stability >= service["hot_C"])
                cp_unc = candidate.get("current_cp_rel_unc", np.nan)
                rho_unc = candidate.get("current_rho_rel_unc", np.nan)
                if pd.notna(cp_unc) and pd.notna(rho_unc):
                    perf_sigma = float(math.sqrt(float(cp_unc) ** 2 + float(rho_unc) ** 2))
                else:
                    cp_sigma = normal_sigma(candidate.get("cp_J_gK_quality_weight"), "cp_J_gK")
                    rho_sigma = normal_sigma(candidate.get("density_kg_m3_quality_weight"), "density_kg_m3")
                    perf_sigma = float(math.sqrt(cp_sigma**2 + rho_sigma**2))
                center = float(screen_row["opportunity_performance"])
                performance = deterministic_substream(seed, service_id, key, "performance").lognormal(
                    math.log(center) - 0.5 * perf_sigma**2, perf_sigma, iterations
                )
                unit = "kWh/m3"
            else:
                physical = (
                    (tm >= service["phase_min_C"])
                    & (tm <= service["phase_max_C"])
                    & (stability >= tm + service["stability_margin_C"])
                )
                latent_sigma = candidate.get("current_latent_rel_unc", np.nan)
                if pd.isna(latent_sigma):
                    latent_sigma = normal_sigma(candidate.get("latent_heat_J_g_quality_weight"), "latent_heat_J_g")
                center = float(screen_row["opportunity_performance"])
                performance = deterministic_substream(seed, service_id, key, "performance").lognormal(
                    math.log(center) - 0.5 * float(latent_sigma) ** 2,
                    float(latent_sigma),
                    iterations,
                )
                unit = "MJ/t"
            performance_draws[:, j] = np.where(physical, performance, -np.inf)
            pass_probs.append(float(physical.mean()))
            raw_perf.append(performance)
        winner = np.argmax(performance_draws, axis=1)
        no_selection = np.all(~np.isfinite(performance_draws), axis=1)
        for j, key in enumerate(keys):
            candidate = by_key.loc[key]
            perf = raw_perf[j]
            rows.append(
                {
                    "service_id": service_id,
                    "service_label": service["label"],
                    "candidate_key": key,
                    "display_system": candidate["display_system"],
                    "thermophysical_rank1_frequency": float(((winner == j) & ~no_selection).mean()),
                    "robust_physical_pass_probability": pass_probs[j],
                    "performance_p05": float(np.quantile(perf, 0.05)),
                    "performance_median": float(np.quantile(perf, 0.50)),
                    "performance_p95": float(np.quantile(perf, 0.95)),
                    "performance_unit": unit,
                    "iterations": iterations,
                    "scope": scope,
                    "seed_strategy": "candidate_keyed_sha256_substreams",
                }
            )
        rows.append(
            {
                "service_id": service_id,
                "service_label": service["label"],
                "candidate_key": "none",
                "display_system": "none",
                "thermophysical_rank1_frequency": float(no_selection.mean()),
                "robust_physical_pass_probability": np.nan,
                "performance_p05": np.nan,
                "performance_median": np.nan,
                "performance_p95": np.nan,
                "performance_unit": unit,
                "iterations": iterations,
                "scope": scope,
                "seed_strategy": "candidate_keyed_sha256_substreams",
            }
        )
    return pd.DataFrame(rows)

def build_attrition(records: pd.DataFrame, candidates: pd.DataFrame, screen: pd.DataFrame) -> pd.DataFrame:
    raw_formula_systems = records["canonical_system"].nunique() if "canonical_system" in records else np.nan
    supported = screen["service_domain_supported"]
    registry_linked = supported & screen["engineering_registry_linked"]
    values = [
        ("V13/V18 thermophysical records plus new rows", int(len(records)), "property_records"),
        ("Distinct formula systems in application library", int(raw_formula_systems), "formula_systems"),
        ("Exact-composition candidates after canonical deduplication", int(len(candidates)), "candidates"),
        ("Candidate-service pairs across seven frozen duties", int(len(screen)), "candidate_service_pairs"),
        ("Physical-window-compatible pairs", int(screen["physical_window_pass"].sum()), "candidate_service_pairs"),
        ("Quantitative thermophysical pairs", int(screen["quantitative_thermophysical_complete"].sum()), "candidate_service_pairs"),
        ("Service-domain-supported thermophysical pairs", int(supported.sum()), "candidate_service_pairs"),
        ("Tier-A equation/phase-resolved service-domain-supported pairs", int((supported & screen["tier_A_equation_or_phase_resolved"]).sum()), "candidate_service_pairs"),
        ("Tier-B reported-interval/phase service-domain-supported pairs", int((supported & screen["tier_B_reported_interval_or_phase_supported"]).sum()), "candidate_service_pairs"),
        ("Service-domain-supported pairs linked to frozen engineering registry", int(registry_linked.sum()), "candidate_service_pairs"),
        ("Service-domain-supported pairs outside frozen engineering registry", int((supported & ~screen["engineering_registry_linked"]).sum()), "candidate_service_pairs"),
    ]
    return pd.DataFrame(values, columns=["stage", "count", "count_unit"])

def build_cross_layer_storyline(screen: pd.DataFrame, mc: pd.DataFrame, mc_domain: pd.DataFrame) -> pd.DataFrame:
    robustness = pd.read_csv(CURRENT_ROBUSTNESS)
    robust_by_service = robustness.set_index("scenario")
    rows = []
    for service_id, service in SERVICES.items():
        subset = screen[screen["service_id"].eq(service_id)]
        all_rank = mc[(mc["service_id"].eq(service_id)) & ~mc["candidate_key"].eq("none")]
        domain_rank = mc_domain[(mc_domain["service_id"].eq(service_id)) & ~mc_domain["candidate_key"].eq("none")]
        all_top = all_rank.sort_values("thermophysical_rank1_frequency", ascending=False).head(1)
        domain_top = domain_rank.sort_values("thermophysical_rank1_frequency", ascending=False).head(1)
        formal = robust_by_service.loc[service_id]
        all_name = all_top["display_system"].iloc[0] if len(all_top) else "none"
        domain_name = domain_top["display_system"].iloc[0] if len(domain_top) else "none"
        formal_name = formal["balanced_leader"]
        if all_name != domain_name:
            interpretation = "apparent_property_leader_removed_by_service_domain_audit"
        elif domain_name != formal_name and domain_name != "none":
            interpretation = "thermophysical_leader_blocked_by_engineering_evidence"
        elif formal_name == "none":
            interpretation = "no_evidence_qualified_material"
        else:
            interpretation = "thermophysical_and_formal_leader_consistent"
        rows.append(
            {
                "service_id": service_id,
                "service_label": service["label"],
                "exact_candidates_screened": int(subset["candidate_key"].nunique()),
                "physical_window_pairs": int(subset["physical_window_pass"].sum()),
                "quantitative_pairs": int(subset["quantitative_thermophysical_complete"].sum()),
                "temperature_domain_validated_pairs": int(subset["service_domain_supported"].sum()),
                "service_domain_supported_pairs": int(subset["service_domain_supported"].sum()),
                "tier_A_supported_pairs": int((subset["service_domain_supported"] & subset["tier_A_equation_or_phase_resolved"]).sum()),
                "tier_B_supported_pairs": int((subset["service_domain_supported"] & subset["tier_B_reported_interval_or_phase_supported"]).sum()),
                "all_scalar_thermophysical_leader": all_name,
                "all_scalar_leader_probability": float(all_top["thermophysical_rank1_frequency"].iloc[0]) if len(all_top) else 0.0,
                "domain_validated_thermophysical_leader": domain_name,
                "domain_validated_leader_probability": float(domain_top["thermophysical_rank1_frequency"].iloc[0]) if len(domain_top) else 0.0,
                "evidence_qualified_balanced_leader": formal_name,
                "evidence_qualified_leader_probability": float(formal["balanced_leader_frequency"]),
                "evidence_qualified_no_selection_probability": float(formal["balanced_no_selection_frequency"]),
                "cross_layer_interpretation": interpretation,
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    for directory in [TABLES, QC]:
        directory.mkdir(parents=True, exist_ok=True)
    records, used = load_records()
    candidates = summarize_candidates(used)
    candidates, membership = attach_current_registry(candidates)
    screen = screen_services(candidates, membership)
    iterations = int(os.environ.get("TES_N_MC", "20000"))
    mc = monte_carlo_opportunity(candidates, screen, iterations=iterations)
    mc_domain = monte_carlo_opportunity(candidates, screen, iterations=iterations, domain_validated_only=True)
    attrition = build_attrition(records, candidates, screen)
    storyline = build_cross_layer_storyline(screen, mc, mc_domain)

    records.to_csv(TABLES / "expanded_v3_unified_property_record_audit.csv", index=False, encoding="utf-8-sig")
    candidates.to_csv(TABLES / "expanded_v3_exact_composition_candidate_summary.csv", index=False, encoding="utf-8-sig")
    screen.to_csv(TABLES / "expanded_v3_candidate_service_screen.csv", index=False, encoding="utf-8-sig")
    mc.to_csv(TABLES / "expanded_v3_thermophysical_opportunity_mc.csv", index=False, encoding="utf-8-sig")
    mc_domain.to_csv(TABLES / "expanded_v3_domain_validated_thermophysical_mc.csv", index=False, encoding="utf-8-sig")
    attrition.to_csv(TABLES / "expanded_v3_evidence_attrition.csv", index=False, encoding="utf-8-sig")
    storyline.to_csv(TABLES / "expanded_v3_cross_layer_storyline.csv", index=False, encoding="utf-8-sig")

    coverage = (
        candidates.groupby("family")
        .agg(
            exact_candidates=("candidate_key", "nunique"),
            candidates_with_melting=("melting_temperature_C", lambda x: int(x.notna().sum())),
            candidates_with_upper_boundary=("stability_temperature_C", lambda x: int(x.notna().sum())),
            candidates_with_cp=("cp_J_gK", lambda x: int(x.notna().sum())),
            candidates_with_density=("density_kg_m3", lambda x: int(x.notna().sum())),
            candidates_with_latent=("latent_heat_J_g", lambda x: int(x.notna().sum())),
            candidates_with_cycles=("cycle_count", lambda x: int(x.notna().sum())),
        )
        .reset_index()
        .sort_values("exact_candidates", ascending=False)
    )
    coverage.to_csv(TABLES / "expanded_v3_family_evidence_coverage.csv", index=False, encoding="utf-8-sig")

    current_ranks = pd.read_csv(CURRENT_RANKS) if CURRENT_RANKS.exists() else pd.DataFrame()
    current_rank1 = current_ranks[current_ranks.get("rank", pd.Series(dtype=float)).eq(1)].copy() if len(current_ranks) else current_ranks
    current_rank1.to_csv(TABLES / "expanded_v3_current_formal_rank1_reference.csv", index=False, encoding="utf-8-sig")

    new_source_ids = {"LIU_NKCA_2025", "LI_HXLN_2025", "LIU_NKM12_2025", "TIAN_NCCK_2025"}
    new_keys = set(used.loc[used["source_id"].isin(new_source_ids), "candidate_key"])
    new_screen = screen[screen["candidate_key"].isin(new_keys)].copy()
    new_screen.to_csv(TABLES / "expanded_v3_new_candidate_entry_audit.csv", index=False, encoding="utf-8-sig")

    checks = {
        "records_total": int(len(records)),
        "records_used_exact_plausible_nonduplicate": int(len(used)),
        "raw_formula_systems": int(records["canonical_system"].nunique()),
        "exact_composition_candidates": int(len(candidates)),
        "unresolved_or_nonexact_records": int((~records["exact_composition"]).sum()),
        "duplicate_property_records": int(records["duplicate_property_record"].sum()),
        "candidate_service_pairs": int(len(screen)),
        "physical_window_pass_pairs": int(screen["physical_window_pass"].sum()),
        "quantitative_thermophysical_pairs": int(screen["quantitative_thermophysical_complete"].sum()),
        "service_domain_supported_pairs": int(screen["service_domain_supported"].sum()),
        "tier_A_supported_pairs": int((screen["service_domain_supported"] & screen["tier_A_equation_or_phase_resolved"]).sum()),
        "tier_B_supported_pairs": int((screen["service_domain_supported"] & screen["tier_B_reported_interval_or_phase_supported"]).sum()),
        "atomic_registry_linked_pairs": int(screen["engineering_evidence_status"].eq("atomic_registry_and_service_membership_available").sum()),
        "new_exact_candidates": int(len(new_keys)),
        "new_physical_window_entries": int(new_screen["physical_window_pass"].sum()),
        "new_service_domain_supported_entries": int(new_screen["service_domain_supported"].sum()),
        "new_formal_assessments_completed": int(new_screen["formal_assessment_completed"].sum()),
        "nkca_2025_pcm500_physical_pass": bool(
            new_screen["display_system"].str.contains("23.5-25.0-51.5", regex=False, na=False)
            .where(new_screen["service_id"].eq("pcm_target_500C"), False)
            .where(new_screen["physical_window_pass"], False)
            .any()
        ),
        "hitec_xl_nitrite_physical_services": int(
            new_screen[
                new_screen["display_system"].str.contains("HXLN", regex=False, na=False)
                & new_screen["physical_window_pass"]
            ]["service_id"].nunique()
        ),
        "formal_predictions_used": 0,
        "monte_carlo_iterations": iterations,
        "random_seed": 20260815,
        "source_hashes": {
            RECORDS_FILE.name: sha256(RECORDS_FILE),
            ADDITIONS_FILE.name: sha256(ADDITIONS_FILE),
            SOURCES_FILE.name: sha256(SOURCES_FILE),
            "molten_salt_database_v13_user_resolved_extraction.xlsx": sha256(DATA / "molten_salt_database_v13_user_resolved_extraction.xlsx"),
        },
    }
    checks["validation_pass"] = bool(
        checks["records_total"] >= 770
        and checks["exact_composition_candidates"] >= 130
        and checks["nkca_2025_pcm500_physical_pass"]
        and checks["new_formal_assessments_completed"] == 0
        and checks["formal_predictions_used"] == 0
    )
    (QC / "expanded_v3_full_library_validation.json").write_text(
        json.dumps(checks, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(checks, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
