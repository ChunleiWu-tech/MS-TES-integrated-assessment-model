from pathlib import Path
import json
from high_density_extensions import run_high_density_extensions
ROOT=Path(__file__).resolve().parents[1]
print(json.dumps(run_high_density_extensions(ROOT,'core'),indent=2))
