"""Independent engineering-evidence invariants and known-value checks."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
T=ROOT/"outputs/tables"
checks=[]
def check(name,value): checks.append(dict(check=name,passed=bool(value)))
d=pd.read_csv(T/"engineering_corrosion_endpoints.csv").set_index("observation_id")
t=pd.read_csv(T/"engineering_rate_threshold_sensitivity.csv")
m=pd.read_csv(T/"engineering_composition_transfer.csv")
r=pd.read_csv(T/"engineering_score_sensitivity_summary.csv")
p=pd.read_csv(T/"engineering_score_sensitivity.csv")
c=pd.read_csv(T/"engineering_matched_comparisons.csv")
check("26_condition_resolved_records_5_studies",len(d)==26 and d.study_id.nunique()==5)
check("unique_observation_keys",d.index.is_unique)
check("mm_to_um_conversion",np.isclose(d.loc["H26_KNC700_304","rate_or_upper_bound_um_per_year"],663.7))
check("EG_explicit_published_endpoint",np.isclose(d.loc["W21_EG300","rate_or_upper_bound_um_per_year"],2.6) and d.loc["W21_EG300","extraction_basis"]=="primary_reported_mean_rate")
check("two_censored_endpoints",(d.relation=="less_than").sum()==2)
check("bound15_does_not_establish_threshold10",(t[t.observation_id.str.contains("2000") & t.threshold_um_per_year.eq(10)].classification=="indeterminate").all())
check("bound15_establishes_threshold15",(t[t.observation_id.str.contains("2000") & t.threshold_um_per_year.eq(15)].classification=="below_threshold").all())
check("all_KNC700_exceed_100",(t[t.observation_id.str.contains("KNC700") & t.threshold_um_per_year.eq(100)].classification=="above_threshold").all())
check("no_MgCl_family_exact_composition_transfer",not m[m.target_system_id.eq("mgcl_kcl_nacl")].composition_match.any())
check("eight_KNC_matching_endpoints",m[m.target_system_id.eq("knc")].composition_match.sum()==8)
check("one_rounded_LiNaK_composition_match",m[m.target_system_id.eq("linak_carbonate")].composition_match.sum()==1)
check("no_automatic_service_qualification",not m.automatic_service_qualification.any())
check("no_invented_sampling_error_distribution",(d.sampling_error_model=="not_assigned").all())
check("paired_method_ratios",np.isclose(c[c.alloy.eq("HaC276")].ratio.iloc[0],526/79))
check("seven_services_25_paired_settings_each",len(r)==175 and (r.groupby("scenario").size()==25).all())
check("probability_mass_conserved",np.allclose(r.probability_sum,1,atol=1e-12))
check("selection_frequencies_bounded",p.selection_frequency.between(0,1).all())
check("score_free_invariant_to_aggregation",p[p.credibility_weight.eq(0)].groupby(["scenario","system_id"]).selection_frequency.nunique().max()==1)
check("no_selection_invariant_to_scoring",r.groupby("scenario").no_selection_frequency.nunique().max()==1)
check("draw_counts_consistent",r.mc_draws.nunique()==1 and p.mc_draws.nunique()==1)
reg=pd.read_csv(ROOT/"data/input/core_atomic_engineering_credibility_registry.csv")
tms=reg[reg.system_id.str.contains("tms",case=False)]
check("isothermal_aging_not_cycle_validation",len(tms)>0 and tms.gap_cycling_phase.all())
payload=dict(status="PASS" if all(v["passed"] for v in checks) else "FAIL",checks=checks,
             checks_passed=sum(v["passed"] for v in checks),checks_total=len(checks))
(ROOT/"outputs/qc/engineering_evidence_validation.json").write_text(json.dumps(payload,indent=2),encoding="utf-8")
print(json.dumps(payload,indent=2))
if payload["status"]!="PASS": raise SystemExit(1)
