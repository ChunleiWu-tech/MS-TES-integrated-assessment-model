from __future__ import annotations

from pathlib import Path
import csv
import json

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
IN = ROOT / "data" / "input"
PROV = ROOT / "data" / "provenance"
QC = ROOT / "outputs" / "qc"
PROV.mkdir(parents=True, exist_ok=True)
QC.mkdir(parents=True, exist_ok=True)

GROUPS = [
    "composition", "melting_temperature", "practical_upper_temperature",
    "specific_heat", "density", "thermal_conductivity", "viscosity",
    "latent_heat", "reported_energy_density",
]

with (IN / f"{VERSION}_candidate_property_registry.csv").open(encoding="utf-8-sig", newline="") as f:
    candidates = list(csv.DictReader(f))
with (IN / f"{VERSION}_authoritative_source_registry.csv").open(encoding="utf-8-sig", newline="") as f:
    sources = {r["source_id"]: r for r in csv.DictReader(f)}


def impl(r: dict[str, str], group: str) -> tuple[str, str, str, str]:
    if group == "composition":
        return "composition", r["composition"], "as registered", ""
    if group == "melting_temperature":
        return "Tm_C;Tm_unc_C", f'{r["Tm_C"]} +/- {r["Tm_unc_C"]}', "degC", "Tm_unc_C"
    if group == "practical_upper_temperature":
        return "Tmax_practical_C;Tmax_unc_C", f'{r["Tmax_practical_C"]} +/- {r["Tmax_unc_C"]}', "degC", "Tmax_unc_C"
    if group == "specific_heat":
        model = r["cp_model"]
        if model == "linear_molar_K":
            val = f'Cp_molar={r["cp_a"]}+({r["cp_b"]})*T_K; MW={r["cp_mw_g_mol"]} g mol-1'
        elif model in {"constant", "predicted_family"}:
            val = f'Cp={r["cp_a"]}'
        else:
            val = f'{model}; a={r["cp_a"]}; b={r["cp_b"]}'
        return "cp_model;cp_a;cp_b;cp_mw_g_mol", val, "J g-1 K-1 unless molar form stated", "cp_rel_unc"
    if group == "density":
        model = r["rho_model"]
        if model == "linear_K":
            val = f'rho={r["rho_a"]}+({r["rho_b"]})*T_K'
            unit = "g cm-3"
        elif model == "linear_C":
            val = f'rho={r["rho_a"]}+({r["rho_b"]})*T_C'
            unit = "g cm-3"
        else:
            val = f'{model}; a={r["rho_a"]}; b={r["rho_b"]}'
            unit = "kg m-3"
        return "rho_model;rho_a;rho_b", val, unit, "rho_rel_unc"
    if group == "thermal_conductivity":
        if r["k_model"] == "missing":
            val = "not used"
        elif r["k_model"] == "linear_K":
            val = f'k={r["k_a"]}+({r["k_b"]})*T_K'
        else:
            val = f'{r["k_model"]}; k={r["k_a"]}'
        return "k_model;k_a;k_b", val, "W m-1 K-1", "k_rel_unc"
    if group == "viscosity":
        val = "not used" if r["mu_model"] == "missing" else f'{r["mu_model"]}; mu={r["mu_a"]}'
        return "mu_model;mu_a;mu_b", val, "mPa s", "mu_rel_unc"
    if group == "latent_heat":
        val = r["latent_J_g"] or "not used"
        return "latent_J_g", val, "J g-1", "latent_rel_unc"
    if group == "reported_energy_density":
        val = r["reported_energy_density_MJ_m3"] or "not used"
        return "reported_energy_density_MJ_m3", val, "MJ m-3", ""
    raise KeyError(group)


def rec(source_id: str, locator: str, source_value: str, source_unit: str = "",
        condition: str = "", origin: str = "direct", transformation: str = "none",
        validity: str = "not applicable", status: str = "CLOSED",
        claim: str = "May be used only within the registered model role and validity range.") -> dict[str, str]:
    return dict(source_id=source_id, source_locator=locator, source_value_or_equation=source_value,
                source_unit=source_unit, source_condition=condition, evidence_origin=origin,
                transformation_or_margin=transformation, source_validity_range=validity,
                review_status=status, article_claim_boundary=claim)

E: dict[tuple[str, str], dict[str, str]] = {}
def put(system: str, group: str, *args, **kwargs) -> None:
    E[(system, group)] = rec(*args, **kwargs)

# Solar Salt SS60. Composition-specific DLR values and the NIST/classical
# correlation are kept distinct; the implemented values are harmonised model inputs.
put("solar_salt_ss60","composition","WANG_TMS_2024","Tables 1 and 3, Solar Salt reference row","60 NaNO3 / 40 KNO3","wt%",origin="primary table")
put("solar_salt_ss60","melting_temperature","WANG_TMS_2024","Table 1, Solar Salt reference row","227.47","degC",origin="primary DSC/TG table")
put("solar_salt_ss60","practical_upper_temperature","DOE_NREL_GEN3_2017","Gen3 roadmap current molten-salt outlet boundary; cross-check WANG_TMS_2024 Table 1","565 practical; 572.32 decomposition cross-check","degC",origin="official system boundary plus primary cross-check",transformation="practical limit selected below decomposition",validity="current power-tower nitrate service")
put("solar_salt_ss60","specific_heat","DLR_SQM_SOLAR_SALT","Table 6, SS60; cross-check critical-review correlations","1.59646 composition-specific point; implemented 1.55 harmonised constant","J g-1 K-1",origin="technical-report benchmark",transformation="registered conservative harmonisation with 5% relative uncertainty",validity="250-565 degC engineering benchmark",claim="A registered engineering benchmark, not a new measurement by this study.")
put("solar_salt_ss60","density","NIST_SRD27","machine-readable NaNO3-KNO3 density correlation; DLR Table 6 cross-check at 565 degC","rho=2.2905-6.7242E-4*T_K; DLR SS60=1712.33 kg m-3 at 565 degC","g cm-3",origin="database correlation with composition-specific cross-check",validity="250-565 degC registered model domain")
put("solar_salt_ss60","thermal_conductivity","DLR_SQM_SOLAR_SALT","Table 6, SS60","0.5501; implemented 0.52 conservative benchmark","W m-1 K-1",origin="technical-report benchmark",transformation="conservative registered constant with 10% uncertainty",validity="250-565 degC engineering benchmark",claim="Diagnostic transport property; not a direct ranking axis.")
put("solar_salt_ss60","viscosity","DLR_SQM_SOLAR_SALT","Table 6, SS60","3.452 at 290 degC; implemented 3.45","mPa s","290 degC",origin="technical-report point",transformation="rounding",validity="250-565 degC engineering benchmark",claim="Diagnostic viscosity benchmark only.")
put("solar_salt_ss60","latent_heat","WANG_TMS_2024","Table 1, Solar Salt reference row","113","J g-1",origin="primary table",claim="Retained for provenance; sensible-service ranking does not use latent heat.")
put("solar_salt_ss60","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design",claim="No external reported-energy-density value is used.")

# KNC exact composition.
put("knc","composition","SANG_KNC_2023","composition statement near Fig. 2","0.259 KNO2 / 0.687 KNO3 / 0.054 K2CO3","mol fraction",origin="primary article")
put("knc","melting_temperature","SANG_KNC_2023","p.4, text near Fig. 2","342.1 recommended repeated-cycle value","degC",origin="primary DSC text")
put("knc","practical_upper_temperature","SANG_KNC_2023","p.4, Fig. 2b and text","750.1 decomposition; implemented 700.1","degC",origin="primary TGA",transformation="50 degC operational margin below decomposition")
put("knc","specific_heat","SANG_KNC_2023","p.5, measured liquid value","1.407","J g-1 K-1","400-450 degC",origin="primary experiment",validity="400-450 degC",claim="Must not be extrapolated into the 500-700 degC strict route.")
put("knc","density","SANG_KNC_2023","p.5, Eq. 6","rho=2.02816-6.59712E-4*T_C","g cm-3","400-600 degC",origin="primary equation",transformation="implemented representative constant 1747 kg m-3 within the registered equation range",validity="400-600 degC")
put("knc","thermal_conductivity","SANG_KNC_2023","p.5, Fig. 5b and text","about 0.3","W m-1 K-1","400-450 degC",origin="primary experimental range",validity="400-450 degC",claim="Diagnostic only and never extrapolated in strict figures.")
put("knc","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("knc","latent_heat","SANG_KNC_2023","p.4, text near Fig. 2","114.5","J g-1",origin="primary experiment")
put("knc","reported_energy_density","SANG_KNC_2023","p.6, Table 5","865","MJ m-3",origin="primary table",claim="Reported comparator retained separately from model-integrated energy density.")

# QNCC exact composition. The paper's reported average is primary; its fitted
# equation is retained in the explicit model-form sensitivity.
put("qncc","composition","HUANG_QNCC_2025","p.3, Table 2, sample 1","54/36/6/4 NaNO3/KNO3/Na2CO3/NaCl","wt%",origin="primary table")
put("qncc","melting_temperature","HUANG_QNCC_2025","p.3, Table 2","199.1","degC",origin="primary DSC table")
put("qncc","practical_upper_temperature","HUANG_QNCC_2025","thermal-stability figure/text","620 decomposition; implemented 600","degC",origin="primary TGA",transformation="20 degC operational margin")
put("qncc","specific_heat","HUANG_QNCC_2025","abstract/conclusion average; p.4 Eq. 2 model-form cross-check","1.56 +/-0.05 average; Cp=1.7061-5.5826E-4*T_C sensitivity","J g-1 K-1","average liquid value; fit 250-450 degC",origin="primary experiment and equation",transformation="reported average is primary; fitted equation is separately exported",validity="250-450 degC")
put("qncc","density","HUANG_QNCC_2025","p.5, Eq. 4","rho=2.1250-6.5469E-4*T_C","g cm-3","300-600 degC",origin="primary equation",validity="300-600 degC")
put("qncc","thermal_conductivity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("qncc","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("qncc","latent_heat","HUANG_QNCC_2025","p.4, text and Fig. 3","111.9 +/-2.0","J g-1",origin="primary experiment",claim="Retained for provenance; sensible-service ranking does not use latent heat.")
put("qncc","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# MgCl2-KCl-NaCl exact composition.
put("mgcl_kcl_nacl","composition","WANG_MGCL_2021","experimental composition definition","45.98/38.91/15.11 MgCl2/KCl/NaCl","wt%",origin="primary article")
put("mgcl_kcl_nacl","melting_temperature","WANG_MGCL_2021","DSC summary; 15 measurements","401.4 +/-1.3; MSD-TP alternate 382.85","degC",origin="primary DSC plus database sensitivity",transformation="direct DSC is primary; database value exported as sensitivity")
put("mgcl_kcl_nacl","practical_upper_temperature","WANG_MGCL_2021","reported property ranges and engineering discussion","700","degC",origin="primary property-range boundary",claim="Does not replace separate corrosion and purification gates.")
put("mgcl_kcl_nacl","specific_heat","WANG_MGCL_2021","Table 9","Cp=1.30138-0.0005*T_C","J g-1 K-1","450-625 degC",origin="primary regression",transformation="algebraically converted to molar-K form using MW=79.1411 g mol-1",validity="450-625 degC")
put("mgcl_kcl_nacl","density","WANG_MGCL_2021","density regression","rho=1958.8438-0.56355*T_C","kg m-3","430-700 degC",origin="primary regression",transformation="converted to g cm-3 and Kelvin basis",validity="430-700 degC")
put("mgcl_kcl_nacl","thermal_conductivity","WANG_MGCL_2021","thermal-conductivity regression","k=0.5822-2.6E-4*T_C","W m-1 K-1","450-700 degC",origin="primary regression",transformation="converted to Kelvin basis",validity="450-700 degC")
put("mgcl_kcl_nacl","viscosity","WANG_MGCL_2021","viscosity regression available","mu=0.70645*exp[1204.11348/(T_C+273.15)]","mPa s","445-700 degC",origin="primary regression",transformation="not used in present ranking",validity="445-700 degC")
put("mgcl_kcl_nacl","latent_heat","WANG_MGCL_2021","DSC summary","248.32 +/-7.37","J g-1",origin="primary experiment",claim="Not used because this candidate is evaluated in sensible mode.")
put("mgcl_kcl_nacl","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# Exact-composition NKCA; no mixing with the nearby 2025 composition.
put("nkca","composition","YIN_NKCA_2022","composition definition","0.408/0.075/0.517 NaCl/KCl/CaCl2","mol fraction",origin="primary article",transformation="converted to 27.47/6.44/66.09 wt% for cost calculation")
put("nkca","melting_temperature","YIN_NKCA_2022","DSC result","496.3 +/-1","degC",origin="primary experiment")
put("nkca","practical_upper_temperature","YIN_NKCA_2022","TGA result","939 thermal upper boundary; implemented 800","degC",origin="primary experiment",transformation="corrosion/service cap is more restrictive than decomposition")
put("nkca","specific_heat","YIN_NKCA_2022","measured liquid average","0.80 +/-0.15","J g-1 K-1","541-829 degC",origin="primary experiment",validity="541-829 degC")
put("nkca","density","YIN_NKCA_2022","density equation","rho=2.2093-4.5399E-4*T_C","g cm-3","509-800 degC",origin="primary equation",validity="509-800 degC")
put("nkca","thermal_conductivity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("nkca","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("nkca","latent_heat","YIN_NKCA_2022","DSC result","171.5 +/-5","J g-1",origin="primary experiment")
put("nkca","reported_energy_density","TES_INTERNAL","candidate registry","not used; former nearby-composition 616.01 removed",origin="removed mismatched proxy",claim="No nearby-composition reported value is presented as exact-composition evidence.")

# LiF-containing PCM S1.
put("pcm_lif_s1","composition","LI_PCM_2024","p.3, Table 2","57/32/11 Na2CO3/Li2CO3/LiF wt%; 38/31/31 mol ratio","wt% and mol ratio",origin="primary table")
put("pcm_lif_s1","melting_temperature","LI_PCM_2024","p.4, Fig. 2 and text","426.8","degC","N2, 10 degC min-1",origin="primary experiment")
put("pcm_lif_s1","practical_upper_temperature","LI_PCM_2024","p.5, Fig. 8 and text","0.8 wt% loss at 600 degC; 3.6 wt% at 800 degC; implemented 650","degC",origin="primary TGA anchors",transformation="registered conservative engineering boundary")
put("pcm_lif_s1","specific_heat","LI_PCM_2024","p.5, Eq. 3 (solid-phase evidence); candidate registry diagnostic model","direct equation valid 50-400 degC; liquid-family diagnostic Cp=1.5","J g-1 K-1",origin="direct solid equation plus declared family prediction",validity="direct evidence 50-400 degC",claim="Predicted Cp is used only in the separate +50 K opportunity diagnostic, not the primary latent ranking.")
put("pcm_lif_s1","density","TES_INTERNAL","candidate registry family prediction","2200","kg m-3",origin="declared family prediction",validity="426.8-650 degC declared model domain",claim="Not described as an exact-composition measurement.")
put("pcm_lif_s1","thermal_conductivity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("pcm_lif_s1","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("pcm_lif_s1","latent_heat","LI_PCM_2024","p.4, Fig. 2 and text","413","J g-1","N2, 10 degC min-1",origin="primary experiment")
put("pcm_lif_s1","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# Binary carbonate, with exact mol-to-mass conversion for the cost model.
put("pcm_binary_carbonate","composition","GE_BINARY_CARBONATE_2018","Fig. 1 and text","about 51 Li2CO3 / 49 Na2CO3","mol%",origin="primary experiment and MD study",transformation="molar masses give 42.0498/57.9502 wt%")
put("pcm_binary_carbonate","melting_temperature","GE_BINARY_CARBONATE_2018","eutectic-region literature/experiment discussion","about 496-498","degC",origin="primary/literature anchor")
put("pcm_binary_carbonate","practical_upper_temperature","TES_INTERNAL","candidate registry engineering boundary","750","degC",origin="registered analytical boundary",claim="An analytical upper boundary, not a directly measured decomposition point for the exact candidate.")
put("pcm_binary_carbonate","specific_heat","TES_INTERNAL","candidate registry family prediction","1.6","J g-1 K-1",origin="declared family prediction",validity="496-750 degC declared model domain",claim="Used only in the separate +50 K opportunity diagnostic.")
put("pcm_binary_carbonate","density","TES_INTERNAL","derived from registered reported energy density and latent heat","rho=858 MJ m-3 / 351 kJ kg-1 = 2444 kg m-3","kg m-3",origin="derived calculation",transformation="unit-consistent algebraic derivation",claim="Explicitly labelled derived, not measured.")
put("pcm_binary_carbonate","thermal_conductivity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("pcm_binary_carbonate","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("pcm_binary_carbonate","latent_heat","GE_BINARY_CARBONATE_2018","Fig. 1; text-confirmed maximum near 51 mol% Li2CO3","351","J g-1",origin="primary figure/text with registered digitization uncertainty")
put("pcm_binary_carbonate","reported_energy_density","TES_INTERNAL","registered derived-data chain","858","MJ m-3",origin="registered reported/derived comparator",claim="Used only to derive the explicitly labelled density proxy.")

# Commercial HITEC.
put("hitec","composition","BERNAGOZZI_SELECTION_2019","Tables 2/11 commercial benchmark","53 KNO3 / 40 NaNO2 / 7 NaNO3","wt%",origin="peer-reviewed selection review")
put("hitec","melting_temperature","BERNAGOZZI_SELECTION_2019","Table 2","142","degC",origin="review benchmark")
put("hitec","practical_upper_temperature","DOE_TES_ASSESSMENT_2023","technology-assessment practical nitrate boundary; Bernagozzi Table 3 cross-check","450 implemented; 550 review degradation benchmark","degC",origin="official context plus review",transformation="conservative industrial-service cap")
put("hitec","specific_heat","SERRANO_MOLTEN_SALTS_2013","recommended property table","1560","J kg-1 K-1",origin="critical-review recommended constant",transformation="converted to 1.56 J g-1 K-1",validity="250-450 degC registered engineering domain")
put("hitec","density","SERRANO_MOLTEN_SALTS_2013","selected review correlation","rho=2279.799-0.7324*T_K","kg m-3","448-773 K",origin="critical-review selected correlation",transformation="stored as g cm-3 linear-K coefficients",validity="175-500 degC")
put("hitec","thermal_conductivity","SERRANO_MOLTEN_SALTS_2013","recommended constant","0.48","W m-1 K-1",origin="critical-review recommended constant",validity="250-450 degC registered engineering domain",claim="Diagnostic transport property.")
put("hitec","viscosity","BERNAGOZZI_SELECTION_2019","Table 11, 100-400 degC simulation average","5.64","mPa s","100-400 degC average",origin="review simulation average",transformation="retained as diagnostic constant",validity="250-450 degC registered engineering proxy",claim="Diagnostic viscosity only; not a new measurement.")
put("hitec","latent_heat","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("hitec","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# Commercial HITEC XL review averages.
put("hitec_xl","composition","BERNAGOZZI_SELECTION_2019","Tables 2/11","7 NaNO3 / 45 KNO3 / 48 Ca(NO3)2","wt%",origin="peer-reviewed selection review")
put("hitec_xl","melting_temperature","BERNAGOZZI_SELECTION_2019","Table 2","120","degC",origin="review benchmark")
put("hitec_xl","practical_upper_temperature","BERNAGOZZI_SELECTION_2019","Table 3","500","degC",origin="review degradation benchmark")
put("hitec_xl","specific_heat","BERNAGOZZI_SELECTION_2019","Table 11, 100-400 degC simulation average","1.45","kJ kg-1 K-1",origin="review simulation average",validity="100-400 degC",claim="Review average; not extrapolated to 450 degC in the strict route.")
put("hitec_xl","density","BERNAGOZZI_SELECTION_2019","Table 11, 100-400 degC simulation average","2002","kg m-3",origin="review simulation average",validity="100-400 degC")
put("hitec_xl","thermal_conductivity","BERNAGOZZI_SELECTION_2019","Table 11, 100-400 degC simulation average","0.52","W m-1 K-1",origin="review simulation average",validity="100-400 degC",claim="Diagnostic transport property.")
put("hitec_xl","viscosity","BERNAGOZZI_SELECTION_2019","Table 11, 100-400 degC simulation average","31.37","mPa s",origin="review simulation average",validity="100-400 degC",claim="Diagnostic viscosity only.")
put("hitec_xl","latent_heat","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("hitec_xl","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# S7. Decomposition stability is not interpreted as high-temperature property validation.
put("quat_s7","composition","KWASI_QUATERNARY_2023","composition table, S7","28/35/18/19 Ca(NO3)2/LiNO3/KNO3/NaNO2","wt%",origin="primary table")
put("quat_s7","melting_temperature","KWASI_QUATERNARY_2023","S7 DSC record","73.5","degC",origin="primary experiment")
put("quat_s7","practical_upper_temperature","KWASI_QUATERNARY_2023","S7 decomposition table","620 decomposition; implemented 590","degC",origin="primary TGA",transformation="30 degC operational margin")
put("quat_s7","specific_heat","KWASI_QUATERNARY_2023","S7 heat-capacity record","2.01","J g-1 K-1","50-280 degC",origin="primary experiment",validity="50-280 degC",claim="Not extrapolated to the 380-550 degC coal strict route.")
put("quat_s7","density","TES_INTERNAL","candidate registry family prediction","1950","kg m-3",origin="declared family prediction",validity="80-280 degC domain cap",claim="Not described as a direct S7 measurement.")
put("quat_s7","thermal_conductivity","KWASI_QUATERNARY_2023","S7/Table 4 range","reported range over 80-280 degC; model proxy 0.6","W m-1 K-1","80-280 degC",origin="primary range plus declared family proxy",validity="80-280 degC",claim="Diagnostic only; proxy is not a direct point measurement.")
put("quat_s7","viscosity","KWASI_QUATERNARY_2023","S7 viscosity record","11.56","mPa s","120 degC",origin="primary point",validity="120 degC point only")
put("quat_s7","latent_heat","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("quat_s7","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# 2024 sulfate-modified nitrate TMS-2.  Only values recoverable from the
# accessible primary record are registered; graphical-only transport values
# remain missing to prevent silent digitisation or extrapolation.
put("tms2","composition","WANG_TMS_2024","Table 1, TMS-2 composition","42.01 NaNO3 / 56.30 KNO3 / 1.69 Na2SO4","wt%",origin="primary table")
put("tms2","melting_temperature","WANG_TMS_2024","Table 1 and DSC text","220.97","degC",origin="primary experiment")
put("tms2","practical_upper_temperature","WANG_TMS_2024","Section 2.9, 1008 h isothermal aging at 550 C; decomposition table","550 isothermal test; 611.25 decomposition","degC",origin="primary isothermal aging plus TGA",transformation="550 C retained as directly exercised practical boundary; not repeated thermal-cycle qualification")
put("tms2","specific_heat","WANG_TMS_2024","Cp section, liquid average","1.69","J g-1 K-1","250-400 degC",origin="primary experiment",validity="250-400 degC")
put("tms2","density","TES_INTERNAL","candidate registry","not used","",origin="missing by design",claim="Graphical density data were not converted into a numerical correlation; strict selection cannot use density.")
put("tms2","thermal_conductivity","TES_INTERNAL","candidate registry","not used","",origin="missing by design",claim="A calculated/graphical value is not promoted into the strict property route.")
put("tms2","viscosity","TES_INTERNAL","candidate registry","not used","",origin="missing by design")
put("tms2","latent_heat","WANG_TMS_2024","Table 1 and DSC result","96.04","J g-1",origin="primary experiment",claim="Retained for provenance; sensible-service ranking does not use latent heat.")
put("tms2","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# 2026 process-informed NaNO3-KNO3-KCl formulation.  The accessible primary
# record reports scalar Cp and density but does not expose their measurement
# domains; both domains therefore remain unassigned.
put("nknkcl_2026","composition","ZHANG_NKNKCL_2026","Abstract and formulation statement","32.6 NaNO3 / 53.2 KNO3 / 14.2 KCl","mol%",origin="primary article")
put("nknkcl_2026","melting_temperature","ZHANG_NKNKCL_2026","Abstract and highlights","211.1","degC",origin="experimentally verified primary value")
put("nknkcl_2026","practical_upper_temperature","ZHANG_NKNKCL_2026","Abstract thermal-stability limit","619 stability; implemented 569","degC",origin="primary summary",transformation="50 degC conservative margin")
put("nknkcl_2026","specific_heat","ZHANG_NKNKCL_2026","Abstract scalar property","1.60","J g-1 K-1",origin="primary scalar",validity="temperature domain not recoverable from accessible record",claim="The scalar is retained for provenance but not assigned strict service coverage.")
put("nknkcl_2026","density","ZHANG_NKNKCL_2026","Abstract scalar property","1.83","g cm-3",origin="primary scalar",validity="temperature domain not recoverable from accessible record",claim="The scalar is retained for provenance but not assigned strict service coverage.")
put("nknkcl_2026","thermal_conductivity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("nknkcl_2026","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("nknkcl_2026","latent_heat","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("nknkcl_2026","reported_energy_density","ZHANG_NKNKCL_2026","Abstract operating-window comparison","0.96","GJ m-3",origin="primary reported comparison",transformation="not entered as a ranking input",claim="Reported energy density is contextual only because the property-temperature domain is not independently recoverable.")

# 2026 nitrate-carbonate-chloride formulation.
put("nkckcl_2026","composition","YIN_NKCKCL_2026","Abstract and methods formulation","48 NaNO3 / 32 KNO3 / 10 K2CO3 / 10 KCl","wt%",origin="primary article")
put("nkckcl_2026","melting_temperature","YIN_NKCKCL_2026","Conclusions","199.0","degC",origin="primary experiment")
put("nkckcl_2026","practical_upper_temperature","YIN_NKCKCL_2026","Abstract and conclusions","612 decomposition; stable to 630 with 2.6 wt% loss; implemented 562","degC",origin="primary TGA",transformation="50 degC margin below decomposition; stability criterion retained separately")
put("nkckcl_2026","specific_heat","YIN_NKCKCL_2026","Conclusions, mean liquid-phase value","1.45 +/- 0.05","J g-1 K-1",origin="primary liquid mean",transformation="domain co-registered to explicit density interval",validity="300-600 degC declared harmonisation",claim="The co-registered domain is transparent and the data-completeness/evidence gates remain independent.")
put("nkckcl_2026","density","YIN_NKCKCL_2026","Abstract density equation","rho=2.2331-7.4756E-4*T_C","g cm-3",origin="primary equation",validity="300-600 degC")
put("nkckcl_2026","thermal_conductivity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("nkckcl_2026","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("nkckcl_2026","latent_heat","YIN_NKCKCL_2026","Conclusions","84.3","J g-1",origin="primary experiment",claim="Retained for provenance; sensible-service ranking does not use latent heat.")
put("nkckcl_2026","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# LiNaK carbonate.  The recent critical review is used only for a transparent
# multi-study density harmonisation; direct measurements and corrosion remain
# separately cited.
put("linak_carbonate","composition","AN_LINAK_2016","Exact eutectic composition","32.12 Li2CO3 / 33.36 Na2CO3 / 34.52 K2CO3","wt%",origin="primary article")
put("linak_carbonate","melting_temperature","AN_LINAK_2016","DSC/liquidus result","397","degC",origin="primary experiment")
put("linak_carbonate","practical_upper_temperature","AN_LINAK_2016","Thermal-analysis onset","658 decomposition; implemented 608","degC",origin="primary TGA",transformation="50 degC conservative margin")
put("linak_carbonate","specific_heat","AN_LINAK_2016","DSC liquid-property evaluation","1.61 registered average","J g-1 K-1",origin="primary experiment with review cross-check",transformation="10% harmonisation uncertainty",validity="397-658 degC",claim="A registered average, not a proposed universal reference correlation.")
put("linak_carbonate","density","LINAK_CRITICAL_REVIEW_2026","Eq. 1 multi-study regression","rho=2.387527-4.4466E-4*T_K","g cm-3",origin="critical multi-study regression",validity="650-1150 K; model clipped to liquid 397-658 degC")
put("linak_carbonate","thermal_conductivity","AN_LINAK_2016","Direct diffusivity-density-Cp evaluation; review cross-check","0.612 registered point","W m-1 K-1",origin="primary experiment",validity="450-600 degC diagnostic range",claim="Diagnostic transport value; the critical review does not endorse a universal conductivity correlation.")
put("linak_carbonate","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design",claim="Conflicting literature correlations are not collapsed into the strict model.")
put("linak_carbonate","latent_heat","AN_LINAK_2016","Phase-property record and review cross-check","275","J g-1",origin="primary/review value",claim="Retained for provenance; this candidate is not registered in a PCM service.")
put("linak_carbonate","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

# FLiNaK multi-laboratory round robin.  The nominal formulation is retained as
# a label while measured composition dispersion remains an explicit gate.
put("flinak_rr","composition","MUNRO_FLINAK_RR_2026","Common-batch nominal composition and laboratory composition results","46.5 LiF / 11.5 NaF / 42.0 KF nominal; laboratory values dispersed","mol%",origin="21-laboratory round robin",claim="Nominal composition is not treated as exact composition at every laboratory.")
put("flinak_rr","melting_temperature","MUNRO_FLINAK_RR_2026","Round-robin melting results","454.7-464.6; implemented midpoint 459.65 +/- 4.95","degC",origin="21-laboratory round robin")
put("flinak_rr","practical_upper_temperature","MUNRO_FLINAK_RR_2026","Round-robin high-temperature property range","700 registered analysis boundary","degC",origin="round-robin measurement boundary",transformation="not interpreted as a decomposition limit")
put("flinak_rr","specific_heat","TES_INTERNAL","candidate registry","not used",origin="missing by design",claim="The round robin did not supply a Cp result; strict sensible-service coverage is therefore zero.")
put("flinak_rr","density","MUNRO_FLINAK_RR_2026","Aggregate round-robin correlation","rho=2.45-6.85E-4*T_C","g cm-3",origin="21-laboratory round robin",validity="500-800 degC registered range")
put("flinak_rr","thermal_conductivity","MUNRO_FLINAK_RR_2026","Two-group thermal-conductivity comparison near 700 C","0.66 and 0.689; implemented 0.675","W m-1 K-1",origin="round-robin participating laboratories",transformation="midpoint with 10% uncertainty",validity="600-800 degC diagnostic range")
put("flinak_rr","viscosity","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("flinak_rr","latent_heat","TES_INTERNAL","candidate registry","not used",origin="missing by design")
put("flinak_rr","reported_energy_density","TES_INTERNAL","candidate registry","not used",origin="missing by design")

if set(E) != {(r["system_id"], g) for r in candidates for g in GROUPS}:
    missing = {(r["system_id"], g) for r in candidates for g in GROUPS} - set(E)
    extra = set(E) - {(r["system_id"], g) for r in candidates for g in GROUPS}
    raise RuntimeError(f"evidence map mismatch missing={sorted(missing)} extra={sorted(extra)}")

rows = []
for r in candidates:
    for sequence, group in enumerate(GROUPS, 1):
        fields, value, unit, unc_field = impl(r, group)
        e = E[(r["system_id"], group)]
        sid = e["source_id"]
        src = sources.get(sid, {})
        domain_prefix = {"specific_heat":"cp", "density":"rho", "thermal_conductivity":"k", "viscosity":"mu"}.get(group)
        model_domain = "not applicable"
        domain_basis = "not applicable"
        if domain_prefix:
            lo, hi = r.get(f"{domain_prefix}_Tmin_C", ""), r.get(f"{domain_prefix}_Tmax_C", "")
            model_domain = f"{lo}-{hi} degC" if lo and hi else "not available"
            domain_basis = r.get(f"{domain_prefix}_domain_basis", "")
        strict_role = {
            "composition":"candidate identity and cost conversion",
            "melting_temperature":"physical service gate",
            "practical_upper_temperature":"physical service gate",
            "specific_heat":"sensible energy integral; PCM +50 K diagnostic only",
            "density":"volumetric energy integral or latent volumetric conversion",
            "thermal_conductivity":"diagnostic transport frontier only",
            "viscosity":"diagnostic engineering context only",
            "latent_heat":"primary PCM gravimetric energy",
            "reported_energy_density":"provenance comparator/derived-density support only",
        }[group]
        rows.append({
            "ledger_id": f'PVL-{r["system_id"]}-{sequence:02d}',
            "system_id": r["system_id"],
            "display_system": r["display_system"],
            "property_group": group,
            "implementation_fields": fields,
            "implementation_value_or_equation": value,
            "implementation_unit": unit,
            "implementation_uncertainty_field": unc_field,
            "implementation_uncertainty": r.get(unc_field, "") if unc_field else "",
            "candidate_declared_source_ids": r["source_ids"],
            "primary_source_id": sid,
            "source_title": src.get("title", "core internal model declaration"),
            "source_url": src.get("url", "internal://core/candidate_property_registry"),
            "source_locator": e["source_locator"],
            "source_value_or_equation": e["source_value_or_equation"],
            "source_unit": e["source_unit"],
            "source_condition": e["source_condition"],
            "evidence_origin": e["evidence_origin"],
            "transformation_or_margin": e["transformation_or_margin"],
            "source_validity_range": e["source_validity_range"],
            "model_validity_range": model_domain,
            "model_domain_basis": domain_basis,
            "strict_model_role": strict_role,
            "article_claim_boundary": e["article_claim_boundary"],
            "review_status": e["review_status"],
        })

headers = list(rows[0])
out = PROV / f"{VERSION}_property_source_ledger.csv"
with out.open("w", encoding="utf-8-sig", newline="") as f:
    w = csv.DictWriter(f, fieldnames=headers)
    w.writeheader(); w.writerows(rows)

summary = {
    "status": "PASS",
    "version": VERSION,
    "candidate_count": len(candidates),
    "property_groups_per_candidate": len(GROUPS),
    "ledger_rows": len(rows),
    "closed_rows": sum(r["review_status"] == "CLOSED" for r in rows),
    "authoritative_file": str(out.relative_to(ROOT)),
    "policy": "CSV is authoritative; the XLSX file is a human-readable mirror generated from this CSV.",
}
(QC / f"{VERSION}_PROPERTY_SOURCE_LEDGER_BUILD.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
print(json.dumps(summary, indent=2))
