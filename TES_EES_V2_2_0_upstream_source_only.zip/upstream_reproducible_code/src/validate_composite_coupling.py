from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
INPUT = ROOT / "data" / "input"
N_MC = int(os.environ.get("TES_N_MC", "20000"))


def check(rows: list[dict[str, object]], name: str, passed: object, detail: object) -> None:
    rows.append({"check": name, "passed": bool(passed), "detail": str(detail)})


def main() -> None:
    evidence = pd.read_csv(INPUT / "core_composite_evidence_registry.csv")
    sources = pd.read_csv(INPUT / "core_composite_source_registry.csv")
    response = pd.read_csv(TABLES / "core_composite_property_response.csv")
    service = pd.read_csv(TABLES / "core_composite_service_coupling.csv")
    dynamic = pd.read_csv(TABLES / "core_composite_dynamic_summary.csv")
    summary = pd.read_csv(TABLES / "core_composite_system_summary.csv").set_index("metric")
    claims = pd.read_csv(TABLES / "core_composite_claim_registry.csv")

    rows: list[dict[str, object]] = []
    check(rows, "twenty_two registered experimental conditions", len(evidence) == len(response) == 22, (len(evidence), len(response)))
    check(rows, "seven primary sources with DOI", len(sources) == 7 and sources.doi.str.startswith("10.").all(), len(sources))
    check(rows, "condition identifiers unique", evidence.record_id.is_unique and response.record_id.is_unique, response.record_id.nunique())
    check(rows, "all evidence rows link to a registered source", set(evidence.source_id).issubset(set(sources.source_id)), sorted(set(evidence.source_id) - set(sources.source_id)))

    calculated = response[response.base_capacity_value.notna() & response.composite_capacity_value.notna()]
    check(rows, "capacity ratios independently reproduce reported means", np.allclose(calculated.capacity_ratio, calculated.composite_capacity_value / calculated.base_capacity_value, atol=1e-12), len(calculated))
    latent = response[response.base_latent_kJ_kg.notna() & response.composite_latent_kJ_kg.notna()]
    check(rows, "latent ratios independently reproduce reported means", np.allclose(latent.latent_ratio, latent.composite_latent_kJ_kg / latent.base_latent_kJ_kg, atol=1e-12), len(latent))
    check(rows, "all capacity intervals ordered", ((response.capacity_ratio_low <= response.capacity_ratio) & (response.capacity_ratio <= response.capacity_ratio_high)).loc[response.capacity_ratio.notna()].all(), response.capacity_ratio.notna().sum())

    ch = response[response.source_id.eq("CHIERUZZI_2013")]
    an = response[response.source_id.eq("ANDREU_2014")]
    check(rows, "multi-additive study has four midpoint liquid-cp gains", len(ch) == 12 and ch.capacity_ratio.gt(1).sum() == 4, int(ch.capacity_ratio.gt(1).sum()))
    check(rows, "multi-additive study has one resolved liquid-cp gain", ch.capacity_gain_resolved.astype(bool).sum() == 1, int(ch.capacity_gain_resolved.astype(bool).sum()))
    check(rows, "replicated concentration series has one resolved liquid-cp gain", len(an) == 4 and an.capacity_gain_resolved.astype(bool).sum() == 1, int(an.capacity_gain_resolved.astype(bool).sum()))

    high = dynamic[dynamic.record_id.eq("ELFAR_SIO2_HIGH_SHEAR")].iloc[0]
    low = dynamic[dynamic.record_id.eq("ELFAR_SIO2_LOW_SHEAR")].iloc[0]
    check(rows, "high-shear capacity-pumping opportunity remains conditional", 0.15 < high.probability_capacity_pumping_index_gt_1 < 0.30, high.probability_capacity_pumping_index_gt_1)
    check(rows, "low-shear capacity-pumping index never exceeds one", np.isclose(low.probability_capacity_pumping_index_gt_1, 0.0), low.probability_capacity_pumping_index_gt_1)
    check(rows, "registered dynamic summaries use requested draw count", set(dynamic.mc_iterations.astype(int)) == {N_MC}, sorted(set(dynamic.mc_iterations.astype(int))))

    foam = response[response.record_id.eq("XIAO_FOAM_AL2O3")].iloc[0]
    graphite = response[response.record_id.eq("WANG_EG10")].iloc[0]
    check(rows, "foam charge-power ratio reproduces 110.76 divided by 31.94", np.isclose(foam.charge_power_ratio, 110.76 / 31.94, rtol=2e-9), foam.charge_power_ratio)
    check(rows, "foam bidirectional ratio reproduces Table 2 discharge powers", np.isclose(foam.bidirectional_power_ratio, 12.48 / 14.74), foam.bidirectional_power_ratio)
    check(rows, "expanded-graphite corrosion ratio reproduces 0.0026 divided by 0.0032", np.isclose(graphite.corrosion_rate_ratio, 0.0026 / 0.0032), graphite.corrosion_rate_ratio)
    check(rows, "expanded-graphite active-salt fraction is explicit", np.isclose(graphite.active_salt_fraction_derived, 0.90), graphite.active_salt_fraction_derived)

    check(rows, "no material record is promoted to a full-duty composite selection", int(service.formal_composite_eligible.astype(bool).sum()) == 0, int(service.formal_composite_eligible.astype(bool).sum()))
    check(rows, "no composite record spans a complete registered service domain", int(service.full_composite_domain.astype(bool).sum()) == 0, int(service.full_composite_domain.astype(bool).sum()))
    check(rows, "formal gap sets are explicit", service.formal_gap_set.notna().all() and service.formal_gap_set.ne("none").all(), service.formal_gap_set.value_counts().to_dict())
    check(rows, "summary matches service-level formal outcome", int(summary.loc["formal_composite_eligible_links", "value"]) == int(service.formal_composite_eligible.astype(bool).sum()), summary.loc["formal_composite_eligible_links", "value"])
    check(rows, "composite claims unique and source-backed", claims.claim_id.is_unique and claims.source_table.str.endswith(".csv").all(), len(claims))

    audit = pd.DataFrame(rows)
    audit.to_csv(TABLES / "core_composite_model_validation.csv", index=False)
    passed = bool(audit.passed.all())
    status = {
        "status": "PASS" if passed else "FAIL",
        "checks": int(len(audit)),
        "checks_passed": int(audit.passed.sum()),
        "checks_failed": audit.loc[~audit.passed, "check"].tolist(),
        "mc_iterations": N_MC,
        "formal_composite_eligible_links": int(service.formal_composite_eligible.astype(bool).sum()),
    }
    (QC / "core_COMPOSITE_COUPLING_VALIDATION.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))
    if not passed:
        print(audit.loc[~audit.passed].to_string(index=False))
        sys.exit(2)


if __name__ == "__main__":
    main()
