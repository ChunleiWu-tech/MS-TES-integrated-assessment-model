from __future__ import annotations

import json
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
RELEASE_ID = "TES-EES-V2.2.0-20260909"


def read(name: str) -> pd.DataFrame:
    path = TABLES / name
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def one(frame: pd.DataFrame, **filters) -> pd.Series:
    selected = frame.copy()
    for column, value in filters.items():
        selected = selected[selected[column].astype(str) == str(value)]
    if len(selected) != 1:
        raise ValueError(f"Expected one row for {filters}, found {len(selected)}")
    return selected.iloc[0]


def main() -> None:
    cross = read("expanded_v3_cross_layer_storyline.csv")
    attrition = read("expanded_v3_evidence_attrition.csv")
    prior = read("core_prior_outcome_summary.csv")
    pairwise = read("core_pairwise_superiority_matrix.csv")
    domain_mc = read("expanded_v3_domain_validated_thermophysical_mc.csv")
    signed = read("core_counterfactual_candidate_signed_changes.csv")
    external = read("joule_external_validation_summary.csv")
    composite_claims = read("core_composite_claim_registry.csv")
    composite_dynamic = read("core_composite_dynamic_summary.csv")
    composite_summary = read("core_composite_system_summary.csv")

    coal = one(cross, service_id="coal_flexibility_storage")
    csp = one(cross, service_id="csp_sensible_storage")
    industrial = one(prior, scenario="industrial_medium_heat", weight_prior="balanced")
    industrial_pair = one(
        pairwise,
        scenario="industrial_medium_heat",
        system_i="hitec",
        system_j="solar_salt_ss60",
    )
    new_chloride = domain_mc[
        domain_mc.service_id.eq("pcm_target_500C")
        & domain_mc.display_system.astype(str).str.contains("23.5-25.0-51.5", regex=False)
    ]
    if len(new_chloride) != 1:
        raise ValueError(f"Expected one new chloride row, found {len(new_chloride)}")
    new_chloride = new_chloride.iloc[0]
    programme = one(
        signed,
        closure_action="combined_atomic_evidence_closure",
        scenario="coal_flexibility_storage",
        system_id="nkckcl_2026",
    )

    stage = attrition.set_index("stage")["count"].to_dict()
    external_values = external.set_index("metric")["value"].astype(int).to_dict()

    claims: list[dict] = []

    def add(
        claim_id: str,
        statement: str,
        value,
        unit: str,
        denominator: str,
        conditioning: str,
        source_table: str,
        source_filter: str,
        intended_location: str,
    ) -> None:
        claims.append(
            {
                "claim_id": claim_id,
                "statement": statement,
                "value": value,
                "unit": unit,
                "denominator": denominator,
                "conditioning": conditioning,
                "source_table": source_table,
                "source_filter": source_filter,
                "intended_location": intended_location,
            }
        )

    add("C01", "The reference-database snapshot contains 976 property records.", 976, "records", "reference-database snapshot", "record inventory", "core_database_to_shortlist_transition.csv", "stage=database records", "Abstract; Fig. 1")
    add("C02", "Canonical parsing yields 142 exact-composition candidates.", 142, "candidates", "bounded application library", "identity and duplicate audit", "expanded_v3_evidence_attrition.csv", "stage=Exact-composition candidates after canonical deduplication", "Abstract; Results; Fig. 1")
    add("C03", "The screen evaluates 994 candidate-service pairs.", 994, "pairs", "142 candidates x 7 services", "frozen service definitions", "expanded_v3_evidence_attrition.csv", "stage=Candidate-service pairs across seven frozen duties", "Abstract; Results; Fig. 1")
    add("C04", "Seventy-six pairs pass the physical window.", int(stage["Physical-window-compatible pairs"]), "pairs", "994 candidate-service pairs", "phase and upper-temperature gates", "expanded_v3_evidence_attrition.csv", "stage=Physical-window-compatible pairs", "Abstract; Results; Fig. 1")
    add("C05", "Eighteen physically admissible pairs support a quantitative metric.", int(stage["Quantitative thermophysical pairs"]), "pairs", "76 physical-window pairs", "registered performance variables", "expanded_v3_evidence_attrition.csv", "stage=Quantitative thermophysical pairs", "Abstract; Results; Fig. 1")
    add("C06", "Eleven quantitative pairs support the full registered duty domain.", int(stage["Service-domain-supported thermophysical pairs"]), "pairs", "18 quantitative pairs", "Tier A or Tier B support", "expanded_v3_evidence_attrition.csv", "stage=Service-domain-supported thermophysical pairs", "Abstract; Results; Fig. 1")
    add("C07", "Solar Salt is formally selected in 93.78% of coal-duty draws.", float(coal.evidence_qualified_leader_probability), "fraction", "20,000 matched draws", "balanced prior; frozen engineering registry", "expanded_v3_cross_layer_storyline.csv", "service_id=coal_flexibility_storage", "Abstract; Results; Fig. 2")
    add("C08", "Solar Salt is formally selected in 51.18% of CSP draws.", float(csp.evidence_qualified_leader_probability), "fraction", "20,000 matched draws", "balanced prior; frozen engineering registry", "expanded_v3_cross_layer_storyline.csv", "service_id=csp_sensible_storage", "Abstract; Results; Fig. 2")
    add("C09", "Industrial heat selects Solar Salt in 45.66% of draws.", float(industrial.leader_selection_frequency), "fraction", "20,000 matched draws", "balanced prior; frozen engineering registry", "core_prior_outcome_summary.csv", "scenario=industrial_medium_heat; weight_prior=balanced", "Results; Fig. 2")
    add("C10", "Industrial heat selects HITEC in 33.38% of draws.", float(industrial.benchmark_selection_frequency), "fraction", "20,000 matched draws", "balanced prior; frozen engineering registry", "core_prior_outcome_summary.csv", "scenario=industrial_medium_heat; weight_prior=balanced", "Results; Fig. 2")
    add("C11", "Industrial heat returns no formal selection in 20.97% of draws.", float(industrial.no_selection_frequency), "fraction", "20,000 matched draws", "balanced prior; frozen engineering registry", "core_prior_outcome_summary.csv", "scenario=industrial_medium_heat; weight_prior=balanced", "Results; Fig. 2")
    add("C12", "Solar Salt exceeds HITEC in energy performance in 57.19% of their 5,900 jointly comparable industrial draws.", float(industrial_pair.energy_superiority_j_gt_i), "fraction", int(industrial_pair.energy_comparable_draws), "industrial heat; pairwise finite energy values", "core_pairwise_superiority_matrix.csv", "scenario=industrial_medium_heat; system_i=hitec; system_j=solar_salt_ss60", "Results; Supplementary Fig. 4")
    add("C13", "The new NaCl-KCl-CaCl2 composition reaches a 23.48% PCM500 thermophysical rank-one frequency.", float(new_chloride.thermophysical_rank1_frequency), "fraction", "20,000 matched draws", "service-domain-supported opportunity layer", "expanded_v3_domain_validated_thermophysical_mc.csv", "service_id=pcm_target_500C; composition=23.5:25.0:51.5 wt%", "Abstract; Results; Fig. 2")
    add("C14", "The new NaCl-KCl-CaCl2 composition passes the PCM500 physical window in 99.79% of draws.", float(new_chloride.robust_physical_pass_probability), "fraction", "20,000 matched draws", "phase band and upper-temperature margin", "expanded_v3_domain_validated_thermophysical_mc.csv", "service_id=pcm_target_500C; composition=23.5:25.0:51.5 wt%", "Abstract; Results; Fig. 2")
    add("C15", "The external challenge set contains nine exact nitrate formulations.", external_values["external_candidates"], "candidates", "independent 2026 study", "rules applied without recalibration", "joule_external_validation_summary.csv", "metric=external_candidates", "Results; Fig. 2")
    add("C16", "The external challenge creates 27 physically admissible pairs but no full-duty-supported pair.", external_values["physical_window_pairs"], "physical pairs", "63 external candidate-service pairs", "single-temperature cp and density do not span a registered duty", "joule_external_validation_summary.csv", "metrics=physical_window_pairs,service_domain_supported_pairs", "Results; Fig. 2; Supplementary Note")
    add("C17", "A coordinated evidence programme raises the coal-duty selection frequency of NaNO3-KNO3-K2CO3-KCl from zero to 29.78%.", float(programme.selection_frequency_after), "fraction", "20,000 counterfactual draws", "corrosion, cycling and containment closed jointly within the frozen registry", "core_counterfactual_candidate_signed_changes.csv", "closure_action=combined_atomic_evidence_closure; scenario=coal_flexibility_storage; system_id=nkckcl_2026", "Results; Fig. 6")

    composite_values = composite_summary.set_index("metric")["value"].astype(float).to_dict()
    high_shear = one(composite_dynamic, record_id="ELFAR_SIO2_HIGH_SHEAR")
    low_shear = one(composite_dynamic, record_id="ELFAR_SIO2_LOW_SHEAR")
    add("C18", "One of twelve nanoparticle formulations in the multi-additive Solar Salt study retains a resolved liquid heat-capacity gain under the study-motivated symmetric 6% protocol-sensitivity scenario.", int(composite_values["chieruzzi_liquid_cp_resolved_gains"]), "formulation", "12 nanoparticle formulations", "symmetric 6% protocol-sensitivity scenario motivated by the approximately 6% difference between DSC scans at 10 and 20 C min-1", "core_composite_property_response.csv", "source_id=CHIERUZZI_2013", "Abstract; Results; Fig. 6; Supplementary Fig. 13")
    add("C19", "At 240 s-1 the Solar Salt-SiO2 capacity-pumping index exceeds unity in 21.19% of the registered hydraulic-exponent envelope.", float(high_shear.probability_capacity_pumping_index_gt_1), "fraction", "20,000 hydraulic-exponent draws", "beta uniformly sampled from 0.25 to 1.0", "core_composite_dynamic_summary.csv", "record_id=ELFAR_SIO2_HIGH_SHEAR", "Abstract; Results; Fig. 6; Supplementary Fig. 13")
    add("C20", "At 10 s-1 the same Solar Salt-SiO2 formulation never exceeds unity on the capacity-pumping index.", float(low_shear.probability_capacity_pumping_index_gt_1), "fraction", "20,000 hydraulic-exponent draws", "beta uniformly sampled from 0.25 to 1.0", "core_composite_dynamic_summary.csv", "record_id=ELFAR_SIO2_LOW_SHEAR", "Results; Supplementary Fig. 13")
    add("C21", "Copper foam plus alumina has a 3.47 charging-power ratio and a 0.847 discharge-power ratio at the reported 240 to 50 C laboratory boundary.", 12.48/14.74, "bidirectional power ratio", "one laboratory comparison", "minimum of Table 2 charge and discharge ratios", "core_composite_property_response.csv", "record_id=XIAO_FOAM_AL2O3", "Results; Fig. 6; Supplementary Fig. 13")
    add("C22", "No composite evidence record closes exact identity, full-duty temperature support, hydraulic or bidirectional response, durability and compatibility simultaneously.", int(composite_values["formal_composite_eligible_links"]), "formal record-service links", f'{int(composite_values["base_qualified_service_links"])} base-qualified record-service links', "second-stage non-compensatory composite gates", "core_composite_service_coupling.csv", "formal_composite_eligible=true", "Abstract; Results; Fig. 6; Supplementary Fig. 13")

    registry = pd.DataFrame(claims)
    # Statements follow calculated values; numerical outcomes are not acceptance targets.
    for claim_id, old in {'C07':'93.78','C08':'51.18','C09':'45.66','C10':'33.38','C11':'20.97','C12':'57.19','C13':'23.48','C14':'99.79','C17':'29.78','C19':'21.19'}.items():
        selected = registry.claim_id.eq(claim_id)
        if selected.any():
            actual = float(registry.loc[selected,'value'].iloc[0])
            formatted = str((Decimal(str(actual))*100).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP))
            registry.loc[selected,'statement'] = registry.loc[selected,'statement'].str.replace(old, formatted, regex=False)
    registry.to_csv(TABLES / "joule_claim_registry.csv", index=False)

    checks = {
        "claim_ids_unique": registry.claim_id.is_unique,
        "coal_formal_selection_is_a_valid_frequency": 0 <= float(coal.evidence_qualified_leader_probability) <= 1,
        "industrial_pairwise_denominator_is_5900": int(industrial_pair.energy_comparable_draws) == 5900,
        "industrial_pairwise_energy_share_is_a_valid_frequency": 0 <= float(industrial_pair.energy_superiority_j_gt_i) <= 1,
        "new_chloride_rank_one_rounds_to_23_48_percent": np.isclose(float(new_chloride.thermophysical_rank1_frequency), 0.23475),
        "new_chloride_physical_pass_rounds_to_99_79_percent": np.isclose(float(new_chloride.robust_physical_pass_probability), 0.99785),
        "external_supported_pairs_zero": external_values["service_domain_supported_pairs"] == 0,
        "programme_selection_is_a_valid_frequency": 0 <= float(programme.selection_frequency_after) <= 1,
        "composite_claim_registry_has_eight_source_backed_claims": len(composite_claims) == 8,
        "composite_high_shear_probability_is_21_19_percent": np.isclose(float(high_shear.probability_capacity_pumping_index_gt_1), 0.2119),
        "composite_low_shear_probability_is_zero": np.isclose(float(low_shear.probability_capacity_pumping_index_gt_1), 0.0),
        "composite_formal_qualifiers_zero": int(composite_values["formal_composite_eligible_links"]) == 0,
    }
    checks = {key: bool(value) for key, value in checks.items()}
    storyline = {
        "release_id": RELEASE_ID,
        "central_finding": "Full-duty evidence changes material rankings and determines whether a thermophysical opportunity can enter an engineering decision.",
        "sequence": [
            "Canonicalize exact compositions and preserve source validity domains.",
            "Screen each composition against seven energy-service windows.",
            "Separate single-temperature metrics from full-duty support.",
            "Apply non-compensatory engineering evidence gates only within the registered decision set.",
            "Trace the smallest ordered experiment set capable of changing a decision.",
        ],
        "external_test": "Nine independent nitrate formulations pass 27 physical service windows, yet single-temperature measurements support no complete duty. The rule transfers without recalibration.",
        "system_extension": "A calculated second-stage module now couples nanoparticles and stationary scaffolds to their exact base salts, then tests heat capacity, viscosity and pumping, conductivity, active-salt displacement, bidirectional power, durability and corrosion without altering the registered base-salt decision model.",
        "checks": checks,
    }
    (QC / "JOULE_CLAIM_SYNTHESIS_STATUS.json").write_text(
        json.dumps({"status": "PASS" if all(checks.values()) else "FAIL", **storyline}, indent=2),
        encoding="utf-8",
    )
    if not all(checks.values()):
        raise SystemExit(json.dumps(checks, indent=2))
    print(json.dumps({"status": "PASS", "claims": len(registry), "checks": checks}, indent=2))


if __name__ == "__main__":
    main()
