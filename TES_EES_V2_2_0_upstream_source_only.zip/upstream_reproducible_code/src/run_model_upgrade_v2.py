from pathlib import Path
import json

from model_upgrade_v2 import run_model_upgrade_v2


ROOT = Path(__file__).resolve().parents[1]
print(json.dumps(run_model_upgrade_v2(ROOT, "core"), indent=2))
