from __future__ import annotations

from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / 'outputs' / 'tables'
QC = ROOT / 'outputs' / 'qc'
VERSION = 'submission'
BASE = 'core'
STAT = 'statistical'
QC.mkdir(parents=True, exist_ok=True)

SERVICES = [
    'coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat',
    'sco2_high_temperature_storage','pcm_target_350C','pcm_target_425C','pcm_target_500C'
]
SERVICE_LABEL = {
    'coal_flexibility_storage':'Coal','csp_sensible_storage':'CSP',
    'industrial_medium_heat':'Industrial','sco2_high_temperature_storage':'sCO2',
    'pcm_target_350C':'PCM350','pcm_target_425C':'PCM425','pcm_target_500C':'PCM500'
}

def read(stem: str, version: str = BASE) -> pd.DataFrame:
    p = TABLES / f'{version}_{stem}.csv'
    if not p.exists():
        raise FileNotFoundError(p)
    return pd.read_csv(p)

def write(df: pd.DataFrame, stem: str) -> Path:
    p = TABLES / f'{VERSION}_{stem}.csv'
    df.to_csv(p, index=False)
    return p

def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def service_regime_archetypes() -> pd.DataFrame:
    joint = read('joint_threshold_regime_map')
    cov = read('service_coverage_threshold_sensitivity')
    sweep = read('threshold_retention_sweep')
    st = read('structural_stochastic_uncertainty_classification', STAT)
    st_map = st.set_index('scenario').uncertainty_structure_class.to_dict()
    rows = []
    for s in SERVICES:
        j = joint[joint.scenario.eq(s)]
        c = cov[cov.scenario.eq(s)]
        e = sweep[sweep.scenario.eq(s)]
        regimes = int(j.decision_regime.nunique())
        no_states = int(j.no_selection_frequency.nunique())
        cov_states = int(c.no_selection_frequency.nunique())
        ev_states = int(e.expected_strict_complete_candidate_count.nunique())
        informative = regimes > 1 or no_states > 1
        structure = st_map.get(s, 'unclassified')
        if not informative:
            if 'service-incomplete' in structure:
                archetype = 'structural service limitation'
            elif 'evidence-locked' in structure:
                archetype = 'structural evidence lock'
            else:
                archetype = 'stable single regime'
        elif regimes >= 3:
            archetype = 'multi-boundary regime'
        elif cov_states > 1 and ev_states > 1:
            archetype = 'joint threshold-sensitive'
        elif cov_states > 1:
            archetype = 'coverage-sensitive'
        elif ev_states > 1:
            archetype = 'evidence-sensitive'
        else:
            archetype = 'conditional access'
        rows.append({
            'scenario':s,'service_label':SERVICE_LABEL[s],
            'uncertainty_structure_class':structure,'regime_archetype':archetype,
            'main_map_informative':bool(informative),'secondary_threshold_response_informative':bool(cov_states > 1 or ev_states > 1),
            'decision_regime_count':regimes,'joint_no_selection_state_count':no_states,
            'coverage_response_state_count':cov_states,'expected_strict_complete_response_state_count':ev_states,
            'minimum_no_selection_frequency':float(j.no_selection_frequency.min()),
            'maximum_no_selection_frequency':float(j.no_selection_frequency.max()),
            'registered_joint_states':int(len(j)),
            'main_figure_rule':'draw full regime map only when at least two decision states occur; otherwise compress to structural status strip'
        })
    return pd.DataFrame(rows)


def pareto_dominance_mechanisms() -> pd.DataFrame:
    pa = read('pareto_joint_uncertainty_and_robustness', STAT)
    q = pa[pa.frontier_scope.eq('opportunity')].copy()
    rows = []
    tol = 1e-9
    for s, g in q.groupby('scenario', sort=False):
        valid = g[g.joint_valid_draws.gt(0) & g.representative_performance_score.notna() & g.representative_credibility_score.notna()].copy()
        for r in g.itertuples(index=False):
            base = {
                'scenario':s,'service_label':SERVICE_LABEL.get(s,s),'system_id':r.system_id,
                'display_system':r.display_system,'joint_valid_draws':int(r.joint_valid_draws),
                'performance_score':r.representative_performance_score,
                'credibility_score':r.representative_credibility_score,
                'frontier_membership_frequency':r.frontier_membership_frequency,
                'robust_frontier_member_50pct':bool(r.threshold_50_member),
                'representative_frontier_member':bool(r.representative_frontier_member)
            }
            if int(r.joint_valid_draws) == 0 or not np.isfinite(r.representative_performance_score) or not np.isfinite(r.representative_credibility_score):
                base.update({'dominance_class':'not evaluable','nearest_dominator':'none','performance_shortfall':np.nan,'credibility_shortfall':np.nan})
                rows.append(base); continue
            if bool(r.representative_frontier_member):
                base.update({'dominance_class':'reference frontier','nearest_dominator':'none','performance_shortfall':0.0,'credibility_shortfall':0.0})
                rows.append(base); continue
            dominators = valid[
                valid.representative_performance_score.ge(r.representative_performance_score-tol) &
                valid.representative_credibility_score.ge(r.representative_credibility_score-tol) &
                ((valid.representative_performance_score.gt(r.representative_performance_score+tol)) |
                 (valid.representative_credibility_score.gt(r.representative_credibility_score+tol)))
            ].copy()
            if dominators.empty:
                base.update({'dominance_class':'draw-unstable frontier','nearest_dominator':'none','performance_shortfall':0.0,'credibility_shortfall':0.0})
            else:
                dominators['dp'] = dominators.representative_performance_score-r.representative_performance_score
                dominators['dc'] = dominators.representative_credibility_score-r.representative_credibility_score
                dominators['distance'] = np.hypot(dominators.dp, dominators.dc)
                d = dominators.sort_values('distance').iloc[0]
                total = float(d.dp+d.dc)
                share = float(d.dp/total) if total > tol else 0.5
                cls = 'performance-dominated' if share >= .75 else ('evidence-dominated' if share <= .25 else 'dual-dominated')
                base.update({'dominance_class':cls,'nearest_dominator':d.system_id,'performance_shortfall':float(d.dp),'credibility_shortfall':float(d.dc)})
            rows.append(base)
    return pd.DataFrame(rows)


def property_domain_contraction() -> pd.DataFrame:
    d = read('property_domain_coverage_audit').copy()
    d['coverage_loss_due_to_registered_property_domains'] = (d.physical_window_coverage-d.fixed_window_coverage).clip(lower=0)
    d['domain_status'] = np.select(
        [d.strict_complete_thermophysical_feasible.astype(bool), d.fixed_window_coverage.ge(.95), d.fixed_window_coverage.gt(0)],
        ['strict-complete','near-complete','partial registered domain'], default='no registered overlap')
    d['service_label'] = d.scenario.map(SERVICE_LABEL)
    return d[['scenario','service_label','system_id','display_system','physical_window_coverage','fixed_window_coverage',
              'coverage_loss_due_to_registered_property_domains','property_domain_extrapolation_required',
              'thermal_k_domain_valid_at_service','domain_status']]


def atomic_evidence_unlock() -> pd.DataFrame:
    g = read('gate_shapley_attribution').copy()
    g = g[g.scope.eq('application') & ~g.gate.eq('incomplete_service')].copy()
    g['service_label'] = g.scenario.map(SERVICE_LABEL)
    g['gate_label'] = g.gate.map({
        'corrosion':'Corrosion','cycling_phase':'Cycling/phase','containment':'Containment',
        'literature_validation':'Literature replication','data_completeness':'Data completeness'}).fillna(g.gate)
    g['normalized_unlock_share'] = g.groupby('scenario').shapley_unlock_contribution.transform(
        lambda x: x/x.sum() if x.sum()>0 else 0.0)
    return g[['scenario','service_label','gate','gate_label','shapley_unlock_contribution',
              'normalized_unlock_share','baseline_retained_frequency','all_gates_closed_frequency']]


def gate_interactions() -> pd.DataFrame:
    g = read('gate_pair_synergy_summary').copy()
    g = g[g.maximum_absolute_synergy.gt(1e-12)].copy()
    g['pair_label'] = g.gate_a.str.replace('_',' ').str.title()+' × '+g.gate_b.str.replace('_',' ').str.title()
    g['interaction_direction'] = np.where(g.mean_synergy>1e-12,'complementary',np.where(g.mean_synergy<-1e-12,'overlapping','mixed/zero mean'))
    return g.sort_values('maximum_absolute_synergy',ascending=False)


def action_frontier() -> pd.DataFrame:
    a = read('research_action_nondominance_assessment').copy()
    a['action_label'] = a.evidence_action
    a['decision_benefit'] = a['largest_positive_decision_benefit']
    a['release_scope'] = np.select([a.action_type.eq('evidence_acquisition') & a.comparison_eligible.astype(bool), a.action_type.eq('evidence_programme') & a.comparison_eligible.astype(bool)], ['registered evidence action','registered evidence programme'], default='diagnostic boundary only')
    a['benefit_semantics'] = 'largest positive value among separately registered decision responses; diagnostic upper envelope, not a composite utility'
    return a.sort_values(['comparison_eligible','non_dominated_under_registered_ordering','burden_ordinal_index'],ascending=[False,False,True])


def candidate_research_priority() -> pd.DataFrame:
    ready = read('candidate_readiness_profile')
    mins = read('dag_constrained_minimal_action_sets', STAT)
    mins = mins[mins.target.eq('reach_1pct_selection')].copy()
    m = ready.merge(mins[['scenario','system_id','admissible_minimal_action_set','action_count','burden_ordinal','reachability_class']],
                    on=['scenario','system_id'],how='left')
    def classify(r):
        if r.evidence_qualified_selection_frequency >= .01:
            return 'current formal selection'
        if isinstance(r.admissible_minimal_action_set,str) and r.admissible_minimal_action_set != 'not reachable':
            if r.action_count <= 1: return 'one-step evidence opportunity'
            return 'multi-step evidence programme'
        if 'thermophysical' in str(r.reachability_class) or 'physical_service' in str(r.reachability_class):
            return 'stop: service/property limited'
        if r.closable_gap_count == 0:
            return 'stop: no registered evidence lever'
        return 'not reachable under registered actions'
    m['research_priority_class'] = m.apply(classify,axis=1)
    m['service_label'] = m.scenario.map(SERVICE_LABEL)
    return m[['scenario','service_label','system_id','display_system','strict_complete_service_probability',
              'evidence_qualified_selection_frequency','closable_gap_count','admissible_minimal_action_set',
              'action_count','burden_ordinal','reachability_class','research_priority_class']]


def build_audit(tables: dict[str,pd.DataFrame]) -> pd.DataFrame:
    rows=[]
    for name,df in tables.items():
        numeric=df.select_dtypes(include=[np.number])
        zero_share=float((numeric.fillna(0).abs()<=1e-12).to_numpy().mean()) if numeric.size else np.nan
        rows.append({'table':name,'rows':len(df),'columns':len(df.columns),'zero_share_numeric':zero_share,
                     'duplicate_rows':int(df.duplicated().sum()),'status':'PASS' if len(df)>0 and df.duplicated().sum()==0 else 'REVIEW'})
    return pd.DataFrame(rows)


def main() -> None:
    outputs = {
        'service_regime_archetype_summary':service_regime_archetypes(),
        'pareto_dominance_mechanism_summary':pareto_dominance_mechanisms(),
        'property_domain_contraction_summary':property_domain_contraction(),
        'atomic_evidence_unlock_summary':atomic_evidence_unlock(),
        'nonzero_gate_interaction_summary':gate_interactions(),
        'research_action_frontier_summary':action_frontier(),
        'candidate_research_priority_summary':candidate_research_priority(),
    }
    paths=[]
    for stem,df in outputs.items(): paths.append(write(df,stem))
    audit=build_audit(outputs); paths.append(write(audit,'editorial_synthesis_table_audit'))

    # Verify that the synthesis writes only submission-prefixed files and does not mutate the frozen baseline.
    frozen = [
        TABLES/'core_candidate_system_metrics_deterministic.csv',
        TABLES/'core_layered_selection_frequencies.csv',
        TABLES/'core_no_selection_frequencies.csv',
        TABLES/'statistical_pareto_joint_uncertainty_and_robustness.csv',
        TABLES/'statistical_continuous_decision_variance_attribution.csv',
        TABLES/'statistical_categorical_selection_information_attribution.csv',
        TABLES/'statistical_dag_constrained_minimal_action_sets.csv',
    ]
    hashes=[{'file':p.name,'sha256':sha256(p),'exists':p.exists()} for p in frozen]
    pd.DataFrame(hashes).to_csv(QC/f'{VERSION}_FROZEN_TABLE_HASHES.csv',index=False)
    status={
        'version':VERSION,'status':'PASS' if (audit.status=='PASS').all() else 'REVIEW',
        'science_changed':False,'new_tables':[p.name for p in paths],
        'main_map_services':int(outputs['service_regime_archetype_summary'].main_map_informative.sum()),
        'compressed_structural_services':int((~outputs['service_regime_archetype_summary'].main_map_informative).sum()),
        'interpretation':'Editorial synthesis only. Strict-complete, evidence-bounded, Pareto, uncertainty and DAG definitions are inherited unchanged. Evidence-threshold counts use expected strict-complete candidates; action benefit is the registered diagnostic upper envelope, not a composite utility.'
    }
    (QC/f'{VERSION}_EDITORIAL_SYNTHESIS_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    print(json.dumps(status,indent=2))

if __name__=='__main__':
    main()
