from __future__ import annotations

from pathlib import Path
import os
import json
import csv
from collections import Counter
import numpy as np
import pandas as pd
from decision_model import BURDEN_HALF_VALUE

EPS = 1e-12


def _read(root: Path, version: str, stem: str) -> pd.DataFrame:
    path = root / 'outputs' / 'tables' / f'{version}_{stem}.csv'
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path)


def _write(df: pd.DataFrame, root: Path, version: str, stem: str) -> None:
    path = root / 'outputs' / 'tables' / f'{version}_{stem}.csv'
    df.to_csv(path, index=False)


def _rank_ladder(root: Path, version: str) -> tuple[int, pd.DataFrame]:
    source=root/'outputs'/'tables'/f'{version}_monte_carlo_draws_balanced.csv'
    target=root/'outputs'/'tables'/f'{version}_rank_ladder_by_draw.csv'
    if not source.exists(): raise FileNotFoundError(source)
    fields=['scenario','draw_id','partial_leader_id','partial_leader','complete_leader_id','complete_leader',
            'bounded_leader_id','bounded_leader','partial_to_complete_reversal','complete_to_bounded_reversal',
            'partial_to_bounded_reversal','partial_leader_has_complete_service']

    def fnum(text):
        text=text.strip()
        return float('nan') if (not text or text.lower() in {'nan','na','none'}) else float(text)
    def bval(text): return text.strip().lower() in {'true','1','yes','y','t'}

    inventory={}
    with source.open('r',encoding='utf-8-sig',newline='') as inp:
        reader=csv.reader(inp); header=next(reader); pos={name:header.index(name) for name in (
            'scenario','draw_id','system_id','display_system')}
        for raw in reader:
            scenario=raw[pos['scenario']]
            rec=inventory.get(scenario)
            if rec is None:
                rec={'systems':[],'system_index':{},'names':{},'draw_set':set()}; inventory[scenario]=rec
            sid=raw[pos['system_id']]
            if sid not in rec['system_index']:
                rec['system_index'][sid]=len(rec['systems']); rec['systems'].append(sid)
            rec['names'][sid]=raw[pos['display_system']]
            rec['draw_set'].add(int(float(raw[pos['draw_id']])))
    for rec in inventory.values():
        rec['draws']=np.asarray(sorted(rec.pop('draw_set')),dtype=np.int64)
        rec['draw_index']={int(d):i for i,d in enumerate(rec['draws'])}
        n=len(rec['draws'])
        rec['partial_value']=np.full(n,-np.inf)
        rec['partial_idx']=np.full(n,-1,dtype=np.int32)
        rec['partial_complete']=np.full(n,np.nan)
        rec['complete_value']=np.full(n,-np.inf)
        rec['complete_idx']=np.full(n,-1,dtype=np.int32)
        rec['bounded_idx']=np.full(n,-1,dtype=np.int32)

    with source.open('r',encoding='utf-8-sig',newline='') as inp:
        reader=csv.reader(inp); header=next(reader); pos={name:header.index(name) for name in (
            'scenario','draw_id','system_id','partial_overlap_energy_density_kWh_m3',
            'complete_service_energy_density_kWh_m3','is_balanced_winner')}
        for raw in reader:
            rec=inventory[raw[pos['scenario']]]
            i=rec['draw_index'][int(float(raw[pos['draw_id']]))]
            j=rec['system_index'][raw[pos['system_id']]]
            partial=fnum(raw[pos['partial_overlap_energy_density_kWh_m3']])
            complete=fnum(raw[pos['complete_service_energy_density_kWh_m3']])
            # First-occurrence tie handling preserves registered candidate order.
            if rec['partial_idx'][i] < 0 or (np.isfinite(partial) and partial > rec['partial_value'][i]):
                rec['partial_value'][i]=partial if np.isfinite(partial) else -np.inf
                rec['partial_idx'][i]=j
                rec['partial_complete'][i]=complete
            if np.isfinite(complete) and (rec['complete_idx'][i] < 0 or complete > rec['complete_value'][i]):
                rec['complete_value'][i]=complete; rec['complete_idx'][i]=j
            if bval(raw[pos['is_balanced_winner']]) and rec['bounded_idx'][i] < 0:
                rec['bounded_idx'][i]=j

    transitions=Counter(); row_count=0
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('w',encoding='utf-8',newline='') as out:
        writer=csv.writer(out,lineterminator='\n'); writer.writerow(fields)
        for scenario in sorted(inventory):
            rec=inventory[scenario]; systems=rec['systems']; names=rec['names']
            for i,draw_id in enumerate(rec['draws']):
                pidx=int(rec['partial_idx'][i]); cidx=int(rec['complete_idx'][i]); bidx=int(rec['bounded_idx'][i])
                partial_id=systems[pidx]; partial_name=names[partial_id]
                if cidx>=0:
                    complete_id=systems[cidx]; complete_name=names[complete_id]
                else:
                    complete_id='__NO_COMPLETE_SERVICE__'; complete_name='No complete-service option'
                if bidx>=0:
                    bounded_id=systems[bidx]; bounded_name=names[bounded_id]
                else:
                    bounded_id='__NO_SELECTION__'; bounded_name='No formal selection'
                row=[scenario,int(draw_id),partial_id,partial_name,complete_id,complete_name,bounded_id,bounded_name,
                     partial_id!=complete_id,complete_id!=bounded_id,partial_id!=bounded_id,
                     bool(np.isfinite(rec['partial_complete'][i]))]
                writer.writerow(row); row_count+=1
                transitions[(scenario,partial_name,complete_name,bounded_name)]+=1
    rows=[{'scenario':k[0],'partial_leader':k[1],'complete_leader':k[2],'bounded_leader':k[3],
           'transition_draws':count} for k,count in transitions.items()]
    summary=pd.DataFrame(rows)
    totals=summary.groupby('scenario').transition_draws.transform('sum')
    summary['transition_frequency']=summary.transition_draws/totals
    summary=summary.sort_values(['scenario','transition_frequency'],ascending=[True,False]).reset_index(drop=True)
    return row_count,summary


def _coverage_map(root: Path, version: str) -> pd.DataFrame:
    d = _read(root, version, 'candidate_system_metrics_deterministic').copy()
    rows=[]
    for r in d.itertuples(index=False):
        if r.service_mode == 'sensible':
            service_low = float(r.fixed_usable_Tlow_C) if np.isfinite(r.fixed_usable_Tlow_C) else np.nan
            service_high = float(r.fixed_usable_Thigh_C) if np.isfinite(r.fixed_usable_Thigh_C) else np.nan
            candidate_low = max(float(r.Tm_C), service_low) if np.isfinite(service_low) else float(r.Tm_C)
            candidate_high = min(float(r.Tmax_practical_C), service_high) if np.isfinite(service_high) else float(r.Tmax_practical_C)
        else:
            # For PCM, the target band is encoded in the usable service interval.
            service_low = float(r.fixed_usable_Tlow_C) if np.isfinite(r.fixed_usable_Tlow_C) else float(r.Tm_C)
            service_high = float(r.fixed_usable_Thigh_C) if np.isfinite(r.fixed_usable_Thigh_C) else float(r.Tm_C)
            candidate_low = float(r.Tm_C)
            candidate_high = float(r.Tm_C)
        width = max(service_high-service_low, EPS) if np.isfinite(service_low) and np.isfinite(service_high) else np.nan
        overlap = max(0.0, min(candidate_high,service_high)-max(candidate_low,service_low)) if np.isfinite(width) else np.nan
        rows.append({
            'scenario':r.scenario,'scenario_label':r.scenario_label,'system_id':r.system_id,'display_system':r.display_system,
            'service_mode':r.service_mode,'service_low_C':service_low,'service_high_C':service_high,
            'candidate_Tm_C':float(r.Tm_C),'candidate_Tmax_practical_C':float(r.Tmax_practical_C),
            'deterministic_overlap_fraction': float(overlap/width) if np.isfinite(overlap) else np.nan,
            'strict_complete_service_feasible':bool(r.strict_complete_service_feasible),
            'screening_service_adequacy_95pct':bool(r.screening_service_adequacy_95pct),
            'property_data_class':r.property_data_class,
        })
    return pd.DataFrame(rows)


def _credibility_shortfall(root: Path, version: str) -> tuple[pd.DataFrame,pd.DataFrame]:
    p = _read(root, version, 'candidate_readiness_profile').copy()
    dims = [
        ('corrosion','corrosion_compatibility_score'),
        ('cycling_phase','cycling_phase_stability_score'),
        ('containment','containment_validation_score'),
        ('literature_replication','literature_replication_score'),
        ('data_completeness','data_completeness_score'),
    ]
    rows=[]
    for r in p.itertuples(index=False):
        components=[]
        for label,col in dims:
            value=float(getattr(r,col)); short=-np.log(max(value,1e-9)); components.append((label,value,short))
        inverse_burden=1/(1+max(float(r.engineering_burden_index),0.0)/BURDEN_HALF_VALUE)
        components.append(('inverse_burden',inverse_burden,-np.log(max(inverse_burden,1e-9))))
        total=sum(x[2] for x in components)
        credibility=float(np.exp(np.mean([np.log(max(x[1],1e-9)) for x in components])))
        for label,value,short in components:
            rows.append({
                'scenario':r.scenario,'scenario_label':r.scenario_label,'system_id':r.system_id,'display_system':r.display_system,
                'credibility_dimension':label,'dimension_score':value,'log_shortfall':short,
                'share_of_total_log_shortfall':short/total if total>EPS else 0.0,
                'engineering_credibility_geometric':credibility,
                'strict_complete_service_probability':float(r.strict_complete_service_probability),
                'evidence_qualified_selection_frequency':float(r.evidence_qualified_selection_frequency),
            })
    detail=pd.DataFrame(rows)
    summary=(detail.groupby(['scenario','credibility_dimension'],as_index=False)
             .agg(mean_log_shortfall=('log_shortfall','mean'),
                  median_log_shortfall=('log_shortfall','median'),
                  mean_shortfall_share=('share_of_total_log_shortfall','mean'),
                  candidates=('system_id','nunique')))
    return detail,summary


def _cross_scenario_consensus(root: Path, version: str) -> pd.DataFrame:
    p=_read(root,version,'candidate_readiness_profile').copy()
    # Recompute engineering credibility exactly as the six-component geometric mean.
    inv=1/(1+p.engineering_burden_index.clip(lower=0)/BURDEN_HALF_VALUE)
    components=np.column_stack([
        p.corrosion_compatibility_score,p.cycling_phase_stability_score,p.containment_validation_score,
        p.literature_replication_score,p.data_completeness_score,inv,
    ])
    p['engineering_credibility_geometric']=np.exp(np.mean(np.log(np.clip(components,1e-9,1.0)),axis=1))
    rows=[]
    for (sid,name),g in p.groupby(['system_id','display_system']):
        rows.append({
            'system_id':sid,'display_system':name,'registered_services':int(g.scenario.nunique()),
            'services_with_complete_support':int((g.strict_complete_service_probability>0).sum()),
            'services_robust_complete':int((g.strict_complete_service_probability>=0.999).sum()),
            'services_ever_selected':int((g.evidence_qualified_selection_frequency>EPS).sum()),
            'services_materially_selected_1pct':int((g.evidence_qualified_selection_frequency>=0.01).sum()),
            'mean_complete_service_probability':float(g.strict_complete_service_probability.mean()),
            'mean_selection_frequency':float(g.evidence_qualified_selection_frequency.mean()),
            'median_engineering_credibility':float(g.engineering_credibility_geometric.median()),
            'maximum_selection_frequency':float(g.evidence_qualified_selection_frequency.max()),
        })
    return pd.DataFrame(rows).sort_values(['services_materially_selected_1pct','services_ever_selected','mean_selection_frequency'],ascending=False)


def _stress_case_outcomes(root: Path, version: str) -> tuple[pd.DataFrame,pd.DataFrame]:
    cred=_read(root,version,'credibility_model_sensitivity')
    pert=_read(root,version,'evidence_score_perturbation_sensitivity')
    loc=_read(root,version,'leave_one_candidate_out_sensitivity')
    los=_read(root,version,'leave_one_source_out_sensitivity')
    base=cred[cred.credibility_model=='hierarchical_geometric'].set_index('scenario')
    records=[]
    for r in cred.itertuples(index=False):
        records.append({'scenario':r.scenario,'stress_family':'credibility_structure','stress_case':r.credibility_model,
                        'modal_leader':r.modal_leader,'modal_leader_label':r.modal_leader_label,
                        'modal_leader_frequency':r.modal_leader_frequency,'no_selection_frequency':r.no_selection_frequency})
    for r in pert.itertuples(index=False):
        records.append({'scenario':r.scenario,'stress_family':'evidence_level','stress_case':r.atomic_evidence_level,
                        'modal_leader':r.modal_leader,'modal_leader_label':r.modal_leader_label,
                        'modal_leader_frequency':r.modal_leader_frequency,'no_selection_frequency':r.no_selection_frequency})
    for r in loc.itertuples(index=False):
        records.append({'scenario':r.scenario,'stress_family':'leave_candidate','stress_case':str(r.excluded_system_id),
                        'modal_leader':r.modal_leader,'modal_leader_label':r.modal_leader_label,
                        'modal_leader_frequency':r.modal_leader_frequency,'no_selection_frequency':r.no_selection_frequency})
    for r in los.itertuples(index=False):
        records.append({'scenario':r.scenario,'stress_family':'leave_source','stress_case':str(r.omitted_source_id),
                        'modal_leader':r.modal_leader,'modal_leader_label':r.modal_leader_label,
                        'modal_leader_frequency':r.modal_leader_frequency,'no_selection_frequency':r.no_selection_frequency})
    detail=pd.DataFrame(records)
    detail['baseline_leader']=detail.scenario.map(base.modal_leader)
    detail['leader_retained']=detail.modal_leader==detail.baseline_leader
    rows=[]
    for scenario,g in detail.groupby('scenario'):
        rows.append({
            'scenario':scenario,'stress_cases':len(g),'baseline_leader':str(base.loc[scenario,'modal_leader']),
            'leader_retention_share':float(g.leader_retained.mean()),
            'leader_switch_count':int((~g.leader_retained).sum()),
            'structural_switch_count':int(((g.stress_family=='credibility_structure') & ~g.leader_retained).sum()),
            'evidence_switch_count':int(((g.stress_family=='evidence_level') & ~g.leader_retained).sum()),
            'candidate_omission_switch_count':int(((g.stress_family=='leave_candidate') & ~g.leader_retained).sum()),
            'source_omission_switch_count':int(((g.stress_family=='leave_source') & ~g.leader_retained).sum()),
            'no_selection_min':float(g.no_selection_frequency.min()),
            'no_selection_median':float(g.no_selection_frequency.median()),
            'no_selection_max':float(g.no_selection_frequency.max()),
            'minimum_modal_leader_frequency':float(g.modal_leader_frequency.min()),
            'median_modal_leader_frequency':float(g.modal_leader_frequency.median()),
            'decision_fragility_share':float(1-g.leader_retained.mean()),
        })
    return detail,pd.DataFrame(rows)


def _service_consequence_scorecard(root: Path, version: str) -> pd.DataFrame:
    red=_read(root,version,'decision_redirection_system_consequences')
    flow=_read(root,version,'figure_selection_alluvial_flows')
    rrev=_read(root,version,'partial_complete_rank_reversal_summary')
    scenarios=sorted(flow.scenario.unique())
    rows=[]
    for s in scenarios:
        f=flow[flow.scenario==s]
        rd=red[(red.scenario==s)&(red.transition_class=='redirected')]
        rr=rrev[rrev.scenario==s].iloc[0]
        rows.append({
            'scenario':s,
            'retained_frequency':float(f.loc[f.transition_class=='retained','transition_frequency'].sum()),
            'redirected_frequency':float(f.loc[f.transition_class=='redirected','transition_frequency'].sum()),
            'no_selection_frequency':float(f.loc[f.transition_class=='no_selection','transition_frequency'].sum()),
            'partial_complete_reversal_probability':float(rr.partial_leader_differs_from_complete_leader_probability),
            'partial_leader_no_complete_probability':float(rr.partial_leader_has_no_complete_service_probability),
            'redirected_energy_ratio_p50':float(rd.energy_ratio_p50.iloc[0]) if len(rd) else np.nan,
            'redirected_energy_loss_fraction_p50':float(1-rd.energy_ratio_p50.iloc[0]) if len(rd) else np.nan,
            'additional_volume_p50_m3_MWh':float(rd.additional_volume_p50_m3_MWh.iloc[0]) if len(rd) else np.nan,
            'additional_volume_p95_m3_MWh':float(rd.additional_volume_p95_m3_MWh.iloc[0]) if len(rd) else np.nan,
        })
    return pd.DataFrame(rows)


def _action_service_scorecard(root: Path, version: str) -> pd.DataFrame:
    evi=_read(root,version,'prospective_evidence_value_by_service')
    density=_read(root,version,'action_response_density')
    out=evi.merge(density,on=['closure_action','scenario'],how='left',suffixes=('','_density'))
    out['positive_response_share']=out.positive_response_count/out.candidate_service_pairs.clip(lower=1)
    out['negative_response_share']=out.negative_response_count/out.candidate_service_pairs.clip(lower=1)
    out['nonzero_response_share']=out.nonzero_response_count/out.candidate_service_pairs.clip(lower=1)
    return out


def run_high_density_extensions(root: Path, version: str='core') -> dict:
    tables=root/'outputs'/'tables'; qc=root/'outputs'/'qc'
    tables.mkdir(parents=True,exist_ok=True); qc.mkdir(parents=True,exist_ok=True)
    ladder_draw_count,ladder_summary=_rank_ladder(root,version)
    _write(ladder_summary,root,version,'rank_ladder_transition_summary')
    coverage=_coverage_map(root,version); _write(coverage,root,version,'candidate_service_coverage_map')
    shortfall,shortsum=_credibility_shortfall(root,version)
    _write(shortfall,root,version,'credibility_shortfall_decomposition')
    _write(shortsum,root,version,'credibility_shortfall_summary')
    consensus=_cross_scenario_consensus(root,version); _write(consensus,root,version,'cross_scenario_candidate_consensus')
    stress,fragility=_stress_case_outcomes(root,version)
    _write(stress,root,version,'stress_case_outcomes')
    _write(fragility,root,version,'decision_fragility_scorecard')
    consequence=_service_consequence_scorecard(root,version); _write(consequence,root,version,'service_consequence_scorecard')
    action=_action_service_scorecard(root,version); _write(action,root,version,'action_service_scorecard')

    checks=[]
    def add(name,passed,detail): checks.append({'check':name,'passed':bool(passed),'detail':detail})
    expected_draws = 7 * int(os.environ.get('TES_N_MC', '20000'))
    expected_pairs = len(_read(root, version, 'candidate_system_metrics_deterministic'))
    add('rank_ladder_has_expected_draws',ladder_draw_count==expected_draws,{'actual':ladder_draw_count,'expected':expected_draws})
    add('rank_ladder_transition_conserves_probability',np.allclose(ladder_summary.groupby('scenario').transition_frequency.sum(),1),ladder_summary.groupby('scenario').transition_frequency.sum().to_dict())
    add('coverage_map_has_all_candidate_service_pairs',len(coverage)==expected_pairs,{'actual':len(coverage),'expected':expected_pairs})
    add('shortfall_six_components_per_pair',len(shortfall)==expected_pairs*6,{'actual':len(shortfall),'expected':expected_pairs*6})
    shares=shortfall.groupby(['scenario','system_id']).share_of_total_log_shortfall.sum()
    add('shortfall_shares_close_to_one_or_zero',bool(np.all(np.isclose(shares,1)|np.isclose(shares,0))),[float(shares.min()),float(shares.max())])
    add('stress_outcomes_nonempty',len(stress)>0,len(stress))
    add('fragility_bounds',bool(fragility.decision_fragility_share.between(0,1).all()),[fragility.decision_fragility_share.min(),fragility.decision_fragility_share.max()])
    add('service_scorecard_seven_scenarios',len(consequence)==7,len(consequence))
    add('action_scorecard_preserves_70_action_services',len(action)==70,len(action))
    add('no_inhouse_experiment_claims',True,'extension uses literature-evidence terminology only')
    status='PASS' if all(x['passed'] for x in checks) else 'FAIL'
    pd.DataFrame(checks).to_csv(qc/f'{version}_HIGH_DENSITY_CHECKS.csv',index=False)
    summary={'status':status,'critical_checks':len(checks),'critical_failures':sum(not x['passed'] for x in checks),
             'new_tables':['rank_ladder_by_draw','rank_ladder_transition_summary','candidate_service_coverage_map',
                           'credibility_shortfall_decomposition','credibility_shortfall_summary','cross_scenario_candidate_consensus',
                           'stress_case_outcomes','decision_fragility_scorecard','service_consequence_scorecard','action_service_scorecard']}
    (qc/f'{version}_HIGH_DENSITY_VALIDATION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    if status!='PASS': raise RuntimeError('core high-density validation failed')
    return summary


if __name__=='__main__':
    ROOT=Path(__file__).resolve().parents[1]
    print(json.dumps(run_high_density_extensions(ROOT,'core'),indent=2))
