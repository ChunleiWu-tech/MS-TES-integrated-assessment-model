from __future__ import annotations

import json
import re
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = ROOT / "config" / "SEED_REGISTRY.csv"
QC = ROOT / "outputs" / "qc"
SRC = ROOT / "src"


def main() -> None:
    frame = pd.read_csv(REGISTRY)
    checks = []
    required = {"module", "entry_script", "base_seed", "derivation_rule", "random_objects", "analysis_role", "formal_status"}
    checks.append({"check": "required_columns", "passed": bool(required.issubset(frame.columns))})
    checks.append({"check": "module_ids_unique", "passed": bool(frame["module"].is_unique)})
    checks.append({"check": "positive_integer_base_seeds", "passed": bool(pd.to_numeric(frame["base_seed"], errors="coerce").notna().all() and (pd.to_numeric(frame["base_seed"]) > 0).all())})
    checks.append({"check": "entry_scripts_exist", "passed": bool(all((ROOT / p).exists() for p in frame["entry_script"]))})
    checks.append({"check": "derivation_rules_nonempty", "passed": bool(frame["derivation_rule"].fillna("").str.len().gt(10).all())})
    source_text = "\n".join(path.read_text(encoding="utf-8", errors="ignore") for path in SRC.glob("*.py"))
    for seed in sorted(set(pd.to_numeric(frame["base_seed"]).astype(int))):
        checks.append({"check": f"seed_declared_in_source_or_registry:{seed}", "passed": bool(str(seed) in source_text or f"{seed:_}" in source_text)})
    passed = all(bool(row["passed"]) for row in checks)
    out = {"status": "PASS" if passed else "FAIL", "registered_modules": int(len(frame)), "checks": checks,
           "policy": "Every stochastic module has a module-specific frozen seed and an explicit derivation rule; the package does not claim one global seed."}
    QC.mkdir(parents=True, exist_ok=True)
    (QC / "seed_registry_validation.json").write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(json.dumps(out, indent=2))
    if not passed:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
