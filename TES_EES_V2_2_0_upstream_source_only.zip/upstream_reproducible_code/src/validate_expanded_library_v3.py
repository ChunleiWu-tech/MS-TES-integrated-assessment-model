from __future__ import annotations

import json
import os
import re
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
DATA = ROOT / "data" / "expanded_library_v3"


def check(name: str, passed: bool, detail: str) -> dict[str, object]:
    return {"check": name, "passed": bool(passed), "detail": str(detail)}


def composition_sum(text: str) -> float:
    return sum(float(x) for x in re.findall(r"(\d+(?:\.\d+)?)%", str(text)))


def as_bool(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False)
    return series.astype(str).str.strip().str.lower().isin({"true", "1", "yes"})


def no_local_path(values: pd.Series) -> bool:
    text = "\n".join(values.fillna("").astype(str).tolist())
    forbidden = [r"[A-Za-z]:\\Users\\", r"[A-Za-z]:/Users/", r"/home/[^/]+/", "吴春雷", ".codex"]
    return not any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in forbidden)


def main() -> None:
    candidates = pd.read_csv(TABLES / "expanded_v3_exact_composition_candidate_summary.csv")
    records = pd.read_csv(TABLES / "expanded_v3_unified_property_record_audit.csv")
    screen = pd.read_csv(TABLES / "expanded_v3_candidate_service_screen.csv")
    mc_all = pd.read_csv(TABLES / "expanded_v3_thermophysical_opportunity_mc.csv")
    mc_domain = pd.read_csv(TABLES / "expanded_v3_domain_validated_thermophysical_mc.csv")
    storyline = pd.read_csv(TABLES / "expanded_v3_cross_layer_storyline.csv")
    sources = pd.read_csv(DATA / "expanded_library_v3_source_registry.csv")
    status = json.loads((QC / "expanded_v3_full_library_validation.json").read_text(encoding="utf-8"))

    required_screen_columns = {
        "service_domain_supported",
        "service_domain_support_class",
        "tier_A_equation_or_phase_resolved",
        "tier_B_reported_interval_or_phase_supported",
        "tier_C_scalar_or_partial_screening_only",
        "engineering_registry_linked",
        "formal_assessment_completed",
        "formal_assessment_status",
    }
    missing_columns = sorted(required_screen_columns - set(screen.columns))

    sums = candidates["normalized_composition"].map(composition_sum)
    used_keys = set(
        records.loc[
            as_bool(records["exact_composition"])
            & as_bool(records["expanded_v3_value_plausible"])
            & as_bool(records["formal_numeric_use"])
            & ~as_bool(records["duplicate_property_record"]),
            "candidate_key",
        ]
    )
    candidate_keys = set(candidates["candidate_key"])

    a = as_bool(screen["tier_A_equation_or_phase_resolved"]) if not missing_columns else pd.Series(False, index=screen.index)
    b = as_bool(screen["tier_B_reported_interval_or_phase_supported"]) if not missing_columns else pd.Series(False, index=screen.index)
    c = as_bool(screen["tier_C_scalar_or_partial_screening_only"]) if not missing_columns else pd.Series(False, index=screen.index)
    supported = as_bool(screen["service_domain_supported"]) if not missing_columns else pd.Series(False, index=screen.index)
    quantitative = as_bool(screen["quantitative_thermophysical_complete"])
    linked = as_bool(screen["engineering_registry_linked"]) if not missing_columns else pd.Series(False, index=screen.index)
    completed = as_bool(screen["formal_assessment_completed"]) if not missing_columns else pd.Series(False, index=screen.index)

    nkca = screen[
        screen["display_system"].str.contains("23.5-25.0-51.5", regex=False, na=False)
        & screen["service_id"].eq("pcm_target_500C")
    ]
    hxl = screen[screen["display_system"].str.contains("HXLN", regex=False, na=False)]

    checks: list[dict[str, object]] = [
        check("upstream_status_pass", status.get("validation_pass") is True, status.get("validation_pass")),
        check("required_service_domain_columns_present", not missing_columns, missing_columns),
        check("legacy_formal_new_entrant_column_removed", "formal_new_entrant" not in screen.columns, "column absent"),
        check("candidate_keys_unique", candidates["candidate_key"].is_unique, f"n={len(candidates)}"),
        check(
            "composition_sums_are_100pct",
            bool(np.allclose(sums, 100.0, atol=0.01)),
            f"min={sums.min():.6f}; max={sums.max():.6f}",
        ),
        check("used_record_keys_equal_candidate_keys", used_keys == candidate_keys, f"used={len(used_keys)}; candidates={len(candidate_keys)}"),
        check("seven_services_per_candidate", len(screen) == len(candidates) * 7, f"pairs={len(screen)}"),
        check("candidate_service_pairs_unique", not screen.duplicated(["candidate_key", "service_id"]).any(), "candidate_key+service_id"),
        check(
            "physical_pass_is_gate_intersection",
            bool((as_bool(screen["physical_window_pass"]) == (as_bool(screen["phase_gate_pass"]) & as_bool(screen["upper_boundary_gate_pass"]))).all()),
            "phase and upper-boundary gates",
        ),
        check("support_tiers_are_mutually_exclusive_and_exhaustive", bool(((a.astype(int) + b.astype(int) + c.astype(int)) == 1).all()), f"A={int(a.sum())}; B={int(b.sum())}; C={int(c.sum())}"),
        check("service_domain_support_equals_quantitative_tier_A_or_B", bool((supported == (quantitative & (a | b))).all()), f"supported={int(supported.sum())}"),
        check("service_domain_support_excludes_tier_C", not bool((supported & c).any()), "supported ∩ Tier C = 0"),
        check("formal_assessment_completed_iff_registry_service_linked", bool((completed == linked).all()), f"completed={int(completed.sum())}; linked={int(linked.sum())}"),
        check("outside_registry_candidates_not_reported_as_formally_failed", not bool((~linked & screen["formal_assessment_status"].astype(str).str.contains("failed|rejected", case=False, regex=True)).any()), "no failure inference outside frozen registry"),
        check(
            "nkca2025_is_service_domain_supported_opportunity",
            len(nkca) == 1 and bool(as_bool(nkca["physical_window_pass"]).iloc[0]) and bool(as_bool(nkca["service_domain_supported"]).iloc[0]),
            nkca[["physical_window_pass", "service_domain_supported", "service_domain_support_class"]].to_dict("records"),
        ),
        check(
            "nkca2025_formal_assessment_explicitly_pending",
            len(nkca) == 1
            and not bool(as_bool(nkca["formal_assessment_completed"]).iloc[0])
            and nkca.iloc[0]["formal_assessment_status"] == "not_formally_evaluated_outside_frozen_registry",
            nkca[["formal_assessment_completed", "formal_assessment_status"]].to_dict("records"),
        ),
        check("hxl_enters_three_sensible_physical_windows", int(as_bool(hxl["physical_window_pass"]).sum()) == 3, f"physical_services={int(as_bool(hxl['physical_window_pass']).sum())}"),
        check("current_atomic_registry_links_present", int(as_bool(candidates["atomic_engineering_registry_available"]).sum()) >= 10, f"linked_candidates={int(as_bool(candidates['atomic_engineering_registry_available']).sum())}"),
        check("source_ids_unique", sources["source_id"].is_unique, f"sources={len(sources)}"),
        check("source_registry_contains_no_personal_local_paths", no_local_path(sources.astype(str).agg(" | ".join, axis=1)), "relative/public locators only"),
        check("storyline_has_all_services", storyline["service_id"].nunique() == 7, f"services={storyline['service_id'].nunique()}"),
    ]

    expected_iterations = int(status.get("monte_carlo_iterations", 0))
    mode = os.environ.get("TES_PIPELINE_MODE", "full").strip().lower()
    for label, mc in [("all_quantitative", mc_all), ("service_domain_supported", mc_domain)]:
        sums_mc = mc.groupby("service_id")["thermophysical_rank1_frequency"].sum()
        iterations = sorted(set(pd.to_numeric(mc["iterations"], errors="coerce").dropna().astype(int)))
        checks.extend(
            [
                check(
                    f"{label}_mc_frequencies_sum_to_one",
                    bool(np.allclose(sums_mc.values, 1.0, atol=max(1.0 / max(expected_iterations, 1), 1e-9))),
                    sums_mc.round(8).to_dict(),
                ),
                check(f"{label}_mc_iterations_match_status", iterations == [expected_iterations], iterations),
                check(f"{label}_mc_scope_is_thermophysical_not_formal", mc["scope"].astype(str).str.contains("not_formal_selection", regex=False).all(), sorted(mc["scope"].unique().tolist())),
                check(f"{label}_uses_candidate_keyed_substreams", set(mc["seed_strategy"].astype(str)) == {"candidate_keyed_sha256_substreams"}, sorted(set(mc["seed_strategy"].astype(str)))),
            ]
        )

    if mode == "full":
        checks.append(check("full_run_uses_at_least_20000_draws", expected_iterations >= 20_000, expected_iterations))
    else:
        checks.append(check("smoke_run_uses_positive_draw_count", expected_iterations > 0, expected_iterations))

    common = mc_all.merge(
        mc_domain,
        on=["service_id", "candidate_key"],
        suffixes=("_all", "_domain"),
    )
    common = common[common["candidate_key"].ne("none")]
    matched_columns = ["robust_physical_pass_probability", "performance_p05", "performance_median", "performance_p95"]
    max_diffs: dict[str, float] = {}
    matched = True
    for column in matched_columns:
        left = pd.to_numeric(common[f"{column}_all"], errors="coerce")
        right = pd.to_numeric(common[f"{column}_domain"], errors="coerce")
        diff = (left - right).abs()
        max_diff = float(diff.max()) if len(diff) else 0.0
        max_diffs[column] = max_diff
        matched = matched and bool(np.allclose(left, right, rtol=0.0, atol=1e-12, equal_nan=True))
    checks.append(check("candidate_keyed_draws_match_across_analysis_scopes", matched, max_diffs))

    checks_df = pd.DataFrame(checks)
    checks_df.to_csv(QC / "expanded_v3_validation_checks.csv", index=False, encoding="utf-8-sig")
    summary = {
        "validation_pass": bool(checks_df["passed"].all()),
        "checks_total": int(len(checks_df)),
        "checks_passed": int(checks_df["passed"].sum()),
        "checks_failed": checks_df.loc[~checks_df["passed"], "check"].tolist(),
        "pipeline_mode": mode,
        "monte_carlo_iterations": expected_iterations,
        "service_domain_supported_pairs": int(supported.sum()),
        "tier_A_supported_pairs": int((supported & a).sum()),
        "tier_B_supported_pairs": int((supported & b).sum()),
        "formally_assessed_pairs_within_frozen_registry": int(completed.sum()),
        "supported_pairs_outside_frozen_registry": int((supported & ~linked).sum()),
        "matched_draw_max_abs_differences": max_diffs,
    }
    (QC / "expanded_v3_independent_validation.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if not summary["validation_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
