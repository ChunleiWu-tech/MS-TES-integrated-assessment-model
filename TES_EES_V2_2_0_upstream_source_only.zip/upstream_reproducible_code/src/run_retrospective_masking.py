"""Temperature masking diagnostic on an already-cited database source.

No rule fitting, future-temperature extrapolation, new engineering admission,
or independent-validation designation occurs in this calculation.
"""
from pathlib import Path
from hashlib import sha256
import json
import numpy as np
import pandas as pd
from run_expanded_library_v3 import conditions_cover

ROOT=Path(__file__).resolve().parents[1]

def run():
    path=ROOT/'data/input/wei2020_retrospective_masking.json'
    d=json.loads(path.read_text(encoding='utf-8'))
    temps=np.array(d['temperature_C'],float);low=d['duty_low_C'];high=d['duty_high_C']
    rows=[]
    for c in d['candidates']:
        assert abs(sum(c['composition_mol_percent'].values())-100)<1e-8
        assert low>=c['melting_C']+20
        cp=np.array(c['cp_J_g_K'],float)
        enthalpy=float(np.trapezoid(cp,temps))*1000
        density=(c['rho_intercept_g_cm3']+c['rho_slope_g_cm3_C']*high)*1000
        q=density*enthalpy/3.6e6
        for temperature,value in zip(temps,cp):
            scalar_q=density*value*1000*(high-low)/3.6e6
            rows.append(dict(candidate=c['id'],composition_mol_percent=json.dumps(c['composition_mol_percent']),
                low_C=low,high_C=high,revealed_cp_temperature_C=temperature,scalar_cp_J_g_K=value,
                full_interval_enthalpy_J_kg=enthalpy,hot_end_density_kg_m3=density,
                integrated_capacity_kWh_m3=q,scalar_capacity_kWh_m3=scalar_q,
                scalar_energy_error_percent=100*(scalar_q/q-1),
                scalar_volume_error_percent=100*(q/scalar_q-1),
                partial_evidence_pass=conditions_cover(f'{temperature} C',low,high),
                full_evidence_pass=conditions_cover(f'{low}–{high} C',low,high),
                capacity_sensitivity_low=q*.98*.98,capacity_sensitivity_high=q*1.02*1.02,
                uncertainty_scope='deterministic 2% component bounds; not confidence limits; interpolation error unquantified',
                source_doi=d['doi'],source_locations='Table 1; Table 2; Table 3; Figure 3',
                independence_status='source_already_in_bundled_database_references'))
    frame=pd.DataFrame(rows)
    frame['scalar_rank']=frame.groupby('revealed_cp_temperature_C').scalar_capacity_kWh_m3.rank(ascending=False,method='min')
    frame['full_data_rank']=frame.groupby('revealed_cp_temperature_C').integrated_capacity_kWh_m3.rank(ascending=False,method='min')
    out=ROOT/'outputs/tables';out.mkdir(parents=True,exist_ok=True)
    frame.to_csv(out/'traceability_retrospective_masking.csv',index=False)
    report=dict(status='PASS',source_independent=False,prospectively_blinded=False,
        scientific_scope='Retrospective point-property error calculation, not an independent performance test.',
        cases=len(frame),complete_temperature_intervals=3,
        energy_error_percent=[float(frame.scalar_energy_error_percent.min()),float(frame.scalar_energy_error_percent.max())],
        volume_error_percent=[float(frame.scalar_volume_error_percent.min()),float(frame.scalar_volume_error_percent.max())],
        nominal_rank_changes=int((frame.scalar_rank!=frame.full_data_rank).sum()),
        partial_supported=int(frame.partial_evidence_pass.sum()),full_supported=int(frame.full_evidence_pass.sum()),
        source_sha256=sha256(path.read_bytes()).hexdigest(),
        limitations='Three already-referenced mixtures, a selected common measured interval, piecewise-linear heat-capacity integration and source density fits. No engineering qualification, full-cycle device prediction or empirical score calibration. Nominal ranking agreement does not resolve overlapping measurement-sensitivity bounds.')
    assert not frame.partial_evidence_pass.any() and frame.full_evidence_pass.all()
    q=ROOT/'outputs/qc';q.mkdir(parents=True,exist_ok=True)
    (q/'RETROSPECTIVE_MASKING_AUDIT.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2));return report

if __name__=='__main__':run()
