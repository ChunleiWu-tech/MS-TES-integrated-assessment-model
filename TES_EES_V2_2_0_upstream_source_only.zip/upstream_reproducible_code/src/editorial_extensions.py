from __future__ import annotations

from pathlib import Path
from itertools import combinations
import json
import numpy as np
import pandas as pd


def _read(root: Path, version: str, name: str) -> pd.DataFrame:
    return pd.read_csv(root / 'outputs' / 'tables' / f'{version}_{name}.csv')


def _write(df: pd.DataFrame, root: Path, version: str, name: str) -> None:
    path = root / 'outputs' / 'tables' / f'{version}_{name}.csv'
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)


def _source_stream(source_type: str) -> str:
    s = str(source_type).lower()
    if 'database' in s:
        return 'Reference databases'
    if 'corrosion' in s:
        return 'Corrosion literature'
    if 'primary_article' in s or 'peer_reviewed' in s:
        return 'Thermophysical literature'
    if 'official_system' in s or 'roadmap' in s or 'assessment' in s or 'program' in s:
        return 'System benchmarks'
    if 'commodity' in s or 'context' in s:
        return 'Contextual literature'
    return 'Other literature'


def _family_group(family: str) -> str:
    s = str(family).lower()
    if 'nitrate' in s or 'nitrite' in s:
        return 'Nitrate/nitrite'
    if 'chloride' in s:
        return 'Chloride'
    if 'carbonate' in s or 'fluoride' in s:
        return 'Carbonate/fluoride'
    return str(family)


def run_editorial_extensions(root: Path, version: str) -> dict:
    t = root / 'outputs' / 'tables'
    src = pd.read_csv(root / 'data' / 'input' / f'{version}_authoritative_source_registry.csv')
    atomic = pd.read_csv(root / 'data' / 'input' / f'{version}_atomic_engineering_credibility_registry.csv')
    metrics = _read(root, version, 'integrated_system_decision_table')
    signed = _read(root, version, 'counterfactual_candidate_signed_changes')
    joint = _read(root, version, 'joint_gate_closure')
    cred = _read(root, version, 'credibility_model_sensitivity')
    pert = _read(root, version, 'evidence_score_perturbation_sensitivity')
    loc = _read(root, version, 'leave_one_candidate_out_sensitivity')
    los = _read(root, version, 'leave_one_source_out_sensitivity')
    conv = _read(root, version, 'independent_seed_convergence')
    flow = _read(root, version, 'figure_selection_alluvial_flows')
    consequences = _read(root, version, 'decision_redirection_system_consequences')
    cchange = _read(root, version, 'counterfactual_selection_changes')

    # 1. Unique literature source-candidate links. This is a count of declared links,
    # not evidence quality or publication volume.
    src_map = src.set_index('source_id')['source_type'].to_dict()
    candidate_family = metrics.drop_duplicates('system_id').set_index('system_id')['family'].map(_family_group).to_dict()
    links = []
    unique_candidate_sources = set()
    for row in atomic.itertuples(index=False):
        for sid in str(row.source_ids).split(';'):
            sid = sid.strip()
            if not sid:
                continue
            unique_candidate_sources.add((row.system_id, sid))
    for system_id, sid in sorted(unique_candidate_sources):
        links.append({
            'evidence_stream': _source_stream(src_map.get(sid, 'other')),
            'candidate_family': candidate_family.get(system_id, 'Other'),
            'system_id': system_id,
            'source_id': sid,
            'unique_source_candidate_link': 1,
        })
    literature_flow = pd.DataFrame(links)
    _write(literature_flow, root, version, 'literature_evidence_flow')

    # 2. Candidate readiness profile using only transparent observed/model outputs.
    profile_cols = [
        'scenario','scenario_label','system_id','display_system','family',
        'strict_complete_service_probability',
        'energy_density_p05_kWh_m3_conditional_on_adequacy',
        'energy_density_p50_kWh_m3_conditional_on_adequacy',
        'energy_density_p95_kWh_m3_conditional_on_adequacy',
        'evidence_qualified_selection_frequency','strict_complete_thermophysical_selection_frequency',
        'corrosion_compatibility_score','cycling_phase_stability_score','containment_validation_score',
        'literature_replication_score','data_completeness_score','engineering_burden_index',
        'gap_corrosion','gap_cycling_phase','gap_containment','gap_literature_validation',
        'gap_data_completeness','nonclosable_direct_risk'
    ]
    profile = metrics[profile_cols].copy()
    gap_cols = ['gap_corrosion','gap_cycling_phase','gap_containment','gap_literature_validation','gap_data_completeness']
    profile['closable_gap_count'] = profile[gap_cols].astype(bool).sum(axis=1)
    profile['all_noncompensatory_gate_count'] = profile['closable_gap_count'] + profile['nonclosable_direct_risk'].astype(int)
    profile['strict_probability_class'] = np.select(
        [profile.strict_complete_service_probability >= 0.999,
         profile.strict_complete_service_probability > 0],
        ['robust_complete_service','uncertain_complete_service'],
        default='no_complete_service'
    )
    _write(profile, root, version, 'candidate_readiness_profile')

    # 3. Scenario-level composition of complete-service feasibility.
    comp = (profile.groupby(['scenario','scenario_label','strict_probability_class'])
            .size().rename('candidate_service_pairs').reset_index())
    totals = comp.groupby('scenario').candidate_service_pairs.transform('sum')
    comp['share_within_service'] = comp.candidate_service_pairs / totals
    _write(comp, root, version, 'service_feasibility_composition')

    # 4. Pairwise gate interaction: exact non-additive increment from the full 2^6 closure table.
    gates = ['incomplete_service','corrosion','cycling_phase','containment','literature_validation','data_completeness']
    bit = {g: 1 << i for i,g in enumerate(gates)}
    synergy_rows = []
    for scenario, gdf in joint.groupby('scenario'):
        vals = gdf.set_index('closed_gate_mask').retained_candidate_draw_frequency.to_dict()
        f0 = float(vals[0])
        for ga, gb in combinations(gates, 2):
            fa = float(vals[bit[ga]])
            fb = float(vals[bit[gb]])
            fab = float(vals[bit[ga] | bit[gb]])
            synergy_rows.append({
                'scenario': scenario,
                'gate_a': ga,
                'gate_b': gb,
                'single_a_unlock': fa - f0,
                'single_b_unlock': fb - f0,
                'joint_unlock': fab - f0,
                'nonadditive_synergy': fab - fa - fb + f0,
            })
    synergy = pd.DataFrame(synergy_rows)
    _write(synergy, root, version, 'gate_pair_synergy')
    synergy_summary = (synergy.groupby(['gate_a','gate_b'])
        .agg(mean_synergy=('nonadditive_synergy','mean'),
             mean_absolute_synergy=('nonadditive_synergy',lambda s: float(np.mean(np.abs(s)))),
             minimum_synergy=('nonadditive_synergy','min'),
             maximum_synergy=('nonadditive_synergy','max'),
             maximum_absolute_synergy=('nonadditive_synergy',lambda s: float(np.max(np.abs(s)))),
             nonzero_service_count=('nonadditive_synergy',lambda s: int((np.abs(s)>1e-12).sum())),
             positive_service_count=('nonadditive_synergy',lambda s: int((s>1e-12).sum())),
             negative_service_count=('nonadditive_synergy',lambda s: int((s<-1e-12).sum())),
             zero_service_count=('nonadditive_synergy',lambda s: int((np.abs(s)<=1e-12).sum())))
        .reset_index())
    _write(synergy_summary, root, version, 'gate_pair_synergy_summary')

    # 5. Robustness consensus across structural, evidence and leave-one-out stresses.
    base = cred[cred.credibility_model == 'hierarchical_geometric'].set_index('scenario')
    consensus_rows = []
    scenarios = sorted(metrics.scenario.unique())
    for scenario in scenarios:
        baseline_leader = str(base.loc[scenario, 'modal_leader'])
        records = []
        for frame, label in [(cred,'credibility_model'),(pert,'evidence_state'),(loc,'leave_candidate'),(los,'leave_source')]:
            sub = frame[frame.scenario == scenario]
            for r in sub.itertuples(index=False):
                records.append({
                    'stress_family': label,
                    'modal_leader': str(r.modal_leader),
                    'modal_leader_frequency': float(r.modal_leader_frequency),
                    'no_selection_frequency': float(r.no_selection_frequency),
                })
        rdf = pd.DataFrame(records)
        seed_final = conv[(conv.scenario == scenario) & (conv.n_draws == conv.n_draws.max())]
        consensus_rows.append({
            'scenario': scenario,
            'baseline_leader': baseline_leader,
            'stress_cases': len(rdf),
            'leader_retention_share': float((rdf.modal_leader == baseline_leader).mean()) if len(rdf) else np.nan,
            'minimum_modal_leader_frequency': float(rdf.modal_leader_frequency.min()) if len(rdf) else np.nan,
            'median_modal_leader_frequency': float(rdf.modal_leader_frequency.median()) if len(rdf) else np.nan,
            'no_selection_min': float(rdf.no_selection_frequency.min()) if len(rdf) else np.nan,
            'no_selection_max': float(rdf.no_selection_frequency.max()) if len(rdf) else np.nan,
            'no_selection_range': float(rdf.no_selection_frequency.max()-rdf.no_selection_frequency.min()) if len(rdf) else np.nan,
            'independent_seed_final_range': float(seed_final.no_selection_frequency.max()-seed_final.no_selection_frequency.min()) if len(seed_final) else np.nan,
        })
    consensus = pd.DataFrame(consensus_rows)
    _write(consensus, root, version, 'robustness_consensus_summary')

    # 6. Action-response density: explicitly summarise zero, positive and negative candidate responses.
    density_rows = []
    for (action, scenario), gdf in signed.groupby(['closure_action','scenario']):
        delta = gdf.delta_selection_frequency.fillna(0).to_numpy(float)
        eps = 1e-12
        pos = delta > eps
        neg = delta < -eps
        zero = ~(pos | neg)
        density_rows.append({
            'closure_action': action,
            'scenario': scenario,
            'candidate_service_pairs': len(delta),
            'positive_response_count': int(pos.sum()),
            'negative_response_count': int(neg.sum()),
            'zero_response_count': int(zero.sum()),
            'nonzero_response_count': int((pos|neg).sum()),
            'zero_response_share': float(zero.mean()),
            'positive_frequency_sum': float(delta[pos].sum()),
            'negative_frequency_sum': float(delta[neg].sum()),
            'net_frequency_change': float(delta.sum()),
            'maximum_absolute_candidate_change': float(np.max(np.abs(delta))) if len(delta) else 0.0,
        })
    density = pd.DataFrame(density_rows)
    _write(density, root, version, 'action_response_density')

    # 7. Compact scenario storyline table. Every column is a direct lookup or aggregation.
    red = consequences[consequences.transition_class == 'redirected'].set_index('scenario')
    baseline_change = cchange[cchange.closure_action == 'baseline'].set_index('scenario') if 'baseline' in set(cchange.closure_action) else pd.DataFrame()
    scenario_rows = []
    for scenario in scenarios:
        p = profile[profile.scenario == scenario]
        f = flow[flow.scenario == scenario]
        scenario_rows.append({
            'scenario': scenario,
            'candidate_service_pairs': len(p),
            'robust_complete_candidates': int((p.strict_probability_class == 'robust_complete_service').sum()),
            'candidate_pairs_with_any_gate': int((p.all_noncompensatory_gate_count > 0).sum()),
            'retained_transition_frequency': float(f.loc[f.transition_class == 'retained','transition_frequency'].sum()),
            'redirected_transition_frequency': float(f.loc[f.transition_class == 'redirected','transition_frequency'].sum()),
            'no_selection_transition_frequency': float(f.loc[f.transition_class == 'no_selection','transition_frequency'].sum()),
            'redirected_energy_ratio_p50': float(red.loc[scenario,'energy_ratio_p50']) if scenario in red.index else np.nan,
            'redirected_additional_volume_p50_m3_MWh': float(red.loc[scenario,'additional_volume_p50_m3_MWh']) if scenario in red.index else np.nan,
            'leader_retention_share_across_stresses': float(consensus.set_index('scenario').loc[scenario,'leader_retention_share']),
        })
    storyline = pd.DataFrame(scenario_rows)
    _write(storyline, root, version, 'scenario_storyline_summary')

    summary = {
        'status': 'PASS',
        'literature_source_candidate_links': int(len(literature_flow)),
        'candidate_readiness_rows': int(len(profile)),
        'gate_pair_synergy_rows': int(len(synergy)),
        'gate_pair_synergy_summary_rows': int(len(synergy_summary)),
        'robustness_consensus_rows': int(len(consensus)),
        'action_response_density_rows': int(len(density)),
    }
    (root / 'outputs' / 'qc' / f'{version}_EDITORIAL_EXTENSION_STATUS.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    return summary
