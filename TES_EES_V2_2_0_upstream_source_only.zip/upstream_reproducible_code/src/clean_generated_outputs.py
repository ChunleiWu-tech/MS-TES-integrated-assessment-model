from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'
if OUT.is_symlink() or OUT.resolve().parent != ROOT:
    raise RuntimeError('Refusing to clean a redirected generated-output directory')
for child in OUT.iterdir() if OUT.exists() else []:
    if child.name=='README.md':
        continue
    if child.is_symlink() or child.resolve().parent != OUT.resolve():
        raise RuntimeError(f'Refusing redirected output: {child}')
    if child.is_dir():
        shutil.rmtree(child)
    else:
        child.unlink()
(OUT/'tables').mkdir(parents=True,exist_ok=True)
(OUT/'qc').mkdir(parents=True,exist_ok=True)
print('Removed prior generated upstream outputs; retained outputs/README.md.')
