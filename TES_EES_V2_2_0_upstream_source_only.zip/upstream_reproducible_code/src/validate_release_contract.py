from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

from release_paths import (
    ENVIRONMENT_STATUS,
    ENVIRONMENT_STATUS_COMPAT,
    UPSTREAM_RELEASE_CONTRACT_AUDIT,
    UPSTREAM_RELEASE_STATUS,
    UPSTREAM_RELEASE_STATUS_COMPAT,
)

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
RELEASE_ID = "TES-EES-V2.2.0-20260909"


def load(name: str) -> dict:
    path = QC / name
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}


def canonical_json_equal(a: str, b: str) -> bool:
    return (QC / a).exists() and (QC / b).exists() and load(a) == load(b)


required_qc = [
    ENVIRONMENT_STATUS,
    ENVIRONMENT_STATUS_COMPAT,
    "core_FINAL_VALIDATION_SUMMARY.json",
    "core_RELEASE_VALIDATION_SUMMARY.json",
    "core_RELEASE_QC_STATUS.json",
    "submission_EDITORIAL_SYNTHESIS_STATUS.json",
    "expanded_v3_full_library_validation.json",
    "expanded_v3_independent_validation.json",
    "seed_registry_validation.json",
    "JOULE_EXTERNAL_VALIDATION_STATUS.json",
    "JOULE_CLAIM_SYNTHESIS_STATUS.json",
    "core_COMPOSITE_COUPLING_STATUS.json",
    "core_COMPOSITE_COUPLING_VALIDATION.json",
    UPSTREAM_RELEASE_STATUS,
    UPSTREAM_RELEASE_STATUS_COMPAT,
]
required_tables = [
    "core_system_value_monte_carlo_summary.csv",
    "core_layered_selection_frequencies.csv",
    "core_joint_threshold_regime_map.csv",
    "statistical_decision_scope_matrix.csv",
    "statistical_pareto_joint_uncertainty_and_robustness.csv",
    "submission_service_regime_archetype_summary.csv",
    "core_selection_frequency_numerical_uncertainty.csv",
    "expanded_v3_candidate_service_screen.csv",
    "expanded_v3_evidence_attrition.csv",
    "expanded_v3_cross_layer_storyline.csv",
    "expanded_v3_thermophysical_opportunity_mc.csv",
    "expanded_v3_domain_validated_thermophysical_mc.csv",
    "expanded_v3_all_quantitative_mc_numerical_uncertainty.csv",
    "expanded_v3_service_domain_supported_mc_numerical_uncertainty.csv",
    "joule_external_validation_summary.csv",
    "joule_external_rule_transfer_screen.csv",
    "joule_claim_registry.csv",
    "core_composite_property_response.csv",
    "core_composite_service_coupling.csv",
    "core_composite_dynamic_summary.csv",
    "core_composite_system_summary.csv",
    "core_composite_claim_registry.csv",
    "core_composite_source_audit.csv",
    "core_composite_model_validation.csv",
]

checks: list[dict[str, object]] = []
for name in required_qc:
    checks.append({"check": f"qc_file:{name}", "passed": (QC / name).exists()})
for name in required_tables:
    checks.append({"check": f"table_file:{name}", "passed": (TABLES / name).exists()})
checks.extend(
    [
        {"check": "environment_alias_match", "passed": canonical_json_equal(ENVIRONMENT_STATUS, ENVIRONMENT_STATUS_COMPAT)},
        {"check": "upstream_release_alias_match", "passed": canonical_json_equal(UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT)},
    ]
)

release = load(UPSTREAM_RELEASE_STATUS)
expanded = load("expanded_v3_independent_validation.json")
seed = load("seed_registry_validation.json")
composite = load("core_COMPOSITE_COUPLING_STATUS.json")
composite_validation = load("core_COMPOSITE_COUPLING_VALIDATION.json")
checks.extend(
    [
        {"check": "canonical_upstream_release_status_pass", "passed": release.get("status") == "PASS"},
        {"check": "release_id_current", "passed": release.get("release_id") == RELEASE_ID},
        {"check": "scientific_extension_declared", "passed": release.get("science_changed") is True and release.get("scientific_extension_added") is True},
        {"check": "fixed_mass_hot_volume_reference_declared", "passed": release.get("core_scientific_baseline_changed") is True},
        {"check": "canonical_release_declares_20000_draws", "passed": release.get("mc_iterations") == 20_000},
        {"check": "expanded_independent_validation_pass", "passed": expanded.get("validation_pass") is True},
        {"check": "expanded_full_draw_count", "passed": expanded.get("monte_carlo_iterations") == 20_000},
        {"check": "expanded_candidate_keyed_draws_exactly_matched", "passed": all(float(v) <= 1e-12 for v in expanded.get("matched_draw_max_abs_differences", {}).values())},
        {"check": "seed_registry_pass", "passed": seed.get("status") == "PASS"},
        {"check": "composite_coupling_pass", "passed": composite.get("status") == "PASS"},
        {"check": "composite_independent_validation_pass", "passed": composite_validation.get("status") == "PASS"},
        {"check": "composite_formal_eligibility_not_inferred", "passed": composite.get("formal_composite_eligible_links") == 0},
    ]
)

mc_values: list[int] = []
mc_path = TABLES / "core_system_value_monte_carlo_summary.csv"
if mc_path.exists():
    mc = pd.read_csv(mc_path, usecols=["mc_iterations"])
    mc_values = sorted(set(pd.to_numeric(mc.mc_iterations, errors="coerce").dropna().astype(int).tolist()))
checks.append({"check": "core_monte_carlo_summary_only_20000_draws", "passed": mc_values == [20_000]})

expanded_values: dict[str, list[int]] = {}
for name in ["expanded_v3_thermophysical_opportunity_mc.csv", "expanded_v3_domain_validated_thermophysical_mc.csv"]:
    path = TABLES / name
    values: list[int] = []
    if path.exists():
        values = sorted(set(pd.to_numeric(pd.read_csv(path, usecols=["iterations"])["iterations"], errors="coerce").dropna().astype(int)))
    expanded_values[name] = values
    checks.append({"check": f"{name}:only_20000_draws", "passed": values == [20_000]})

screen_path = TABLES / "expanded_v3_candidate_service_screen.csv"
if screen_path.exists():
    screen = pd.read_csv(screen_path)
    def _as_bool(series):
        return series.map(lambda value: value if isinstance(value, bool) else str(value).strip().lower() in {'true','1','yes','y'})
    checks.extend(
        [
            {"check": "legacy_formal_new_entrant_absent", "passed": "formal_new_entrant" not in screen.columns},
            {"check": "formal_assessment_completed_matches_registry_service_link", "passed": bool(_as_bool(screen["formal_assessment_completed"]).equals(_as_bool(screen["engineering_registry_linked"])))},
            {"check": "thermophysical_opportunity_not_relabelled_formal_selection", "passed": bool(screen["formal_assessment_scope"].astype(str).eq("frozen_15_candidate_engineering_registry_only").all())},
        ]
    )

passed = all(bool(row["passed"]) for row in checks)
out = {
    "status": "PASS" if passed else "FAIL",
    "release_id": RELEASE_ID,
    "science_changed": True,
    "core_scientific_baseline_changed": True,
    "scientific_extension_added": True,
    "expanded_library_scope_semantics_corrected": True,
    "mc_iterations_found": mc_values,
    "expanded_mc_iterations_found": expanded_values,
    "canonical_environment_status": ENVIRONMENT_STATUS,
    "canonical_upstream_release_status": UPSTREAM_RELEASE_STATUS,
    "checks_total": len(checks),
    "checks_passed": sum(bool(row["passed"]) for row in checks),
    "checks_failed": [row["check"] for row in checks if not row["passed"]],
    "checks": checks,
    "policy": "The frozen 15-candidate engineering decision model and the expanded thermophysical opportunity library are separate registered scopes. Candidates outside the frozen engineering registry are not assigned formal selection or formal failure outcomes.",
}
(QC / UPSTREAM_RELEASE_CONTRACT_AUDIT).write_text(json.dumps(out, indent=2), encoding="utf-8")
print(json.dumps(out, indent=2))
if not passed:
    sys.exit(2)
