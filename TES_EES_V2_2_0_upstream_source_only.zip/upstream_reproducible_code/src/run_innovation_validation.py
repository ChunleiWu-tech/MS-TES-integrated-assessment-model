from __future__ import annotations
from pathlib import Path
import json
import numpy as np
import pandas as pd

VERSION='core'
ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'outputs'/'tables'; Q=ROOT/'outputs'/'qc'; Q.mkdir(parents=True,exist_ok=True)
checks=[]
def add(name,passed,detail,critical=True):
    checks.append({'check':name,'passed':bool(passed),'critical':critical,'detail':str(detail)})
def read(stem): return pd.read_csv(T/f'{VERSION}_{stem}.csv')

# Required outputs
required=['deployability_contraction','partial_complete_rank_reversal_candidates','partial_complete_rank_reversal_summary',
          'service_conditioned_deployability_frontier','candidate_archetype_cluster_summary','candidate_archetype_method',
          'smaa_rank_acceptability','smaa_central_weights','smaa_design','prospective_evidence_value_by_service','prospective_evidence_value_summary']
for stem in required: add(f'{stem}_exists',(T/f'{VERSION}_{stem}.csv').exists(),T/f'{VERSION}_{stem}.csv')

c=read('deployability_contraction')
add('contraction_seven_services',c.scenario.nunique()==7,c.scenario.nunique())
add('contraction_five_stages_each',c.groupby('scenario').size().eq(5).all(),c.groupby('scenario').size().to_dict())
mono=c.sort_values(['scenario','stage_order']).groupby('scenario').candidate_service_pairs.apply(lambda s:(np.diff(s.to_numpy())<=0).all())
add('contraction_counts_monotonic',mono.all(),mono.to_dict())
add('contraction_shares_bounded',c.share_of_registered.between(0,1).all(),[c.share_of_registered.min(),c.share_of_registered.max()])

rs=read('partial_complete_rank_reversal_summary'); rc=read('partial_complete_rank_reversal_candidates')
expected_pairs=len(pd.read_csv(ROOT/'data'/'input'/f'{VERSION}_candidate_scenario_membership.csv'))
prob_cols=[x for x in rs.columns if x.endswith('probability')]
add('rank_reversal_probabilities_bounded',all(rs[x].between(0,1).all() for x in prob_cols),prob_cols)
add('rank_reversal_all_services',rs.scenario.nunique()==7,rs.scenario.nunique())
add('rank_reversal_all_candidate_pairs',len(rc)==expected_pairs,{'actual':len(rc),'expected':expected_pairs})
add('rank_reversal_candidate_probabilities_bounded',rc.probability_becomes_unranked_under_complete_service.between(0,1).all(),'bounded')

f=read('service_conditioned_deployability_frontier')
add('frontier_all_candidate_pairs',len(f)==expected_pairs,{'actual':len(f),'expected':expected_pairs})
add('frontier_has_member_each_service',f.groupby('scenario').deployability_frontier.any().all(),f.groupby('scenario').deployability_frontier.sum().to_dict())
add('frontier_metrics_bounded',f[['performance_normalized','strict_complete_service_probability','engineering_credibility_geometric','inverse_burden','robustness','gap_penalty']].apply(lambda s:s.between(0,1).all()).all(),'all [0,1]')
# Verify no frontier row is strictly dominated on all four deployability axes within service.
front_ok=True; detail={}
axes=['performance_normalized','engineering_credibility_geometric','robustness','inverse_burden']
for scenario,g in f.groupby('scenario'):
    x=g[axes].to_numpy(float); flags=g.deployability_frontier.to_numpy(bool); bad=[]
    for i in np.where(flags)[0]:
        dominated=any(np.all(x[j]>=x[i]) and np.any(x[j]>x[i]) for j in range(len(x)) if j!=i)
        if dominated: bad.append(g.iloc[i].system_id)
    detail[scenario]=bad
    front_ok &= not bad
add('frontier_members_nondominated',front_ok,detail)

am=read('candidate_archetype_method')
add('archetype_cluster_count_reasonable',int(am.selected_cluster_count.iloc[0]) in (2,3,4),am.selected_cluster_count.iloc[0])
add('archetype_silhouette_positive',float(am.silhouette_score.iloc[0])>0.25,am.silhouette_score.iloc[0])
add('archetype_perturbation_stability_high',float(am.mean_adjusted_rand_under_5pct_feature_perturbation.iloc[0])>0.8,am.mean_adjusted_rand_under_5pct_feature_perturbation.iloc[0])
k_selected=int(am.selected_cluster_count.iloc[0])
label_text=f.archetype_label.fillna('').astype(str).str.strip()
cluster_label_counts=(f.assign(_label=label_text)
                      .groupby('archetype_cluster_id')._label.nunique(dropna=False))
cluster_label_map=(f.assign(_label=label_text)
                   [['archetype_cluster_id','_label']].drop_duplicates()
                   .sort_values('archetype_cluster_id'))
add('archetype_labels_nonempty',(label_text!='').all(),f.archetype_label.value_counts(dropna=False).to_dict())
add('archetype_cluster_count_matches_method',f.archetype_cluster_id.nunique()==k_selected,
    {'observed':int(f.archetype_cluster_id.nunique()),'selected':k_selected})
add('archetype_labels_one_to_one_with_clusters',
    cluster_label_counts.eq(1).all() and cluster_label_map._label.nunique()==k_selected,
    cluster_label_map.to_dict('records'))

smaa=read('smaa_rank_acceptability'); sw=read('smaa_central_weights'); sd=read('smaa_design')
add('smaa_all_services',smaa.scenario.nunique()==7,smaa.scenario.nunique())
add('smaa_acceptabilities_bounded',smaa.rank_acceptability.between(0,1).all(),'bounded')
rank1=smaa[smaa['rank']==1].groupby('scenario').rank_acceptability.sum()
no=sd.set_index('scenario').no_selection_probability
err=(rank1+no-1).abs()
add('smaa_rank1_plus_no_selection_closes',float(err.max())<1e-12,err.to_dict())
valid_weights=sw.dropna(subset=['central_weight_performance'])
add('smaa_central_weights_sum_one',np.allclose(valid_weights.central_weight_performance+valid_weights.central_weight_engineering_credibility,1,atol=1e-12),len(valid_weights))
add('smaa_confidence_bounded',sw.central_weight_confidence_factor.between(0,1).all(),'bounded')
add('smaa_design_distinct_from_full_scan',(sd.random_weight_vectors.eq(1000)&sd.physical_draws.eq(500)).all(),'1000x500 complementary rank analysis')

ev=read('prospective_evidence_value_by_service'); es=read('prospective_evidence_value_summary')
add('evidence_value_seven_services',ev.scenario.nunique()==7,ev.scenario.nunique())
base=ev[ev.closure_action=='baseline']
add('evidence_value_baseline_zero',np.allclose(base[['delta_expected_normalized_service_value','delta_expected_selected_credibility','delta_selection_probability']],0,atol=1e-12),base.shape)
add('evidence_value_no_monetary_claim',es.interpretation.str.contains('not monetary',case=False).all(),'scope explicit')
add('evidence_value_has_non_dominated_actions',es.evidence_value_non_dominated_under_registered_ordering.any(),es.loc[es.evidence_value_non_dominated_under_registered_ordering,'closure_action'].tolist())
add('evidence_value_signed_outcomes_retained',(es.services_with_adverse_service_value>=0).all() and (es.total_lost_selected>=0).all(),'negative outcomes explicitly counted')

critical_fail=[x for x in checks if x['critical'] and not x['passed']]
summary={'status':'PASS' if not critical_fail else 'FAIL','checks':len(checks),'passed':sum(x['passed'] for x in checks),'critical_failures':len(critical_fail),
         'method_scope':'core innovation validation: service-conditioned decision space, rank reversal, unsupervised archetypes, SMAA, prospective value of evidence.'}
pd.DataFrame(checks).to_csv(Q/f'{VERSION}_INNOVATION_VALIDATION_CHECKS.csv',index=False)
(Q/f'{VERSION}_INNOVATION_VALIDATION_SUMMARY.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
if critical_fail: raise SystemExit(1)
