from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"

Z95 = 1.959963984540054


def wilson(p: np.ndarray, n: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    n = np.asarray(n, dtype=float)
    p = np.asarray(p, dtype=float)
    denom = 1.0 + Z95**2 / n
    center = (p + Z95**2 / (2.0 * n)) / denom
    half = Z95 * np.sqrt((p * (1.0 - p) / n) + Z95**2 / (4.0 * n**2)) / denom
    return np.maximum(0.0, center - half), np.minimum(1.0, center + half)


def add_uncertainty(frame: pd.DataFrame, frequency_col: str, n_col: str) -> pd.DataFrame:
    out = frame.copy()
    p = pd.to_numeric(out[frequency_col], errors="coerce").to_numpy(float)
    n = pd.to_numeric(out[n_col], errors="coerce").to_numpy(float)
    good = np.isfinite(p) & np.isfinite(n) & (n > 0)
    se = np.full(len(out), np.nan)
    lo = np.full(len(out), np.nan)
    hi = np.full(len(out), np.nan)
    se[good] = np.sqrt(p[good] * (1.0 - p[good]) / n[good])
    lo[good], hi[good] = wilson(p[good], n[good])
    out["monte_carlo_standard_error"] = se
    out["monte_carlo_wilson95_low"] = lo
    out["monte_carlo_wilson95_high"] = hi
    out["monte_carlo_wilson95_half_width"] = (hi - lo) / 2.0
    out["numerical_uncertainty_scope"] = "finite_Monte_Carlo_sampling_error_only; excludes epistemic/model uncertainty"
    return out


def main() -> None:
    core_path = TABLES / "core_layered_selection_frequencies.csv"
    core = pd.read_csv(core_path)
    add_uncertainty(core, "selection_frequency", "mc_iterations").to_csv(
        TABLES / "core_selection_frequency_numerical_uncertainty.csv",
        index=False,
        encoding="utf-8-sig",
    )

    for input_name, output_name in [
        ("expanded_v3_thermophysical_opportunity_mc.csv", "expanded_v3_all_quantitative_mc_numerical_uncertainty.csv"),
        ("expanded_v3_domain_validated_thermophysical_mc.csv", "expanded_v3_service_domain_supported_mc_numerical_uncertainty.csv"),
    ]:
        path = TABLES / input_name
        if path.exists():
            frame = pd.read_csv(path)
            add_uncertainty(frame, "thermophysical_rank1_frequency", "iterations").to_csv(
                TABLES / output_name,
                index=False,
                encoding="utf-8-sig",
            )

    print({"status": "PASS", "z95": Z95, "method": "binomial_standard_error_and_Wilson_95pct_interval"})


if __name__ == "__main__":
    main()
