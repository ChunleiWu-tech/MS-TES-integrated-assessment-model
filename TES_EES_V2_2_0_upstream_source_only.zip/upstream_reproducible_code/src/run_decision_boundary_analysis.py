from __future__ import annotations

from itertools import combinations
from pathlib import Path
import hashlib
import json
import math

import numpy as np
import pandas as pd

BASE_VERSION = "core"
VERSION = "decision_boundary"
ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
SEED = 134_760_076
MATERIALITY = 0.01
ATOMIC_DIMS = (
    "corrosion_compatibility",
    "cycling_phase_stability",
    "containment_validation",
    "literature_replication",
    "data_completeness",
)
GAP_MAP = {
    "corrosion_compatibility": "gap_corrosion",
    "cycling_phase_stability": "gap_cycling_phase",
    "containment_validation": "gap_containment",
    "literature_replication": "gap_literature_validation",
    "data_completeness": "gap_data_completeness",
}
CLOSURE_FLOOR = {
    "corrosion_compatibility": 0.75,
    "cycling_phase_stability": 0.75,
    "containment_validation": 0.75,
    "literature_replication": 0.80,
    "data_completeness": 0.75,
}


def read(stem: str, **kwargs) -> pd.DataFrame:
    path = TABLES / f"{BASE_VERSION}_{stem}.csv"
    if not path.exists():
        raise FileNotFoundError(path)
    return pd.read_csv(path, **kwargs)


def write(frame: pd.DataFrame, stem: str) -> Path:
    path = TABLES / f"{VERSION}_{stem}.csv"
    frame.to_csv(path, index=False)
    return path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def minmax(values: np.ndarray, mask: np.ndarray) -> np.ndarray:
    out = np.full_like(values, np.nan, dtype=float)
    for i in range(values.shape[0]):
        m = mask[i] & np.isfinite(values[i])
        if not m.any():
            continue
        x = values[i, m]
        lo, hi = float(np.min(x)), float(np.max(x))
        out[i, m] = 0.5 if hi - lo < 1e-12 else (x - lo) / (hi - lo)
    return out


def credibility(scores: dict[str, np.ndarray], burden: np.ndarray, feasible: np.ndarray) -> np.ndarray:
    inv_burden = 1.0 - minmax(burden, feasible)
    stack = np.stack([scores[d] for d in ATOMIC_DIMS] + [inv_burden], axis=2)
    out = np.exp(np.nanmean(np.log(np.clip(stack, 1e-9, 1.0)), axis=2))
    out[~feasible] = np.nan
    return out


def nondominated(x: np.ndarray, y: np.ndarray, valid: np.ndarray) -> np.ndarray:
    flags = np.zeros(len(x), dtype=bool)
    ids = np.flatnonzero(valid & np.isfinite(x) & np.isfinite(y))
    for i in ids:
        dominated = False
        for j in ids:
            if i == j:
                continue
            if x[j] >= x[i] and y[j] >= y[i] and (x[j] > x[i] or y[j] > y[i]):
                dominated = True
                break
        flags[i] = not dominated
    return flags


def state_class(row: pd.Series) -> str:
    if float(row.get("physical_window_coverage", 0.0)) <= 0:
        return "outside_standardized_service"
    if not bool(row.get("strict_complete_physical_service_feasible", False)):
        return "physical_service_window_limited"
    if not bool(row.get("strict_complete_thermophysical_feasible", False)):
        return "thermophysical_domain_limited"
    if bool(row.get("nonclosable_direct_risk", False)):
        return "direct_risk_excluded"
    if int(row.get("closable_gap_count", 0)) > 0:
        return "evidence_limited"
    return "decision_ready"


def thermophysical_requirement(row: pd.Series) -> str:
    if float(row.get("strict_complete_service_probability", 0.0)) > 0:
        return "none"
    if float(row.get("physical_window_coverage", 0.0)) <= 0:
        return "service_temperature_or_phase_match_change_required"
    if bool(row.get("strict_complete_physical_service_feasible", False)) and not bool(row.get("strict_complete_thermophysical_feasible", False)):
        return "exact_composition_full_interval_property_measurement_required"
    return "physical_service_window_redesign_or_material_change_required"


def build_scope_and_modal_frontier() -> tuple[pd.DataFrame, pd.DataFrame]:
    profile = read("candidate_readiness_profile")
    decision = read("integrated_system_decision_table")
    ledger = read("candidate_service_evidence_score_ledger")
    use = decision[[
        "scenario", "scenario_label", "system_id", "display_system", "family",
        "physical_window_coverage", "fixed_window_coverage",
        "strict_complete_physical_service_feasible", "strict_complete_thermophysical_feasible",
        "property_domain_extrapolation_required", "partial_overlap_energy_fixed_kWh_m3",
        "complete_service_energy_fixed_kWh_m3", "raw_material_cost_proxy_mid_usd_kWhth",
    ]].drop_duplicates(["scenario", "system_id"])
    p = profile.merge(use, on=["scenario", "scenario_label", "system_id", "display_system", "family"], how="left")
    lcols = ["scenario", "system_id", "engineering_credibility_mid", "atomic_evidence_geometric_mid", "baseline_evidence_qualified"]
    p = p.merge(ledger[lcols], on=["scenario", "system_id"], how="left")
    p["decision_scope_class"] = p.apply(state_class, axis=1)
    p["thermophysical_upgrade_requirement"] = p.apply(thermophysical_requirement, axis=1)
    p["required_evidence_dimensions"] = p.apply(
        lambda r: ";".join([d for d, g in GAP_MAP.items() if bool(r.get(g, False))]) or "none", axis=1
    )
    p["opportunity_performance_kWh_m3"] = p["partial_overlap_energy_fixed_kWh_m3"]
    p["strict_performance_kWh_m3"] = p["energy_density_p50_kWh_m3_conditional_on_adequacy"]
    p["performance_value_used_for_frontier"] = p["opportunity_performance_kWh_m3"]
    p["performance_basis"] = np.where(
        p.strict_complete_thermophysical_feasible.fillna(False),
        "strict-complete median when available; opportunity value retained for common-scope frontier",
        "partial-overlap opportunity only; not a deployability claim",
    )
    p["modal_engineering_credibility"] = p["engineering_credibility_mid"]
    # Reconstruct a comparable modal credibility for rows excluded before bounded scoring.
    for scenario, idx in p.groupby("scenario").groups.items():
        ix = list(idx)
        physical = p.loc[ix, "physical_window_coverage"].fillna(0).to_numpy(float) > 0
        burden = p.loc[ix, "engineering_burden_index"].to_numpy(float)
        inv = np.full(len(ix), np.nan)
        if physical.any():
            x = burden[physical]; lo, hi = np.nanmin(x), np.nanmax(x)
            inv[physical] = 0.5 if hi - lo < 1e-12 else 1.0 - (x - lo) / (hi - lo)
        dims = p.loc[ix, [f"{d}_score" for d in ATOMIC_DIMS]].to_numpy(float)
        modal = np.exp(np.nanmean(np.log(np.clip(np.column_stack([dims, inv]), 1e-9, 1.0)), axis=1))
        p.loc[ix, "modal_engineering_credibility_unbounded"] = modal
        perf = p.loc[ix, "opportunity_performance_kWh_m3"].to_numpy(float)
        pnorm = np.full(len(ix), np.nan)
        valid = physical & np.isfinite(perf)
        if valid.any():
            lo, hi = np.nanmin(perf[valid]), np.nanmax(perf[valid])
            pnorm[valid] = 0.5 if hi - lo < 1e-12 else (perf[valid] - lo) / (hi - lo)
        p.loc[ix, "opportunity_performance_normalized"] = pnorm
        p.loc[ix, "opportunity_pareto_front"] = nondominated(pnorm, modal, valid)
        strict_valid = valid & p.loc[ix, "strict_complete_thermophysical_feasible"].fillna(False).to_numpy(bool)
        p.loc[ix, "strict_thermophysical_pareto_front"] = nondominated(pnorm, modal, strict_valid)
    p["current_strict_selection"] = p.evidence_qualified_selection_frequency.fillna(0) >= MATERIALITY
    p["interpretation_boundary"] = (
        "Opportunity-frontier status uses physically overlapping partial-service performance and unbounded modal evidence readiness. "
        "It identifies research opportunities, not current deployability. Strict selection remains governed by complete-service and non-compensatory evidence gates."
    )
    scope_cols = [
        "scenario", "scenario_label", "system_id", "display_system", "family", "decision_scope_class",
        "physical_window_coverage", "fixed_window_coverage", "strict_complete_service_probability",
        "strict_complete_thermophysical_feasible", "strict_complete_physical_service_feasible",
        "evidence_qualified_selection_frequency", "closable_gap_count", "required_evidence_dimensions",
        "thermophysical_upgrade_requirement", "nonclosable_direct_risk",
    ]
    frontier_cols = [
        "scenario", "scenario_label", "system_id", "display_system", "family",
        "opportunity_performance_kWh_m3", "strict_performance_kWh_m3",
        "opportunity_performance_normalized", "modal_engineering_credibility_unbounded",
        "opportunity_pareto_front", "strict_thermophysical_pareto_front", "current_strict_selection",
        "decision_scope_class", "performance_basis", "interpretation_boundary",
    ]
    return p[scope_cols].copy(), p[frontier_cols].copy()


def scenario_matrices(g: pd.DataFrame) -> tuple[list[int], list[str], dict[str, np.ndarray]]:
    draws = sorted(g.draw_id.unique().tolist())
    systems = g.system_id.drop_duplicates().tolist()
    arrays: dict[str, np.ndarray] = {}
    for col in [
        "coverage", "partial_overlap_energy_density_kWh_m3", "complete_service_energy_density_kWh_m3",
        "strict_complete", "sampled_engineering_burden_index",
        *[f"sampled_{d}" for d in ATOMIC_DIMS],
    ]:
        arrays[col] = g.pivot(index="draw_id", columns="system_id", values=col).reindex(index=draws, columns=systems).to_numpy()
    return draws, systems, arrays


def draw_level_frontier_and_dependence() -> tuple[pd.DataFrame, pd.DataFrame]:
    cols = [
        "scenario", "scenario_label", "draw_id", "system_id", "display_system", "coverage",
        "partial_overlap_energy_density_kWh_m3", "complete_service_energy_density_kWh_m3", "strict_complete",
        "sampled_engineering_burden_index", *[f"sampled_{d}" for d in ATOMIC_DIMS],
    ]
    mc = read("monte_carlo_draws_balanced", usecols=cols)
    frontier_rows, dependence_rows = [], []
    for (scenario, label), g in mc.groupby(["scenario", "scenario_label"], sort=False):
        draws, systems, a = scenario_matrices(g)
        names = g.drop_duplicates("system_id").set_index("system_id").display_system.to_dict()
        physical = (a["coverage"] > 0) & np.isfinite(a["partial_overlap_energy_density_kWh_m3"])
        pscore = minmax(a["partial_overlap_energy_density_kWh_m3"], physical)
        scores = {d: a[f"sampled_{d}"] for d in ATOMIC_DIMS}
        cscore = credibility(scores, a["sampled_engineering_burden_index"], physical)
        strict = a["strict_complete"].astype(bool) & physical
        opportunity_flags = np.zeros_like(physical, dtype=bool)
        strict_flags = np.zeros_like(strict, dtype=bool)
        for i in range(len(draws)):
            opportunity_flags[i] = nondominated(pscore[i], cscore[i], physical[i])
            strict_flags[i] = nondominated(pscore[i], cscore[i], strict[i])
        for j, sid in enumerate(systems):
            valid = physical[:, j] & np.isfinite(pscore[:, j]) & np.isfinite(cscore[:, j])
            strict_valid = strict[:, j] & np.isfinite(pscore[:, j]) & np.isfinite(cscore[:, j])
            frontier_rows.append({
                "scenario": scenario, "scenario_label": label, "system_id": sid, "display_system": names[sid],
                "physical_opportunity_draws": int(valid.sum()), "strict_complete_draws": int(strict_valid.sum()),
                "opportunity_pareto_frequency": float(np.mean(opportunity_flags[:, j] & valid)),
                "conditional_opportunity_pareto_frequency": float(opportunity_flags[valid, j].mean()) if valid.any() else np.nan,
                "strict_pareto_frequency": float(np.mean(strict_flags[:, j] & strict_valid)),
                "conditional_strict_pareto_frequency": float(strict_flags[strict_valid, j].mean()) if strict_valid.any() else np.nan,
                "performance_score_mean": float(np.nanmean(pscore[valid, j])) if valid.any() else np.nan,
                "credibility_score_mean": float(np.nanmean(cscore[valid, j])) if valid.any() else np.nan,
                "frontier_scope_note": "Pareto frequencies are two-dimensional and weight-free. Opportunity frequencies include partial-service states and therefore are diagnostic rather than deployability claims.",
            })
            if valid.sum() >= 3 and np.nanstd(pscore[valid, j]) > 0 and np.nanstd(cscore[valid, j]) > 0:
                pearson = float(pd.Series(pscore[valid, j]).corr(pd.Series(cscore[valid, j]), method="pearson"))
                spearman = float(pd.Series(pscore[valid, j]).corr(pd.Series(cscore[valid, j]), method="spearman"))
                cov = float(np.cov(pscore[valid, j], cscore[valid, j], ddof=1)[0, 1])
            else:
                pearson = spearman = cov = np.nan
            dependence_rows.append({
                "scenario": scenario, "scenario_label": label, "system_id": sid, "display_system": names[sid],
                "joint_valid_draws": int(valid.sum()), "pearson_performance_credibility": pearson,
                "spearman_performance_credibility": spearman, "covariance_performance_credibility": cov,
                "interpretation_boundary": "This is a model-architecture dependence audit. Physical-property and evidence draws are registered as separate uncertainty streams; correlation is not experimental evidence that material performance causes evidence maturity.",
            })
    return pd.DataFrame(frontier_rows), pd.DataFrame(dependence_rows)


def utility_metrics(performance: np.ndarray, scores: dict[str, np.ndarray], burden: np.ndarray,
                    strict: np.ndarray, allowed: np.ndarray, weights: np.ndarray,
                    systems: list[str]) -> tuple[dict[str, float | str], np.ndarray]:
    feasible = strict & allowed[None, :]
    pscore = minmax(performance, feasible)
    cscore = credibility(scores, burden, feasible)
    utility = weights[:, [0]] * pscore + weights[:, [1]] * cscore
    utility[~feasible] = -np.inf
    no = ~np.isfinite(utility).any(axis=1)
    winner = np.argmax(utility, axis=1)
    counts = np.array([np.mean((winner == j) & ~no) for j in range(len(systems))])
    if counts.max(initial=0) > 0:
        leader_j = int(np.argmax(counts)); leader = systems[leader_j]
    else:
        leader = "__NO_SELECTION__"
    p = counts[counts > 0]
    no_freq = float(no.mean())
    probs = np.append(p, no_freq) if no_freq > 0 else p
    entropy = float(-(probs * np.log2(probs)).sum()) if len(probs) else 0.0
    order = np.sort(counts)[::-1]
    gap = float(order[0] - order[1]) if len(order) > 1 else float(order[0]) if len(order) else 0.0
    return {
        "no_selection_frequency": no_freq, "selection_entropy_bits": entropy,
        "top1_top2_frequency_gap": gap, "modal_leader_system_id": leader,
    }, counts


def decision_boundary_backtrace(scope: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    cols = [
        "scenario", "scenario_label", "draw_id", "system_id", "display_system", "strict_complete",
        "complete_service_energy_density_kWh_m3", "sampled_engineering_burden_index",
        *[f"sampled_{d}" for d in ATOMIC_DIMS],
    ]
    mc = read("monte_carlo_draws_balanced", usecols=cols)
    ledger = read("candidate_service_evidence_score_ledger")
    states, minima = [], []
    for service_index, ((scenario, label), g) in enumerate(mc.groupby(["scenario", "scenario_label"], sort=False)):
        draws, systems, a = scenario_matrices(g.assign(
            coverage=1.0,
            partial_overlap_energy_density_kWh_m3=g["complete_service_energy_density_kWh_m3"],
        ))
        names = g.drop_duplicates("system_id").set_index("system_id").display_system.to_dict()
        strict = a["strict_complete"].astype(bool)
        performance = a["complete_service_energy_density_kWh_m3"]
        scores0 = {d: a[f"sampled_{d}"].copy() for d in ATOMIC_DIMS}
        burden = a["sampled_engineering_burden_index"]
        reg = ledger[ledger.scenario.eq(scenario)].drop_duplicates("system_id").set_index("system_id").loc[systems]
        gaps = {d: reg[GAP_MAP[d]].astype(bool).to_numpy() for d in ATOMIC_DIMS}
        direct = reg.nonclosable_direct_risk.astype(bool).to_numpy()
        baseline_allowed = ~(np.column_stack(list(gaps.values())).any(axis=1) | direct)
        weights = np.random.default_rng(SEED + service_index * 10_000).dirichlet(np.ones(2), len(draws))
        baseline_met, baseline_counts = utility_metrics(performance, scores0, burden, strict, baseline_allowed, weights, systems)
        for j, sid in enumerate(systems):
            row_scope = scope[(scope.scenario == scenario) & (scope.system_id == sid)].iloc[0]
            required = [d for d in ATOMIC_DIMS if gaps[d][j]]
            if bool(direct[j]):
                minima.append({
                    "scenario": scenario, "scenario_label": label, "system_id": sid, "display_system": names[sid],
                    "current_scope_class": row_scope.decision_scope_class,
                    "minimum_research_route": "not closable by favourable evidence counterfactual because direct-risk exclusion is retained",
                    "thermophysical_requirement": row_scope.thermophysical_upgrade_requirement,
                    "minimum_atomic_evidence_set": ";".join(required) or "none",
                    "decision_effect_quantifiable_with_current_data": False,
                    "minimum_set_for_1pct_selection": "not estimable", "estimated_selection_frequency_after_minimum_set": np.nan,
                    "stop_or_go_class": "direct-risk stop rule",
                })
                continue
            strict_prob = float(row_scope.strict_complete_service_probability)
            if strict_prob <= 0:
                if row_scope.decision_scope_class == "outside_standardized_service":
                    go = "service mismatch; do not prioritize evidence-only testing for this service"
                elif row_scope.decision_scope_class in {"thermophysical_domain_limited", "physical_service_window_limited"}:
                    go = "measure or redesign thermophysical service support before decision-ranking experiments"
                else:
                    go = "decision effect unresolved"
                minima.append({
                    "scenario": scenario, "scenario_label": label, "system_id": sid, "display_system": names[sid],
                    "current_scope_class": row_scope.decision_scope_class,
                    "minimum_research_route": "; ".join([x for x in [row_scope.thermophysical_upgrade_requirement, *(required or ["no additional registered atomic gap"])] if x != "none"]),
                    "thermophysical_requirement": row_scope.thermophysical_upgrade_requirement,
                    "minimum_atomic_evidence_set": ";".join(required) or "none",
                    "decision_effect_quantifiable_with_current_data": False,
                    "minimum_set_for_1pct_selection": "not estimable until complete-service properties are measured",
                    "estimated_selection_frequency_after_minimum_set": np.nan,
                    "stop_or_go_class": go,
                })
                continue
            subsets = [tuple()]
            for k in range(1, len(required) + 1):
                subsets.extend(combinations(required, k))
            target_rows = []
            for subset in subsets:
                closed = set(subset)
                allowed = baseline_allowed.copy()
                unresolved_target = any(d not in closed for d in required)
                allowed[j] = not unresolved_target
                scores = {d: x.copy() for d, x in scores0.items()}
                for d in closed:
                    scores[d][:, j] = np.maximum(scores[d][:, j], CLOSURE_FLOOR[d])
                met, counts = utility_metrics(performance, scores, burden, strict, allowed, weights, systems)
                record = {
                    "scenario": scenario, "scenario_label": label, "system_id": sid, "display_system": names[sid],
                    "closed_atomic_evidence_set": ";".join(subset) or "none",
                    "closed_dimension_count": len(subset), "all_registered_target_gaps_closed": not unresolved_target,
                    "target_selection_frequency": float(counts[j]),
                    "delta_target_selection_frequency": float(counts[j] - baseline_counts[j]),
                    "baseline_target_selection_frequency": float(baseline_counts[j]),
                    "no_selection_frequency": met["no_selection_frequency"],
                    "delta_no_selection_frequency": float(baseline_met["no_selection_frequency"] - met["no_selection_frequency"]),
                    "selection_entropy_bits": met["selection_entropy_bits"],
                    "modal_leader_system_id": met["modal_leader_system_id"],
                    "leader_changed": met["modal_leader_system_id"] != baseline_met["modal_leader_system_id"],
                    "counterfactual_scope": "targeted atomic evidence closure only; thermophysical service definition and all other candidates remain fixed",
                }
                states.append(record); target_rows.append(record)
            target_df = pd.DataFrame(target_rows)
            qualifying = target_df[target_df.target_selection_frequency >= MATERIALITY].sort_values(
                ["closed_dimension_count", "target_selection_frequency", "closed_atomic_evidence_set"], ascending=[True, False, True]
            )
            if not qualifying.empty:
                best = qualifying.iloc[0]
                minset, freq = best.closed_atomic_evidence_set, float(best.target_selection_frequency)
            else:
                minset, freq = "none of the registered targeted closure states", np.nan
            if not required and baseline_counts[j] >= MATERIALITY:
                stop_go = "already decision-ready; further registered gap closure has no defined target"
            elif np.isfinite(freq):
                stop_go = "go: registered evidence closure can cross the material-selection boundary"
            else:
                stop_go = "stop or redesign: evidence closure alone does not create material selection"
            minima.append({
                "scenario": scenario, "scenario_label": label, "system_id": sid, "display_system": names[sid],
                "current_scope_class": row_scope.decision_scope_class,
                "minimum_research_route": minset,
                "thermophysical_requirement": "none",
                "minimum_atomic_evidence_set": ";".join(required) or "none",
                "decision_effect_quantifiable_with_current_data": True,
                "minimum_set_for_1pct_selection": minset,
                "estimated_selection_frequency_after_minimum_set": freq,
                "stop_or_go_class": stop_go,
            })
    return pd.DataFrame(states), pd.DataFrame(minima)


def gradient_summary() -> tuple[pd.DataFrame, pd.DataFrame]:
    sel = read("service_coverage_threshold_selection_frequencies")
    rows = []
    for (scenario, sid, name), g in sel.groupby(["scenario", "system_id", "display_system"]):
        material = g[g.selection_frequency >= MATERIALITY]
        rows.append({
            "scenario": scenario, "system_id": sid, "display_system": name,
            "enters_material_selection_in_coverage_sweep": not material.empty,
            "least_strict_coverage_threshold_tested": float(g.coverage_threshold.min()),
            "strictest_coverage_threshold_with_1pct_selection": float(material.coverage_threshold.max()) if not material.empty else np.nan,
            "maximum_selection_frequency": float(g.selection_frequency.max()),
            "coverage_threshold_at_maximum_selection": float(g.loc[g.selection_frequency.idxmax(), "coverage_threshold"]),
            "interpretation_boundary": "Coverage sweeps are labelled service-design sensitivities. They do not replace the strict-complete baseline.",
        })
    joint = read("joint_threshold_regime_map")
    joint_summary = joint.groupby(["scenario", "scenario_label", "decision_regime"], as_index=False).size().rename(columns={"size": "grid_cells"})
    joint_summary["grid_share"] = joint_summary.groupby("scenario").grid_cells.transform(lambda x: x / x.sum())
    return pd.DataFrame(rows), joint_summary


def main() -> None:
    TABLES.mkdir(parents=True, exist_ok=True); QC.mkdir(parents=True, exist_ok=True)
    baseline_files = [
        TABLES / f"{BASE_VERSION}_integrated_system_decision_table.csv",
        TABLES / f"{BASE_VERSION}_monte_carlo_draws_balanced.csv",
        TABLES / f"{BASE_VERSION}_layered_selection_frequencies.csv",
    ]
    baseline_hashes_before = {p.name: sha256(p) for p in baseline_files}
    scope, modal_frontier = build_scope_and_modal_frontier()
    draw_frontier, dependence = draw_level_frontier_and_dependence()
    states, minima = decision_boundary_backtrace(scope)
    coverage_entry, joint_summary = gradient_summary()
    outputs = {
        "decision_scope_matrix": scope,
        "performance_evidence_pareto_summary": modal_frontier,
        "draw_level_performance_evidence_pareto_frequency": draw_frontier,
        "performance_evidence_dependence_audit": dependence,
        "decision_boundary_backtrace_states": states,
        "decision_boundary_minimum_upgrade": minima,
        "coverage_gradient_candidate_entry_summary": coverage_entry,
        "joint_threshold_regime_compact_summary": joint_summary,
    }
    paths = [write(df, stem) for stem, df in outputs.items()]
    baseline_hashes_after = {p.name: sha256(p) for p in baseline_files}
    invariant = baseline_hashes_before == baseline_hashes_after
    status = {
        "version": VERSION,
        "status": "PASS" if invariant else "FAIL",
        "base_version": BASE_VERSION,
        "baseline_files_unchanged": invariant,
        "generated_tables": {p.name: int(pd.read_csv(p).shape[0]) for p in paths},
        "scientific_scope": [
            "strict baseline preserved",
            "weight-free two-dimensional performance-evidence Pareto diagnostics",
            "coverage and evidence-threshold gradient synthesis",
            "targeted atomic-evidence decision-boundary back-tracing",
            "performance-evidence dependence audit",
        ],
        "interpretation_boundary": "decision_boundary adds diagnostic and prospective research-priority outputs. It does not relax or overwrite the core strict-complete evidence-bounded baseline.",
    }
    (QC / f"{VERSION}_DECISION_BOUNDARY_EXTENSION_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))
    if not invariant:
        raise SystemExit("Baseline output changed during diagnostic extension")


if __name__ == "__main__":
    main()
