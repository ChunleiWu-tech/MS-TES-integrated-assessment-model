from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "input"
CONFIG = ROOT / "config"
TABLES = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
TABLES.mkdir(parents=True, exist_ok=True)
QC.mkdir(parents=True, exist_ok=True)

SEED = 9062026
N_MC = int(os.environ.get("TES_N_MC", "20000"))
if N_MC < 100:
    raise ValueError("TES_N_MC must be at least 100")


def as_bool(series: pd.Series) -> pd.Series:
    return series.map(lambda value: value if isinstance(value, bool) else str(value).strip().lower() in {"true", "1", "yes", "y"})


def numeric(frame: pd.DataFrame, columns: list[str]) -> None:
    for column in columns:
        frame[column] = pd.to_numeric(frame[column], errors="coerce")


def triangular_or_constant(rng: np.random.Generator, low: float, mode: float, high: float, n: int) -> np.ndarray:
    if not np.isfinite(mode):
        return np.full(n, np.nan)
    if not np.isfinite(low) or not np.isfinite(high) or abs(high - low) < 1e-14:
        return np.full(n, mode)
    lo = min(low, mode, high)
    hi = max(low, mode, high)
    md = min(max(mode, lo), hi)
    return rng.triangular(lo, md, hi, n)


def capacity_intervals(evidence: pd.DataFrame) -> pd.DataFrame:
    out = evidence.copy()
    measured = out.base_capacity_value.notna() & out.composite_capacity_value.notna()
    out["capacity_ratio"] = out.capacity_ratio_reported
    out.loc[measured, "capacity_ratio"] = (
        out.loc[measured, "composite_capacity_value"] / out.loc[measured, "base_capacity_value"]
    )
    out["capacity_ratio_low"] = out.capacity_ratio
    out["capacity_ratio_high"] = out.capacity_ratio
    out["capacity_uncertainty_basis"] = np.where(out.capacity_ratio.notna(), "reported_point_value", "not_quantified")

    replicated = measured & out.replicate_n.notna() & out.base_capacity_sd.notna() & out.composite_capacity_sd.notna()
    if replicated.any():
        n = out.loc[replicated, "replicate_n"].clip(lower=1.0)
        ratio = out.loc[replicated, "capacity_ratio"]
        relative_se = np.sqrt(
            (out.loc[replicated, "composite_capacity_sd"] / (out.loc[replicated, "composite_capacity_value"] * np.sqrt(n))) ** 2
            + (out.loc[replicated, "base_capacity_sd"] / (out.loc[replicated, "base_capacity_value"] * np.sqrt(n))) ** 2
        )
        ratio_se = ratio * relative_se
        out.loc[replicated, "capacity_ratio_low"] = (ratio - 1.645 * ratio_se).clip(lower=0.0)
        out.loc[replicated, "capacity_ratio_high"] = ratio + 1.645 * ratio_se
        out.loc[replicated, "capacity_uncertainty_basis"] = "independent_90pct_delta_interval_from_reported_replicate_SD"

    protocol = measured & out.protocol_sensitivity_fraction.notna()
    if protocol.any():
        sensitivity = out.loc[protocol, "protocol_sensitivity_fraction"].clip(lower=0.0)
        out.loc[protocol, "capacity_ratio_low"] = out.loc[protocol, "capacity_ratio"] * (1.0 - sensitivity)
        out.loc[protocol, "capacity_ratio_high"] = out.loc[protocol, "capacity_ratio"] * (1.0 + sensitivity)
        out.loc[protocol, "capacity_uncertainty_basis"] = (
            "symmetric_6pct_protocol_sensitivity_scenario_"
            "motivated_by_approximate_scan_rate_difference"
        )

    latent = out.base_latent_kJ_kg.notna() & out.composite_latent_kJ_kg.notna()
    out["latent_ratio"] = np.nan
    out.loc[latent, "latent_ratio"] = out.loc[latent, "composite_latent_kJ_kg"] / out.loc[latent, "base_latent_kJ_kg"]
    out["latent_ratio_low"] = out.latent_ratio
    out["latent_ratio_high"] = out.latent_ratio
    out.loc[latent & out.protocol_sensitivity_fraction.notna(), "latent_ratio_low"] = (
        out.loc[latent & out.protocol_sensitivity_fraction.notna(), "latent_ratio"]
        * (1.0 - out.loc[latent & out.protocol_sensitivity_fraction.notna(), "protocol_sensitivity_fraction"])
    )
    out.loc[latent & out.protocol_sensitivity_fraction.notna(), "latent_ratio_high"] = (
        out.loc[latent & out.protocol_sensitivity_fraction.notna(), "latent_ratio"]
        * (1.0 + out.loc[latent & out.protocol_sensitivity_fraction.notna(), "protocol_sensitivity_fraction"])
    )

    out["capacity_gain_resolved"] = out.capacity_ratio_low.gt(1.0)
    out["capacity_penalty_resolved"] = out.capacity_ratio_high.lt(1.0)
    out["capacity_response_class"] = np.select(
        [out.capacity_gain_resolved, out.capacity_penalty_resolved, out.capacity_ratio.notna()],
        ["resolved_gain", "resolved_penalty", "interval_crosses_no_change"],
        default="direction_only_or_unreported",
    )
    out["latent_gain_resolved"] = out.latent_ratio_low.gt(1.0)
    out["latent_penalty_resolved"] = out.latent_ratio_high.lt(1.0)
    out["active_salt_fraction_derived"] = out.active_salt_mass_fraction
    nanoparticle_mass_known = out.active_salt_fraction_derived.isna() & out.additive_fraction_wt_pct.notna() & out.evidence_mode.eq("latent_nanocomposite")
    out.loc[nanoparticle_mass_known, "active_salt_fraction_derived"] = 1.0 - out.loc[nanoparticle_mass_known, "additive_fraction_wt_pct"] / 100.0
    out["bidirectional_power_ratio"] = np.minimum(out.charge_power_ratio, out.discharge_power_ratio)
    out["charge_discharge_asymmetry"] = out.charge_power_ratio / out.discharge_power_ratio
    return out


def service_coupling(property_response: pd.DataFrame, deterministic: pd.DataFrame, services: pd.DataFrame, strict_coverage: float, minimum_cycles: int) -> pd.DataFrame:
    candidates = property_response[property_response.base_system_id.notna()].copy()
    coupled = candidates.merge(deterministic, on="base_system_id", how="left", suffixes=("", "_base"))
    coupled = coupled.merge(
        services[["scenario", "service_mode", "fixed_Tcold_C", "fixed_Thot_C", "phase_target_min_C", "phase_target_max_C"]],
        on=["scenario", "service_mode"], how="left", validate="many_to_one"
    )
    coupled["service_low_C"] = np.where(coupled.service_mode.eq("sensible"), coupled.fixed_Tcold_C, coupled.phase_target_min_C)
    coupled["service_high_C"] = np.where(coupled.service_mode.eq("sensible"), coupled.fixed_Thot_C, coupled.phase_target_max_C)
    span = coupled.service_high_C - coupled.service_low_C
    overlap = np.maximum(
        0.0,
        np.minimum(coupled.temperature_high_C, coupled.service_high_C)
        - np.maximum(coupled.temperature_low_C, coupled.service_low_C),
    )
    coupled["composite_domain_coverage"] = np.where(
        coupled.temperature_low_C.notna() & coupled.temperature_high_C.notna() & span.gt(0),
        overlap / span,
        0.0,
    )
    coupled["mode_match"] = (
        coupled.service_domain.eq("sensible_liquid") & coupled.service_mode.eq("sensible")
    ) | (
        coupled.service_domain.eq("stationary_sensible") & coupled.service_mode.eq("sensible")
    ) | (
        coupled.service_domain.eq("latent_pcm") & coupled.service_mode.eq("latent")
    )
    coupled["base_full_duty_qualified"] = as_bool(coupled.strict_complete_service_feasible)
    coupled["full_composite_domain"] = coupled.composite_domain_coverage.ge(strict_coverage)
    coupled["durability_screen_pass"] = pd.to_numeric(coupled.cycle_count, errors="coerce").fillna(0).ge(minimum_cycles)
    coupled["compatibility_direct"] = ~coupled.compatibility_state.fillna("not_reported").isin(
        ["not_reported", "corrosion_reduction_reported_without_ratio"]
    )
    coupled["dispersion_or_structure_reported"] = coupled.dispersion_state.fillna("not_reported").ne("not_reported")
    coupled["mobile_metric_complete"] = (
        coupled.capacity_ratio.notna()
        & coupled.viscosity_ratio.notna()
        & coupled.dispersion_or_structure_reported
        & coupled.compatibility_direct
    )
    coupled["stationary_metric_complete"] = (
        (coupled.capacity_ratio.notna() | coupled.latent_ratio.notna())
        & coupled.active_salt_fraction_derived.notna()
        & coupled.charge_power_ratio.notna()
        & coupled.discharge_power_ratio.notna()
        & coupled.compatibility_direct
    )
    coupled["composite_metric_complete"] = np.where(
        coupled.evidence_mode.eq("mobile_nanofluid"),
        coupled.mobile_metric_complete,
        coupled.stationary_metric_complete,
    )
    coupled["formal_composite_eligible"] = (
        as_bool(coupled.exact_base_link)
        & coupled.base_full_duty_qualified
        & coupled.mode_match
        & coupled.full_composite_domain
        & coupled.composite_metric_complete
        & coupled.durability_screen_pass
    )

    reasons = []
    for row in coupled.itertuples(index=False):
        gap = []
        if not bool(row.exact_base_link): gap.append("exact_base_identity")
        if not bool(row.base_full_duty_qualified): gap.append("base_full_duty")
        if not bool(row.mode_match): gap.append("service_mode")
        if not bool(row.full_composite_domain): gap.append("composite_temperature_domain")
        if not bool(row.composite_metric_complete): gap.append("system_metrics")
        if not bool(row.durability_screen_pass): gap.append("durability")
        reasons.append("none" if not gap else ";".join(gap))
    coupled["formal_gap_set"] = reasons
    keep = [
        "record_id", "source_id", "evidence_mode", "base_system_id", "scenario", "scenario_label",
        "service_mode", "additive", "additive_fraction_wt_pct", "condition_label", "exact_base_link",
        "base_full_duty_qualified", "mode_match", "service_low_C", "service_high_C",
        "temperature_low_C", "temperature_high_C", "composite_domain_coverage", "full_composite_domain",
        "capacity_ratio", "capacity_ratio_low", "capacity_ratio_high", "latent_ratio", "latent_ratio_low",
        "latent_ratio_high", "thermal_conductivity_ratio", "viscosity_ratio", "charge_power_ratio",
        "discharge_power_ratio", "bidirectional_power_ratio", "active_salt_fraction_derived",
        "corrosion_rate_ratio", "dispersion_state", "compatibility_state", "composite_metric_complete",
        "durability_screen_pass", "formal_composite_eligible", "formal_gap_set",
    ]
    return coupled[keep].sort_values(["record_id", "scenario"]).reset_index(drop=True)


def dynamic_monte_carlo(property_response: pd.DataFrame, beta_low: float, beta_high: float) -> pd.DataFrame:
    rng = np.random.default_rng(SEED)
    rows: list[dict[str, object]] = []
    for row in property_response.itertuples(index=False):
        payload: dict[str, object] = {
            "record_id": row.record_id,
            "source_id": row.source_id,
            "evidence_mode": row.evidence_mode,
            "additive": row.additive,
            "condition_label": row.condition_label,
            "mc_iterations": N_MC,
            "hydraulic_exponent_low": beta_low,
            "hydraulic_exponent_high": beta_high,
        }
        if np.isfinite(row.capacity_ratio) and np.isfinite(row.viscosity_ratio):
            cap = triangular_or_constant(rng, row.capacity_ratio_low, row.capacity_ratio, row.capacity_ratio_high, N_MC)
            beta = rng.uniform(beta_low, beta_high, N_MC)
            pump = float(row.viscosity_ratio) ** beta
            capacity_pump = cap / pump
            payload.update({
                "capacity_pumping_index_p05": float(np.quantile(capacity_pump, 0.05)),
                "capacity_pumping_index_p50": float(np.quantile(capacity_pump, 0.50)),
                "capacity_pumping_index_p95": float(np.quantile(capacity_pump, 0.95)),
                "probability_capacity_pumping_index_gt_1": float(np.mean(capacity_pump > 1.0)),
                "capacity_pumping_index_beta025": float(row.capacity_ratio / (row.viscosity_ratio ** beta_low)),
                "capacity_pumping_index_beta100": float(row.capacity_ratio / (row.viscosity_ratio ** beta_high)),
            })
            if np.isfinite(row.thermal_conductivity_ratio):
                transport = capacity_pump * float(row.thermal_conductivity_ratio)
                payload.update({
                    "transport_adjusted_index_p05": float(np.quantile(transport, 0.05)),
                    "transport_adjusted_index_p50": float(np.quantile(transport, 0.50)),
                    "transport_adjusted_index_p95": float(np.quantile(transport, 0.95)),
                    "probability_transport_adjusted_index_gt_1": float(np.mean(transport > 1.0)),
                })
        if np.isfinite(row.bidirectional_power_ratio):
            payload.update({
                "bidirectional_power_ratio": float(row.bidirectional_power_ratio),
                "charge_discharge_asymmetry": float(row.charge_discharge_asymmetry),
            })
        rows.append(payload)
    return pd.DataFrame(rows)


def main() -> None:
    sources = pd.read_csv(INPUT / "core_composite_source_registry.csv")
    evidence = pd.read_csv(INPUT / "core_composite_evidence_registry.csv")
    assumptions = pd.read_csv(CONFIG / "core_composite_model_assumptions.csv")
    deterministic = pd.read_csv(TABLES / "core_candidate_system_metrics_deterministic.csv")
    services = pd.read_csv(CONFIG / "core_system_benchmarks.csv")
    deterministic = deterministic.rename(columns={"system_id": "base_system_id"})

    numeric_columns = [
        "additive_fraction_wt_pct", "temperature_low_C", "temperature_high_C", "replicate_n", "cycle_count",
        "base_capacity_value", "composite_capacity_value", "base_capacity_sd", "composite_capacity_sd",
        "capacity_ratio_reported", "protocol_sensitivity_fraction", "base_latent_kJ_kg", "composite_latent_kJ_kg",
        "thermal_conductivity_ratio", "viscosity_ratio", "charge_power_ratio", "discharge_power_ratio",
        "active_salt_mass_fraction", "corrosion_rate_ratio",
    ]
    numeric(evidence, numeric_columns)
    evidence["exact_base_link"] = as_bool(evidence.exact_base_link)

    if evidence.record_id.duplicated().any():
        raise ValueError("Composite evidence record_id must be unique")
    if not set(evidence.source_id).issubset(set(sources.source_id)):
        raise ValueError("Every composite evidence row must link to the source registry")
    if (evidence[["capacity_ratio_reported", "thermal_conductivity_ratio", "viscosity_ratio", "charge_power_ratio", "discharge_power_ratio", "active_salt_mass_fraction", "corrosion_rate_ratio"]].stack() <= 0).any():
        raise ValueError("All reported composite ratios must be positive")

    assumptions_index = assumptions.set_index("parameter")
    beta_low = float(assumptions_index.loc["hydraulic_viscosity_exponent", "value_low"])
    beta_high = float(assumptions_index.loc["hydraulic_viscosity_exponent", "value_high"])
    strict_coverage = float(assumptions_index.loc["strict_service_domain_coverage", "value_low"])
    minimum_cycles = int(assumptions_index.loc["minimum_cycle_count", "value_low"])

    response = capacity_intervals(evidence)
    response = response.merge(sources, on="source_id", how="left", validate="many_to_one")
    service = service_coupling(response, deterministic, services, strict_coverage, minimum_cycles)
    dynamic = dynamic_monte_carlo(response, beta_low, beta_high)
    dynamic_metrics = dynamic.drop(
        columns=[
            "source_id", "evidence_mode", "additive", "condition_label",
            "mc_iterations", "hydraulic_exponent_low", "hydraulic_exponent_high",
            "bidirectional_power_ratio", "charge_discharge_asymmetry",
        ],
        errors="ignore",
    )
    response = response.merge(dynamic_metrics, on="record_id", how="left", validate="one_to_one")

    chieruzzi = response[response.source_id.eq("CHIERUZZI_2013")]
    andreu = response[response.source_id.eq("ANDREU_2014")]
    summary_rows = [
        ("registered_sources", len(sources), "sources"),
        ("experimental_condition_records", len(response), "records"),
        ("exact_base_linked_records", int(response.exact_base_link.sum()), "records"),
        ("quantified_capacity_records", int(response.capacity_ratio.notna().sum()), "records"),
        ("coupled_capacity_viscosity_records", int((response.capacity_ratio.notna() & response.viscosity_ratio.notna()).sum()), "records"),
        ("direction_resolved_stationary_records", int(response.bidirectional_power_ratio.notna().sum()), "records"),
        ("chieruzzi_liquid_cp_midpoint_gains", int(chieruzzi.capacity_ratio.gt(1.0).sum()), "of_12_records"),
        ("chieruzzi_liquid_cp_resolved_gains", int(chieruzzi.capacity_gain_resolved.sum()), "of_12_records"),
        ("andreu_liquid_cp_resolved_gains", int(andreu.capacity_gain_resolved.sum()), "of_4_records"),
        ("base_qualified_service_links", int(service.base_full_duty_qualified.sum()), "record_service_links"),
        ("full_composite_domain_links", int(service.full_composite_domain.sum()), "record_service_links"),
        ("system_metric_complete_links", int(service.composite_metric_complete.sum()), "record_service_links"),
        ("formal_composite_eligible_links", int(service.formal_composite_eligible.sum()), "record_service_links"),
    ]
    summary = pd.DataFrame(summary_rows, columns=["metric", "value", "unit_or_denominator"])

    high_shear = response.loc[response.record_id.eq("ELFAR_SIO2_HIGH_SHEAR")].iloc[0]
    low_shear = response.loc[response.record_id.eq("ELFAR_SIO2_LOW_SHEAR")].iloc[0]
    foam = response.loc[response.record_id.eq("XIAO_FOAM_AL2O3")].iloc[0]
    graphite = response.loc[response.record_id.eq("WANG_EG10")].iloc[0]
    hybrid = response.loc[response.record_id.eq("CHI_HYBRID_10")].iloc[0]
    claims = pd.DataFrame([
        ("COMP_C01", "One of twelve Solar Salt nanoparticle formulations in the multi-additive study retains a resolved liquid heat-capacity gain under the study-motivated symmetric 6% protocol-sensitivity scenario.", int(chieruzzi.capacity_gain_resolved.sum()), "of 12 formulations", "core_composite_property_response.csv"),
        ("COMP_C02", "The independently replicated Solar Salt-SiO2 concentration series resolves a heat-capacity gain only at 1 wt%.", int(andreu.capacity_gain_resolved.sum()), "of 4 concentrations", "core_composite_property_response.csv"),
        ("COMP_C03", "At 240 s-1 the Solar Salt-SiO2 capacity-pumping index exceeds unity only for a minority of the registered hydraulic exponent envelope.", float(high_shear.probability_capacity_pumping_index_gt_1), "fraction of 20000 draws", "core_composite_dynamic_summary.csv"),
        ("COMP_C04", "At 10 s-1 the same Solar Salt-SiO2 formulation never exceeds unity on the capacity-pumping index.", float(low_shear.probability_capacity_pumping_index_gt_1), "fraction of 20000 draws", "core_composite_dynamic_summary.csv"),
        ("COMP_C05", "Copper foam plus alumina has a 3.47 charging-power ratio and a 0.847 discharge-power ratio at the reported 240 to 50 C laboratory boundary.", float(foam.bidirectional_power_ratio), "bidirectional ratio", "core_composite_property_response.csv"),
        ("COMP_C06", "Ten weight-percent expanded graphite reduces active-salt mass fraction to 0.90 while the reported 316SS corrosion-rate ratio is 0.8125 at 300 C.", float(graphite.corrosion_rate_ratio), "corrosion-rate ratio", "core_composite_property_response.csv"),
        ("COMP_C07", "The 1 wt% silica-alumina hybrid is the only resolved liquid heat-capacity gain in its twelve-formulation study and also raises latent heat by 15.66% at the midpoint.", float(hybrid.latent_ratio - 1.0), "fraction", "core_composite_property_response.csv"),
        ("COMP_C08", "No composite evidence record closes exact identity, full-duty temperature support, bidirectional or hydraulic response, durability and compatibility simultaneously.", int(service.formal_composite_eligible.sum()), "formal record-service links", "core_composite_service_coupling.csv"),
    ], columns=["claim_id", "statement", "value", "unit_or_denominator", "source_table"])

    source_audit = sources.merge(
        evidence.groupby("source_id").agg(condition_records=("record_id", "size"), exact_base_records=("exact_base_link", "sum")).reset_index(),
        on="source_id", how="left", validate="one_to_one"
    )
    source_audit["condition_records"] = source_audit.condition_records.fillna(0).astype(int)
    source_audit["exact_base_records"] = source_audit.exact_base_records.fillna(0).astype(int)
    source_audit["doi_present"] = source_audit.doi.astype(str).str.startswith("10.")

    response.to_csv(TABLES / "core_composite_property_response.csv", index=False)
    service.to_csv(TABLES / "core_composite_service_coupling.csv", index=False)
    dynamic.to_csv(TABLES / "core_composite_dynamic_summary.csv", index=False)
    summary.to_csv(TABLES / "core_composite_system_summary.csv", index=False)
    claims.to_csv(TABLES / "core_composite_claim_registry.csv", index=False)
    source_audit.to_csv(TABLES / "core_composite_source_audit.csv", index=False)

    status = {
        "status": "PASS",
        "module": "second_stage_composite_system_coupling",
        "mc_iterations": N_MC,
        "seed": SEED,
        "sources": int(len(sources)),
        "experimental_condition_records": int(len(response)),
        "record_service_links": int(len(service)),
        "formal_composite_eligible_links": int(service.formal_composite_eligible.sum()),
        "core_base_model_changed": False,
        "scientific_extension_added": True,
        "interpretation": "Composite media are evaluated only after exact base-salt linkage. Material-scale gains remain separate from flow, bidirectional power, active-salt displacement, durability and compatibility gates.",
    }
    (QC / "core_COMPOSITE_COUPLING_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
