from __future__ import annotations

from pathlib import Path
import json
import math
import numpy as np
import pandas as pd
from decision_model import BURDEN_HALF_VALUE

VERSION = "core"
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs" / "tables"
QC = ROOT / "outputs" / "qc"
for d in (OUT, QC):
    d.mkdir(parents=True, exist_ok=True)

SCENARIOS = [
    "coal_flexibility_storage",
    "csp_sensible_storage",
    "industrial_medium_heat",
    "sco2_high_temperature_storage",
    "pcm_target_350C",
    "pcm_target_425C",
    "pcm_target_500C",
]
SCENARIO_CODE = {
    "coal_flexibility_storage":"Coal",
    "csp_sensible_storage":"CSP",
    "industrial_medium_heat":"Industrial",
    "sco2_high_temperature_storage":"sCO2",
    "pcm_target_350C":"PCM350",
    "pcm_target_425C":"PCM425",
    "pcm_target_500C":"PCM500",
}
EPS = 1e-12


def load(name: str) -> pd.DataFrame:
    return pd.read_csv(OUT / f"{VERSION}_{name}.csv")


def save(df: pd.DataFrame, name: str) -> None:
    df.to_csv(OUT / f"{VERSION}_{name}.csv", index=False)


def stable_signature(values, ndigits=10):
    sig=[]
    for v in values:
        if pd.isna(v):
            sig.append("NA")
        elif isinstance(v, (float, np.floating)):
            sig.append(f"{float(v):.{ndigits}g}")
        else:
            sig.append(str(v))
    return "|".join(sig)


def collapse_identical_rows(df: pd.DataFrame, value_cols: list[str], label_col: str = "scenario") -> pd.DataFrame:
    x=df.copy()
    x["profile_signature"]=[stable_signature(row) for row in x[value_cols].to_numpy()]
    rows=[]
    for sig,g in x.groupby("profile_signature", sort=False):
        row={c:g.iloc[0][c] for c in value_cols}
        members=g[label_col].astype(str).tolist()
        row.update({
            "profile_signature":sig,
            "member_count":len(members),
            "member_scenarios":";".join(members),
            "member_labels":" + ".join(SCENARIO_CODE.get(s,s) for s in members),
        })
        rows.append(row)
    return pd.DataFrame(rows)


def build_deployability_trajectory_groups() -> pd.DataFrame:
    contract=load("deployability_contraction")
    cf=load("counterfactual_selection_frequencies")
    cp=(contract[contract.deployability_stage.isin([
        "Any complete-service support","Complete-service and evidence-qualified"
    ])].pivot(index="scenario",columns="deployability_stage",values="share_of_registered").reindex(SCENARIOS))
    base=cf[cf.closure_action.eq("baseline")]
    extra=base.groupby("scenario").agg(
        any_selected_share=("selection_frequency",lambda s:(s>0).mean()),
        material_selected_share=("selection_frequency",lambda s:(s>=0.01).mean()),
    )
    rows=[]
    for s in SCENARIOS:
        rows.append({
            "scenario":s,
            "registered_share":1.0,
            "complete_service_share":float(cp.loc[s,"Any complete-service support"]),
            "evidence_qualified_share":float(cp.loc[s,"Complete-service and evidence-qualified"]),
            "any_selected_share":float(extra.loc[s,"any_selected_share"]),
            "material_selected_share":float(extra.loc[s,"material_selected_share"]),
        })
    df=pd.DataFrame(rows)
    vals=["registered_share","complete_service_share","evidence_qualified_share","any_selected_share","material_selected_share"]
    grouped=collapse_identical_rows(df,vals)
    grouped["group_order"] = grouped.member_scenarios.map(lambda z:min(SCENARIOS.index(s) for s in z.split(';')))
    grouped=grouped.sort_values("group_order").reset_index(drop=True)
    save(grouped,"deployability_trajectory_groups")
    return grouped


def build_service_feasibility_groups() -> pd.DataFrame:
    f=load("service_feasibility_composition")
    cats=["robust_complete_service","uncertain_complete_service","no_complete_service"]
    piv=f.pivot(index="scenario",columns="strict_probability_class",values="share_within_service").reindex(SCENARIOS).fillna(0).reset_index()
    for c in cats:
        if c not in piv: piv[c]=0.0
    grouped=collapse_identical_rows(piv, cats)
    grouped["group_order"] = grouped.member_scenarios.map(lambda z:min(SCENARIOS.index(s) for s in z.split(';')))
    grouped=grouped.sort_values("group_order").reset_index(drop=True)
    save(grouped,"service_feasibility_groups")
    return grouped


def build_redirection_route_diversity() -> pd.DataFrame:
    flow=load("figure_selection_alluvial_flows")
    total_draws=flow.groupby("scenario").mc_iterations.max().to_dict()
    red=flow[flow.transition_class.eq("redirected")].copy()
    rows=[]
    for s in SCENARIOS:
        g=red[red.scenario.eq(s)].copy()
        denom=float(total_draws.get(s,0))
        if g.empty or denom<=0:
            rows.append({"scenario":s,"redirected_draw_frequency":0.0,"distinct_routes":0,"top_route_share_within_redirected":np.nan,"effective_route_count":np.nan,"route_entropy":np.nan})
            continue
        routes=g.groupby(["from_system_id","to_system_id"],as_index=False).transition_draws.sum()
        weights=routes.transition_draws.to_numpy(float)
        p=weights/weights.sum()
        entropy=float(-(p*np.log(np.clip(p,EPS,1))).sum())
        rows.append({
            "scenario":s,
            "redirected_draw_frequency":float(weights.sum()/denom),
            "distinct_routes":int(len(routes)),
            "top_route_share_within_redirected":float(p.max()),
            "effective_route_count":float(np.exp(entropy)),
            "route_entropy":entropy,
        })
    df=pd.DataFrame(rows)
    save(df,"redirection_route_diversity")
    return df


def build_weight_space_stability_summary() -> pd.DataFrame:
    w=load("continuous_weight_space_scan")
    w=w[~w.scenario.str.startswith("pcm_target")].copy()
    rows=[]
    for s,g in w.groupby("scenario",sort=False):
        rows.append({
            "scenario":s,
            "modal_leader":g.modal_selection_label.mode().iat[0],
            "distinct_modal_leaders":int(g.modal_selection_label.nunique()),
            "leader_frequency_p05":float(g.modal_selection_frequency_across_physical_draws.quantile(.05)),
            "leader_frequency_p50":float(g.modal_selection_frequency_across_physical_draws.quantile(.50)),
            "leader_frequency_p95":float(g.modal_selection_frequency_across_physical_draws.quantile(.95)),
            "top1_top2_gap_p05":float(g.top1_top2_frequency_gap.quantile(.05)),
            "top1_top2_gap_p50":float(g.top1_top2_frequency_gap.quantile(.50)),
            "top1_top2_gap_p95":float(g.top1_top2_frequency_gap.quantile(.95)),
            "weight_vectors":int(g.weight_vector_id.nunique()),
        })
    df=pd.DataFrame(rows).set_index("scenario").reindex(SCENARIOS[:4]).reset_index()
    save(df,"weight_space_stability_summary")
    return df


def build_smaa_rank1_groups() -> pd.DataFrame:
    smaa=load("smaa_rank_acceptability")
    design=load("smaa_design")
    top=smaa[smaa["rank"].eq(1)].copy()
    candidates=sorted(set(top.display_system.astype(str)))
    rows=[]
    for s in SCENARIOS:
        row={"scenario":s}
        sub=top[top.scenario.eq(s)]
        for c in candidates:
            row[c]=float(sub.loc[sub.display_system.eq(c),"rank_acceptability"].sum())
        row["No formal selection"]=float(design.loc[design.scenario.eq(s),"no_selection_probability"].iloc[0])
        rows.append(row)
    wide=pd.DataFrame(rows)
    vals=candidates+["No formal selection"]
    grouped=collapse_identical_rows(wide,vals)
    grouped["group_order"] = grouped.member_scenarios.map(lambda z:min(SCENARIOS.index(s) for s in z.split(';')))
    grouped=grouped.sort_values("group_order").reset_index(drop=True)
    save(grouped,"smaa_rank1_groups")
    return grouped


def build_omission_influence() -> pd.DataFrame:
    """Recompute candidate/source omission influence against one hierarchical-geometric baseline.

    Candidate IDs are compared with baseline candidate IDs (never display labels). Entropy is
    normalized by the maximum outcome entropy before it enters the descriptive influence norm.
    The norm is used only for selecting/encoding the strongest displayed omission; all raw signed
    changes remain explicit columns.
    """
    loc=load("leave_one_candidate_out_sensitivity").copy()
    los=load("leave_one_source_out_sensitivity").copy()
    base=load("credibility_model_sensitivity")
    base=base[base.credibility_model.eq("hierarchical_geometric")].set_index("scenario")
    rows=[]
    for omission_type, frame, id_col, label_col in [
        ("candidate",loc,"excluded_system_id","excluded_display_system"),
        ("source",los,"omitted_source_id","omitted_source_id"),
    ]:
        for r in frame.itertuples(index=False):
            b=base.loc[r.scenario]
            leader_changed=str(r.modal_leader)!=str(b.modal_leader)
            delta_no=float(r.no_selection_frequency-b.no_selection_frequency)
            delta_entropy=float(r.selection_entropy-b.selection_entropy)
            delta_leader=float(r.modal_leader_frequency-b.modal_leader_frequency)
            max_entropy=math.log2(max(int(b.bounded_candidate_union_count)+1,2))
            influence=float(np.sqrt(delta_no**2+(delta_entropy/max_entropy)**2+delta_leader**2))
            rows.append({
                "scenario":r.scenario,
                "omission_type":omission_type,
                "omitted_id":str(getattr(r,id_col)),
                "omitted_label":str(getattr(r,label_col)),
                "baseline_model":"hierarchical_geometric",
                "baseline_leader_id":str(b.modal_leader),
                "baseline_leader_label":str(b.modal_leader_label),
                "modal_leader_id":str(r.modal_leader),
                "modal_leader_label":str(r.modal_leader_label),
                "leader_changed":bool(leader_changed),
                "baseline_no_selection_frequency":float(b.no_selection_frequency),
                "omitted_no_selection_frequency":float(r.no_selection_frequency),
                "delta_no_selection":delta_no,
                "baseline_selection_entropy":float(b.selection_entropy),
                "omitted_selection_entropy":float(r.selection_entropy),
                "delta_entropy":delta_entropy,
                "baseline_modal_leader_frequency":float(b.modal_leader_frequency),
                "omitted_modal_leader_frequency":float(r.modal_leader_frequency),
                "delta_modal_leader_frequency":delta_leader,
                "influence_magnitude":influence,
            })
    out=pd.DataFrame(rows)
    out["worst_within_scenario_type"]=False
    if len(out):
        idx=out.groupby(["scenario","omission_type"]).influence_magnitude.idxmax()
        out.loc[idx,"worst_within_scenario_type"]=True
    save(out,"omission_influence")
    return out


def build_omission_influence_summary(omission: pd.DataFrame | None = None) -> pd.DataFrame:
    o=build_omission_influence() if omission is None else omission.copy()
    o=o[(o.influence_magnitude>0.005) & ((o.delta_no_selection.abs()>0.002)|(o.delta_entropy.abs()>0.002)|o.leader_changed)].copy()
    o=o.sort_values("influence_magnitude",ascending=False).groupby(["scenario","omission_type"],as_index=False).head(1)
    o=o.sort_values(["scenario","omission_type"]).reset_index(drop=True)
    save(o,"omission_influence_summary")
    return o


def build_supplementary_candidate_omission_residuals(summary: pd.DataFrame) -> pd.DataFrame:
    omission=load("omission_influence")
    x=omission[omission.omission_type.eq("candidate")].copy()
    shown=set(zip(summary.loc[summary.omission_type.eq("candidate"),"scenario"],summary.loc[summary.omission_type.eq("candidate"),"omitted_id"]))
    x=x[~x.apply(lambda r:(r.scenario,r.omitted_id) in shown,axis=1)]
    x=x[(x.delta_no_selection.abs()>0.005)|(x.delta_entropy.abs()>0.02)|x.leader_changed].copy()
    x=x.sort_values("influence_magnitude",ascending=False).head(18).sort_values(["scenario","delta_no_selection"])
    x["excluded_from_main_figure"]=True
    save(x,"supplementary_candidate_omission_residuals")
    return x


def build_supplementary_candidate_omission_rank_residuals(summary: pd.DataFrame) -> pd.DataFrame:
    """Rank/benchmark effects for candidate omissions not displayed in main Fig. 5d."""
    loc=load("leave_one_candidate_out_sensitivity").copy()
    base=load("credibility_model_sensitivity")
    base=base[base.credibility_model.eq("hierarchical_geometric")].set_index("scenario")
    shown=set(zip(
        summary.loc[summary.omission_type.eq("candidate"),"scenario"],
        summary.loc[summary.omission_type.eq("candidate"),"omitted_id"],
    ))
    rows=[]
    for r in loc.itertuples(index=False):
        if (r.scenario,str(r.excluded_system_id)) in shown:
            continue
        b=base.loc[r.scenario]
        rows.append({
            "scenario":r.scenario,
            "excluded_system_id":str(r.excluded_system_id),
            "excluded_display_system":str(r.excluded_display_system),
            "baseline_model":"hierarchical_geometric",
            "baseline_leader_id":str(b.modal_leader),
            "modal_leader_id":str(r.modal_leader),
            "leader_changed":str(r.modal_leader)!=str(b.modal_leader),
            "delta_top1_top2_frequency_gap":float(r.top1_top2_frequency_gap-b.top1_top2_frequency_gap),
            "delta_leader_exceeds_benchmark_probability":float(r.leader_exceeds_benchmark_probability-b.leader_exceeds_benchmark_probability),
            "bounded_candidate_union_count":int(r.bounded_candidate_union_count),
            "excluded_from_main_figure":True,
        })
    out=pd.DataFrame(rows)
    out=out[(out.delta_top1_top2_frequency_gap.abs()>0.005)|(out.delta_leader_exceeds_benchmark_probability.abs()>0.005)|out.leader_changed].copy()
    out=out.sort_values(["scenario","delta_top1_top2_frequency_gap","excluded_system_id"]).reset_index(drop=True)
    save(out,"supplementary_candidate_omission_rank_residuals")
    return out


def build_supplementary_candidate_omission_decisiveness_residuals(summary: pd.DataFrame) -> pd.DataFrame:
    """Residual candidate omissions expressed on axes independent of main Fig. 5d.

    The x axis is the change in top1-top2 rank-frequency gap and the y axis is
    the change in modal-leader frequency. Cases displayed in main Fig. 5d are
    excluded before joining, and every delta uses the hierarchical-geometric
    baseline.
    """
    rank = build_supplementary_candidate_omission_rank_residuals(summary)
    effect = build_supplementary_candidate_omission_residuals(summary)
    keys = ["scenario", "baseline_model"]
    rank = rank.rename(columns={
        "excluded_system_id": "omitted_id",
        "excluded_display_system": "omitted_label",
    })
    cols = keys + ["omitted_id", "omitted_label",
                   "delta_top1_top2_frequency_gap",
                   "delta_leader_exceeds_benchmark_probability",
                   "bounded_candidate_union_count",
                   "excluded_from_main_figure"]
    rank = rank[cols]
    effect_cols = keys + ["omitted_id", "delta_modal_leader_frequency",
                          "leader_changed", "influence_magnitude",
                          "excluded_from_main_figure"]
    out = rank.merge(effect[effect_cols], on=keys+["omitted_id"], how="inner", suffixes=("_rank","_effect"))
    out["excluded_from_main_figure"] = out.excluded_from_main_figure_rank.astype(bool) & out.excluded_from_main_figure_effect.astype(bool)
    out = out.drop(columns=["excluded_from_main_figure_rank","excluded_from_main_figure_effect"])
    out = out[(out.delta_top1_top2_frequency_gap.abs()>0.005) |
              (out.delta_modal_leader_frequency.abs()>0.005) |
              out.leader_changed.astype(bool)].copy()
    out = out.sort_values(["scenario","delta_top1_top2_frequency_gap","omitted_id"]).reset_index(drop=True)
    save(out,"supplementary_candidate_omission_decisiveness_residuals")
    return out


def build_unique_thermophysical_profiles() -> pd.DataFrame:
    d=load("candidate_system_metrics_deterministic")
    cols=["fixed_window_coverage","cp_at_service_J_gK","density_at_service_kg_m3","thermal_k_at_service_W_mK","complete_service_energy_fixed_kWh_m3"]
    x=d[["system_id","display_system","scenario",*cols]].copy()
    x["profile_signature"]=[stable_signature(row,8) for row in x[cols].to_numpy()]
    rows=[]
    for (sid,name,sig),g in x.groupby(["system_id","display_system","profile_signature"],sort=False,dropna=False):
        row={"system_id":sid,"display_system":name,"profile_signature":sig}
        row.update({c:g.iloc[0][c] for c in cols})
        row["member_scenarios"]=";".join(g.scenario.astype(str))
        row["member_labels"]=" + ".join(SCENARIO_CODE.get(s,s) for s in g.scenario.astype(str))
        row["member_count"]=len(g)
        rows.append(row)
    out=pd.DataFrame(rows)
    save(out,"unique_thermophysical_profiles")
    return out


def build_unique_penalty_profiles() -> pd.DataFrame:
    p=load("partial_vs_complete_service_penalty")
    p=p[p.partial_minus_complete_kWh_m3>0].copy()
    cols=["fixed_window_coverage","partial_minus_complete_kWh_m3","partial_overlap_overclaim_fraction","strict_value_retained_fraction_of_partial"]
    p["profile_signature"]=[stable_signature(row,8) for row in p[cols].to_numpy()]
    rows=[]
    for (sid,name,sig),g in p.groupby(["system_id","display_system","profile_signature"],sort=False):
        row={"system_id":sid,"display_system":name,"profile_signature":sig}
        row.update({c:g.iloc[0][c] for c in cols})
        row["member_scenarios"]=";".join(g.scenario.astype(str))
        row["member_labels"]=" + ".join(SCENARIO_CODE.get(s,s) for s in g.scenario.astype(str))
        row["member_count"]=len(g)
        rows.append(row)
    out=pd.DataFrame(rows)
    save(out,"unique_partial_service_penalty_profiles")
    return out


def build_unique_atomic_interval_profiles() -> pd.DataFrame:
    """Legacy joint-profile table retained for transparent source-data mapping."""
    a=pd.read_csv(ROOT/"data"/"input"/f"{VERSION}_atomic_engineering_credibility_registry.csv")
    roots=["corrosion_compatibility","cycling_phase_stability","containment_validation"]
    cols=[f"{r}_{s}" for r in roots for s in ["low","mid","high"]]
    a["profile_signature"]=[stable_signature(row,8) for row in a[cols].to_numpy()]
    rows=[]
    for (sid,name,sig),g in a.groupby(["system_id","display_system","profile_signature"],sort=False):
        row={"system_id":sid,"display_system":name,"profile_signature":sig}
        row.update({c:g.iloc[0][c] for c in cols})
        row["member_scenarios"]=";".join(g.scenario.astype(str))
        row["member_labels"]=" + ".join(SCENARIO_CODE.get(s,s) for s in g.scenario.astype(str))
        row["member_count"]=len(g)
        rows.append(row)
    out=pd.DataFrame(rows)
    save(out,"unique_atomic_interval_profiles")
    return out


def build_atomic_interval_profiles_by_dimension() -> pd.DataFrame:
    """Collapse exact low/mid/high duplicates separately for each displayed subpanel."""
    a=pd.read_csv(ROOT/"data"/"input"/f"{VERSION}_atomic_engineering_credibility_registry.csv")
    roots=["corrosion_compatibility","cycling_phase_stability","containment_validation"]
    rows=[]
    for root in roots:
        cols=[f"{root}_{s}" for s in ["low","mid","high"]]
        x=a.copy()
        x["profile_signature"]=[stable_signature(row,8) for row in x[cols].to_numpy()]
        for sig,g in x.groupby("profile_signature",sort=False):
            rows.append({
                "dimension":root,
                "profile_signature":sig,
                "low":float(g.iloc[0][cols[0]]),
                "mid":float(g.iloc[0][cols[1]]),
                "high":float(g.iloc[0][cols[2]]),
                "member_count":int(len(g)),
                "member_system_ids":";".join(g.system_id.astype(str)),
                "member_scenarios":";".join(g.scenario.astype(str)),
                "member_labels":" + ".join(f"{SCENARIO_CODE.get(s,s)}·{n}" for s,n in zip(g.scenario.astype(str),g.display_system.astype(str))),
            })
    out=pd.DataFrame(rows)
    out["profile_id"]=out.groupby("dimension").cumcount().add(1).map(lambda x:f"P{x}")
    save(out,"atomic_interval_profiles_by_dimension")
    return out


def build_source_omission_effect_groups() -> pd.DataFrame:
    """Aggregate only sources with the same complete, baseline-referenced effect vector."""
    los=load("leave_one_source_out_sensitivity").copy()
    base=load("credibility_model_sensitivity")
    base=base[base.credibility_model.eq("hierarchical_geometric")].set_index("scenario")
    rows=[]
    for r in los.itertuples(index=False):
        b=base.loc[r.scenario]
        rows.append({
            "scenario":r.scenario,
            "source_id":str(r.omitted_source_id),
            "affected_candidate_count":int(r.affected_candidate_count),
            "leader_changed":str(r.modal_leader)!=str(b.modal_leader),
            "delta_no_selection":float(r.no_selection_frequency-b.no_selection_frequency),
            "delta_entropy":float(r.selection_entropy-b.selection_entropy),
            "delta_modal_leader_frequency":float(r.modal_leader_frequency-b.modal_leader_frequency),
            "delta_top1_top2_frequency_gap":float(r.top1_top2_frequency_gap-b.top1_top2_frequency_gap),
            "delta_mean_top_two_utility_margin":float(r.mean_top_two_utility_margin-b.mean_top_two_utility_margin),
        })
    x=pd.DataFrame(rows)
    metrics=["delta_no_selection","delta_entropy","delta_modal_leader_frequency","delta_top1_top2_frequency_gap","delta_mean_top_two_utility_margin"]
    x=x[(x[metrics].abs().max(axis=1)>0.005)|x.leader_changed].copy()
    x["effect_signature"]=[stable_signature([*(round(float(v),6) for v in row),int(ch),int(n)],8) for row,ch,n in zip(x[metrics].to_numpy(),x.leader_changed,x.affected_candidate_count)]
    grouped=[]
    for (s,sig),g in x.groupby(["scenario","effect_signature"],sort=False):
        rec={"scenario":s,"effect_signature":sig,"source_count":int(len(g)),"source_ids":";".join(g.source_id)}
        for m in metrics: rec[m]=float(g.iloc[0][m])
        rec["leader_changed"]=bool(g.iloc[0].leader_changed)
        rec["affected_candidate_count"]=int(g.iloc[0].affected_candidate_count)
        grouped.append(rec)
    out=pd.DataFrame(grouped).sort_values(["scenario","delta_no_selection","delta_entropy"]).reset_index(drop=True)
    save(out,"source_omission_effect_groups")
    return out


def build_nonadditivity_groups() -> pd.DataFrame:
    x=load("evidence_programme_nonadditivity").copy()
    metric_cols=[c for c in x.columns if c.startswith("nonadditivity_") or c.startswith("combined_") or c.startswith("sum_single_")]
    sig_cols=["interaction_class",*metric_cols]
    x["profile_signature"]=[stable_signature(row,8) for row in x[sig_cols].to_numpy()]
    rows=[]
    for sig,g in x.groupby("profile_signature",sort=False):
        rec={c:g.iloc[0][c] for c in metric_cols}
        rec.update({
            "profile_signature":sig,
            "interaction_class":g.iloc[0].interaction_class,
            "member_count":int(len(g)),
            "member_scenarios":";".join(g.scenario.astype(str)),
            "member_labels":" + ".join(SCENARIO_CODE.get(s,s) for s in g.scenario.astype(str)),
        })
        rows.append(rec)
    out=pd.DataFrame(rows)
    save(out,"evidence_programme_nonadditivity_groups")
    return out


def build_nonzero_model_sensitivity() -> pd.DataFrame:
    cm=load("credibility_model_sensitivity")
    base=cm[cm.credibility_model.eq("hierarchical_geometric")].set_index("scenario")
    x=cm[~cm.credibility_model.eq("hierarchical_geometric")].copy()
    x["delta_no_selection"]=[float(r.no_selection_frequency-base.loc[r.scenario,"no_selection_frequency"]) for r in x.itertuples(index=False)]
    x["delta_entropy"]=[float(r.selection_entropy-base.loc[r.scenario,"selection_entropy"]) for r in x.itertuples(index=False)]
    x=x[(x.delta_no_selection.abs()>0.005)|(x.delta_entropy.abs()>0.005)].copy()
    x["effect_signature"]=[stable_signature(row,7) for row in x[["delta_no_selection","delta_entropy"]].to_numpy()]
    rows=[]
    for (model,sig),g in x.groupby(["credibility_model","effect_signature"],sort=False):
        rows.append({
            "credibility_model":model,
            "effect_signature":sig,
            "delta_no_selection":float(g.delta_no_selection.iloc[0]),
            "delta_entropy":float(g.delta_entropy.iloc[0]),
            "member_scenarios":";".join(g.scenario.astype(str)),
            "member_labels":" + ".join(SCENARIO_CODE.get(s,s) for s in g.scenario.astype(str)),
            "member_count":int(len(g)),
        })
    out=pd.DataFrame(rows, columns=[
        "credibility_model", "effect_signature", "delta_no_selection",
        "delta_entropy", "member_scenarios", "member_labels", "member_count",
    ])
    save(out,"nonzero_model_sensitivity_groups")
    return out



def build_unique_shortfall_profiles() -> pd.DataFrame:
    c=load("credibility_shortfall_decomposition")
    dims=["corrosion","cycling_phase","containment","literature_replication","data_completeness","inverse_burden"]
    p=c.pivot_table(index=["scenario","system_id","display_system"],columns="credibility_dimension",values="share_of_total_log_shortfall").reset_index().fillna(0)
    for d in dims:
        if d not in p: p[d]=0.0
    p["profile_signature"]=[stable_signature(row,8) for row in p[dims].to_numpy()]
    rows=[]
    for i,(sig,g) in enumerate(p.groupby("profile_signature",sort=False),start=1):
        row={"profile_id":f"P{i}","profile_signature":sig}
        row.update({d:float(g.iloc[0][d]) for d in dims})
        labels=[f"{SCENARIO_CODE.get(r.scenario,r.scenario)} · {r.display_system}" for r in g.itertuples(index=False)]
        row["member_pairs"]=";".join(labels)
        row["member_count"]=len(labels)
        row["display_label"]=labels[0] if len(labels)==1 else f"P{i} · {len(labels)} candidate–service pairs"
        rows.append(row)
    out=pd.DataFrame(rows)
    save(out,"unique_credibility_shortfall_profiles")
    return out

def build_unique_readiness_profiles() -> pd.DataFrame:
    r=load("candidate_readiness_profile").copy()
    r["inverse_burden"]=1/(1+r.engineering_burden_index.clip(lower=0)/BURDEN_HALF_VALUE)
    cols=["corrosion_compatibility_score","cycling_phase_stability_score","containment_validation_score","literature_replication_score","data_completeness_score","inverse_burden","evidence_qualified_selection_frequency"]
    r["profile_signature"]=[stable_signature(row,8) for row in r[cols].to_numpy()]
    rows=[]
    for (sid,name,sig),g in r.groupby(["system_id","display_system","profile_signature"],sort=False):
        row={"system_id":sid,"display_system":name,"profile_signature":sig}
        row.update({c:g.iloc[0][c] for c in cols})
        row["member_scenarios"]=";".join(g.scenario.astype(str))
        row["member_labels"]=" + ".join(SCENARIO_CODE.get(s,s) for s in g.scenario.astype(str))
        row["member_count"]=len(g)
        rows.append(row)
    out=pd.DataFrame(rows)
    save(out,"unique_readiness_profiles")
    return out


def build_multiplicity_groups() -> pd.DataFrame:
    tm=load("top_two_margin_summary")
    vals=["multiple_candidate_draw_frequency","single_candidate_draw_frequency","no_candidate_draw_frequency"]
    grouped=collapse_identical_rows(tm[["scenario",*vals]],vals)
    grouped["group_order"] = grouped.member_scenarios.map(lambda z:min(SCENARIOS.index(s) for s in z.split(';')))
    grouped=grouped.sort_values("group_order").reset_index(drop=True)
    save(grouped,"bounded_multiplicity_groups")
    return grouped


def build_convergence_summary() -> pd.DataFrame:
    c=load("independent_seed_convergence")
    maxn=int(c.n_draws.max())
    ref=c[c.n_draws.eq(maxn)][["scenario","independent_seed_replicate","modal_leader_frequency"]].rename(columns={"modal_leader_frequency":"reference_frequency"})
    x=c.merge(ref,on=["scenario","independent_seed_replicate"],how="left")
    x["absolute_error"]=(x.modal_leader_frequency-x.reference_frequency).abs()
    out=(x.groupby("n_draws").absolute_error.quantile([.5,.95]).unstack().reset_index().rename(columns={.5:"median_absolute_error",.95:"p95_absolute_error"}).sort_values("n_draws"))
    out["reference_draws"]=maxn
    save(out,"independent_convergence_summary")
    return out


def main() -> None:
    omission = build_omission_influence()
    omission_summary = build_omission_influence_summary(omission)
    outputs={
        "deployability_trajectory_groups":build_deployability_trajectory_groups(),
        "service_feasibility_groups":build_service_feasibility_groups(),
        "redirection_route_diversity":build_redirection_route_diversity(),
        "weight_space_stability_summary":build_weight_space_stability_summary(),
        "smaa_rank1_groups":build_smaa_rank1_groups(),
        "omission_influence":omission,
        "omission_influence_summary":omission_summary,
        "supplementary_candidate_omission_residuals":build_supplementary_candidate_omission_residuals(omission_summary),
        "supplementary_candidate_omission_rank_residuals":build_supplementary_candidate_omission_rank_residuals(omission_summary),
        "supplementary_candidate_omission_decisiveness_residuals":build_supplementary_candidate_omission_decisiveness_residuals(omission_summary),
        "unique_thermophysical_profiles":build_unique_thermophysical_profiles(),
        "unique_partial_service_penalty_profiles":build_unique_penalty_profiles(),
        "unique_atomic_interval_profiles":build_unique_atomic_interval_profiles(),
        "atomic_interval_profiles_by_dimension":build_atomic_interval_profiles_by_dimension(),
        "source_omission_effect_groups":build_source_omission_effect_groups(),
        "evidence_programme_nonadditivity_groups":build_nonadditivity_groups(),
        "nonzero_model_sensitivity_groups":build_nonzero_model_sensitivity(),
        "unique_credibility_shortfall_profiles":build_unique_shortfall_profiles(),
        "unique_readiness_profiles":build_unique_readiness_profiles(),
        "bounded_multiplicity_groups":build_multiplicity_groups(),
        "independent_convergence_summary":build_convergence_summary(),
    }
    checks=[]
    for name,df in outputs.items():
        checks.append({"check":f"{name}_nonempty","passed":bool(len(df)>0),"detail":int(len(df))})
    checks += [
        {"check":"deployability_identical_trajectories_collapsed","passed":bool(len(outputs['deployability_trajectory_groups'])<len(SCENARIOS)),"detail":int(len(outputs['deployability_trajectory_groups']))},
        {"check":"service_identical_compositions_collapsed","passed":bool(len(outputs['service_feasibility_groups'])<len(SCENARIOS)),"detail":int(len(outputs['service_feasibility_groups']))},
        {"check":"pcm_smaa_rows_collapsed","passed":bool(outputs['smaa_rank1_groups'].member_labels.str.contains('PCM350.*PCM425.*PCM500',regex=True).any()),"detail":outputs['smaa_rank1_groups'].member_labels.tolist()},
        {"check":"omission_baseline_single_and_explicit","passed":set(outputs['omission_influence'].baseline_model)=={'hierarchical_geometric'},"detail":outputs['omission_influence'].baseline_model.unique().tolist()},
        {"check":"omission_leader_ids_compared_consistently","passed":bool((outputs['omission_influence'].leader_changed==(outputs['omission_influence'].modal_leader_id!=outputs['omission_influence'].baseline_leader_id)).all()),"detail":int(outputs['omission_influence'].leader_changed.sum())},
        {"check":"atomic_intervals_unique_within_each_panel","passed":bool(outputs['atomic_interval_profiles_by_dimension'].groupby('dimension').profile_signature.apply(lambda s:s.nunique()==len(s)).all()),"detail":outputs['atomic_interval_profiles_by_dimension'].groupby('dimension').size().to_dict()},
        {"check":"source_omission_full_effect_vectors_grouped","passed":bool(outputs['source_omission_effect_groups'].groupby(['scenario','effect_signature']).size().eq(1).all()),"detail":outputs['source_omission_effect_groups'].source_count.tolist()},
        {"check":"supp_candidate_omissions_exclude_main","passed":bool(outputs['supplementary_candidate_omission_residuals'].excluded_from_main_figure.all()),"detail":int(len(outputs['supplementary_candidate_omission_residuals']))},
        {"check":"supp_rank_omissions_exclude_main","passed":bool(outputs['supplementary_candidate_omission_rank_residuals'].excluded_from_main_figure.all()),"detail":int(len(outputs['supplementary_candidate_omission_rank_residuals']))},
        {"check":"supp_rank_omission_leader_ids_consistent","passed":bool((outputs['supplementary_candidate_omission_rank_residuals'].leader_changed==(outputs['supplementary_candidate_omission_rank_residuals'].modal_leader_id!=outputs['supplementary_candidate_omission_rank_residuals'].baseline_leader_id)).all()),"detail":int(outputs['supplementary_candidate_omission_rank_residuals'].leader_changed.sum())},
        {"check":"supp_decisiveness_omissions_exclude_main","passed":bool(outputs['supplementary_candidate_omission_decisiveness_residuals'].excluded_from_main_figure.all()),"detail":int(len(outputs['supplementary_candidate_omission_decisiveness_residuals']))},
        {"check":"supp_decisiveness_single_baseline","passed":set(outputs['supplementary_candidate_omission_decisiveness_residuals'].baseline_model)=={"hierarchical_geometric"},"detail":outputs['supplementary_candidate_omission_decisiveness_residuals'].baseline_model.unique().tolist()},
        {"check":"supp_decisiveness_finite_axes","passed":bool(outputs['supplementary_candidate_omission_decisiveness_residuals'][['delta_top1_top2_frequency_gap','delta_modal_leader_frequency']].notna().all().all()),"detail":outputs['supplementary_candidate_omission_decisiveness_residuals'][['delta_top1_top2_frequency_gap','delta_modal_leader_frequency']].to_dict('records')},
        {"check":"model_sensitivity_zero_rows_removed","passed":bool(((outputs['nonzero_model_sensitivity_groups'].delta_no_selection.abs()>0.005)|(outputs['nonzero_model_sensitivity_groups'].delta_entropy.abs()>0.005)).all()),"detail":int(len(outputs['nonzero_model_sensitivity_groups']))},
    ]
    advisory_checks={
        "deployability_identical_trajectories_collapsed",
        "service_identical_compositions_collapsed",
        "pcm_smaa_rows_collapsed",
        "redirection_route_diversity_nonempty",
        "nonzero_model_sensitivity_groups_nonempty",
    }
    for c in checks:
        c["severity"]="advisory" if c["check"] in advisory_checks else "critical"
        c["release_blocking"]=c["severity"]=="critical"
    critical_failures=[c for c in checks if c["severity"]=="critical" and not c["passed"]]
    advisory_findings=[c for c in checks if c["severity"]!="critical" and not c["passed"]]
    status="PASS" if not critical_failures else "FAIL"
    payload={
        "version":VERSION,
        "status":status,
        "critical_failures":len(critical_failures),
        "advisory_findings":len(advisory_findings),
        "checks":checks,
        "tables":{k:int(len(v)) for k,v in outputs.items()},
        "validation_policy":"Data integrity and grouping consistency are release-blocking; visual compression and observed information-density targets are advisory.",
    }
    (QC/f"{VERSION}_PRESENTATION_EXTENSION_STATUS.json").write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(payload,indent=2,ensure_ascii=False))
    if status!="PASS":
        raise SystemExit(1)

if __name__=="__main__":
    main()
