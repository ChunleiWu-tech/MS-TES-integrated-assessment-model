# External evidence evaluation protocol

Protocol version 1, 9 September 2026. Prepared before new literature searches and extraction in this upgrade. Existing Wei 2020 results have already been inspected and remain retrospective. This document is a local dated analysis plan, not a registered or blinded trial.

## Fixed question and scope

Evaluate whether composition-specific, complete-duty evidence supports credible estimates of sensible storage energy and whether partial evidence can produce quantifiable comparison errors. An energy check does not validate engineering evidence scores, corrosion, lifetime, or industrial device volume. The current admission rules, score intervals, utility, normalization, and baseline property functions are frozen before new case extraction.

## Source eligibility

Search primary experimental publications and institutional repositories for molten-salt heat capacity, density or directly measured enthalpy over an explicitly measured common liquid interval. Prefer independently measured same-composition data from another team or batch. Match mass versus molar composition, temperature interval, sample preparation, phase, measurement conditions and units. Exclude untraceable secondary-only numbers, unmatched compositions, simulation-only reference values, and extrapolation outside measured support. Retain excluded sources with reasons. Presence in a bundled database triggers a source-use audit, not automatic proof of development use. If independence is uncertain, label the calculation retrospective or external-source comparison, not independent validation.

## Input and reference separation

When a matching baseline curve and new independent measurement exist, use the unmodified baseline curve as prediction and the independent curve or enthalpy as reference. Evaluate their entire shared measured liquid interval. If no such pair exists, a newly found source may support a clearly labelled held-out-source masking benchmark, not independent physical performance validation. Do not claim that re-integrating the same curve validates it. For masking comparisons, use every reported scalar anchor, not only the anchor producing the greatest error. Keep full source data unavailable to model calibration. No scoring parameters are to be fitted using the validation result.

## Endpoints

Report signed and absolute relative enthalpy errors and, only when comparable density support exists, hot-end-volume energy errors and fixed-energy equivalent-volume errors. Report candidate-level data availability, determinate comparison coverage, unresolved status, and ranking changes only when at least two comparable materials exist. Missing evidence is not physical failure. Treat multiple temperatures from one study as dependent, not independent samples. Do not force a universal pass threshold; compare deviations to documented measurement bounds and separately report practical interpretation.

## Uncertainty

Preserve the publication's uncertainty meaning and correlation information. Unspecified plus/minus instrument percentages are deterministic sensitivity bounds, not standard deviations or confidence intervals. Include digitization uncertainty if extracting figures, and report interpolation uncertainty as unquantified when no empirical basis exists. Propagate common-source errors jointly where information supports this. No invented Gaussian error model or artificial replication.

## Device extension

Only evaluate charge or delivery predictions against measurements not used to set their power parameters, with the same material, compatible temperature interval, geometry and boundary conditions. Otherwise retain the present constant-power, lossless device study as a model scenario and numerical consistency test.

## Reporting and release

Retain null and adverse results. Do not tune acceptance rules after extraction. Bind source identities, inputs, code, outputs, figures and manuscript statements with hashes. Replace obsolete delivered packages only after the new package passes computational, source, document and integrity checks. Preserve source literature and original observations.
