# core input data dictionary

- `core_candidate_property_registry.csv`: one row per candidate salt; property correlations, uncertainty ranges and source identifiers.
- `core_candidate_scenario_membership.csv`: application-specific candidate membership.
- `core_corrosion_evidence_registry.csv`: corrosion-evidence tier, bounded claim class, burden range and traceable sources. The `evidence_score` field is an ordinal evidence-adequacy index used only after hard gates; it is not a material-performance score.
- `core_literature_validation_tiers.csv`: independent database or benchmark-validation tier.
- `core_component_cost_supply_safety_proxy.csv`: broad component price and hazard ranges for sensitivity only.
- `core_mixture_cost_overrides.csv`: literature mixture-price cross-checks where available.
- `core_authoritative_source_registry.csv`: DOI or official-source trace.
- `core_composite_source_registry.csv`: primary experimental sources for nanoparticle and stationary-scaffold media, with DOI, access basis and the specific evidence role imported into the second-stage model.
- `core_composite_evidence_registry.csv`: one row per reported composition and operating condition. Base-salt identity, additive fraction, temperature domain, replicate or cycling support, heat-capacity and latent-heat observations, viscosity, conductivity, charge/discharge response, active-salt fraction and corrosion evidence remain separate fields. Blank values mean unreported, not zero.
- `core_composite_model_assumptions.csv`: registered system-coupling conventions, including the hydraulic-exponent diagnostic envelope, full-domain coverage rule, bidirectional-power rule and durability screening convention.

Raw MSD-TP and MSD-TC snapshots are preserved under `data/raw_databases/`. MSD-TP supports thermophysical validation; MSD-TC is used only as thermochemical and phase context.

## Property validity and provenance fields

The candidate-property registry separately records `cp_Tmin_C/cp_Tmax_C`, `rho_Tmin_C/rho_Tmax_C`, `k_Tmin_C/k_Tmax_C` and analogous model-basis fields. These are source-valid model domains, not decomposition limits. For sensible services, strict-complete thermophysical eligibility is calculated from the joint Cp-density intersection with the physically liquid service interval.

`data/provenance/core_property_source_ledger.csv` is the Git-diffable property-level evidence record. It maps each of the ten candidates and nine property groups to the exact implementation fields, primary source, locator, unit, source/model validity range, transformation and permitted article claim. The Excel file under `docs/` is a human-readable mirror and is not the machine-readable authority.

For latent services, `latent_J_g` is the primary ranking input. Predicted-family heat capacity is used only by the isolated fixed-50-K opportunity diagnostic and is not represented as an exact-composition liquid measurement.

## Second-stage composite-system coupling

Nanoparticles and porous or foam scaffolds are not treated as new base salts. Each composite record is first linked to an exact base composition and only then evaluated against services for which the base salt passes the registered physical window. Mobile nanofluids require a coupled capacity–hydraulic response; stationary scaffolds require direction-resolved charge and discharge power. Both routes also require full-duty temperature support, durability and compatibility evidence before formal composite eligibility.

For mobile media, the diagnostic capacity–pumping index is `R_capacity / R_viscosity^beta`, where `beta` is sampled uniformly from 0.25 to 1.0. This is a transparent hydraulic sensitivity envelope, not a universal pump law. Conductivity is reported as an additional transport-adjusted diagnostic only where it was measured in the same system. For stationary scaffolds, bidirectional power is the smaller of the reported charge and discharge ratios. Active-salt displacement is retained explicitly rather than absorbed into a composite performance score.

Generated outputs are `core_composite_property_response.csv`, `core_composite_dynamic_summary.csv`, `core_composite_service_coupling.csv`, `core_composite_system_summary.csv`, `core_composite_claim_registry.csv` and `core_composite_source_audit.csv`. The independent validation records are `outputs/qc/core_COMPOSITE_COUPLING_VALIDATION.json` and `outputs/tables/core_composite_model_validation.csv`.
