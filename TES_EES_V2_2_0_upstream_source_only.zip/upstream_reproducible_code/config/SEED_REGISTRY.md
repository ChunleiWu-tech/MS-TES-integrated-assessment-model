# Deterministic random-stream registry

Every stochastic module uses a frozen, module-specific base seed and a declared derivation rule. There is no single global seed for the entire package.

The expanded-library analysis uses candidate-keyed SHA-256 substreams. Removing or reordering another candidate therefore cannot change the physical-property draws assigned to a retained candidate. The formal 15-candidate model retains its previously registered seeds so that the scientific baseline is not silently changed.
