# core independent information and data-lineage audit

The audit covers 29 main-text panels and 22 supplementary panels, giving 1,275 pairwise comparisons.

The audit does not compare derived-table names alone. It traces known parent and ancestor tables and classifies relationships as:

- direct duplicate (not permitted);
- deterministic re-expression (not permitted);
- shared-root independent claim (permitted only when the observational unit, filter, transformation, aggregation and claim axis differ);
- independent source (permitted).

The fixed-scope evidence-redirection and uncertainty-transition analyses both compare `strict_complete_thermophysical` with `strict_complete_evidence_bounded`. For example, Fig. 2c and Fig. 2d can both be traced to candidate-readiness source data, but Fig. 2c evaluates the transition from strict-service probability to bounded selection, whereas Fig. 2d evaluates the thermal-transport and energy-density frontier. Shared source ancestry is disclosed explicitly and is not described as source independence.

New upstream outputs:
- `core_displaced_leader_shortfall_composition.csv`
- `core_redirection_tradeoff_routes.csv`
- `core_gate_bottleneck_transfer.csv`
- `core_selection_uncertainty_transition.csv`
- `core_evidence_programme_nonadditivity.csv`
