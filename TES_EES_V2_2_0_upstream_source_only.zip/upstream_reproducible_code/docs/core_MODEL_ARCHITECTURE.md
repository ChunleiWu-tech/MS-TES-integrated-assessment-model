# core model architecture

1. Candidate phase limits first define the physically liquid portion of each service interval. This physical-window diagnostic is retained separately from strict model eligibility.
2. For sensible-heat services, the registered source-valid temperature domains of heat capacity and density are intersected with the physical interval. Strict-complete thermophysical eligibility requires this joint interval to cover at least 99.9% of the fixed service window. Thermal stability alone never extends a property equation beyond its documented range.
3. Sensible energy is calculated by analytical integration of Cp(T) for a fixed salt mass. Capacity per hot-end salt volume is rho(T_hot) times the specific enthalpy increment. Both property sources must cover the supported duty. The scalar midpoint-product calculation is a separate partial-evidence diagnostic, not the full-duty result.
4. For latent-heat services, the primary metric is measured latent heat. The fixed +50 K sensible contribution is isolated as a non-ranking opportunity diagnostic, with predicted heat capacity labelled explicitly.
5. Atomic non-compensatory gates remove candidates with unresolved corrosion, cycling/phase, containment, literature-replication or data-completeness gaps; direct severe risk cannot be closed by evidence actions.
6. Within eligible candidates, thermophysical performance and engineering credibility are normalized by draw.
7. A top-level two-component utility combines performance and credibility. Credibility is a declared aggregation of five atomic evidence dimensions plus inverse burden.
8. Robustness is evaluated across random top-level weights, alternative credibility structures, evidence-score states, candidate/source omission, property-model sensitivities and independent seeds.
9. Counterfactual actions close one atomic gap at a time or combine explicitly declared actions. Candidate gains and losses remain signed.
10. Every implemented candidate-property field is linked to a registered source, locator, validity range, transformation and article-claim boundary in `data/provenance/core_property_source_ledger.csv`.
