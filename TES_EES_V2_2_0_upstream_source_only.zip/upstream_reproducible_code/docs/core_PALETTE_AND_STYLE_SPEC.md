# core figure and layout specification

- Main-text figures use a fixed width of approximately 179 mm; final canvas dimensions must not be altered by `bbox_inches=tight`.
- Ordinary text must be at least 6.5 pt; only mathematical subscripts and superscripts may scale proportionally to no less than 4.5 pt.
- Use a restrained navy, mustard, olive, terracotta and burgundy palette, with consistent semantics within each figure.
- Figures are first written to temporary files, verified for PNG/PDF rendering, and then atomically moved to their final paths.
- Labels, legends and annotations must remain inside the PDF page boundary.
