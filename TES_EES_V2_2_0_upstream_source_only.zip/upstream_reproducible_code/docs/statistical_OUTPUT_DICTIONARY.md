# statistical new output dictionary

All files are written to `outputs/tables/`.

| File stem | Purpose |
|---|---|
| `pareto_joint_uncertainty_and_robustness` | Joint representative point, 90% uncertainty ellipse parameters, draw-level Pareto frequency and bootstrap interval. |
| `pareto_representative_draw_registry` | One common representative draw and selection rule per service. |
| `continuous_decision_variance_attribution` | Shapley variance allocation for the continuous utility margin and separate pairwise interactions. |
| `categorical_selection_information_attribution` | Entropy/mutual-information allocation for candidate identity including No selection. |
| `structural_stochastic_uncertainty_classification` | Distinguishes service incomplete, evidence locked, deterministic and stochastic services. |
| `uncertainty_block_activation_design` | Pick-and-freeze activation design used by both attribution layers. |
| `evidence_action_dag_registry` | Evidence actions, closed dimensions, prerequisites, burden and interpretation boundary. |
| `dag_constrained_decision_boundary_states` | All admissible action states and their decision consequences. |
| `dag_constrained_minimal_action_sets` | Inclusion-minimal admissible routes to registered decision targets. |
| `inadmissible_action_combination_audit` | Excluded combinations and the violated DAG rule. |
| `evidence_action_outcome_scenario_registry` | Favourable, neutral, adverse and inconclusive outcomes; no probabilities assigned. |

Validation is written to `outputs/qc/statistical_VALIDATION_SUMMARY.json` and `statistical_VALIDATION_CHECKS.csv`.
