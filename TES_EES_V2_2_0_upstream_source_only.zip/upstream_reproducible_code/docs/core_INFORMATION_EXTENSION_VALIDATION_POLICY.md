# core information-extension validation policy

This source release integrates the final validation semantics directly into
`src/information_extensions.py` and `src/presentation_extensions.py`.
No patch, resume script or predecessor output is required.

## Release-blocking checks

The following classes are release-blocking:

- probability or share conservation;
- required seven-service coverage;
- fixed-scope comparison integrity;
- direction checks that must follow from the registered counterfactual definition;
- required schema, evidence-ledger and source-reference integrity.

## Advisory findings

The number of non-zero redirection routes and the number of observed
non-additivity classes are empirical outcomes. They are reported as advisory
findings but are not forced to exceed a chosen count. Treating result diversity
as a validity condition would make the validator prescribe the desired shape of
the results rather than test scientific and computational correctness.

The release status is therefore `PASS` when and only when critical failures are
zero. Advisory findings remain visible in the JSON and CSV audit outputs.
