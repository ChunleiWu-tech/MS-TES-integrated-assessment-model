# Audit-only property model V2 protocol

## Scientific role

The supervised models are discovery and audit instruments. Their predictions cannot populate the candidate registry, close an atomic engineering-evidence gate, extend a measured temperature range, or alter a bounded decision.

## Corrected targets

- Melting temperature is parsed in kelvin from the registered MSD-TP field.
- Density is evaluated from the database relation `rho [kg m-3] = (A - B*T_K)*1000` at five temperatures inside each record's applicable range. The former use of `A` as if it were density is prohibited.

## Representation

Each mixture is encoded by its registered mole-fraction composition, elemental atomic fractions, derived mixture molecular weight, component count, normalized composition entropy, and transparent atomic-number/atomic-weight summaries. Density additionally includes temperature. An element absent from the training corpus is a hard applicability-domain failure.

## Validation and uncertainty

Candidate models (median dummy, ridge, histogram gradient boosting, and extremely randomized trees) are compared by five-fold outer formula-system grouped cross-validation. Random-record cross-validation is reported only as an optimism diagnostic. Prediction intervals use split conformal calibration groups that are disjoint from model-fitting and outer test formula systems; empirical coverage is evaluated only on untouched outer groups.

## Acceptance rules

- A non-dummy model is selected by grouped-CV MAE.
- Independent interval coverage must be at least 0.80 for a nominal 0.90 interval; failure blocks the AI extension status.
- Candidate prediction requires finite features, no unseen element, and scaled nearest-neighbour distance no greater than the 95th percentile of training leave-one-out distances.
- Every prediction remains `used_in_bounded_decision = False`.
