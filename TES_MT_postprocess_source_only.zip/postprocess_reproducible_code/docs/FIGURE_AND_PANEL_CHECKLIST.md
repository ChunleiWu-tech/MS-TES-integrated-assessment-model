# Scientific storyline

TES-EES-V2.2.0-20260909

Composition-specific evidence determines whether a material can be compared over the intended duty. Charging, delivery, capacity and circulation constraints then determine whether the measured enhancement changes a model design requirement.

## Main-figure sequence

1. Composition evidence defines the application comparison.
2. Complete-duty support changes material ranking.
3. Thermal and engineering constraints define different access regimes.
4. Pareto opportunity is broader than qualified material access.
5. Evidence dependencies determine measurement priorities.
6. Operating constraints govern the value of material enhancement.

## Complementary evidence

Supplementary Figures 1–7 resolve the library, property domains, pairwise comparisons and uncertainty. Figures 8–12 separate omission effects, score aggregation, readiness, evidence actions and diagnostic property-model validity. Figure 13 resolves nanoparticle and scaffold measurements. Figures 14–15 connect evidence actions and operating constraints. Figure 16 gives condition-specific corrosion and evidence-index sensitivity. Figure 17 supplies the independent calorimetric comparison.

The independent comparison uses previously unused Solar Salt enthalpy measurements over the shared 250–400 °C liquid interval. Its primary energy error is +3.86%, with a −3.72% fixed-energy material-mass error. The 36 endpoint intervals share nine measured means. They are not independent experiments. The retrospective chloride masking comparison remains separate. Constant-power chronological agreement is a numerical check, not device-scale validation.

The 0.504, 0.885 and 1.053 HITEC composite-to-base volume ratios describe prescribed 1/10, 8/16 and 8/2 h charge/delivery windows in a constant-power, lossless, capacity-constrained model. Nanoparticle fluids and stationary scaffolds retain their own experimental domains. No high-temperature engineering qualification is transferred from a lower-temperature device test.

## Panel and source map

FINAL_FIGURE_CAPTIONS.md contains the complete descriptions of all six main and seventeen supplementary figures. The final outputs/qa/figure_source_map.csv links all 23 figures to generated source tables. Data/Supplementary_Data in the submission package supplies criterion-level reasons, numerical checks and independent calorimetry provenance.

Current captions synchronized from official Word documents on 2026-10-03.

Figure 1. Composition evidence connects material eligibility to application-constrained design. a Separate reference-database and application-library inventories. Formula systems and exact compositions are different counting units. b The 33 distinct source–candidate links in the 15-composition engineering evidence set, grouped by evidence stream and salt family; ribbon widths represent link counts. c All ten joint-availability patterns across 142 exact compositions for melting temperature Tₘ, upper stability limit, heat capacity cₚ and density ρ. Filled circles indicate reported values. Burgundy identifies seven compositions with all four properties reported; availability alone does not establish validity over a duty. d Prescribed cold-to-hot intervals for sensible storage and target phase-transition windows for PCM350, PCM425 and PCM500. e Conditional retention at successive physical, quantitative, complete-duty and engineering-evidence linkage. Each numerator is divided by the preceding-stage count, starting from 142 compositions × 7 duties = 994 pairs. The final 8/11 proportion is the intersection with a separately defined engineering evidence set.

Figure 2a resolves the evidence contraction by duty. Industrial heat retains 26 physical, five quantitative and three complete-duty pairs; coal flexibility retains 23, three and one; concentrating solar power retains 19, two and one. PCM500 retains three complete-duty pairs, whereas PCM350 and PCM425 each retain one. The physical opportunity set therefore contains different levels of comparison depth across applications, as detailed in Supplementary Figure 4 and Supplementary Table 5.

Figure 2b provides a separate composition-level rule-transfer comparison. Nine exact nitrate formulations have tabulated volumetric heat capacities of 3.83–8.09 MJ m⁻³ K⁻¹ at 300 °C and viscosities 4.2–7.1 times the Solar Salt reference. Their tabulated phase boundaries yield 27 physically compatible pairs across coal flexibility, concentrating solar power and industrial heat. This comparison uses the source's comparative specification table, which includes literature values; it is conditional on those tabulated boundaries. Single-temperature values support scalar comparison, whereas complete-duty ranking requires heat-capacity and density support over the prescribed interval (Supplementary Table 4).

Figure 2. Temperature-domain support changes material ranking before engineering qualification. a Pair counts after physical, quantitative and complete-duty requirements. b Volumetric heat capacity and viscosity at 300 °C for nine external nitrate formulations, normalized to Solar Salt. Numbers retain the source formulation identifiers. c Rank-one frequencies for all complete-duty-supported candidate–duty pairs. Ca-nitrate denotes NaNO₃–KNO₃–Ca(NO₃)₂ 16:48:36 wt%; KNC denotes KNO₂–KNO₃–K₂CO₃; C–LiF denotes Na₂CO₃–Li₂CO₃–LiF. Binary carbonate is Na₂CO₃–Li₂CO₃. Cl-2025 is the 23.5:25.0:51.5 wt% NaCl–KCl–CaCl₂ formulation, compared with Cl-reference, the 40.8:7.5:51.7 mol% NaCl–KCl–CaCl₂ composition labelled NKCA in Supplementary Fig. 10. d Formal outcomes for the 15-composition engineering evidence set under balanced preferences. Panels c and d each use 20,000 draws but retain distinct sampling and eligibility specifications. e Complete-duty minus scalar rank-one frequency for sensible-storage duties. Rows include compositions or the no-candidate outcome with an absolute change of at least one percentage point in any duty. Zero denotes no change; grey cells denote absence from both quantitative comparisons. QNCC denotes NaNO₃–KNO₃–Na₂CO₃–NaCl.

Figure 3a separates robust access, conditional access and inaccessible states across the joint coverage–evidence scan. Of 90 states per duty, coal flexibility contains 60 robust-access, 12 conditional-access and 18 inaccessible states. Concentrating solar power and industrial heat each contain 72 conditional-access and 18 inaccessible states, while the four higher-temperature or phase-change duties remain inaccessible throughout the scan. The full 630-state map is provided in Supplementary Figure 6.

Figure 3d identifies thermal headroom as a separate stopping regime. The recent NaCl–KCl–CaCl₂ formulation has +11 °C limiting headroom for PCM500 and negative headroom in the other six duties; HXLN meets three sensible windows but lacks complete-duty property support, NKM-12 lies outside the prescribed windows, and the Na₂CO₃–NaCl–KCl formulation has an unresolved upper stability boundary. Figure 3e summarizes the resulting service-level regimes: coal flexibility contains three joint regimes, concentrating solar power and industrial heat contain two each, and the remaining duties contain one. Supplementary Table 6 records the exact candidate conditions.

Figure 3. Thermal headroom and evidence thresholds identify different stopping mechanisms. a Fractions of 90 coverage–evidence states per duty classified as robust, conditional or inaccessible. b No-selection response to minimum coverage; bands show approximate 90% Monte Carlo sampling intervals. c Evidence-threshold response using the same service colors as b. d Signed limiting thermal headroom. Non-negative values meet the thermal criterion; hatched N/R cells lack an upper stability limit and are excluded from the numerical scale. Cl-2025 denotes the exact chloride formulation reported in 2025 and NC–Cl denotes Na₂CO₃–NaCl–KCl. HXLN and NKM-12 retain their source names. e Classified service-level regime types. Numbers give distinct joint regimes; dark outlines identify services with informative threshold maps.

Figure 4a compares performance and engineering evidence within each duty. The five multi-candidate maps expose different performance–evidence trade-offs, while PCM350 and PCM425 form interval-only singleton comparisons. The marginal 5th–95th percentile ranges on both axes preserve draw-level variation, and Fig. 4b quantifies the resulting bootstrap stability of Pareto membership. Supplementary Figures 8–10 extend these maps to omission sensitivity, evidence aggregation and candidate archetypes.

Figure 4c separates frontier membership from formal selection: Solar Salt reaches the formal-selection threshold in three applications, while HITEC reaches it in industrial heat. Across the 36 candidate–duty memberships, four meet Pareto membership of at least 50%, decision-ready evidence and formal selection of at least 1%; five meet the Pareto criterion alone and 27 meet none of the three criteria (Fig. 4d). The intersections identify the small set of candidate–duty states that are simultaneously competitive, evidenced and formally accessible.

Figure 4. Pareto membership and formal selection describe different outcomes. a Five within-duty performance–evidence maps and one interval-only panel for singleton duties. Filled markers lie on the representative frontier; error bars show marginal 5th–95th percentile draw ranges. Numbers identify the compositions listed in c. b Pareto-membership frequencies with bootstrap 5th–95th percentile intervals, shown for memberships with frequencies of at least 1%. c Numbers of duties with Pareto membership ≥50% or formal selection ≥1%. d Intersections across all 36 candidate–duty memberships. Filled circles indicate Pareto membership ≥50%, decision-ready evidence and formal selection ≥1%, respectively. The small intersection distinguishes comparative opportunity from qualified access.

Figure 5c locates property-domain losses: several candidate–duty pairs lose their entire usable domain when the reported heat-capacity or density range is enforced, producing coverage losses of 1.00 among the largest contractions. Figure 5d ranks the engineering-evidence unlock contributions summed across duties: data completeness contributes 1.07 frequency units, followed by corrosion at 0.93 and containment at 0.91. Supplementary Figures 11 and 12 resolve action precedence, formula-system separation and candidate-invariant value contributions.

Figure 5e shows that prerequisite closure is combinatorial. Coal median retained frequency is 11.72% after one or two closures, 29.55% after three and 62.50% after five. For the phase-change targets, the median remains zero through four closures and reaches 25% after five. The six diagnostic gates are complete-duty support, corrosion, cycling, containment, replication and data completeness; their joint closure determines candidate–draw retention.

Figure 5. Uncertainty attribution and prerequisite closure identify measurement priorities. a Shapley variance shares for continuous top-two utility margins. b Shapley information shares for categorical selection outcomes. Services enter each panel only when its response is defined and variable. c The 12 largest non-zero losses of duty coverage caused by reported property domains. d Engineering-evidence unlock contributions summed across duties. e Median candidate–draw retention across combinations closing the same number of six gates: complete-duty support, corrosion, cycling, containment, replication and data completeness. Each denominator is the number of included candidates in that duty multiplied by 20,000 draws.

Figure 6. Conditional design consequences of reported material and device responses. a Composite-to-base charging and heat-release mean-power ratios for Solar Salt and HITEC. Circles denote 2 wt% alumina and diamonds denote alumina–copper-foam composites; repeated charging values share a source condition. b Model transfer-volume ratios against charge-to-delivery time for two foam comparisons. c Capacity-constrained model volume ratios for HITEC at 180→50 °C under three time-allocation scenarios. d Source-calculated extractable enthalpy per effective filled volume and mean heat-release power as the experimental endpoint changes. e Equal-duty pumping ratios under friction-exponent scenarios using two shear-conditioned apparent viscosities. f Incremental pumping electricity against assumed baseline pumping input. Device data describe central electrical heating and natural-air heat release. Nominal temperature endpoints are paired, and ambient conditions are recorded in the source data. Volumetric mean powers are fixed model coefficients, and delivery windows are prescribed scenarios.

Figure 7a,b show the response to a zero-to-six-action budget in the paired 20,000-draw primary simulation. At six actions, EI reaches a duty-averaged mean formal-candidate count of 0.9420 compared with 0.9304 for random, an increase of 1.25%; EIG reaches 0.9419, an increase of 1.24%. The mean dimensionless cumulative planning burden is 4.5954 for EI and 5.0199 for EIG, compared with 5.9932 for random, corresponding to reductions of 23.32% and 16.24%. Supplementary Table 13 summarizes the six-action endpoint; the complete zero-to-six-action results are provided in the source-data tables.

Figure 7c,d resolve the duty-level mechanism. Formal-candidate differences are concentrated in coal-flexibility and industrial-medium-heat duties, while CSP sensible storage, sCO₂ storage and all three PCM duties share the same six-action formal-candidate count. EI reduces the dimensionless planning burden in all seven duties; EIG reduces it in the non-PCM duties and increases it in the PCM duties. At six actions, no-selection frequency converges to 0.43946 across the four policies; it varies with budget and differs between policies at intermediate budgets. Known nominal physical incompatibilities and direct risks remain fixed in the action model. Endpoint convergence alone does not establish that every remaining exclusion is structural. Supplementary Table 14 and Supplementary Figure 19 provide duty-specific contrasts, robustness directions and paired comparison intervals.

Figure 7. Sequential evidence acquisition under a finite action budget. a Duty-averaged mean formal-candidate count across action budgets. b Dimensionless cumulative planning burden. c Duty-specific differences in mean formal-candidate count relative to random at the six-action horizon. d Duty-specific dimensionless planning-burden reduction relative to random for EIG and EI at the same horizon. Only the two duties with nonzero differences appear in c; the other five duties have exactly zero differences in mean formal-candidate count and are reported in Supplementary Table 14. Results are from the paired 20,000-draw primary simulation; the burden index is a dimensionless planning quantity. The sequential simulation represents hypothetical evidence acquisition. Known nominal melting/upper-temperature incompatibilities and direct-risk exclusions remain fixed; full-range property gaps may be closed by successful actions, and engineering gaps are binary resolved states. Latent-storage thermal dimensions follow the phase-window rule. The continuous evidence thresholds and sampled freeze-margin eligibility used in Figures 2–3 are not reapplied after every action. Simulated post-action candidate counts therefore describe this specified evidence-completion model, rather than current qualification or experimental success.

Figure 8a reports the semi-synthetic sequential assessment over 22 property records from four publications, represented by five extraction labels and including 2 property-linked service-proxy anchors. A policy receives the initial evidence state, selects an action and receives its disclosed generated outcome. At six actions, EI gives an estimated 8.0% planning-burden reduction relative to random (paired record-bootstrap 95% interval -10.0 to 24.9%); EIG gives a 26.3% planning-burden reduction relative to random (paired record-bootstrap 95% interval 8.3 to 43.3%). The source evidence retains pass, fail, unreported and indeterminate states separately. Generated outcomes use publication-separated development data. These record-bootstrap intervals quantify conditional variation within this small literature cohort and do not provide inference across independent experiments or new publications.

Figure 8b shows step-specific action accuracy. At the third disclosure step it is 38.2% for random, 70.6% for greedy-unlock, 16.7% for EIG and 70.6% for EI. Cumulative action accuracy through each budget is a separate estimand (Supplementary Tables 17, 21 and 22). Figure 8c gives first-disclosure reliability curves; Fig. 8d shows record-level burden reductions at six actions. Fixed-budget formal-candidate counts are identical across policies at this property-record grain. The small cohort and generated truth restrict these results to conditional diagnostics. All policies produce zero formal candidates because every record has at least one failing generated gate; the burden contrast describes assessment and stopping effort in these cases.

Figure 8. Holdout-anchored semi-synthetic sequential assessment. a Record-level paired dimensionless cumulative planning-burden reduction relative to random across the action horizon; ribbons show 95% bootstrap intervals across holdout records. b Step-specific action accuracy at each disclosure step; greedy-unlock follows the EI trace and is therefore not drawn separately. c Reliability curves for the first action across all holdout records. d Per-record burden-reduction distributions at six actions. EI and greedy-unlock coincide for this six-action per-record burden distribution and are therefore shown together in d. The holdout supplies the initial evidence state and property-linked service-proxy anchors where available; pass, fail, not reported and cannot judge remain distinct, and remaining gate outcomes are generated from development-only probabilities. Fixed-budget mean formal-candidate count is listed in Supplementary Tables 17 and 21.

Supplementary Figure 1. Complete evidence-library audit

Supplementary Figure 2. Provenance linkage and candidate-specific credibility

Supplementary Figure 3. Unique thermophysical profiles

Supplementary Figure 4. Pairwise energy performance and raw-material boundary

Supplementary Figure 5. Complete-duty overclaim from partial intervals

Supplementary Figure 6. Threshold sensitivity and convergence

Supplementary Figure 7. Candidate-specific engineering-evidence intervals

Supplementary Figure 8. Omission sensitivity

Supplementary Figure 9. Credibility shortfall and aggregation sensitivity

Supplementary Figure 10. Readiness profiles and candidate archetypes

Supplementary Figure 11. Complementary evidence-action diagnostics

Supplementary Figure 12. Formula-system-disjoint model diagnostics and candidate-invariant value audit

Supplementary Figure 13. Composite-media evidence and system-response audit

Supplementary Figure 14. Precedence-valid evidence programs

Supplementary Figure 15. Application switching boundaries and numerical verification

Supplementary Figure 16. Physical compatibility and evidence-index sensitivity

Supplementary Figure 17. Independent enthalpy comparison over a shared liquid interval

Supplementary Figure 18. Decision-evidence availability and sequential inputs. The chart counts 732 candidate–duty gate-state rows across six gates; its denominator is distinct from the 22 property records. Unreported and indeterminate states remain separate from pass and fail. No record establishes two directly measured independent qualification gates. The sequential assessment combines initial evidence, two property-linked availability anchors and development-generated outcomes, preserving each origin.

Supplementary Figure 19. Primary policy, robustness and statistical support. a EI action sequences by duty. b Direction of EI mean-count and dimensionless planning-burden differences from random across specified sensitivity cases. c Duty-specific no-selection frequency at six actions, common to all four policies at that horizon; coal flexibility, CSP and industrial heat have zero no-selection frequency and are listed in the accompanying source data. d Pooled paired differences in mean formal-candidate count from random by action budget. All panels derive from the primary simulation.

Supplementary Figure 20. Publication-level property transportability diagnostic. a Strict-holdout coverage by target. b Strict-holdout coverage by material family. c Publication-level leave-out development coverage by target. d Calibrated target-level log-scale interval radius; wider radii indicate broader uncertainty. Dashed lines in a–c mark the nominal 95% source-calibrated property prediction interval target. The figure reports property-level calibration and evidence coverage; decision-level policy metrics are reported in the holdout assessment.

Supplementary Figure 21. Source-level and material-family assessment stability at the six-action budget. Bars show dimensionless cumulative planning-burden reduction relative to random for EI, EIG and greedy-unlock. All policies give zero formal-candidate counts in this generated-outcome cohort. All stratum values, including small cohorts, are provided in the accompanying data.

Supplementary Figure 22. Provenance of assessment gate states. Grouped bars compare records with unknown source status, records assigned development-generated synthetic truth and records assigned property-availability proxy anchors for each decision gate. Source status and assigned truth origin are different dimensions; their bars are not additive. Development-generated outcomes are not direct experimental observations.
