# Synchronized source data

The integrated local package includes data/input and data/provenance copied from the upstream component. A standard postprocessing run refreshes these copies through src/sync_upstream.py before rendering. The upstream component retains the original inputs; synchronize from that matching sibling release.
