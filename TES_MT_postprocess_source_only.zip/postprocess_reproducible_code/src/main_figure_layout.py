"""Common physical layout for publication Figures 6–8.

The exported canvas is the actual 158.75 mm manuscript width. Each plot is
53.975 by 27.94 mm; extra rows change figure height, never label scale.
"""
import re
import matplotlib.pyplot as plt
from matplotlib.text import Text

WIDTH = 6.25
HEIGHT = {6: 7.15, 7: 4.90, 8: 4.90}

def apply(fig, number):
    fig.set_layout_engine(None)
    fig.set_size_inches(WIDTH, HEIGHT[number])
    axes = fig.axes
    legends = []
    for ax in axes:
        leg = ax.get_legend()
        legends.append((list(leg.legend_handles), [t.get_text() for t in leg.get_texts()]) if leg else ([], []))
        if leg: leg.remove()
    for leg in list(fig.legends): leg.remove()
    for text in list(fig.texts):
        if re.fullmatch('[a-f]', text.get_text()): text.remove()
    rows = 3 if number == 6 else 2
    for i, ax in enumerate(axes):
        for text in list(ax.texts):
            if re.fullmatch('[a-f]', text.get_text()): text.remove()
        row, col = divmod(i, 2)
        bottom = .63 + 2.32 * (rows - row - 1)
        ax.set_position((.14 + .50*col, bottom/HEIGHT[number], .34, 1.10/HEIGHT[number]))
        ax.tick_params(labelsize=8, length=3, width=.7)
        ax.xaxis.label.set_size(8.5); ax.yaxis.label.set_size(8.5)
        ax.title.set_size(8)
        for spine in ax.spines.values(): spine.set_linewidth(.7)
        for text in ax.texts: text.set_fontsize(8)
        for line in ax.lines:
            if line.get_linewidth() > 1: line.set_linewidth(1.4)
        fig.text(.14+.50*col-.045, (bottom+1.10+.075)/HEIGHT[number], chr(97+i),
                 fontsize=11, weight='bold', va='bottom')
    for text in fig.findobj(match=Text): text.set_fontfamily('DejaVu Sans')
    return legends

def top_legend(ax, handles, labels, columns=1):
    """Center each legend in its own reserved strip above the plot."""
    return ax.legend(handles, labels, loc='lower center', bbox_to_anchor=(.5, 1.07),
                     ncol=columns, fontsize=8, frameon=False, borderaxespad=0,
                     handlelength=1.35, handletextpad=.45, columnspacing=.75,
                     labelspacing=.35)

def verify(fig):
    fig.canvas.draw()
    renderer = fig.canvas.get_renderer()
    bounds = fig.bbox
    rows = []
    for i, ax in enumerate(fig.axes):
        outside_ticks=set()
        for axis, lim in [(ax.xaxis,ax.get_xlim()),(ax.yaxis,ax.get_ylim())]:
            low,high=sorted(lim)
            for tick in [*axis.get_major_ticks(),*axis.get_minor_ticks()]:
                if not low <= tick.get_loc() <= high:
                    outside_ticks.update([tick.label1,tick.label2])
        leg = ax.get_legend()
        if leg:
            b = leg.get_window_extent(renderer)
            assert b.x0 >= bounds.x0 and b.x1 <= bounds.x1 and b.y0 >= bounds.y0 and b.y1 <= bounds.y1, (i, 'legend outside canvas',b.bounds,bounds.bounds)
            collisions = [j for j, other in enumerate(fig.axes) if b.overlaps(other.get_window_extent(renderer))]
            assert not collisions, (i, 'legend overlaps plot', collisions)
            label_collisions=[(j,t.get_text()) for j,other in enumerate(fig.axes) if j!=i
                              for t in [other.xaxis.label,other.yaxis.label,other.title]
                              if t.get_visible() and t.get_text() and b.overlaps(t.get_window_extent(renderer))]
            assert not label_collisions,(i,'legend overlaps another panel label',label_collisions)
            rows.append({'panel':chr(97+i),'legend_position':'centered_above_own_plot',
                         'legend_labels':[t.get_text() for t in leg.get_texts()],
                         'overlapping_plot_indices':collisions,'overlapping_other_panel_labels':label_collisions})
        # Include axis labels, tick labels and in-panel annotations in the crop check.
        for text in ax.findobj(match=Text):
            if not text.get_visible() or not text.get_text() or text in outside_ticks: continue
            b = text.get_window_extent(renderer)
            assert b.x0 >= bounds.x0-1 and b.x1 <= bounds.x1+1 and b.y0 >= bounds.y0-1 and b.y1 <= bounds.y1+1, (i,text.get_text(),'text outside canvas',b.bounds)
    return rows
