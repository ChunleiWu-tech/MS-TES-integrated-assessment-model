"""Current figures from hard-cost planning and existing-measurement challenges.

All numbers are read from retained upstream tables. No response is synthesized
for experimental validation. The V3 action-count study remains historical.
"""
from pathlib import Path
import json, shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from render_evidence_upgrade import panels as original_panels, finish, joint_mass, conditional_table

ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'outputs/tables'
P=ROOT.parent/'EES_Submission_Package'
N='#244658';TEAL='#278A83';GOLD='#B17C23';RED='#A45D68';GRAY='#84939A'
COL={'random':GRAY,'cheapest':GOLD,'greedy_cert':RED,'point':N,'robust':TEAL,'robust_continue':'#78834B'}
LAB={'random':'Random','cheapest':'Cheapest','greedy_cert':'Greedy certificate','point':'Point planner','robust':'Robust planner','robust_continue':'Robust, continue'}
TARGET=['melting_temperature_K_literature_only','density_kg_m3','viscosity_mPa_s']
TL=['Melting, literature','Density','Viscosity']
SC=['central_independent','central_positive035','central_positive070','central_antagonistic','low_corner','high_corner','mixed_corner','probability_downshift','probability_upshift','dependence_outside_family']
SN=['Independent','Positive 0.35','Positive 0.70','Antagonistic','Low corner','High corner','Mixed corner','Downshift','Upshift','Outside 0.90']
SERV=['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat','sco2_high_temperature_storage','pcm_target_350C','pcm_target_425C','pcm_target_500C']
SV=['Coal','CSP','Industry','Gen3','PCM 350','PCM 425','PCM 500']

def read(n):return pd.read_csv(T/(n+'.csv'))
def panels(*args,**kw):
 fig,axs=original_panels(*args,**kw)
 for ax in axs.flat:ax.set_axisbelow(True)
 return fig,axs
def select(d,**kw):
 for k,v in kw.items():d=d[d[k]==v]
 return d
def main7(s):
 fig,axs=panels(height=6.2);a,b,c,d=axs.flat
 g=select(s,process_scenario='central_positive035',duty='pooled',objective='pass2_fail1')
 for p in ['random','cheapest','greedy_cert','point','robust']:
  q=select(g,policy=p).sort_values('cost_budget_per_duty')
  a.plot(q.cost_budget_per_duty,q.mean_pass,'o-',color=COL[p],ms=3,label=LAB[p])
  b.plot(q.cost_budget_per_duty,q.mean_fail,'o-',color=COL[p],ms=3)
 a.set(xlabel='Cost cap per duty (ordinal units)',ylabel='New all-pass certificates',xticks=[4,8,12],ylim=(0,3.4))
 b.set(xlabel='Cost cap per duty (ordinal units)',ylabel='New exclusion certificates',xticks=[4,8,12],ylim=(0,14))
 h,l=a.get_legend_handles_labels();fig.legend(h,l,loc='upper center',bbox_to_anchor=(.53,1.015),ncol=3,frameon=False,fontsize=8.6)
 fig.get_layout_engine().set(rect=(0,.065,1,.85))
 for ob,style in [('pass1_fail1','--'),('pass2_fail1','-')]:
  for p in ['random','point','robust']:
   q=select(s,process_scenario='central_positive035',duty='pooled',objective=ob,policy=p).sort_values('cost_budget_per_duty')
   c.plot(q.cost_budget_per_duty,q.mean_weighted_utility,style,marker='o',color=COL[p],ms=3)
 c.set(xlabel='Cost cap per duty (ordinal units)',ylabel='Weighted utility',xticks=[4,8,12])
 c.text(.04,.98,'Solid: pass 2 / fail 1\nDashed: pass 1 / fail 1',transform=c.transAxes,va='top',fontsize=8.5)
 case=read('core_certificate_case_ledger').query('case_id == 0').iloc[0]
 q=np.array(json.loads(case.planning_marginal_central));ct=conditional_table(joint_mass(q,.35,False,96)[None,:],len(q))[0][0]
 x=np.arange(len(q));d.barh(x-.17,q,height=.32,color=N,label='Before test');d.barh(x+.17,ct[1<<2,:],height=.32,color=TEAL,label='Corrosion passes')
 d.set(yticks=x,yticklabels=['Cp','Density','Corrosion','Cycling','Containment','Completeness'],xlim=(0,1),xlabel='Assumed conditional pass probability');d.invert_yaxis()
 h,l=d.get_legend_handles_labels();fig.legend(h,l,loc='lower center',bbox_to_anchor=(.75,.002),frameon=False,fontsize=8.5)
 return finish(fig,7,sources=['core_certificate_v4_strategy_summary','core_certificate_case_ledger'])

def main8(m,e,dev):
 fig,axs=panels(height=6.0);a,b,c,d=axs.flat
 q=e[e.low_C==250].sort_values('high_C')
 a.plot(q.high_C,q.observed_enthalpy_kJ_kg,'o-',color=N,ms=3,label='Published enthalpy')
 a.plot(q.high_C,q.predicted_enthalpy_kJ_kg,'s--',color=TEAL,ms=3,label='Heat-capacity integral')
 a.set(xlabel='Upper endpoint (°C); lower = 250 °C',ylabel='Liquid enthalpy increment (kJ kg$^{-1}$)')
 a.text(.97,.07,'250–400 °C: +3.86%',ha='right',transform=a.transAxes,fontsize=8.5)
 q=dev[dev.split_type=='leave_publication_out'].copy().sort_values(['heldout_doi','material','direction'])
 y=np.arange(len(q));b.barh(y-.16,q.mean_absolute_error_percent,height=.3,color=TEAL,label='Response surrogate');b.barh(y+.16,q.identity_mean_absolute_error_percent,height=.3,color=GRAY,label='Identity baseline')
 labs=[]
 for _,r in q.iterrows():labs.append(('SS' if 'enbenv' in r.heldout_doi else 'HITEC')+' '+('foam' if 'foam' in r.material else 'Al₂O₃')+' '+('charge' if r.direction=='charge' else 'release'))
 b.set(yticks=y,yticklabels=labs,xlabel='Held-publication mean |error| (%)');b.invert_yaxis()
 ha,la=a.get_legend_handles_labels();hb,lb=b.get_legend_handles_labels()
 fig.legend(ha+hb,la+lb,frameon=False,fontsize=8.5,ncol=2,loc='upper center',bbox_to_anchor=(.53,1.01))
 fig.get_layout_engine().set(rect=(0,0,1,.88))
 q=m[(m.target=='density_kg_m3')&(m.validation_scheme=='publication_component')].sort_values('nominal_coverage')
 y=np.arange(2);c.barh(y,q.finite_only_whole_component_coverage,color=[TEAL,N],height=.55)
 for j,(_,r) in enumerate(q.iterrows()):
  n=int(r.n_finite_blocking_components);covered=round(r.finite_only_whole_component_coverage*n)
  c.text(.035,j,f'{covered}/{n} publications',va='center',color='white',fontsize=8.6)
  c.plot([r.nominal_coverage]*2,[j-.35,j+.35],color=GOLD,lw=2)
 c.set(yticks=y,yticklabels=['Nominal 90%','Nominal 95%'],xlim=(0,1.05),xlabel='Whole-publication density coverage');c.invert_yaxis();c.xaxis.set_major_formatter(PercentFormatter(1))
 q=m[(m.target=='viscosity_mPa_s')&(m.validation_scheme=='publication_component')].sort_values('nominal_coverage')
 y=np.arange(2);d.barh(y,np.log10(q.finite_mean_multiplicative_radius),color=[TEAL,N],height=.55)
 for j,(_,r) in enumerate(q.iterrows()):d.text(.2,j,f'{int(r.n_finite_blocking_components)}/{int(r.n_blocking_components)} publications',va='center',color='white',fontsize=8.6)
 d.set(yticks=y,yticklabels=['Nominal 90%','Nominal 95%'],xlabel='log₁₀(mean viscosity interval factor)');d.invert_yaxis()
 return finish(fig,8,sources=['core_existing_v4_enthalpy_intervals','core_existing_v4_device_transfer_summary','core_thermophysical_v4_summary'])

def supp12(m):
 fig,axs=panels(height=5.8)
 for ax,field,title in zip(axs.flat,['publication_macro_log_MAE','finite_component_fraction','finite_only_whole_component_coverage','allocation_supported_component_fraction'],['Publication mean |log error|','Completely finite component fraction','Finite-component empirical coverage','Allocation-supported component fraction']):
  for delta,scheme,col in [(-.17,'publication_component',TEAL),(.17,'joint_publication_formula',N)]:
   q=select(m,validation_scheme=scheme,nominal_coverage=.9).set_index('target')
   ax.barh(np.arange(3)+delta,[q.loc[t,field] for t in TARGET],height=.32,color=col,label='Publication' if delta<0 else 'Publication + formula')
  ax.set(yticks=range(3),yticklabels=TL,xlabel=title);ax.invert_yaxis()
  if 'fraction' in field or 'coverage' in field:ax.set_xlim(0,1.05);ax.xaxis.set_major_formatter(PercentFormatter(1))
 h,l=axs[0,0].get_legend_handles_labels();fig.legend(h,l,ncol=2,loc='upper center',frameon=False,fontsize=8.6,bbox_to_anchor=(.53,1.01));fig.get_layout_engine().set(rect=(0,0,1,.92))
 return finish(fig,12,True,['core_thermophysical_v4_summary'])

def supp25(s):
 fig,axs=panels(height=5.9);x=np.arange(7)
 for ax,field,title in zip(axs.flat,['mean_pass','mean_fail','mean_burden','mean_undetermined'],['New all-pass certificates','New exclusion certificates','Spent ordinal burden','Remaining undetermined cases']):
  g=select(s,process_scenario='central_positive035',objective='pass2_fail1',cost_budget_per_duty=12)
  for j,p in enumerate(['random','point','robust']):
   q=select(g,policy=p).set_index('duty').loc[SERV]
   ax.bar(x+(j-1)*.24,q[field],width=.22,color=COL[p],label=LAB[p])
  ax.set(xticks=x,xticklabels=SV,ylabel=title);ax.tick_params(axis='x',rotation=45)
 h,l=axs[0,0].get_legend_handles_labels();fig.legend(h,l,ncol=3,frameon=False,fontsize=8.6,loc='upper center',bbox_to_anchor=(.53,1.015));fig.get_layout_engine().set(rect=(0,0,1,.93))
 return finish(fig,25,True,['core_certificate_v4_strategy_summary'])

def supp26(o):
 fig,axs=panels(3,2,height=8.1)
 for i,t in enumerate(TARGET):
  for j,scheme in enumerate(['publication_component','joint_publication_formula']):
   ax=axs[i,j];q=select(o,target=t,validation_scheme=scheme,nominal_coverage=.9);q=q[q.prediction.notna()]
   if i==2:
    q=q[(q.prediction>0)&(q.observed_database_target>0)];ax.set_xscale('log');ax.set_yscale('log')
   ax.scatter(q.observed_database_target,q.prediction,s=4,alpha=.35,color=TEAL if j==0 else N,rasterized=True)
   lo=min(q.observed_database_target.min(),q.prediction.min());hi=max(q.observed_database_target.max(),q.prediction.max());ax.plot([lo,hi],[lo,hi],color=GRAY,lw=.8)
   unit=['K','kg m$^{-3}$','mPa s'][i]
   ax.set(xlabel=f'Database target ({unit})',ylabel=f'Held-out prediction ({unit})',title=TL[i]+('\nPublication' if j==0 else '\nPublication + formula'))
 return finish(fig,26,True,['core_thermophysical_v4_oof_predictions'])

def supp27(pc,oracle):
 fig,axs=panels(height=6.4);a,b,c,d=axs.flat
 # Read actual process order instead of inferring or relabelling outcomes.
 order=pc.process_scenario.drop_duplicates().tolist()
 for ax,ob in [(a,'pass1_fail1'),(b,'pass2_fail1')]:
  ax.grid(False)
  q=select(pc,objective=ob,policy='robust',reference='point',metric='weighted_utility')
  z=q.pivot(index='process_scenario',columns='cost_budget_per_duty',values='paired_difference').loc[order,[4.,8.,12.]].to_numpy()
  im=ax.imshow(z,cmap='RdBu',vmin=-1.3,vmax=1.3,aspect='auto');ax.set(xticks=range(3),xticklabels=[4,8,12],yticks=range(10),yticklabels=SN,xlabel='Cost cap per duty',title='Pass / fail rewards '+('1 / 1' if ob=='pass1_fail1' else '2 / 1'))
  for y in range(10):
   for x in range(3):ax.text(x,y,f'{z[y,x]:.2f}',ha='center',va='center',fontsize=8.2,color='white' if abs(z[y,x])>.6 else N)
 fig.colorbar(im,ax=[a,b],label='Robust minus point: weighted utility',shrink=.8)
 for ob,col,dx in [('pass1_fail1',N,-.12),('pass2_fail1',TEAL,.12)]:
  q=oracle[oracle.objective==ob]
  for k,cap in enumerate([4,8,12]):
   vals=q[q.cost_budget==cap].relative_optimality_gap*100
   c.scatter(np.full(len(vals),k+dx),vals,color=col,s=12,alpha=.55,label=('Pass / fail '+('1 / 1' if ob=='pass1_fail1' else '2 / 1')) if k==0 else None)
 c.set(xticks=range(3),xticklabels=[4,8,12],xlabel='Small-instance cost cap',ylabel='Exact-to-separable value gap (%)');c.legend(frameon=False,fontsize=8.2)
 q=select(pc,objective='pass2_fail1',cost_budget_per_duty=12,policy='robust',reference='robust_continue',metric='weighted_utility').set_index('process_scenario').loc[order]
 v=q.paired_difference.to_numpy();d.errorbar(v,np.arange(10),xerr=np.array([v-q.mc95_lower,q.mc95_upper-v]),fmt='o',ms=3,color=TEAL,capsize=2);d.axvline(0,color=GRAY,lw=.8)
 d.set(yticks=range(10),yticklabels=SN,xlabel='Stopping minus continuation: utility');d.invert_yaxis()
 return finish(fig,27,True,['core_certificate_v4_paired_comparisons','core_certificate_v4_small_portfolio_oracle'])

def supp28(counter,dev,e,m):
 fig,axs=panels(height=6.2);a,b,c,d=axs.flat
 q=counter[counter.kind=='temperature_transfer_counterexample'];a.barh(range(len(q)),q.challenge_over_reference,color=RED,height=.55)
 a.set(yticks=range(len(q)),yticklabels=[x.replace('CORR_TEMP_','') for x in q.counterexample_id],xlabel='700 °C / 500 °C corrosion rate');a.invert_yaxis()
 q=counter[counter.kind=='endpoint_transfer_counterexample']
 if len(q)==0:q=counter[counter.counterexample_id.str.startswith('CORR_ENDPOINT_')]
 b.barh(range(len(q)),q.challenge_over_reference,color=GOLD,height=.55);b.set(yticks=range(len(q)),yticklabels=[x.replace('CORR_ENDPOINT_','') for x in q.counterexample_id],xlabel='Penetration / mass-loss rate');b.invert_yaxis()
 q=dev[dev.split_type=='hold_high_temperature_domain'].copy().sort_values(['heldout_doi','material','direction'])
 if len(q)==0:q=dev[dev.split_type!='leave_publication_out'].copy().sort_values(['heldout_doi','material','direction'])
 c.barh(range(len(q)),q.mean_absolute_error_percent,color=TEAL,height=.55)
 c.set(yticks=range(len(q)),yticklabels=[('SS' if 'enbenv' in r.heldout_doi else 'HITEC')+' '+('foam' if 'foam' in r.material else 'Al₂O₃')+' '+('charge' if r.direction=='charge' else 'release') for _,r in q.iterrows()],xlabel='Held-hot-domain mean |error| (%)');c.invert_yaxis()
 q=e.sort_values(['low_C','high_C']);d.scatter(q.high_C-q.low_C,q.model_minus_observed_percent,color=N,s=15,alpha=.7);d.axhline(0,color=GRAY,lw=.8)
 r=q[q.primary_full_interval==True].iloc[0];d.scatter([r.high_C-r.low_C],[r.model_minus_observed_percent],color=GOLD,s=50,zorder=3)
 d.set(xlabel='Shared-endpoint interval width (°C)',ylabel='Enthalpy prediction error (%)')
 return finish(fig,28,True,['core_existing_v4_counterexamples','core_existing_v4_device_transfer_summary','core_existing_v4_enthalpy_intervals'])

def main():
 import presentation_v5
 presentation_v5.install()
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.,'axes.labelsize':9.,'axes.titlesize':9.,'xtick.labelsize':8.5,'ytick.labelsize':8.5,'legend.fontsize':8.5,'pdf.fonttype':42,'ps.fonttype':42})
 s=read('core_certificate_v4_strategy_summary');pc=read('core_certificate_v4_paired_comparisons');m=read('core_thermophysical_v4_summary');o=read('core_thermophysical_v4_oof_predictions');e=read('core_existing_v4_enthalpy_intervals');dev=read('core_existing_v4_device_transfer_summary');counter=read('core_existing_v4_counterexamples')
 rows=[main7(s),main8(m,e,dev),supp12(m),supp25(s),supp26(o),supp27(pc,read('core_certificate_v4_small_portfolio_oracle')),supp28(counter,dev,e,m)]
 (ROOT/'outputs/qc/scientific_v4_figure_sources.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
 for f in T.glob('*v4*'):
  if f.is_file():shutil.copy2(f,P/'Data'/f.name)
 print('V4: regenerated main 7–8 and supplementary 12,25–28; all source tables copied.')
if __name__=='__main__':main()
