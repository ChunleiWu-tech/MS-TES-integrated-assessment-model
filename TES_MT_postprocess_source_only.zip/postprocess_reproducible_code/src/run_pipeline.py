from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
QC = ROOT / "outputs" / "qc"
RELEASE_ID = "TES-EES-SCIENTIFIC-V5-PRESENTATION-V9-20261006"
STAGES = [
    "clean_generated_outputs.py",
    "check_env.py",
    "check_upstream_contract.py",
    "run_postprocess.py",
    "validate_postprocess.py",
    "validate_release_contract.py",
    "render_application_figures.py",
    "render_ees_presentation.py",
    "render_engineering_evidence.py",
    "render_external_enthalpy.py",
    "render_evidence_upgrade.py",
    "render_scientific_v4.py",
    "render_submission_presentation_v5.py",
    "render_scientific_v5.py",
    "render_main_figures_v9.py",
    "write_package_manifest.py",
]


def main() -> None:
    parser = argparse.ArgumentParser(description="Canonical OS-independent post-processing workflow")
    parser.add_argument("--upstream-root", default="../upstream_reproducible_code")
    parser.add_argument("--no-sync", action="store_true")
    parser.add_argument("--no-clean", action="store_true", help="Preserve separately authored diagnostics; overwrite generated figures")
    parser.add_argument("--resume-from", choices=STAGES)
    args = parser.parse_args()

    env = os.environ.copy()
    env.setdefault("PYTHONFAULTHANDLER", "1")
    env.setdefault("PYTHONUNBUFFERED", "1")
    for key in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
        env[key] = "1"

    if not args.no_sync:
        sync = subprocess.run([sys.executable, "-X", "faulthandler", "-u", str(SRC / "sync_upstream.py"), args.upstream_root], cwd=ROOT, env=env)
        if sync.returncode != 0:
            raise SystemExit(sync.returncode)

    started = time.time()
    records = []
    stages = [s for s in STAGES if not(args.no_clean and s == "clean_generated_outputs.py")]
    resume_index=stages.index(args.resume_from) if args.resume_from else 0
    if args.resume_from:
        if not(args.no_clean and args.no_sync):
            parser.error("Resume requires --no-clean --no-sync to preserve verified preceding stages")
        previous=json.loads((QC/"pipeline_execution_status.json").read_text(encoding="utf-8"))
        records=previous['stages'][:resume_index]
        if [r['stage'] for r in records]!=stages[:resume_index] or any(r['returncode'] for r in records):
            raise ValueError("Resume prefix does not match successfully executed preceding stages")
    for index, stage in enumerate(stages, 1):
        if index<=resume_index:continue
        print(f"\n=== [{index:02d}/{len(stages):02d}] {stage} ===", flush=True)
        t0 = time.time()
        result = subprocess.run([sys.executable, "-X", "faulthandler", "-u", str(SRC / stage)], cwd=ROOT, env=env)
        records.append({"index": index, "stage": stage, "returncode": result.returncode, "elapsed_s": round(time.time() - t0, 6)})
        if result.returncode != 0:
            QC.mkdir(parents=True, exist_ok=True)
            payload = {"status": "FAIL", "release_id": RELEASE_ID, "failed_stage": stage, "stages": records}
            (QC / "pipeline_execution_status.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
            raise SystemExit(result.returncode)
    payload = {"status": "PASS", "release_id": RELEASE_ID, "failed_stage": None, "elapsed_s": round(time.time() - started, 6), "stages": records,
               "resume_from": args.resume_from, "reused_successful_prefix_stages": stages[:resume_index],
               "executed_stages_this_invocation": stages[resume_index:], "upstream_sync_performed": not args.no_sync}
    (QC / "pipeline_execution_status.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    if stages[-1] == "write_package_manifest.py":
        subprocess.run([sys.executable, str(SRC / stages[-1])], cwd=ROOT, env=env, check=True)
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
