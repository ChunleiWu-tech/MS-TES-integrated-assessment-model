"""Figures from the source-blocked property study and individual-task study.

Every numerical panel reads a supplied table. No experimental gate data are
created here. Prefix curves are checkpoints of a six-action planning horizon.
"""
from pathlib import Path
import json, sys, shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT=Path(__file__).resolve().parents[1]
RELEASE=ROOT.parent
UP=RELEASE/'upstream_reproducible_code'
T=ROOT/'outputs/tables'
PKG=RELEASE/'EES_Submission_Package'
sys.path.insert(0,str(UP/'src'))
from evidence_certificate_model import joint_mass, conditional_table
NAVY='#244658'; TEAL='#278A83'; GOLD='#B17C23'; RED='#A45D68'; GRAY='#84939A'
COLORS={'random':GRAY,'ei_proxy':GOLD,'entropy':RED,'greedy_resolution':'#78834B',
        'rcp_point':'#6788A8','rcp':TEAL,'rcp_continue':NAVY}
LABELS={'random':'Random','ei_proxy':'EI proxy','entropy':'Entropy','greedy_resolution':'Greedy resolution',
        'rcp_point':'Point planner','greedy_stop':'Greedy + stop','rcp_independent':'Independent robust',
        'rcp_cost0':'Robust λ = 0','rcp_l025':'Robust λ = 0.025','rcp':'Robust + stop',
        'rcp_continue':'Robust, continue','rcp_l100':'Robust λ = 0.10'}
TARGETS=['melting_temperature_K','melting_temperature_K_literature_only','density_kg_m3',
         'viscosity_mPa_s','thermal_conductivity_W_m_K']
TL=['Tm, all','Tm, literature','Density','Viscosity','Conductivity']
SERV=['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat',
      'sco2_high_temperature_storage','pcm_target_350C','pcm_target_425C','pcm_target_500C']
SN=['Coal','CSP','Industry','Gen3','PCM 350','PCM 425','PCM 500']

def read(name):
    return pd.read_csv(T/(name+'.csv'))

def panels(rows=2,cols=2,height=6.1):
    fig,axs=plt.subplots(rows,cols,figsize=(6.3,height),layout='constrained',squeeze=False)
    fig.get_layout_engine().set(w_pad=.09,h_pad=.12,wspace=.10,hspace=.12)
    for i,ax in enumerate(axs.flat):
        ax.text(-.20,1.07,chr(97+i),transform=ax.transAxes,fontweight='bold',fontsize=11,va='bottom')
        ax.spines[['top','right']].set_visible(False)
        ax.grid(axis='y',color='#EDF0F1',linewidth=.6,zorder=0)
    return fig,axs

def finish(fig,n,supp=False,sources=()):
    dest=ROOT/'outputs'/('supplementary_figures' if supp else 'main_figures')
    dest.mkdir(parents=True,exist_ok=True)
    stem=f'submission_{"Supp_Fig" if supp else "Fig"}{n}'
    for ext in ['pdf','png']:
        p=dest/(stem+'.'+ext)
        fig.savefig(p,dpi=300,bbox_inches='tight',pad_inches=.12,
                    **({'metadata':{'CreationDate':None,'ModDate':None}} if ext=='pdf' else {}))
        target=PKG/'Figures'/('Supplementary' if supp else 'Main')/p.name
        shutil.copy2(p,target)
    plt.close(fig)
    return {'figure':('Supp_Fig' if supp else 'Fig')+str(n),'source_tables':list(sources)}

def endpoints(s,process='central_independent',scenario='pooled'):
    return s[(s.process_scenario==process)&(s.scenario==scenario)&(s.trajectory_step==6)].set_index('policy')

def main7(s):
    fig,axs=panels(height=6.1); a,b,c,d=axs.flat
    g=s[(s.process_scenario=='central_independent')&(s.scenario=='pooled')]
    for p in ['random','ei_proxy','entropy','rcp','rcp_continue']:
        q=g[g.policy==p].sort_values('trajectory_step'); co=COLORS[p]
        a.plot(q.trajectory_step,q.mean_new_certificates/19,marker='o',ms=3,color=co,label=LABELS[p])
        b.plot(q.trajectory_step,q.mean_burden,marker='o',ms=3,color=co)
    a.set(xlabel='Disclosure checkpoint per duty',ylabel='Resolved fraction of 19 cases',ylim=(0,1),xticks=[0,2,4,6]);a.yaxis.set_major_formatter(PercentFormatter(1))
    handles,labels=a.get_legend_handles_labels()
    fig.legend(handles,labels,fontsize=8.2,loc='upper center',bbox_to_anchor=(.54,1.01),ncol=3,frameon=False)
    fig.get_layout_engine().set(rect=(0,.065,1,.85))
    b.set(xlabel='Disclosure checkpoint per duty',ylabel='Pooled ordinal burden',xticks=[0,2,4,6])
    e=endpoints(s)
    for p in e.index:
        c.scatter(e.loc[p,'mean_burden'],e.loc[p,'mean_new_certificates'],s=28,color=COLORS.get(p,'#BBC3C6'),zorder=3)
    labelpos={'random':(52,13.85),'entropy':(42,12.98),'rcp_point':(40.4,15.86),'rcp':(47.6,15.10),'rcp_continue':(47,16.29),'greedy_stop':(53.1,16.45)}
    for p,pos in labelpos.items():
        c.annotate(LABELS[p],(e.loc[p,'mean_burden'],e.loc[p,'mean_new_certificates']),xytext=pos,ha='center',fontsize=8.2,color=COLORS.get(p,NAVY),arrowprops={'arrowstyle':'-','lw':.5,'color':GRAY})
    c.set(xlabel='Pooled ordinal burden at checkpoint 6',ylabel='New pass or fail certificates',xlim=(37.5,56),ylim=(12.7,16.55))
    ledger=read('core_certificate_case_ledger');case=ledger[ledger.case_id==0].iloc[0]
    q=np.array(json.loads(case.planning_marginal_central));joint=joint_mass(q,.35,False,96)
    cond=conditional_table(joint[None,:],len(q))[0][0]
    names=['Cp','ρ','Corrosion','Cycling','Containment','Completeness'];x=np.arange(len(q));after=cond[1<<2,:]
    d.barh(x-.17,q,height=.32,color=NAVY,label='Before disclosure')
    d.barh(x+.17,after,height=.32,color=TEAL,label='After corrosion passes')
    d.set(yticks=x,yticklabels=names,xlim=(0,1),xlabel='Assumed conditional pass probability');d.invert_yaxis()
    handles,labels=d.get_legend_handles_labels()
    fig.legend(handles,labels,loc='lower center',bbox_to_anchor=(.76,.002),fontsize=8.2,frameon=False)
    return finish(fig,7,sources=['core_certificate_strategy_summary','core_certificate_case_ledger'])

def main8(s,m):
    fig,axs=panels(height=6.0);a,b,c,d=axs.flat
    a.barh([0,1,2,3,4],[360,634,374,32,9],color=TEAL,height=.58)
    a.barh(0,572,left=360,color=GOLD,height=.58,label='Calculated melting targets')
    a.set(yticks=range(5),yticklabels=['Melting','Density','Viscosity','Conductivity','Heat capacity'],xlabel='Retained source curves or melting records',xlim=(0,1050));a.invert_yaxis()
    for y,v in enumerate([932,634,374,32,9]):a.text(v+15,y,str(v),va='center',fontsize=8.2)
    a.legend(frameon=False,loc='lower right',fontsize=8.2)
    pub=m[m.validation_scheme=='publication_component'].set_index(['target','nominal_coverage'])
    x=np.arange(5)
    b.barh(x-.17,[pub.loc[(t,.9),'finite_component_fraction'] for t in TARGETS],height=.32,color=TEAL,label='Nominal 90%')
    b.barh(x+.17,[pub.loc[(t,.95),'finite_component_fraction'] for t in TARGETS],height=.32,color=NAVY,label='Nominal 95%')
    b.set(yticks=x,yticklabels=TL,xlim=(0,1.12),xlabel='Source groups with finite intervals');b.invert_yaxis();b.xaxis.set_major_formatter(PercentFormatter(1))
    b.legend(frameon=False,loc='lower right',fontsize=8.2)
    pairs=read('core_certificate_paired_comparisons')
    ps=pairs[(pairs.policy=='rcp')&(pairs.reference=='random')&(pairs.metric=='certificates')]
    process_names=['Independent','Positive 0.35','Positive 0.70','Antagonistic','Low corner','High corner','Mixed corner','Downshift','Upshift','Outside: 0.90']
    order=s.process_scenario.drop_duplicates().tolist();ps=ps.set_index('process_scenario').loc[order]
    val=ps.paired_difference.to_numpy()/19*100
    c.errorbar(val,np.arange(10),xerr=np.array([val-ps.mc95_lower.to_numpy()/19*100,ps.mc95_upper.to_numpy()/19*100-val]),fmt='o',ms=3,color=TEAL,capsize=2)
    c.axvline(0,color=GRAY,lw=.8);c.set(yticks=range(10),yticklabels=process_names,xlabel='Resolved fraction gain vs Random (pp)');c.invert_yaxis()
    stops=read('core_certificate_stopping_comparisons')
    stop=stops[stops.metric=='utility_lambda005'].set_index('process_scenario').loc[order]
    val=stop.paired_difference.to_numpy()
    d.errorbar(val,np.arange(10),xerr=np.array([val-stop.mc95_lower.to_numpy(),stop.mc95_upper.to_numpy()-val]),fmt='o',ms=3,color=RED,capsize=2)
    d.axvline(0,color=GRAY,lw=.8);d.set(yticks=range(10),yticklabels=process_names,xlabel='Utility change from stopping (λ = 0.05)');d.invert_yaxis()
    return finish(fig,8,sources=['core_thermophysical_v3_summary','core_thermophysical_v3_record_ledger','core_certificate_paired_comparisons','core_certificate_stopping_comparisons'])

def supp12(m):
    fig,axs=panels(height=5.7);a,b,c,d=axs.flat
    for ax,field,label in [(a,'point_R2','Point R² (physical scale)'),(b,'publication_macro_log_MAE','Publication mean |log error|')]:
        for delta,scheme,col in [(-.17,'publication_component',TEAL),(.17,'joint_publication_formula',NAVY)]:
            q=m[(m.validation_scheme==scheme)&(m.nominal_coverage==.9)].set_index('target')
            ax.barh(np.arange(5)+delta,[q.loc[t,field] for t in TARGETS],height=.32,color=col,label='Publication' if delta<0 else 'Publication + formula')
        ax.set(yticks=range(5),yticklabels=TL,xlabel=label);ax.invert_yaxis()
    a.axvline(0,color=GRAY,lw=.8)
    handles,labels=a.get_legend_handles_labels()
    fig.legend(handles,labels,frameon=False,fontsize=8.2,loc='upper center',bbox_to_anchor=(.53,1.025),ncol=2)
    fig.get_layout_engine().set(rect=(0,0,1,.93))
    for delta,scheme,col in [(-.17,'publication_component',TEAL),(.17,'joint_publication_formula',NAVY)]:
        q=m[(m.validation_scheme==scheme)&(m.nominal_coverage==.9)].set_index('target')
        c.barh(np.arange(5)+delta,[q.loc[t,'finite_component_fraction'] for t in TARGETS],height=.32,color=col)
        d.barh(np.arange(5)+delta,[q.loc[t,'finite_only_whole_component_coverage'] for t in TARGETS],height=.32,color=col)
    for ax,label in [(c,'Groups with finite 90% intervals'),(d,'Whole-group coverage, finite groups only')]:
        ax.set(yticks=range(5),yticklabels=TL,xlim=(0,1.05),xlabel=label);ax.invert_yaxis();ax.xaxis.set_major_formatter(PercentFormatter(1))
    return finish(fig,12,True,['core_thermophysical_v3_summary'])

def supp23():
    bounds=read('core_certificate_probability_bounds');bounds=bounds[bounds.unknown_gates.gt(0)&~bounds.case_id.isin(read('core_certificate_case_ledger').query('structurally_excluded').case_id)]
    fig,axs=panels(1,2,height=4.5);a,b=axs.flat
    y=np.arange(len(bounds));a.hlines(y,bounds.elicited_frechet_lower,bounds.elicited_frechet_upper,color=TEAL,lw=3)
    a.scatter(bounds.independent_central_product,y,color=GOLD,s=14,label='Independent central product')
    a.set(yticks=y,yticklabels=['Case '+str(i) for i in bounds.case_id],xlim=(0,1),xlabel='Conditional joint-pass bounds');a.invert_yaxis()
    handles,labels=a.get_legend_handles_labels()
    fig.legend(handles,labels,frameon=False,loc='upper center',bbox_to_anchor=(.52,1.025),fontsize=8.2)
    fig.get_layout_engine().set(rect=(0,0,1,.93))
    b.hlines(y,0,1,color=GRAY,lw=3);b.set(yticks=y,yticklabels=[],xlim=(0,1),xlabel='Empirical joint-pass probability is unidentified');b.invert_yaxis()
    return finish(fig,23,True,['core_certificate_probability_bounds','core_certificate_case_ledger'])

def supp24(s):
    fig,axs=panels(height=6.0);a,b,c,d=axs.flat;e=endpoints(s);order=list(e.index);y=np.arange(len(order))
    for ax,col,label in [(a,'mean_new_certificates','New certificates'),(b,'mean_burden','Ordinal burden'),(c,'mean_new_pass_certificates','New all-pass certificates'),(d,'mean_fixed_penalty_utility','Certificates − 0.05 × burden')]:
        ax.barh(y,e[col],color=[COLORS.get(p,'#A4AFB5') for p in order],height=.65)
        ax.set(yticks=y,yticklabels=[LABELS[p] for p in order],xlabel=label);ax.invert_yaxis()
    return finish(fig,24,True,['core_certificate_strategy_summary'])

def supp25(s):
    fig,axs=panels(height=5.8);a,b,c,d=axs.flat
    for ax,col,label in [(a,'mean_new_certificates','New certificates'),(b,'mean_burden','Ordinal burden'),(c,'mean_new_pass_certificates','New all-pass certificates'),(d,'mean_undetermined','Remaining undetermined cases')]:
        for delta,p in [(-.23,'random'),(0,'rcp'),(.23,'rcp_continue')]:
            vals=[]
            for duty in SERV:
                q=endpoints(s,scenario=duty);vals.append(q.loc[p,col] if p in q.index else 0)
            ax.bar(np.arange(7)+delta,vals,width=.22,color=COLORS[p],label=LABELS[p])
        ax.set(xticks=range(7),xticklabels=SN,ylabel=label);ax.tick_params(axis='x',rotation=45)
    a.legend(frameon=False,fontsize=8.2)
    return finish(fig,25,True,['core_certificate_strategy_summary'])

def supp26():
    o=read('core_thermophysical_v3_oof_predictions');fig,axs=panels(height=5.9)
    for ax,t,label in zip(axs.flat,['melting_temperature_K_literature_only','density_kg_m3','viscosity_mPa_s','thermal_conductivity_W_m_K'],['Melting (K), literature only','Density (kg m$^{-3}$)','Viscosity (mPa s), logarithmic axes','Conductivity (W m$^{-1}$ K$^{-1}$)']):
        for scheme,col in [('publication_component',TEAL),('joint_publication_formula',NAVY)]:
            g=o[(o.target==t)&(o.validation_scheme==scheme)&(o.nominal_coverage==.9)]
            ax.scatter(g.observed_database_target,g.prediction,s=5,alpha=.24,color=col,label='Publication' if scheme=='publication_component' else 'Publication + formula',rasterized=True)
        g=o[(o.target==t)&(o.nominal_coverage==.9)];lo=min(g.observed_database_target.min(),g.prediction.min());hi=max(g.observed_database_target.max(),g.prediction.max())
        if t=='viscosity_mPa_s':ax.set_xscale('log');ax.set_yscale('log');lo=max(lo,.05)
        ax.plot([lo,hi],[lo,hi],color=GRAY,lw=.8);ax.set(xlabel='Source target: '+label,ylabel='Held-out prediction')
    axs[0,0].legend(frameon=False,fontsize=8.2,markerscale=2)
    return finish(fig,26,True,['core_thermophysical_v3_oof_predictions'])

def main():
    plt.rcParams.update({'font.family':'Arial','font.size':8.5,'axes.labelsize':8.5,'xtick.labelsize':8.2,'ytick.labelsize':8.2,'legend.fontsize':8.2,'pdf.fonttype':42})
    s=read('core_certificate_strategy_summary');m=read('core_thermophysical_v3_summary')
    records=[main7(s),main8(s,m),supp12(m),supp23(),supp24(s),supp25(s),supp26()]
    qa=ROOT/'outputs/qa';qa.mkdir(exist_ok=True)
    (qa/'evidence_upgrade_figure_sources.json').write_text(json.dumps({'status':'PASS','records':records,'numerical_origin':'provided tables; simulation and source-correlation diagnostics, not experimental gate qualification'},indent=2),encoding='utf-8')
    print('Regenerated main Figures 7–8, Supplementary Figure 12 and Figures 23–26')

if __name__=='__main__':main()
