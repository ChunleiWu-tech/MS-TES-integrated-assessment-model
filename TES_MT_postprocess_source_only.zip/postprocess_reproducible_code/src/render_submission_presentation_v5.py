"""Render the integrated manuscript figures after scientific postprocessing."""
from pathlib import Path
import runpy
ROOT=Path(__file__).resolve().parents[1]
entry=ROOT.parent/'EES_Submission_Package/Analysis_Scripts/render_submission_figures.py'
if not entry.exists():raise FileNotFoundError('Extract the complete release, including EES_Submission_Package and Active_Learning_Upgrade, before rendering publication assets.')
runpy.run_path(str(entry),run_name='__main__')
