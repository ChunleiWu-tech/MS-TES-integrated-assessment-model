"""Publication layout and source-backed replacements; scientific inputs unchanged."""
from pathlib import Path
import re,json,shutil,textwrap
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.figure import Figure
from matplotlib.text import Text
from matplotlib.ticker import PercentFormatter
ROOT=Path(__file__).resolve().parents[1]
P=ROOT.parent/'EES_Submission_Package'
T=ROOT/'outputs/tables'
Q=ROOT.parent/'QA'
N='#244658'; TEAL='#278A83'; GOLD='#B17C23'; RED='#A45D68'; GRAY='#84939A'
ORIGINAL=Figure.savefig
LOG=[]
def read(n):
    paths=[T/(n+'.csv'),P/'Data'/(n+'.csv'),P/'Data/Figure_Source_Tables'/(n+'.csv'),P/'Data/Application_Analysis_Tables'/(n+'.csv')]
    return pd.read_csv(next(p for p in paths if p.exists()))
def clean(ax):
    ax.spines[['top','right']].set_visible(False)
    ax.set_axisbelow(True)
def edit_panel(fig,name):
    if 'Supp_Fig2.' in name:
        q=read('core_candidate_database_linkage_audit');nonzero=q[q.best_component_set_jaccard>0].sort_values('best_component_set_jaccard',ascending=False);zero=q[q.best_component_set_jaccard==0]
        ax=fig.axes[0];ax.clear();clean(ax)
        names={'flinak_rr':'FLiNaK RR','mgcl_kcl_nacl':'MgCl₂ mix','nkca':'NKCA','nknkcl_2026':'NKN-KCl','pcm_lif_s1':'Carbonate–LiF','nkckcl_2026':'NKC-KCl','qncc':'QNCC'}
        vals=nonzero.best_component_set_jaccard.tolist()+[0.];labs=[names.get(x,x) for x in nonzero.system_id]+[f'No component match\n{len(zero)} candidates']
        cols=[N if v else GOLD for v in nonzero.exact_formula_system_match]+[GRAY]
        for j,(v,col) in enumerate(zip(vals,cols)):
            ax.hlines(j,0,v,color=GRAY,lw=1);ax.scatter(v,j,color=col,s=22)
            if v>0:ax.text(v+.04,j,f'{v:.2f}',va='center',color=col)
        ax.set(yticks=range(len(vals)),yticklabels=labs,xlim=(-.04,1.28),xlabel='Component-set match');ax.invert_yaxis();ax.text(-.16,1.04,'a',transform=ax.transAxes,weight='bold')
    if 'Supp_Fig14.' in name and len(fig.axes)>2:
        q=read('submission_research_action_frontier_summary');q=q[q.mean_no_selection_reduction>1e-12].sort_values('mean_no_selection_reduction')
        ax=fig.axes[2];ax.clear();clean(ax);names={'comprehensive_upper_bound':'All-evidence bound','combined_atomic_evidence_closure':'Evidence program','service_redesign_95pct':'Duty redesign'}
        ax.barh(range(len(q)),q.mean_no_selection_reduction,color=[TEAL if x=='combined_atomic_evidence_closure' else N for x in q.closure_action],height=.55)
        for j,v in enumerate(q.mean_no_selection_reduction):ax.text(v+.015,j,f'{100*v:.1f}%',va='center')
        ax.set(yticks=range(len(q)),yticklabels=[names[x] for x in q.closure_action],xlim=(0,.61),xlabel='Mean no-selection reduction');ax.xaxis.set_major_formatter(PercentFormatter(1));ax.text(-.14,1.04,'c',transform=ax.transAxes,weight='bold')
    if any(x in name for x in ['Supp_Fig8.','Supp_Fig10.']):
        for ax in fig.axes:
            for t in list(ax.texts):
                if t.get_text().strip() in ['+0.00','-0.00','0.00']:t.remove()
    if 'submission_Fig8.' in name:
        for ax in fig.axes:
            for t in ax.texts:
                if re.fullmatch('[a-d]',t.get_text()):t.set_position((-.18,1.09))
    if 'submission_Fig5.' in name and len(fig.axes)>2:
        ax=fig.axes[2];ax.clear();clean(ax)
        q=read('submission_property_domain_contraction_summary');field='coverage_loss_due_to_registered_property_domains'
        q=q[q[field]>.01].sort_values(field).tail(12);full=q[q[field]>=1-1e-12];partial=q[q[field]<1-1e-12]
        vals=partial[field].tolist()+([1.] if len(full) else [])
        duties={'csp_sensible_storage':'CSP','coal_flexibility_storage':'Coal','industrial_medium_heat':'Industry'}
        names={'tms2':'TMS-2','knc':'KNC','qncc':'QNCC'}
        labels=[duties.get(r.scenario,r.scenario)+' · '+names.get(r.system_id,str(r.system_id).upper()) for r in partial.itertuples()]+([f'Complete domain loss\n{len(full)} pairs'] if len(full) else [])
        ax.barh(range(len(vals)),vals,color=[N]*len(partial)+([TEAL] if len(full) else []),height=.55)
        ax.set(yticks=range(len(vals)),yticklabels=labels,xlim=(0,1.05),xlabel='Duty coverage lost');ax.xaxis.set_major_formatter(PercentFormatter(1));ax.invert_yaxis()
        e=fig.axes[-1]
        if e.images:
            im=e.images[0];arr=np.ma.asarray(im.get_array())
            if len(arr)==7 and np.allclose(arr[-3].filled(np.nan),arr[-2].filled(np.nan),equal_nan=True) and np.allclose(arr[-2].filled(np.nan),arr[-1].filled(np.nan),equal_nan=True):
                merged=np.ma.vstack([arr[:4],arr[4:5]]);im.set_data(merged);ext=im.get_extent();im.set_extent((ext[0],ext[1],4.5,-.5));e.set_ylim(4.5,-.5)
                e.set_yticks(range(5),['Coal','CSP','Industry','sCO₂','PCM 350/425/500'])
                for t in list(e.texts):
                    if t.get_text()!='e':t.remove()
                for i in range(5):
                    for j in range(merged.shape[1]):
                        v=merged[i,j]
                        if not np.ma.is_masked(v) and v>0 and (j==0 or not np.isclose(v,merged[i,j-1])) and (v<1 or i==0):e.text(j,i,f'{100*v:.1f}%',ha='center',va='center',fontsize=8.5,color='white' if v>.55 else N)
    if 'submission_Fig7.' in name:
        ax=fig.axes[0]
        for line in list(ax.lines):
            if line.get_label()=='Robust planner':line.remove()
    if 'Supp_Fig25.' in name:
        s=read('core_certificate_v4_strategy_summary');g=s[(s.process_scenario=='central_positive035')&(s.objective=='pass2_fail1')&(s.cost_budget_per_duty==12)&(s.duty!='pooled')]
        duties=['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat','sco2_high_temperature_storage','pcm_target_350C','pcm_target_425C','pcm_target_500C'];p=g[g.policy=='point'].set_index('duty').loc[duties];r=g[g.policy=='robust'].set_index('duty').loc[duties]
        assert np.allclose(p.mean_pass,r.mean_pass)
        ax=fig.axes[0];ax.clear();clean(ax)
        for delta,policy,col in [(-.15,'random',GRAY),(.15,'point',N)]:
            z=g[g.policy==policy].set_index('duty').loc[duties];ax.bar(np.arange(7)+delta,z.mean_pass,width=.28,color=col)
        ax.set(xticks=range(7),xticklabels=['Coal','CSP','Industry','Gen3','PCM 350','PCM 425','PCM 500'],ylabel='New all-pass certificates');ax.tick_params(axis='x',rotation=45);ax.text(-.20,1.04,'a',transform=ax.transAxes,weight='bold')
    if 'submission_Fig1.' in name:
        for t in fig.findobj(match=Text):
            if t.get_text()=='Formula systems':t.set_text('Formula\nsystems')
            if t.get_text()=='Exact compositions':t.set_text('Exact\ncompositions')
    if 'Supp_Fig1.' in name and len(fig.axes)>1:
        ax=fig.axes[1]
        if ax.images:
            im=ax.images[0];arr=im.get_array()
            if np.all(arr[:,-1]==0):
                im.set_data(arr[:,:-1]);old=im.get_extent();im.set_extent((old[0],old[1]-1,old[2],old[3]));ax.set_xlim(old[0],old[1]-1)
                labs=[t.get_text() for t in ax.get_xticklabels()][:-1];ax.set_xticks(range(len(labs)),labs)
                for t in list(ax.texts):
                    if t.get_position()[0]>=len(labs)-.5:t.remove()
    if re.search(r'(?:submission_)?Fig4(?:\.|$)',name) and 'Supp_' not in name:
        small=[a for a in fig.axes if a.get_position().height<.18]
        for ax,title in zip(small[:6],['Coal flexibility','Concentrating solar power','Industrial heat','Supercritical CO₂','PCM 500','PCM 350 / PCM 425']):
            ax.set_title(title,fontsize=9,pad=7)
    if 'Supp_Fig6' in name:
        for ax in fig.axes:
            for line in list(ax.lines):
                if line.get_label()=='Median':line.remove()
    if 'Supp_Fig9' in name and len(fig.axes)>=2:
        ax=fig.axes[1];ax.clear();clean(ax)
        q=read('core_credibility_model_sensitivity')
        base=q[q.credibility_model=='hierarchical_geometric'][['scenario','selection_entropy']].rename(columns={'selection_entropy':'base'})
        q=q[q.credibility_model!='hierarchical_geometric'].merge(base,on='scenario')
        q=q[(q.selection_entropy-q.base).abs()>1e-12];ss=q.scenario.drop_duplicates().tolist()
        for model,color,shift in [('hierarchical_arithmetic',N,-.16),('bottleneck_minimum',TEAL,.16)]:
            z=q[q.credibility_model==model].set_index('scenario').loc[ss]
            ax.barh(np.arange(len(ss))+shift,1000*(z.selection_entropy-z.base),height=.30,color=color,label='Arithmetic' if color==N else 'Bottleneck')
        ax.axvline(0,color=GRAY,lw=.7);ax.set(yticks=range(len(ss)),yticklabels=['Industry' if 'industrial' in x else x for x in ss],xlabel='Selection-entropy change (10⁻³ bit)');ax.invert_yaxis();ax.legend()
        ax.text(-.15,1.04,'b',transform=ax.transAxes,fontweight='bold')
    if 'Supp_Fig15' in name and len(fig.axes)>=4:
        ax=fig.axes[2];ax.clear();clean(ax)
        q=read('application_chronological_checks').drop_duplicates(['source_id','chemistry','material','hot_C','cold_C','archetype'])
        counts=pd.crosstab(q.archetype,q.active_constraint).reindex(['balanced','rapid_delivery','short_charge']).fillna(0)
        # The source uses named archetypes; retain its actual labels if they differ.
        if counts.sum().sum()!=len(q):counts=pd.crosstab(q.archetype,q.active_constraint)
        left=np.zeros(len(counts))
        for k,col in enumerate(counts.columns):
            ax.barh(range(len(counts)),counts[col],left=left,color=[N,TEAL,GOLD][k],label=col.replace('_',' ').capitalize());left+=counts[col].to_numpy()
        ax.set(yticks=range(len(counts)),yticklabels=[x.replace('_',' ').capitalize() for x in counts.index],xlabel='Distinct capacity-constrained cases');ax.invert_yaxis();ax.legend()
        ax.text(-.15,1.04,'c',transform=ax.transAxes,fontweight='bold')
    if 'Supp_Fig12' in name and len(fig.axes)>=4:
        ax=fig.axes[3];ax.clear();clean(ax);m=read('core_thermophysical_v4_summary')
        ts=['melting_temperature_K_literature_only','density_kg_m3','viscosity_mPa_s'];labs=[];y=0
        for target,short in zip(ts,['Melting','Density','Viscosity']):
            for scheme,sh in [('publication_component','Publication'),('joint_publication_formula','Joint')]:
                z=m[(m.target==target)&(m.validation_scheme==scheme)].set_index('nominal_coverage')
                for level,dx,col in [(.90,-.15,TEAL),(.95,.15,N)]:
                    r=z.loc[level];frac=r.n_supported_blocking_components/r.n_blocking_components
                    ax.barh(y+dx,frac,height=.28,color=col,label=f'Nominal {int(level*100)}%' if y==0 else None)
                counts=[f'{int(z.loc[level].n_supported_blocking_components)}/{int(z.loc[level].n_blocking_components)}' for level in [.90,.95]]
                label=counts[0] if counts[0]==counts[1] else ' → '.join(counts)
                ax.text(1.06,y,label,va='center',fontsize=8.5)
                labs.append(short+' · '+sh);y+=1
        ax.set(yticks=range(y),yticklabels=labs,xlim=(0,1.90),xticks=[0,.5,1],xlabel='Allocation-supported\ncomponent fraction');ax.invert_yaxis();ax.xaxis.set_major_formatter(PercentFormatter(1));ax.legend()
        ax.text(-.20,1.04,'d',transform=ax.transAxes,fontweight='bold')
    if 'Supp_Fig28' in name and len(fig.axes)>=4:
        ax=fig.axes[3];ax.clear();clean(ax)
        q=read('core_existing_v4_counterexamples');q=q[q.kind=='direction_transfer_counterexample'].reset_index(drop=True)
        mid=(q.discharge_response_low+q.discharge_response_high)/2
        for j,r in q.iterrows():
            col=TEAL if r.discharge_sensitivity_class=='decrease' else GOLD
            ax.errorbar(mid[j],j,xerr=[[mid[j]-r.discharge_response_low],[r.discharge_response_high-mid[j]]],fmt='o',color=col,ms=3,capsize=2)
        ax.axvline(1,color=GRAY,lw=.8,ls='--')
        labels=[]
        for x in q.counterexample_id:
            year=re.search(r'XIAO[_\s]*(\d+)',str(x));hot=re.search(r'hot(\d+)',str(x));cold=re.search(r'discharge(\d+)',str(x))
            labels.append(('SS' if year and year[1]=='2023' else 'HITEC')+' '+hot[1]+'→'+cold[1]+' °C')
        ax.set(yticks=range(len(q)),yticklabels=labels,xlabel='Foam / base heat-release ratio');ax.invert_yaxis()
        ax.text(-.20,1.04,'d',transform=ax.transAxes,fontweight='bold')
def reflow(fig,name):
    if getattr(fig,'_presentation_v5',False):return
    edit_panel(fig,name)
    for ax in fig.axes:ax.tick_params(axis='both',labelsize=8.5)
    for t in fig.findobj(match=Text):
        if not t.get_text():continue
        val=t.get_text().replace('registered threshold','comparison threshold').replace('registered model','specified model').replace('engineering registry','engineering evidence set').replace('Program non-additivity','Combined-action effect')
        t.set_text(val);t.set_fontsize(max(8.5,t.get_fontsize()))
        t.set_fontfamily('DejaVu Sans')
        if re.fullmatch('[a-h]',val):t.set_fontsize(11)
    # Preserve the physical plot area and reserve a separate strip for legends.
    legends=[*fig.legends,*[a.get_legend() for a in fig.axes if a.get_legend() is not None]]
    handles=[];labels=[]
    for leg in legends:
        for h,t in zip(leg.legend_handles,leg.get_texts()):
            lab=t.get_text()
            if 'Supp_Fig6.' in name and lab=='Median':continue
            if lab not in labels:handles.append(h);labels.append(lab)
        leg.remove()
    fig.canvas.draw()
    if labels:
        cols=min(3,len(labels));rows=int(np.ceil(len(labels)/cols));extra=.30*rows+.25
        old=fig.get_figheight();unused=max(0,old*(1-max(a.get_position().y1 for a in fig.axes))-.35);new=old+extra-unused
        positions=[a.get_position().frozen() for a in fig.axes]
        fig.set_layout_engine(None);fig.set_size_inches(fig.get_figwidth(),new)
        for ax,pos in zip(fig.axes,positions):ax.set_position([pos.x0,pos.y0*old/new,pos.width,pos.height*old/new])
        for t in fig.texts:
            x,y=t.get_position();t.set_position((x,y*old/new))
        fig.legend(handles,[textwrap.fill(x,30) for x in labels],loc='upper center',bbox_to_anchor=(.5,.995),ncol=cols,frameon=False,fontsize=9,columnspacing=1.4,handlelength=1.8)
    if ('submission_Fig6.' in name or 'Supp_Fig15.' in name):
        for ax in fig.axes:
            for t in list(ax.texts):
                if re.fullmatch('[a-f]',t.get_text()):t.remove()
        for t in list(fig.texts):
            if re.fullmatch('[a-f]',t.get_text()):t.remove()
        for i,ax in enumerate(fig.axes):
            p=ax.get_position();fig.text(max(.01,p.x0-.055),p.y1+.015,chr(97+i),weight='bold',fontsize=11,fontfamily='DejaVu Sans')
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    collisions=[]
    for leg in fig.legends:
        b=leg.get_window_extent(renderer)
        for i,a in enumerate(fig.axes):
            p=a.get_window_extent(renderer)
            if min(b.x1,p.x1)>max(b.x0,p.x0) and min(b.y1,p.y1)>max(b.y0,p.y0):collisions.append(i)
    LOG.append({'asset':name,'legend_labels':labels,'legend_intersects_plot_axes':collisions,'min_visible_font_pt':min(t.get_fontsize() for t in fig.findobj(match=Text) if t.get_text() and t.get_visible())})
    fig._presentation_v5=True
def savefig(fig,fname,*args,**kw):
    if 'submission_' in str(fname):
        reflow(fig,Path(fname).name)
        kw.setdefault('bbox_inches','tight');kw.setdefault('pad_inches',.10)
    return ORIGINAL(fig,fname,*args,**kw)
def install():Figure.savefig=savefig
def panels(r=1,c=2,height=4):
    fig,axs=plt.subplots(r,c,figsize=(6.8,height),layout='constrained',squeeze=False)
    fig.get_layout_engine().set(w_pad=.1,h_pad=.15,wspace=.16,hspace=.20)
    for i,ax in enumerate(axs.flat):clean(ax);ax.text(-.16,1.04,chr(97+i),transform=ax.transAxes,weight='bold',fontsize=11)
    return fig,axs
SOURCES={}
def finish(fig,n,sources):
    stem=f'submission_Supp_Fig{n}'
    for dest in [ROOT/'outputs/supplementary_figures',P/'Figures/Supplementary']:
        for ext in ['png','pdf']:fig.savefig(dest/(stem+'.'+ext),dpi=300,bbox_inches='tight',pad_inches=.12)
    plt.close(fig);SOURCES['Supp_Fig'+str(n)]=sources
def s3():
    q=read('core_unique_thermophysical_profiles')
    q=q.groupby('profile_signature',sort=False,dropna=False).agg({'display_system':'first','member_count':'sum','fixed_window_coverage':'first','cp_at_service_J_gK':'first','density_at_service_kg_m3':'first','thermal_k_at_service_W_mK':'first','complete_service_energy_fixed_kWh_m3':'first'}).reset_index()
    cols=['fixed_window_coverage','cp_at_service_J_gK','density_at_service_kg_m3','thermal_k_at_service_W_mK','complete_service_energy_fixed_kWh_m3']
    x=q[cols];lo=x.min();span=x.max()-lo;x=(x-lo)/span.replace(0,1)
    mask=q[cols].isna();x=x.mask(mask)
    fig,axs=panels(1,1,height=max(4,len(q)*.25));ax=axs[0,0]
    cmap=plt.get_cmap('YlGnBu').copy();cmap.set_bad('#E1E5E7')
    im=ax.imshow(np.ma.masked_invalid(x.to_numpy()),cmap=cmap,vmin=0,vmax=1,aspect='auto')
    labels=[str(r.display_system) if r.member_count==1 else f'Shared profile · {int(r.member_count)} pairs' for r in q.itertuples()]
    ax.set(yticks=range(len(q)),yticklabels=labels,xticks=range(5),xticklabels=['Duty\ncoverage','Heat\ncapacity','Density','Thermal\nconductivity','Duty\nenergy'])
    for i,j in zip(*np.where(mask.to_numpy())):ax.text(j,i,'N/E',ha='center',va='center',fontsize=8,color=N)
    fig.colorbar(im,ax=ax,location='top',label='Within-column normalized reported value',pad=.08,shrink=.8)
    finish(fig,3,['core_unique_thermophysical_profiles'])
def s18():
    q=read('semi_synthetic_cohort_manifest');counts=pd.crosstab(q.family,q.linkage_status)
    fig,axs=panels(1,1,height=3.6);ax=axs[0,0];left=np.zeros(len(counts))
    for col,color in zip(counts.columns,[TEAL,GRAY]):
        ax.barh(range(len(counts)),counts[col],left=left,label=col.replace('_',' '),color=color);left+=counts[col].to_numpy()
    ax.set(yticks=range(len(counts)),yticklabels=[str(x).replace('mixed_carbonate_chloride','carbonate/chloride') for x in counts.index],xlabel='Published property records (total = 22)');ax.invert_yaxis();ax.legend()
    finish(fig,18,['semi_synthetic_cohort_manifest'])
def s20():
    a=read('conformal_validation_metrics_by_target');f=read('conformal_validation_metrics_by_family');cal=read('conformal_target_calibration')
    fig,axs=panels(2,2,6.4);ax,b,c,d=axs.flat
    targets=a.target.drop_duplicates().tolist();ys=np.arange(len(targets))
    for k,cohort in enumerate(a.cohort.drop_duplicates()):
        z=a[a.cohort==cohort].set_index('target').reindex(targets);ax.barh(ys+(k-.5)*.25,z.mean_absolute_log_error,height=.24,label='Published challenge' if cohort=='strict_holdout' else 'Development records',color=[N,TEAL,GOLD][k%3])
    target_names={'cp_J_gK':'Heat capacity','cycle_count':'Cycle count','density_kg_m3':'Density','latent_heat_J_g':'Latent heat','melting_temperature_C':'Melting temperature','stability_temperature_C':'Stability limit','thermal_conductivity_W_mK':'Thermal conductivity','viscosity_mPa_s':'Viscosity'}
    short=lambda x:target_names.get(x,x.replace('_',' ').replace('temperature','temp.'))
    ax.set(yticks=ys,yticklabels=[short(x) for x in targets],xlabel='Mean absolute log-ratio error');ax.invert_yaxis();ax.legend()
    b.barh(range(len(cal)),cal.multiplicative_factor,color=TEAL);b.set(yticks=range(len(cal)),yticklabels=[short(x) for x in cal.target],xlabel='95% multiplicative interval factor');b.invert_yaxis()
    challenge=f[f.cohort.str.contains('holdout|challenge',regex=True)].copy()
    if challenge.empty:challenge=f[f.cohort==f.cohort.iloc[-1]].copy()
    family=challenge.material_family if 'material_family' in challenge else challenge.family
    c.scatter(challenge.mean_absolute_log_error,range(len(challenge)),color=N,s=24);c.set(yticks=range(len(challenge)),yticklabels=family.str.replace('mixed_carbonate_chloride','carbonate/chloride',regex=False),xlabel='Challenge mean absolute log-ratio error');c.invert_yaxis()
    challenge=a[a.cohort.str.contains('holdout|challenge',regex=True)].copy()
    if challenge.empty:challenge=a[a.cohort==a.cohort.iloc[-1]].copy()
    for j,r in challenge.reset_index(drop=True).iterrows():
        d.barh(j,r.supported_records,color=TEAL);d.text(r.records+.2,j,f'{int(r.supported_records)}/{int(r.records)}',va='center')
    d.set(yticks=range(len(challenge)),yticklabels=[short(x) for x in challenge.target],xlabel='Challenge records with supported intervals');d.invert_yaxis()
    finish(fig,20,['conformal_validation_metrics_by_target','conformal_validation_metrics_by_family','conformal_target_calibration'])
def s21():
    q=read('semi_synthetic_replay_summary');q=q[(q.budget_actions==6)&q.cohort_type.isin(['source','material_family'])]
    fig,axs=panels(1,2,5.8)
    for ax,typ in zip(axs.flat,['source','material_family']):
        z=q[q.cohort_type==typ];base=z[z.policy=='random'].set_index('cohort');cohorts=base.index.tolist()
        for j,(policy,color,label) in enumerate([('ei',TEAL,'EI / greedy unlock'),('eig',N,'EIG')]):
            v=z[z.policy==policy].set_index('cohort').loc[cohorts];greedy=z[z.policy=='greedy_unlock'].set_index('cohort').loc[cohorts]
            if policy=='ei':assert np.allclose(v.cumulative_measurement_burden,greedy.cumulative_measurement_burden)
            reduction=100*(1-v.cumulative_measurement_burden/base.cumulative_measurement_burden)
            ax.barh(np.arange(len(cohorts))+(j-.5)*.28,reduction,height=.26,color=color,label=label)
        labs=[textwrap.fill(str(x).replace('mixed_carbonate_chloride','carbonate/chloride'),24)+f' · n={int(base.loc[x,"n_records"])}' for x in cohorts]
        ax.set(yticks=range(len(cohorts)),yticklabels=labs,xlabel='Burden reduction versus random (%)');ax.axvline(0,color=GRAY,lw=.8);ax.invert_yaxis();ax.legend()
    finish(fig,21,['semi_synthetic_replay_summary'])
def s22():
    q=read('semi_synthetic_cohort_manifest');counts=pd.crosstab(q.source,q.target)
    fig,axs=panels(1,1,4.8);a=axs[0,0];arr=counts.to_numpy();masked=np.ma.masked_where(arr==0,arr)
    cmap=plt.get_cmap('YlGnBu').copy();cmap.set_bad('#EEF0F1');im=a.imshow(masked,cmap=cmap,vmin=0,vmax=arr.max(),aspect='auto')
    labs=[textwrap.fill(x.replace('comparison table','comparison').replace('thermal stability','stability'),30) for x in counts.index]
    targets=[x.replace('_',' ').replace('temperature','temp.') for x in counts.columns]
    a.set(yticks=range(len(counts)),yticklabels=labs,xticks=range(len(counts.columns)),xticklabels=targets);a.tick_params(axis='x',rotation=60)
    for i,j in zip(*np.where(arr>0)):a.text(j,i,str(arr[i,j]),ha='center',va='center',color='white' if arr[i,j]>=3 else N)
    anchors=q[q.truth_origin_incomplete_service=='property_anchored_exact_holdout']
    for r in anchors.itertuples():a.scatter(counts.columns.get_loc(r.target),counts.index.get_loc(r.source),s=210,facecolors='none',edgecolors=GOLD,linewidths=2)
    fig.colorbar(im,ax=a,location='top',label='Published scalar records per source–target cell',pad=.10,shrink=.8)
    finish(fig,22,['semi_synthetic_cohort_manifest'])
def s23():
    q=read('core_certificate_probability_bounds');ledger=read('core_certificate_case_ledger')
    q=q[q.case_id.isin(ledger[ledger.initial_state=='undetermined'].case_id)]
    fig,axs=panels(1,2,5.8);a,b=axs.flat;y=np.arange(len(q));lo=q.elicited_frechet_lower;hi=q.elicited_frechet_upper
    a.hlines(y,lo,hi,color=TEAL,lw=2);a.scatter(q.independent_central_product,y,color=N,s=15,label='Central independent product')
    a.set(yticks=y,yticklabels=[f'Case {int(x)}' for x in q.case_id],xlabel='Conditional all-pass probability',xlim=(0,1));a.invert_yaxis();a.legend()
    b.scatter(q.unknown_gates,hi-lo,color=TEAL,s=28,alpha=.7);b.set(xlabel='Unresolved gates',ylabel='Elicited Fréchet interval width',ylim=(0,1.05))
    finish(fig,23,['core_certificate_probability_bounds','core_certificate_case_ledger'])
def posterior():
    from render_evidence_upgrade import joint_mass,conditional_table
    case=read('core_certificate_case_ledger').query('case_id==0').iloc[0];q=np.array(json.loads(case.planning_marginal_central))
    ct=conditional_table(joint_mass(q,.35,False,96)[None,:],len(q))[0][0]
    pd.DataFrame({'case_id':0,'gate':['heat_capacity','density','corrosion','cycling','containment','completeness'],'prior_assumed_pass':q,'conditional_after_corrosion_pass':ct[1<<2,:],'latent_dependence_parameter':.35,'quadrature_nodes':96}).to_csv(T/'core_certificate_conditional_beliefs.csv',index=False)
    shutil.copy2(T/'core_certificate_conditional_beliefs.csv',P/'Data/core_certificate_conditional_beliefs.csv')
def main():
    install();plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'pdf.fonttype':42})
    for fn in [s3,s18,s20,s21,s22,s23,posterior]:fn()
    mapping=pd.read_csv(P/'Data/Figure_source_map.csv')
    for figure,sources in SOURCES.items():
        mapping.loc[mapping.figure==figure,'source_paths']=';'.join('Data/'+next(p.relative_to(P/'Data').as_posix() for p in (P/'Data').rglob(n+'.csv')) for n in sources)
    i=mapping.figure=='Fig7';mapping.loc[i,'source_paths']=mapping.loc[i,'source_paths']+';Data/core_certificate_conditional_beliefs.csv'
    mapping.to_csv(P/'Data/Figure_source_map.csv',index=False)
    (Q/'PRESENTATION_V5_FIGURE_LAYOUT.json').write_text(json.dumps(LOG,indent=2),encoding='utf-8')
    print('V5 source-backed replacements complete')
if __name__=='__main__':main()
