"""Translate fixed analysis identifiers to the manuscript's chapter order."""
from pathlib import Path
import json,re
import pandas as pd
ROOT=Path(__file__).resolve().parents[1];P=ROOT.parent/'EES_Submission_Package'

def prepare():
    path=P/'Data/Figure_source_map.csv'
    if not path.exists():return
    m=pd.read_csv(path)
    if 'source_analysis_figure_id' in m:
        m['figure']=m.source_analysis_figure_id;m=m.drop(columns=['source_analysis_figure_id']);m.to_csv(path,index=False)

def publish():
    crosspath=P/'Data/Publication_Figure_Identifiers.csv'
    if not crosspath.exists():return
    x=pd.read_csv(crosspath)
    legacy=x[x.source_analysis_figure_id.str.startswith('Supp_Fig')]
    assets={(r.publication_figure_id,ext):(P/'Figures/Supplementary'/f'submission_{r.source_analysis_figure_id}.{ext}').read_bytes() for r in legacy.itertuples() for ext in ['png','pdf']}
    for (name,ext),data in assets.items():(P/'Figures/Supplementary'/f'submission_{name}.{ext}').write_bytes(data)
    m=pd.read_csv(P/'Data/Figure_source_map.csv');assert 'source_analysis_figure_id' not in m,'Call prepare before source rendering.'
    m['source_analysis_figure_id']=m.figure;translate=x.set_index('source_analysis_figure_id').publication_figure_id.to_dict()
    m['figure']=m.figure.map(lambda s:translate.get(s,s));m['source_paths']=m.source_paths.str.replace('\\','/',regex=False).map(lambda s:';'.join(dict.fromkeys(s.split(';'))))
    m=m.iloc[sorted(range(len(m)),key=lambda i:('Supp_' in m.iloc[i].figure,int(re.search(r'Fig(\d+)',m.iloc[i].figure)[1])))].reset_index(drop=True)
    m.to_csv(P/'Data/Figure_source_map.csv',index=False)
    pd.DataFrame({'publication_figure_id':m.figure,'source_analysis_figure_id':m.source_analysis_figure_id,'data_sources':m.source_paths}).to_csv(crosspath,index=False)
    print('Published',len(m),'figures in chapter order; analysis identifiers and data retained.')

if __name__=='__main__':publish()
