"""Physical consistency, fair calibration and decision reliability figures."""
from pathlib import Path
import json,shutil,sys,textwrap
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;P=BASE/'EES_Submission_Package'
UP=BASE/'upstream_reproducible_code';T=ROOT/'outputs/tables';FIG=P/'Figures'
N='#244658';TEAL='#278A83';GOLD='#B17C23';RED='#A45D68';GRAY='#84939A'
COL={'random':GRAY,'greedy_cert':GOLD,'point':N,'robust':TEAL,'cheapest':RED,'robust_continue':'#78834B'}
LAB={'random':'Random','greedy_cert':'Greedy','point':'Point','robust':'Robust','cheapest':'Cheapest','robust_continue':'Continue'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.labelsize':10,'legend.fontsize':9.5,
                     'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})

def read(n):return pd.read_csv(T/(n+'.csv'))
def panels(height=5.8):
    fig,axs=plt.subplots(2,2,figsize=(7.2,height),layout='constrained')
    fig.get_layout_engine().set(w_pad=.08,h_pad=.10,wspace=.12,hspace=.17)
    for i,a in enumerate(axs.flat):
        a.text(-.08,1.12,chr(97+i),transform=a.transAxes,weight='bold',fontsize=12)
        a.set_axisbelow(True);a.grid(axis='y',color='#EDF0F1',lw=.6)
    return fig,axs.flat
def finish(fig,name,sources):
    if name in ('submission_Fig7','submission_Fig8'):
        from render_main_figures_v9 import export_scientific
        return export_scientific(fig, int(name[-1]), sources)
    temporary=BASE/'QA/Scientific_V5_Figures';temporary.mkdir(parents=True,exist_ok=True)
    for ext in ('pdf','png'):
        fig.savefig(temporary/(name+'.'+ext),dpi=300,bbox_inches='tight',pad_inches=.12,
                    **({'metadata':{'CreationDate':None,'ModDate':None}} if ext=='pdf' else {}))
    plt.close(fig)
    return dict(figure=name,sources=sources)
def legend(fig,axs,ncol=3):
    h,l=axs.get_legend_handles_labels()
    fig.legend(h,l,loc='upper center',bbox_to_anchor=(.53,1.025),ncol=ncol,frameon=False)
    fig.get_layout_engine().set(rect=(0,0,1,.89))

def main7():
    empirical=read('core_certificate_v5_empirical_baselines');oracle=read('core_certificate_v5_common_criterion')
    fig,(a,b,c,d)=panels()
    q=empirical[(empirical.process=='central_positive035')&(empirical.objective=='pass2_fail1')]
    for policy in ('random','greedy_cert','point','robust'):
        z=q[q.policy==policy].sort_values('cost_cap');a.plot(z.cost_cap,z.mean_utility,'o-',color=COL[policy],ms=4,label=LAB[policy])
    a.set(xlabel='Cost cap per duty (ordinal units)',ylabel='Weighted utility',xticks=[4,8,12])
    handles,labels=a.get_legend_handles_labels()
    from matplotlib.lines import Line2D
    handles.extend([Line2D([0],[0],color=COL[p],marker='o') for p in ('cheapest','robust_continue')]);labels.extend(['Cheapest','Continue'])
    fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.53,1.025),ncol=3,frameon=False)
    fig.get_layout_engine().set(rect=(0,0,1,.88))
    for policy in ('random','cheapest','greedy_cert','point','robust','robust_continue'):
        z=q[q.policy==policy].sort_values('cost_cap')
        b.plot(z.mean_cost,z.mean_pass+z.mean_fail,'o-',color=COL[policy],ms=4)
    b.set(xlabel='Spent cost across seven duties',ylabel='New resolved certificates')
    for j,(policy,label,color) in enumerate([('point_exact','Exact point',N),('robust_separable','Separable planners',TEAL),('greedy','Greedy',GOLD)]):
        delta=oracle.robust_exact_rectangular-oracle[policy+'_rectangular']
        c.barh(j,float(delta.mean()),color=color,height=.55)
        c.text(float(delta.mean())+.001,j,f'{int((delta>1e-9).sum())}/72',va='center',fontsize=8.4)
    c.set(yticks=range(3),yticklabels=['Exact point','Separable planners','Greedy'],xlabel='Mean worst-case gain\nof exact robust',xlim=(0,.055));c.invert_yaxis()
    case=read('core_certificate_case_ledger').query('case_id==0').iloc[0]
    beliefs=read('core_certificate_conditional_beliefs');x=np.arange(len(beliefs))
    d.barh(x-.16,beliefs.prior_assumed_pass,height=.3,color=N,label='Before test')
    d.barh(x+.16,beliefs.conditional_after_corrosion_pass,height=.3,color=TEAL,label='Corrosion passes')
    d.set(yticks=x,yticklabels=['Heat capacity','Density','Corrosion','Cycling','Containment','Completeness'],xlim=(0,1),xlabel='Assumed conditional\npass probability');d.invert_yaxis()
    d.legend(loc='lower left',bbox_to_anchor=(.10,1.02),ncol=2,fontsize=9,frameon=False)
    return finish(fig,'submission_Fig7',['core_certificate_v5_empirical_baselines','core_certificate_v5_common_criterion','core_certificate_conditional_beliefs'])

def main8():
    s=read('core_thermophysical_v5_summary');e=read('core_existing_v4_enthalpy_intervals');dev=read('core_existing_v5_device_summary')
    fig,(a,b,c,d)=panels(6.0)
    q=e[e.low_C==250].sort_values('high_C')
    a.plot(q.high_C,q.observed_enthalpy_kJ_kg,'o-',color=N,label='Published enthalpy',ms=4)
    a.plot(q.high_C,q.predicted_enthalpy_kJ_kg,'s--',color=TEAL,label='Heat-capacity integral',ms=4)
    a.set(xlabel='Upper endpoint (°C); lower = 250 °C',ylabel='Enthalpy increment (kJ kg$^{-1}$)');a.text(.97,.08,'250–400 °C: +3.86%',ha='right',transform=a.transAxes,fontsize=8.7)
    legend(fig,a,2)
    q=dev[dev.split_type=='leave_publication_out']
    for j,(model,label,color) in enumerate([('identity','Identity',GRAY),('legacy','Ratio',N),('shrinkage','Shrinkage',TEAL)]):
        z=q[q.model==model].set_index('direction').loc[['charge','discharge']]
        b.bar(np.arange(2)+(j-1)*.24,z.endpoint_MAPE,width=.22,color=color,label=label)
    b.set(xticks=[0,1],xticklabels=['Charge (12)','Release (36)'],ylabel='Held-source MAPE (%)')
    b.legend(loc='lower left',bbox_to_anchor=(.10,1.02),ncol=3,fontsize=9,frameon=False,columnspacing=.7,handlelength=1.3)
    q=s[(s.target=='density_kg_m3')&(s.validation_scheme=='publication_component')&(s.nominal_coverage==.95)]
    u=q[q.model_family=='unconstrained'].set_index('seed');r=q[q.model_family=='constitutive_density'].set_index('seed').loc[u.index]
    for seed in u.index:
        c.plot([0,1],[u.loc[seed,'source_macro_MAE'],r.loc[seed,'source_macro_MAE']],'o-',color=TEAL if seed==760076 else GRAY,alpha=1 if seed==760076 else .65,ms=4)
    c.set(xticks=[0,1],xticklabels=['Unconstrained','Positive monotone'],ylabel='Source-macro density MAE (kg m$^{-3}$)',xlim=(-.2,1.2))
    c.set_title('Five fixed allocations',fontsize=9)
    q=s[(s.target=='density_kg_m3')&(s.validation_scheme=='publication_component')&(s.seed==760076)]
    for family,col,marker in [('unconstrained',N,'o'),('constitutive_density',TEAL,'s')]:
        z=q[q.model_family==family].sort_values('nominal_coverage');d.plot(z.mean_width,z.whole_source_coverage,marker+'-',color=col,ms=5,label='Unconstrained' if family=='unconstrained' else 'Positive monotone')
        for r in z.itertuples():d.annotate(f'{r.nominal_coverage:.0%}',(r.mean_width,r.whole_source_coverage),xytext=(4,7 if family=='constitutive_density' else -13),textcoords='offset points',color=col,fontsize=8.3)
    d.set(xlabel='Mean density band width (kg m$^{-3}$)',ylabel='Whole-source empirical coverage',ylim=(.80,1.025),xlim=(2380,3150));d.yaxis.set_major_formatter(PercentFormatter(1))
    d.legend(loc='lower left',bbox_to_anchor=(.10,1.02),ncol=1,fontsize=9,frameon=False)
    return finish(fig,'submission_Fig8',['core_existing_v4_enthalpy_intervals','core_existing_v5_device_summary','core_thermophysical_v5_summary'])

def density():
    s=read('core_thermophysical_v5_summary');p=read('core_thermophysical_v5_oof_predictions')
    fig,(a,b,c,d)=panels(6.0)
    q=p[(p.target=='density_kg_m3')&(p.seed==760076)&(p.validation_scheme=='publication_component')&(p.nominal_coverage==.95)]
    raw=q[q.model_family=='unconstrained']
    changes=raw.groupby('curve_id').apply(lambda z:np.diff(z.sort_values('temperature_K').prediction).max(),include_groups=False)
    curve=changes.idxmax();z=q[q.curve_id==curve].sort_values('temperature_K')
    first=z[z.model_family=='unconstrained'];a.plot(first.temperature_K,first.observed_database_target,'o-',color=GRAY,label='Source relation',ms=4)
    for fam,color,label in [('unconstrained',N,'Unconstrained'),('constitutive_density',TEAL,'Positive monotone')]:
        h=z[z.model_family==fam];a.plot(h.temperature_K,h.prediction,'s--',color=color,label=label,ms=4)
    a.set(xlabel='Temperature (K)',ylabel='Density (kg m$^{-3}$)');a.set_title(first.formula.iloc[0]+'; largest baseline increase',fontsize=9)
    legend(fig,a,3)
    q=s[(s.target=='density_kg_m3')&(s.validation_scheme=='publication_component')&(s.nominal_coverage==.95)]
    seeds=sorted(q.seed.unique())
    for offset,fam,color in [(-.16,'unconstrained',N),(.16,'constitutive_density',TEAL)]:
        z=q[q.model_family==fam].set_index('seed').loc[seeds];b.bar(np.arange(5)+offset,z.source_macro_MAE,width=.3,color=color)
    b.set(xticks=range(5),xticklabels=['1','2','3','4','5'],xlabel='Target-blind allocation index',ylabel='Source-macro MAE (kg m$^{-3}$)')
    for scheme,style in [('publication_component','o-'),('joint_publication_formula','s--')]:
        z=s[(s.target=='density_kg_m3')&(s.validation_scheme==scheme)&s.nominal_coverage.eq(.95)&s.model_family.eq('unconstrained')].sort_values('seed')
        c.plot(range(1,6),100*z.n_increasing_curves/z.n_finite_curves,style,color=N if scheme=='publication_component' else GOLD,label='Publication' if scheme=='publication_component' else 'Publication + formula',ms=4)
    c.plot(range(1,6),[0]*5,'-',color=TEAL,label='Constrained, both schemes')
    c.set(xlabel='Target-blind allocation index',ylabel='Increasing predicted curves (%)',xticks=range(1,6),ylim=(-1,80));c.legend(loc='lower left',bbox_to_anchor=(0,1.02),ncol=1,fontsize=8,frameon=False)
    q=s[(s.target=='density_kg_m3')&(s.validation_scheme=='publication_component')]
    for fam,color in [('unconstrained',N),('constitutive_density',TEAL)]:
        for cov,marker in [(.9,'o'),(.95,'s')]:
            z=q[(q.model_family==fam)&(q.nominal_coverage==cov)];d.scatter(z.mean_width,z.whole_source_coverage,color=color,marker=marker,s=32)
    d.set(xlabel='Mean band width (kg m$^{-3}$)',ylabel='Whole-source empirical coverage',ylim=(.75,1.025));d.yaxis.set_major_formatter(PercentFormatter(1));d.text(.03,.05,'Circle: nominal 90%; square: 95%',transform=d.transAxes,fontsize=8.5)
    return finish(fig,'new_density',['core_thermophysical_v5_oof_predictions','core_thermophysical_v5_summary'])

def planning():
    paired=read('core_certificate_v5_greedy_contrasts');cost=read('core_certificate_v5_cost_sensitivity');noise=read('core_certificate_v5_assay_stress')
    fig,(a,b,c,d)=panels(6.0)
    processes=paired.process.drop_duplicates().tolist();y=np.arange(len(processes))
    for off,policy,col in [(-.16,'point',N),(.16,'robust',TEAL)]:
        z=paired[paired.policy==policy].groupby('process').paired_mean_difference.mean().reindex(processes)
        a.barh(y+off,z,height=.3,color=col,label=LAB[policy])
    labels=['Independent','Positive 0.35','Positive 0.70','Antagonistic','Low corner','High corner','Mixed corner','Downshift','Upshift','Outside 0.90']
    names=dict(zip(['central_independent','central_positive035','central_positive070','central_antagonistic','low_corner','high_corner','mixed_corner','probability_downshift','probability_upshift','dependence_outside_family'],labels))
    a.set(yticks=y,yticklabels=[names[x] for x in processes],xlabel='Mean utility difference from greedy');a.axvline(0,color=GRAY,lw=.8);a.invert_yaxis();legend(fig,a,2)
    z=cost[(cost.case_id==2)&(cost.objective=='pass2_fail1')&cost.cost_penalty.eq(.05)]
    for mult,color in [(.5,GOLD),(1.,N),(2.,TEAL)]:
        q=z[z.corrosion_cost_multiplier==mult].sort_values('cost_cap');b.plot(q.cost_cap,q.robust_exact_rectangular,'o-',color=color,label=f'Corrosion cost ×{mult:g}',ms=4)
    b.set(xlabel='Local cost cap (ordinal units)',ylabel='Worst-case local value',xticks=[4,8,12]);b.legend(loc='lower left',bbox_to_anchor=(0,1.02),ncol=1,fontsize=8,frameon=False)
    q=noise[noise.cost_cap.eq(12)].groupby(['policy','assumed_false_positive_probability']).sum(numeric_only=True).reset_index()
    for policy in ('greedy_cert','point','robust'):
        z=q[q.policy==policy].sort_values('assumed_false_positive_probability')
        c.plot(z.assumed_false_positive_probability*100,z.false_positive_certificate,'o-',color=COL[policy],ms=4,label=LAB[policy])
        d.plot(z.assumed_false_positive_probability*100,z.false_exclusion,'o-',color=COL[policy],ms=4)
    c.set(xlabel='Assumed symmetric gate error (%)',ylabel='False all-pass declarations per world');d.set(xlabel='Assumed symmetric gate error (%)',ylabel='False exclusions per world')
    c.legend(loc='lower left',bbox_to_anchor=(0,1.02),ncol=3,fontsize=8,frameon=False)
    return finish(fig,'new_planning',['core_certificate_v5_greedy_contrasts','core_certificate_v5_cost_sensitivity','core_certificate_v5_assay_stress'])

def cases():
    p=read('core_existing_v5_device_predictions');case=read('core_existing_v5_material_case');loc=read('core_existing_v5_locator_sensitivity')
    fig,(a,b,c,d)=panels(6.0);q=p[p.split_type=='leave_publication_out']
    for ax,dir in [(a,'charge'),(b,'discharge')]:
        z=q[q.direction==dir]
        for k,(model,color,label) in enumerate([('identity',GRAY,'Identity'),('legacy',N,'Ratio'),('shrinkage',TEAL,'Shrinkage')]):
            vals=z.groupby('model_id')[model+'_abs_percent_error'].mean()
            ax.bar(np.arange(4)+(k-1)*.24,vals,width=.22,color=color,label=label)
        ax.set(xticks=range(4),xticklabels=['SS alumina','SS foam','HITEC alumina','HITEC foam'],ylabel=('Charge' if dir=='charge' else 'Release')+' MAPE (%)');ax.tick_params(axis='x',rotation=25)
    legend(fig,a,3)
    for j,r in enumerate(case.itertuples()):
        for off,domain,col in [(-.16,'cp_domain_C',N),(.16,'density_domain_C',TEAL)]:
            vals=json.loads(getattr(r,domain));coverage=0 if not np.isfinite(vals).all() else max(0,min(vals[1],r.hot_C)-max(vals[0],r.cold_C))/(r.hot_C-r.cold_C)
            c.barh(j+off,coverage,height=.3,color=col,label='Heat capacity' if j==0 and off<0 else 'Density' if j==0 else '_nolegend_')
    c.set(yticks=[0,1],yticklabels=['TMS-2','Solar Salt'],xlabel='Fraction of industrial temperature duty',xlim=(0,1.05));c.xaxis.set_major_formatter(PercentFormatter(1));c.legend(loc='upper center',bbox_to_anchor=(.5,1.22),ncol=2,fontsize=8,frameon=False)
    states=['model_qualified','undetermined','excluded']
    for off,col,column in [(-.16,N,'baseline_state'),(.16,TEAL,'strict_locator_state')]:
        counts=loc[column].value_counts().reindex(states,fill_value=0);d.bar(np.arange(3)+off,counts,width=.3,color=col,label='Commercial experience' if off<0 else 'Exact corrosion locator')
    d.set(xticks=range(3),xticklabels=['Accepted','Unresolved','Excluded'],ylabel='Candidate–duty memberships');d.legend(loc='lower left',bbox_to_anchor=(0,1.02),ncol=1,fontsize=8,frameon=False)
    return finish(fig,'new_cases',['core_existing_v5_device_predictions','core_existing_v5_material_case','core_existing_v5_locator_sensitivity'])

def repair_frontier():
    sys.path.insert(0,str(ROOT/'src'))
    import render_ees_presentation as old
    import presentation_v5 as layout
    from matplotlib.text import Text
    def save(fig,n,title,sources,supp=False):
        fig.axes[5].remove();fig.set_layout_engine('none')
        old.legible_legacy(fig);old.supplement_layout(fig,14)
        layout.edit_panel(fig,'submission_Supp_Fig14.pdf')
        a=fig.axes[0];a.clear();a.axis('off');a.set_position((.08,.81,.85,.13))
        fig.text(.02,.97,'a',weight='bold',fontsize=12)
        for leg in fig.legends:leg.set_bbox_to_anchor((.55,1.12));leg.set_loc('upper center')
        headings=[(.02,'Current state'),(.50,'Next action'),(.85,'Decision endpoint')]
        for x,label in headings:a.text(x,1.14,label,ha='left' if x==.02 else 'center',weight='bold',fontsize=8.5)
        data=old.B.read('candidate_research_priority_summary',old.B.V).research_priority_class.value_counts()
        entries=[('stop: service/property limited','Service/property limited','Measure or redesign','Reassess duty'),
            ('not reachable under registered actions','No tested evidence route','New measurement design','Reassess evidence'),
            ('current formal selection','Current selection','No additional gate closure','Qualified benchmark'),
            ('one-step evidence opportunity','Evidence opportunity','Targeted evidence','Test selection gain')]
        for j,(key,l,m,r) in enumerate(entries):
            y=.86-j*.30
            for x,label in [(.02,f'{l} ({int(data.get(key,0))})'),(.50,m),(.85,r)]:
                a.text(x,y,textwrap.fill(label,22),fontsize=8.3,ha='left' if x==.02 else 'center',va='center')
        for t in fig.findobj(match=Text):
            if t.get_text() and t not in a.texts:t.set_fontsize(max(8.3,t.get_fontsize()))
        # Collapse only mathematically identical program/bound responses for the
        # same material and duty; both intervention identities remain in labels.
        signed=old.B.read('counterfactual_candidate_signed_changes')
        z=signed[signed.delta_selection_frequency.abs().ge(.01)].copy()
        z=z.reindex(z.delta_selection_frequency.abs().sort_values(ascending=False).index).head(8)
        grouped=[]
        for (_,_,value),q in z.groupby(['scenario','system_id','delta_selection_frequency'],sort=False):
            actions=set(q.closure_action)
            if actions=={'combined_atomic_evidence_closure','comprehensive_upper_bound'}:label='Program / bound'
            else:label={'combined_atomic_evidence_closure':'Program','comprehensive_upper_bound':'Bound','service_redesign_95pct':'95% duty'}.get(q.closure_action.iloc[0],q.closure_action.iloc[0])
            r=q.iloc[0];material=old.B.short_id(r.system_id).replace('Carbonate–LiF','C–LiF').replace('Binary carbonate','Binary C')
            grouped.append((value,label+' · '+old.B.SERVICE[r.scenario]+'\n'+material))
        grouped.sort(reverse=True)
        e=fig.axes[4];e.clear();e.set_position((.76,.04,.21,.24))
        for j,(v,label) in enumerate(grouped):
            e.hlines(j,0,v,color='#B6CAD7',lw=2);e.scatter(v,j,color=TEAL,s=30,zorder=3)
            e.text(v+.035,j,f'{v:+.0%}',va='center',color=TEAL,fontsize=8.5)
        e.set(yticks=range(len(grouped)),yticklabels=[r[1] for r in grouped],xlim=(-.025,1.4),ylim=(len(grouped)-.5,-.5),xlabel='Selection-frequency change\n(|Δ| ≥ 1%)')
        e.tick_params(axis='y',labelsize=8);e.grid(axis='x',color='#EDF0F1',lw=.6)
        for spine in ('top','right'):e.spines[spine].set_visible(False)
        fig.text(.72,.29,'e',weight='bold',fontsize=12)
        finish(fig,'replacement_frontier',sources)
    original=old.B.save;old.B.save=save
    try:old.B.fig6()
    finally:old.B.save=original

def main():
    T.mkdir(parents=True,exist_ok=True)
    for path in (UP/'outputs/tables').glob('core_*v5*'):
        shutil.copy2(path,T/path.name);shutil.copy2(path,P/'Data'/path.name)
    rows=[fn() for fn in (main7,main8,density,planning,cases)]
    repair_frontier()
    cross=P/'Data/Publication_Figure_Identifiers.csv'
    if cross.exists():
        mapping=pd.read_csv(cross).set_index('source_analysis_figure_id').publication_figure_id.to_dict()
        for name,source in [('new_density','V5_new_density'),('new_planning','V5_new_planning'),('new_cases','V5_new_cases')]:
            if source in mapping:
                for ext in ('png','pdf'):shutil.copy2(BASE/'QA/Scientific_V5_Figures'/(name+'.'+ext),FIG/'Supplementary'/('submission_'+mapping[source]+'.'+ext))
        for n in (7,8):
            for ext in ('png','pdf'):shutil.copy2(BASE/'QA/Scientific_V5_Figures'/f'submission_Fig{n}.{ext}',FIG/'Main'/f'submission_Fig{n}.{ext}')
        for ext in ('png','pdf'):shutil.copy2(BASE/'QA/Scientific_V5_Figures'/('replacement_frontier.'+ext),FIG/'Supplementary'/('submission_'+mapping['Supp_Fig14']+'.'+ext))
        data=pd.read_csv(P/'Data/Figure_source_map.csv')
        lookup={'Fig7':rows[0],'Fig8':rows[1],**{mapping['V5_'+r['figure']]:r for r in rows[2:] if 'V5_'+r['figure'] in mapping}}
        for i,r in data.iterrows():
            if r.figure in lookup:data.loc[i,'source_paths']=';'.join('Data/'+n+'.csv' for n in lookup[r.figure]['sources'])
        data.to_csv(P/'Data/Figure_source_map.csv',index=False)
        pd.DataFrame({'publication_figure_id':data.figure,'source_analysis_figure_id':data.source_analysis_figure_id,'data_sources':data.source_paths}).to_csv(cross,index=False)
    (BASE/'QA/SCIENTIFIC_V5_FIGURE_SOURCES.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
    print('Rendered five source-backed scientific upgrade figures')

if __name__=='__main__':main()
