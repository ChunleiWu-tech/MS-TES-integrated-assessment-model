"""Regenerate only main Figures 6–8, preserving scientific series exactly."""
from pathlib import Path
import sys
import json, hashlib, shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from main_figure_layout import apply, top_legend, verify, WIDTH, HEIGHT

ROOT=Path(__file__).resolve().parents[1]; B=ROOT.parent
P=B/'EES_Submission_Package'; Q=B/'QA'; T=ROOT/'outputs/tables'
ROWS=[]
if __name__=='__main__':sys.modules['render_main_figures_v9']=sys.modules[__name__]

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def series(fig):
    # Extract only numerical marks. Text, legend and geometry edits have no role.
    result=[]
    for ax in fig.axes:
        result.append({'lines':[(np.asarray(l.get_xdata()).tolist(),np.asarray(l.get_ydata()).tolist()) for l in ax.lines],
                       'collections':[np.asarray(c.get_offsets()).tolist() for c in ax.collections],
                       'patches':[(p.get_x(),p.get_y(),p.get_width(),p.get_height()) for p in ax.patches if hasattr(p,'get_height')]})
    return result

def export(fig,n,sources):
    records=verify(fig)
    stem=f'submission_Fig{n}'
    dest=P/'Figures/Main'
    for ext in ['pdf','png','svg']:
        path=dest/(stem+'.'+ext)
        kw={'dpi':600}
        if ext=='pdf': kw['metadata']={'CreationDate':None,'ModDate':None}
        if ext=='svg': kw['metadata']={'Date':None}
        # No tight bounding box: PDF, SVG and PNG share exactly one canvas.
        fig.savefig(path,**kw)
        shutil.copy2(path,ROOT/'outputs/main_figures'/path.name)
    ROWS.append({'figure':n,'width_in':WIDTH,'height_in':HEIGHT[n],
                 'panel_width_in':WIDTH*.34,'panel_height_in':1.10,
                 'axes_font_pt':8.5,'tick_legend_font_pt':8,'panel_letter_font_pt':11,
                 'legend_checks':records,'sources':sources,
                 'asset_sha256':{ext:sha(dest/(stem+'.'+ext)) for ext in ['pdf','png','svg']}})
    plt.close(fig)
    return dict(figure=stem,sources=sources)

def main6():
    import render_application_figures as a
    a.style()
    plt.rcParams.update({'font.family':'DejaVu Sans','mathtext.fontset':'dejavusans'})
    names=['application_paired_response','application_duty_frontiers','application_device_conditions','application_chronological_checks','application_equal_duty_hydraulics']
    fig=a.build_main6(*[pd.read_csv(T/(name+'.csv')) for name in names])
    before=series(fig); legends=apply(fig,6)
    axes=fig.axes
    axes[0].set_ylabel('Heat-release power ratio')
    axes[1].set_ylabel('Model transfer-volume ratio')
    axes[2].set_ylabel('Model volume ratio')
    axes[3].set_ylabel('Mean heat-release power\n(kW m$^{-3}$)')
    axes[3].set_ylim(8,18.5)
    axes[4].set_ylabel('Equal-duty pumping-\npower ratio')
    axes[5].set_xlabel('Base pumping input\n(kWh MWh$_{th}^{-1}$)')
    axes[5].set_ylabel('Change in electricity\n(kWh MWh$_{th}^{-1}$)')
    for i in [0,1,2,4,5]:
        h,l=legends[i]
        if i==0:l=[v.replace(', ','\n') for v in l]
        if i==2:l=['Base salt','2 wt% Al$_2$O$_3$','Alumina + Cu foam']
        top_legend(axes[i],h,l,2 if i in [0,4] else 1)
    # The middle-row material colors also explain panel d.
    top_legend(axes[3],*legends[2],columns=1)
    assert series(fig)==before, 'Figure 6 numerical marks changed'
    return export(fig,6,names)

def export_scientific(fig,n,sources):
    before=series(fig)
    legends=apply(fig,n); a,b,c,d=fig.axes
    if n==7:
        ha,la=a.get_legend_handles_labels();hb,lb=b.get_legend_handles_labels()
        # Panel b is originally drawn without labels; preserve its policy order.
        import render_scientific_v5 as s
        from matplotlib.lines import Line2D
        policies=['random','cheapest','greedy_cert','point','robust','robust_continue']
        hb=[Line2D([],[],color=s.COL[p],marker='o',lw=1.4,ms=4) for p in policies];lb=[s.LAB[p] for p in policies]
        top_legend(a,ha,la,2);top_legend(b,hb,lb,2);top_legend(d,*legends[3])
        b.set_ylabel('New resolved\ncertificates')
        a.set_xlabel('Cost cap per duty\n(ordinal units)')
        b.set_xlabel('Spent cost across\nseven duties')
        c.set_yticks(range(3),['Exact point','Separable\nplanners','Greedy'])
        d.set_yticks(range(6),['Heat capacity','Density','Corrosion','Cycling','Containment','Completeness'])
    else:
        top_legend(a,*a.get_legend_handles_labels())
        top_legend(b,*legends[1],columns=2);top_legend(d,*legends[3])
        a.set_ylabel('Enthalpy increment\n(kJ kg$^{-1}$)')
        a.set_xlabel('Upper endpoint (°C)\nLower endpoint: 250 °C')
        b.set_ylabel('Held-source MAPE (%)')
        c.set_ylabel('Source-macro density MAE\n(kg m$^{-3}$)')
        c.set_xticks([0,1],['Unconstrained','Positive\nmonotone'])
        c.set_title('Five fixed allocations',pad=9,fontsize=8)
        d.set_xlabel('Mean density band width\n(kg m$^{-3}$)')
        d.set_ylabel('Whole-source\nempirical coverage')
    assert series(fig)==before, f'Figure {n} numerical marks changed'
    return export(fig,n,sources)

def main():
    import render_scientific_v5 as s
    main6();s.main7();s.main8()
    for file in [P/'Data/Figure_source_map.csv', ROOT/'outputs/qa/figure_source_map.csv']:
        df=pd.read_csv(file)
        for r in ROWS:
            mask=df.figure.eq('Fig'+str(r['figure']))
            for col,val in [('width_px',3750),('height_px',round(600*r['height_in'])),('aspect_ratio',r['width_in']/r['height_in'])]:
                if col in df.columns: df.loc[mask,col]=val
        df.to_csv(file,index=False)
    report={'status':'PASS','scope':'Figure layout only; numerical mark arrays unchanged; all input and output data preserved.',
            'source_sha256':{p.name:sha(p) for p in (T/(v+'.csv') for r in ROWS for v in r['sources'])},'figures':ROWS}
    (Q/'FIGURE_LAYOUT_V9.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('PASS: Figures 6–8 use one physical width, identical panel dimensions and top legend anchors.')

if __name__=='__main__':main()
