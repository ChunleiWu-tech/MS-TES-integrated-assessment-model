from __future__ import annotations

"""Render the four active-learning result figures from aggregate tables only."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


STRATEGY_LABELS = {
    "random": "Random",
    "greedy_unlock": "Greedy unlock",
    "eig": "EIG",
    "ei": "EI",
    "uniform_budget": "Uniform budget",
}
COLORS = {
    "random": "#777777",
    "greedy_unlock": "#D55E00",
    "eig": "#0072B2",
    "ei": "#009E73",
    "uniform_budget": "#CC79A7",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Render active-learning figures")
    here = Path(__file__).resolve()
    default_root = here.parents[2] / "upstream_reproducible_code"
    parser.add_argument("--tables", type=Path, default=default_root / "outputs" / "tables")
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parents[1] / "outputs" / "active_learning_figures")
    return parser.parse_args()


def _load(path: Path, name: str) -> pd.DataFrame:
    file = path / name
    if not file.exists():
        raise FileNotFoundError(file)
    return pd.read_csv(file)


def _aggregate(summary: pd.DataFrame, value: str) -> pd.DataFrame:
    columns = ["strategy", "budget_actions"]
    grouped = summary.groupby(columns, as_index=False)[value].mean()
    return grouped


def render_budget_reward(summary: pd.DataFrame, out: Path) -> None:
    fig, ax = plt.subplots(figsize=(8.2, 5.0), constrained_layout=True)
    for strategy in ("random", "greedy_unlock", "eig", "ei"):
        part = summary[summary.strategy.eq(strategy)].groupby("budget_actions", as_index=False).agg(
            mean=("mean_formal_candidate_count", "mean"),
            lo=("formal_candidate_count_ci95_low", "mean"),
            hi=("formal_candidate_count_ci95_high", "mean"),
        )
        if part.empty:
            continue
        x = part.budget_actions.to_numpy()
        ax.plot(x, part["mean"], marker="o", lw=2, color=COLORS[strategy], label=STRATEGY_LABELS[strategy])
        ax.fill_between(x, part["lo"], part["hi"], color=COLORS[strategy], alpha=0.12, linewidth=0)
    ax.set_xlabel("Action budget (number of actions)")
    ax.set_ylabel("Mean formal candidate count\n(duty-averaged)")
    ax.set_xticks(sorted(summary.budget_actions.unique()))
    ax.grid(axis="y", alpha=0.25)
    ax.legend(frameon=False, ncol=2)
    fig.savefig(out / "Figure_AL_A_budget_reward.png", dpi=300)
    fig.savefig(out / "Figure_AL_A_budget_reward.svg")
    plt.close(fig)


def render_efficiency(summary: pd.DataFrame, out: Path) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.4), constrained_layout=True)
    for strategy in ("random", "greedy_unlock", "eig", "ei"):
        part = summary[summary.strategy.eq(strategy)].groupby("budget_actions", as_index=False).agg(
            improvement=("selection_improvement_per_cost", "mean"),
            cost=("mean_cumulative_cost", "mean"),
        )
        if part.empty:
            continue
        x = part.budget_actions.to_numpy()
        axes[0].plot(x, part.improvement, marker="o", lw=2, color=COLORS[strategy], label=STRATEGY_LABELS[strategy])
        axes[1].plot(x, part.cost, marker="o", lw=2, color=COLORS[strategy], label=STRATEGY_LABELS[strategy])
    axes[0].set_ylabel("Formal candidates gained / cost unit")
    axes[1].set_ylabel("Cost units")
    for ax in axes:
        ax.set_xlabel("Action budget")
        ax.set_xticks(sorted(summary.budget_actions.unique()))
        ax.grid(axis="y", alpha=0.25)
    axes[1].legend(frameon=False, ncol=2, loc="best")
    fig.savefig(out / "Figure_AL_B_efficiency.png", dpi=300)
    fig.savefig(out / "Figure_AL_B_efficiency.svg")
    plt.close(fig)


def _short_action(action: str) -> str:
    return {
        "a1_cp_full_range": "Cp",
        "a2_density_full_range": "ρ",
        "a3_corrosion_test": "Corr",
        "a4_cycle_phase_test": "Cycle",
        "a5_containment_validation": "Cont",
        "a6_independent_replication": "Repl",
        "a7_data_completeness": "Data",
    }.get(action, str(action))


def render_sequences(sequences: pd.DataFrame, out: Path) -> None:
    strategies = [s for s in ("random", "greedy_unlock", "eig", "ei") if s in set(sequences.strategy)]
    duties = list(sequences.sort_values(["scenario", "strategy", "step"]).scenario.unique())
    rows = []
    labels = []
    for duty in duties:
        for strategy in strategies:
            part = sequences[(sequences.scenario == duty) & (sequences.strategy == strategy)].sort_values("step")
            if part.empty:
                continue
            labels.append(f"{duty}\n{STRATEGY_LABELS[strategy]}")
            mapping = {int(row.step): _short_action(row.recommended_action_id) for _, row in part.iterrows()}
            rows.append([mapping.get(step, "") for step in range(1, 7)])
    if not rows:
        return
    fig, ax = plt.subplots(figsize=(10.5, max(4.5, len(rows) * 0.34)), constrained_layout=True)
    ax.imshow(np.zeros((len(rows), 6)), cmap="Greys", vmin=0, vmax=1, alpha=0.05)
    for i, row in enumerate(rows):
        for j, text in enumerate(row):
            ax.text(j, i, text, ha="center", va="center", fontsize=8)
    ax.set_xticks(range(6), [f"Step {i}" for i in range(1, 7)])
    ax.set_yticks(range(len(labels)), labels, fontsize=7)
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    fig.savefig(out / "Figure_AL_C_sequences.png", dpi=300)
    fig.savefig(out / "Figure_AL_C_sequences.svg")
    plt.close(fig)


def render_statistics(tests: pd.DataFrame, out: Path) -> None:
    tests = tests[tests.metric.eq("formal_selection_count")].copy()
    if tests.empty:
        return
    tests["comparison_label"] = tests.comparison.str.replace("_vs_", " vs ", regex=False).str.replace("_", " ", regex=False)
    groups = list(tests.comparison_label.drop_duplicates())
    fig, axes = plt.subplots(1, len(groups), figsize=(5.1 * len(groups), 4.6), sharey=True, constrained_layout=True)
    axes = np.atleast_1d(axes)
    for ax, group in zip(axes, groups):
        part = tests[tests.comparison_label.eq(group)].groupby("budget_actions", as_index=False).agg(
            delta=("mean_delta", "mean"), lo=("ci95_low", "mean"), hi=("ci95_high", "mean"), p=("p_value", "mean")
        )
        x = part.budget_actions.to_numpy()
        ax.axhline(0, color="black", lw=0.8)
        ax.errorbar(x, part.delta, yerr=[part.delta - part.lo, part.hi - part.delta], fmt="o-", color="#0072B2", capsize=3)
        ax.set_xlabel("Action budget")
        ax.set_xticks(x)
        ax.grid(axis="y", alpha=0.25)
    axes[0].set_ylabel("Paired Δ formal candidate count\n(strategy − baseline)")
    fig.savefig(out / "Figure_AL_D_statistics.png", dpi=300)
    fig.savefig(out / "Figure_AL_D_statistics.svg")
    plt.close(fig)


def main() -> None:
    args = parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    summary = _load(args.tables, "active_learning_strategy_summary.csv")
    sequences = _load(args.tables, "active_learning_recommended_sequences.csv")
    tests = _load(args.tables, "active_learning_statistical_tests.csv")
    render_budget_reward(summary, args.out)
    render_efficiency(summary, args.out)
    render_sequences(sequences, args.out)
    render_statistics(tests, args.out)
    metadata = {
        "status": "PASS",
        "source_tables": str(args.tables),
        "output_directory": str(args.out),
        "figures": sorted(p.name for p in args.out.glob("Figure_AL_*")),
        "mc_iterations": sorted(summary.mc_iterations.unique().tolist()) if "mc_iterations" in summary else [],
    }
    (args.out / "ACTIVE_LEARNING_FIGURES_STATUS.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    main()
