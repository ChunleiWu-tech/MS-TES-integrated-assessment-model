"""Common-criterion policy evaluation, elicited cost and assay-error stress tests."""
from functools import lru_cache
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
import certificate_budget_v4 as old


def portfolio_compare(tables,costs,preds,B,wp,wf,penalty=.05):
    """Full shared-budget Bellman solution and fixed-policy worst-case values.

    The same rectangular transition family evaluates every policy. No empirical
    tail quantile is substituted for this recursively defined value criterion.
    """
    ks=[len(c) for c in costs];full=[(1<<k)-1 for k in ks]
    ticks=[old.integer_costs(c) for c in costs]
    local={family:[old.local_dp(p if family=='robust' else p[[-1]],c,B,pr,wp,wf,penalty)[1]
                   for p,c,pr in zip(tables,costs,preds)] for family in ('point','robust')}
    def legal(s,b):
        for ci,k in enumerate(ks):
            if s[ci]<0 or s[ci]==full[ci]:continue
            for a in range(k):
                if ticks[ci][a]<=b and not s[ci]&(1<<a) and (s[ci]&preds[ci][a])==preds[ci][a]:yield ci,a
    @lru_cache(None)
    def optimum(s,b,family):
        best=0.;action=None
        for ci,a in legal(s,b):
            child=s[ci]|(1<<a);pos=list(s);pos[ci]=child;neg=list(s);neg[ci]=-1
            vp=(wp if child==full[ci] else 0)+optimum(tuple(pos),b-ticks[ci][a],family)[0]
            vn=wf+optimum(tuple(neg),b-ticks[ci][a],family)[0]
            p=tables[ci][:,s[ci],a] if family=='robust' else tables[ci][-1:,s[ci],a]
            q=float(np.min((1-p)*vn+p*vp-penalty*costs[ci][a]))
            if q>best+1e-12:best=q;action=(ci,a)
        return best,action
    def selected(s,b,policy):
        if policy.endswith('_exact'):return optimum(s,b,policy.split('_')[0])[1]
        actions=list(legal(s,b))
        if not actions:return None
        scores=[]
        for ci,a in actions:
            if policy=='greedy':
                p=tables[ci][-1,s[ci],a];last=int(s[ci]).bit_count()==ks[ci]-1
                score=((1-p)*wf+p*wp*last-penalty*costs[ci][a])/costs[ci][a]
            else:score=local[policy.split('_')[0]][ci][b,s[ci],a]
            scores.append(score)
        i=min(range(len(actions)),key=lambda i:(-scores[i],costs[actions[i][0]][actions[i][1]],actions[i][1],actions[i][0]))
        return actions[i] if scores[i]>0 else None
    @lru_cache(None)
    def fixed(s,b,policy,evaluation):
        action=selected(s,b,policy)
        if action is None:return 0.
        ci,a=action;child=s[ci]|(1<<a);pos=list(s);pos[ci]=child;neg=list(s);neg[ci]=-1
        vp=(wp if child==full[ci] else 0)+fixed(tuple(pos),b-ticks[ci][a],policy,evaluation)
        vn=wf+fixed(tuple(neg),b-ticks[ci][a],policy,evaluation)
        p=tables[ci][:,s[ci],a] if evaluation=='rectangular' else tables[ci][-1:,s[ci],a]
        return float(np.min((1-p)*vn+p*vp-penalty*costs[ci][a]))
    start=(0,)*len(ks)
    result={}
    for policy in ('point_exact','robust_exact','point_separable','robust_separable','greedy'):
        for evaluation in ('rectangular','central'):
            result[policy+'_'+evaluation]=fixed(start,B,policy,evaluation)
    assert result['robust_exact_rectangular']+1e-9>=max(result[p+'_rectangular'] for p in ('point_exact','point_separable','robust_separable','greedy'))
    result['states_evaluated']=optimum.cache_info().currsize
    return result


def small_common_study():
    rng=np.random.default_rng(461003);rows=[]
    for instance in range(12):
        nc=2+instance%2;k=2+(instance//2)%2;tables=[];costs=[];preds=[]
        for ci in range(nc):
            m=rng.uniform(.25,.8,k)
            masses=np.array([old.v3.joint_mass(m,r) for r in (0.,.35)])
            tables.append(old.v3.conditional_table(masses,k)[0]);costs.append(rng.choice([.5,2.,2.5,3.],k))
            pr=np.zeros(k,int)
            if instance%3==0:pr[-1]=1
            preds.append(pr)
        for cap in old.COST_BUDGETS:
            for obj,wp,wf in old.OBJECTIVES:
                r=portfolio_compare(tables,costs,preds,old.budget_ticks(cap),wp,wf)
                rows.append(dict(instance=instance,candidates=nc,gates=k,objective=obj,cost_cap=cap,**r))
        print('common-criterion oracle',instance,flush=True)
    return pd.DataFrame(rows)


def local_cost_study(cases):
    rows=[]
    for cid,c in enumerate(cases):
        if not c.k or c.structurally_excluded:continue
        p=old.prepare(c,24)['p'];central=old.prepare(c,0)['point_index']
        tables=[np.concatenate([p,np.asarray(p[[central]])])]
        for multiplier in (.5,1.,2.):
            costs=c.costs.copy()
            # Cost of corrosion changes; other ordinal task costs stay fixed.
            for a,gate in enumerate(c.required):
                if old.v3.GATES[int(gate)]=='corrosion':costs[a]*=multiplier
            for penalty in (0.,.05,.15):
                for cap in old.COST_BUDGETS:
                    for obj,wp,wf in old.OBJECTIVES:
                        r=portfolio_compare(tables,[costs],[c.predecessors],old.budget_ticks(cap),wp,wf,penalty)
                        rows.append(dict(case_id=cid,system_id=c.system_id,duty=c.scenario,unknown_gates=c.k,
                            corrosion_cost_multiplier=multiplier,cost_penalty=penalty,objective=obj,cost_cap=cap,**r))
        print('local cost sensitivity',cid,flush=True)
    return pd.DataFrame(rows)


def empirical_baselines(root):
    rows=[];paired=[]
    for path in sorted((root/'outputs/certificate_budget_v4').glob('*__pooled__*__budget*.npz')):
        process,_,obj,cap=path.stem.split('__');cap=float(cap.replace('budget',''))
        wp=2 if obj=='pass2_fail1' else 1
        with np.load(path) as z:
            utility=wp*z['pass']+z['fail']-.05*z['spent_ticks']*.5
            for i,policy in enumerate(old.POLICIES):
                values=utility[i];mean,lo,hi=old.mc(values)
                rows.append(dict(process=process,objective=obj,cost_cap=cap,policy=policy,mean_utility=mean,
                    mc95_lower=lo,mc95_upper=hi,lowest_decile_mean=float(np.sort(values)[:len(values)//10].mean()),
                    mean_cost=float(z['spent_ticks'][i].mean()*.5),mean_pass=float(z['pass'][i].mean()),mean_fail=float(z['fail'][i].mean())))
            for policy in ('point','robust'):
                delta=utility[old.POLICIES.index(policy)]-utility[old.POLICIES.index('greedy_cert')]
                mean,lo,hi=old.mc(delta)
                paired.append(dict(process=process,objective=obj,cost_cap=cap,policy=policy,reference='greedy_cert',
                    paired_mean_difference=mean,mc95_lower=lo,mc95_upper=hi))
    return pd.DataFrame(rows),pd.DataFrame(paired)


def assay_stress(cases,fits,truth,budget,error,seed):
    """Misspecified perfect-observation policies exposed to hypothetical errors.

    Positive/negative declarations are tentative. Actual joint truth remains
    available only to the evaluator. Error probabilities are assumptions, not
    measured assay performance or posterior calibration.
    """
    n,nc=truth.shape;B=old.budget_ticks(budget);rows=[]
    ticks=[old.integer_costs(c.costs) for c in cases]
    for pi,policy in enumerate(('greedy_cert','point','robust')):
        state=np.zeros((n,nc),np.int16);failed=np.zeros((n,nc),bool);spent=np.zeros(n,np.int16);stop=np.zeros(n,bool)
        # Same gate-specific noise draws across policies and caps.
        rng=np.random.default_rng(seed)
        flips=[rng.random((n,c.k))<error for c in cases]
        for step in range(min(B,sum(c.k for c in cases))):
            remaining=B-spent;scores=[];tasks=[]
            for ci,c in enumerate(cases):
                for a in range(c.k):
                    available=(~failed[:,ci]&~stop&((state[:,ci]&(1<<a))==0)&((state[:,ci]&c.predecessors[a])==c.predecessors[a])&(ticks[ci][a]<=remaining))
                    score=fits[ci]['scores'][('pass2_fail1',policy)][remaining,state[:,ci],a].copy()
                    score[~available]=-np.inf;scores.append(score);tasks.append((ci,a))
            if not tasks:break
            raw=np.asarray(scores).T;tie=np.array([cases[c].costs[a]*1e-10+a*1e-12+c*1e-14 for c,a in tasks])
            choice=(raw-tie).argmax(axis=1);best=raw[np.arange(n),choice];active=(best>0)&np.isfinite(best)&~stop
            stop|=~active
            if not active.any():break
            for ti,(ci,a) in enumerate(tasks):
                selected=active&(choice==ti)
                positive=((truth[:,ci]&(1<<a))!=0)^flips[ci][:,a]
                state[selected&positive,ci]|=1<<a;failed[selected&~positive,ci]=True;spent[selected]+=ticks[ci][a]
        accepted=np.column_stack([state[:,ci]==(1<<c.k)-1 for ci,c in enumerate(cases)])
        true_pass=np.column_stack([truth[:,ci]==(1<<c.k)-1 for ci,c in enumerate(cases)])
        assert spent.max(initial=0)<=B
        rows.append(dict(policy=policy,assumed_false_positive_probability=error,assumed_false_negative_probability=error,
            cost_cap=budget,worlds=n,mean_cost=float(spent.mean()*.5),tentative_pass=float(accepted.sum(axis=1).mean()),
            false_positive_certificate=float((accepted&~true_pass).sum(axis=1).mean()),
            tentative_exclusion=float(failed.sum(axis=1).mean()),false_exclusion=float((failed&true_pass).sum(axis=1).mean()),
            correctly_resolved=float(((accepted&true_pass)|(failed&~true_pass)).sum(axis=1).mean())))
    return rows


def run(root):
    root=Path(root);out=root/'outputs/tables';cases=old.v3.load_candidates(root)
    config=dict(version='v5',new_experiments=0,small_instances=12,small_comparisons=72,
        common_evaluation='Same history-dependent rectangular ambiguity family; exact point, exact robust, point/robust separable and greedy',
        cost_assumptions='Ordinal costs; corrosion multiplier0.5/1/2; penalty0/0.05/0.15; cap4/8/12; reward1:1/2:1',
        assay_assumptions='Symmetric gate error0/0.02/0.05/0.10; central_positive035 simulated joint truth;20,000 worlds per duty; not measured reliability',
        assay_policy='Fixed perfect-observation decision rules; reports tentative classifications and actual false certificates; not a noise-calibrated optimizer')
    (out/'core_certificate_v5_model_card.json').write_text(json.dumps(config,indent=2),encoding='utf-8')
    small=small_common_study();small.to_csv(out/'core_certificate_v5_common_criterion.csv',index=False)
    cost=local_cost_study(cases);cost.to_csv(out/'core_certificate_v5_cost_sensitivity.csv',index=False)
    empirical,paired=empirical_baselines(root)
    empirical.to_csv(out/'core_certificate_v5_empirical_baselines.csv',index=False)
    paired.to_csv(out/'core_certificate_v5_greedy_contrasts.csv',index=False)
    fits={i:old.prepare(c,24) for i,c in enumerate(cases) if c.k and not c.structurally_excluded}
    noise=[]
    for path in sorted((root/'outputs/certificate_budget_v4').glob('central_positive035__*__truth.npz')):
        _,duty,_=path.stem.split('__')
        with np.load(path) as z:truth=z['truth'];ids=z['case_ids']
        for cap in old.COST_BUDGETS:
            for err in (0.,.02,.05,.10):
                for r in assay_stress([cases[i] for i in ids],[fits[i] for i in ids],truth,cap,err,719004):
                    noise.append(dict(duty=duty,**r))
        print('assay-error stress',duty,flush=True)
    pd.DataFrame(noise).to_csv(out/'core_certificate_v5_assay_stress.csv',index=False)
    status=dict(status='PASS',small_comparisons=len(small),local_sensitivity_comparisons=len(cost),
        assay_stress_rows=len(noise),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        empirical_point_below_greedy=int(((paired.policy=='point')&(paired.paired_mean_difference<0)).sum()),
        empirical_robust_below_greedy=int(((paired.policy=='robust')&(paired.paired_mean_difference<0)).sum()),
        noisy_results_are_tentative=True,robust_exact_is_portfolio_optimal_within_declared_small_instances=True)
    (out/'core_certificate_v5_quality_control.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    print(status,flush=True)

if __name__=='__main__':run(Path(__file__).resolve().parents[1])
