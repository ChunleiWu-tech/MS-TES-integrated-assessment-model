"""Paired stopping contrasts from retained full-precision world arrays."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]

def main():
    status=json.loads((ROOT/'outputs/qc/EVIDENCE_CERTIFICATE_STATUS.json').read_text())
    policies=status['policies'];i=policies.index('rcp');j=policies.index('rcp_continue');rows=[]
    for p in sorted((ROOT/'outputs/certificate_planning').glob('*_paired_worlds.npz')):
        with np.load(p) as z:
            r=z['certificates'][i,:,-1].astype(float)-z['certificates'][j,:,-1].astype(float)
            c=z['burden'][i,:,-1].astype(float)-z['burden'][j,:,-1].astype(float)
            for metric,v in [('certificates',r),('burden',c),('utility_lambda005',r-.05*c)]:
                mean=float(v.mean());half=1.96*float(v.std(ddof=1))/np.sqrt(len(v))
                rows.append({'process_scenario':p.stem.replace('_paired_worlds',''),'policy':'rcp','reference':'rcp_continue',
                             'metric':metric,'paired_difference':mean,'mc95_lower':mean-half,'mc95_upper':mean+half,
                             'n_common_worlds':len(v),'interval_scope':'paired Monte Carlo sampling interval conditional on process scenario'})
    pd.DataFrame(rows).to_csv(ROOT/'outputs/tables/core_certificate_stopping_comparisons.csv',index=False)
    print('Recomputed 30 paired stopping contrasts from retained common worlds')

if __name__=='__main__':main()
