from __future__ import annotations

"""Publication-disjoint diagnostics of database targets, never engineering evidence.

The JSON correlations are sampled on a fixed five-point grid. These points are
not experimental observations. Split conformal scores are maxima over entire
held-out publication components; infinite intervals are retained when the exact
finite-sample rank cannot be attained. Exchangeability is an assumption, not a
consequence of blocking publications. The v2 model remains historical.
"""
from collections import Counter
from pathlib import Path
import hashlib, io, json, math, re, zipfile
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.dummy import DummyRegressor
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score
from sklearn.model_selection import GroupKFold, GroupShuffleSplit
from sklearn.neighbors import NearestNeighbors
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

SEED = 760076
COVERAGES = (0.90, 0.95)
ATOMS = {
    'Al':(13,26.9815385),'Ba':(56,137.327),'Be':(4,9.0121831),
    'Ca':(20,40.078),'Cl':(17,35.45),'Cs':(55,132.90545196),
    'F':(9,18.998403163),'Gd':(64,157.25),'K':(19,39.0983),
    'La':(57,138.90547),'Li':(3,6.94),'Mg':(12,24.305),
    'Na':(11,22.98976928),'Nd':(60,144.242),'Np':(93,237.0),
    'Pr':(59,140.90766),'Pu':(94,244.0),'Rb':(37,85.4678),
    'Sr':(38,87.62),'Th':(90,232.0377),'U':(92,238.02891),
    'Zr':(40,91.224),
}
ELEMENTS = tuple(sorted(ATOMS))  # A fixed chemical dictionary, not learned from tests.
TARGETS = {
    'melt':('melting_temperature_K','K'),
    'density':('density_kg_m3','kg/m3'),
    'viscosity':('viscosity_mPa_s','mPa s'),
    'thermal_conductivity':('thermal_conductivity_W_m_K','W/(m K)'),
    'heat_capacity':('heat_capacity_J_mol_K','J/(mol K)'),
    'surface_tension':('surface_tension','unverified'),
}

class UnionFind:
    def __init__(self): self.parent = {}
    def find(self,x):
        self.parent.setdefault(x,x)
        if self.parent[x]!=x: self.parent[x]=self.find(self.parent[x])
        return self.parent[x]
    def union(self,a,b):
        x,y=self.find(a),self.find(b)
        if x!=y: self.parent[max(x,y)]=min(x,y)

def norm(x): return re.sub(r'[^a-z0-9]+',' ',str(x).lower()).strip()

def dois(x):
    return sorted(set(m.lower().rstrip('.,;:)') for m in
                      re.findall(r'10\.\d{4,9}/[^\s"<>]+',str(x))))

def build_source_map(entries,refs):
    """Join explicit identities, exact normalized aliases and one verified alias.

    Combined citation strings conservatively unite all explicitly listed DOIs.
    Text-only references retain an inspectable text identity; no author-only or
    chemistry-only fuzzy matching is allowed.
    """
    u=UnionFind();ref_nodes={};manual=[]
    pool=[(str(p.get('reference','')),str(p.get('DOI',''))) for _,_,ps in entries for p in ps.values() if isinstance(p,dict)]
    pool += [(str(r.REFERENCES),str(r.LINKS)) for r in refs.itertuples(index=False)]
    for ref,url in pool:
        if norm(ref) in ['', 'none']: continue
        node='ref:'+norm(ref);ref_nodes[norm(ref)]=node;u.find(node)
        ids=dois(ref+' '+url)
        # Full title/authors/year variants proven to be the same article.
        n=norm(ref)
        if ('yingling' in n and 'thermodynamic measurements and assessments' in n
                and ('106974' in n or '2023' in n)):
            ids.append('10.1016/j.jct.2022.106974')
            manual.append({'reference':ref,'doi':'10.1016/j.jct.2022.106974','basis':'same title, authors, year and article106974'})
        for doi in ids:u.union(node,'doi:'+doi)
        if not ids and url and norm(url) not in ['', 'none']:
            cleaned=url.lower().strip().rstrip('/').removeprefix('https://').removeprefix('http://')
            u.union(node,'url:'+cleaned)
    component_nodes={}
    for node in u.parent:component_nodes.setdefault(u.find(node),[]).append(node)
    identities={}
    for root,nodes in component_nodes.items():
        preferred=sorted(n for n in nodes if n.startswith('doi:')) or sorted(n for n in nodes if n.startswith('url:'))
        identities[root]=preferred[0] if preferred else 'text:'+hashlib.sha256(root.encode()).hexdigest()[:16]
    mapping={n:identities[u.find(node)] for n,node in ref_nodes.items()}
    ledger=[{'reference_normalized':n,'publication_component':k,
             'identity_status':('explicit_doi' if k.startswith('doi:') else 'explicit_url' if k.startswith('url:') else 'text_only_conservative')}
            for n,k in sorted(mapping.items())]
    return mapping,ledger,manual

def composition(formula,comp):
    parts=formula.split('-')
    if any(not re.fullmatch(r'(?:[A-Z][a-z]?\d*)+',s) for s in parts):
        raise ValueError('unparsed_formula')
    fractions=np.asarray([1.] if comp=='1' else [float(x) for x in comp.split('-')])
    if (len(parts)!=len(fractions) or not np.all(np.isfinite(fractions))
            or np.any(fractions<0) or abs(float(fractions.sum())-1)>0.005):
        raise ValueError('invalid_composition')
    # Only harmless decimal-rounding normalization is allowed; never invent fractions.
    fractions=fractions/fractions.sum()
    atom_counts={};mw=0.
    for part,fraction in zip(parts,fractions):
        counts={e:float(n or 1) for e,n in re.findall(r'([A-Z][a-z]?)(\d*)',part)}
        if any(e not in ATOMS for e in counts):raise ValueError('unsupported_element')
        mw += fraction*sum(ATOMS[e][1]*n for e,n in counts.items())
        for e,n in counts.items():atom_counts[e]=atom_counts.get(e,0)+fraction*n
    total=sum(atom_counts.values());af={e:n/total for e,n in atom_counts.items()}
    entropy=-sum(f*math.log(f) for f in fractions if f>0)/math.log(len(parts)) if len(parts)>1 else 0.
    mean_z=sum(ATOMS[e][0]*v for e,v in af.items())
    mean_aw=sum(ATOMS[e][1]*v for e,v in af.items())
    spread=math.sqrt(sum(v*(ATOMS[e][0]-mean_z)**2 for e,v in af.items()))
    features=[af.get(e,0.) for e in ELEMENTS]+[mw,len(parts),entropy,mean_z,mean_aw,spread]
    return np.asarray(features,float),mw,'-'.join(sorted(parts))

def group_quantile(scores,coverage):
    scores=np.asarray(scores,float)
    if not np.all(np.isfinite(scores)):raise ValueError('nonfinite calibration group score')
    rank=math.ceil((len(scores)+1)*coverage-1e-12)
    return (float(np.sort(scores)[rank-1]) if 0<rank<=len(scores) else float('inf')),rank

def graph_groups(frame,joint=False):
    u=UnionFind()
    for row in frame[['publication_component','formula_system']].drop_duplicates().itertuples(index=False):
        p='pub:'+row.publication_component;u.find(p)
        if joint:u.union(p,'formula:'+row.formula_system)
    return frame.publication_component.map(lambda p:u.find('pub:'+p)).to_numpy(str)

def build_records(root):
    zpath=root/'data/raw_databases/msd-tp-master.zip'
    with zipfile.ZipFile(zpath) as z:
        tree=json.loads(z.read('msd-tp-master/Molten_Salt_Thermophysical_Properties.json'))['MSTDBTP']['evaluated']
        refs=pd.read_csv(io.BytesIO(z.read('msd-tp-master/Molten_Salt_Thermophysical_Properties_refs.csv')),encoding='latin1',keep_default_na=False)
    entries=[(formula,comp,props) for formula,versions in tree.items() for comp,props in versions.items()]
    source_map,source_ledger,manual=build_source_map(entries,refs)
    records=[];curation=[]
    for raw_row,(formula,comp,props) in enumerate(entries):
        feature=None;composition_error=''
        try:feature,mw,system=composition(formula,comp)
        except (ValueError,TypeError) as exc:composition_error=str(exc)
        raw_mw=props.get('molecular_weight');mw_error=(abs(mw-float(raw_mw))/mw if feature is not None and raw_mw else np.nan)
        for prop,(target,unit) in TARGETS.items():
            if prop not in props:continue
            p=props[prop];ref=p.get('reference','');pub=source_map.get(norm(ref),'unresolved')
            base=dict(raw_row=raw_row,curve_id=f'JSON{raw_row:04d}:{prop}',target=target,
                      formula=formula,composition=comp,composition_basis='database_molar_fraction_convention',
                      formula_system=('-'.join(sorted(formula.split('-')))),
                      reference=ref,source_doi_or_url=p.get('DOI',''),publication_component=pub,
                      uncertainty=p.get('pct_uncertainty',p.get('abs_uncertainty','')),
                      uncertainty_notes=p.get('uncertainty_notes',''),unit=unit,
                      database_molecular_weight_relative_discrepancy=mw_error,
                      target_origin=('calculated_MSTDB_TC' if prop=='melt' and norm(ref)=='mstdb tc' else 'literature_correlation_or_assessment'))
            status=composition_error
            if not status and np.isfinite(mw_error) and mw_error>0.05:
                # Independent schema-consistency gate, unrelated to model residuals.
                # LiCl-UCl4 0.8-0.2 has MW for reversed fractions: do not guess
                # whether the composition or metadata was transposed.
                status='quarantined_molecular_weight_composition_discordance_over_5pct'
            temperatures=[];values=[]
            if prop=='surface_tension':status='unsupported_equation_and_unit_not_defined_in_bundled_README'
            if pub=='unresolved':status='unresolved_publication'
            if not status:
                try:
                    if prop=='melt':
                        if p.get('value_notes','') in ['Pressurized','LiquidGas']:raise ValueError('nonstandard_phase_condition')
                        temperatures=[np.nan];values=[float(p['value'])]
                    else:
                        lo,hi=map(float,p.get('range',[0,0]))
                        if not np.isfinite(lo+hi) or not hi>lo>0:raise ValueError('missing_or_degenerate_temperature_range')
                        temperatures=np.linspace(lo,hi,5);coef=np.asarray(p['values'],float)
                        if not np.all(np.isfinite(coef)):raise ValueError('nonfinite_coefficients')
                        if prop=='density' and len(coef)==2:values=(coef[0]-coef[1]*temperatures)*1000
                        elif prop=='viscosity' and len(coef)==2:values=coef[0]*np.exp(coef[1]/(8.31446261815324*temperatures))
                        elif prop=='viscosity' and len(coef)==3:values=10**(coef[0]+coef[1]/temperatures+coef[2]/temperatures**2)
                        elif prop=='thermal_conductivity' and len(coef)==2:values=coef[0]+coef[1]*temperatures
                        elif prop=='heat_capacity' and len(coef)==4:values=coef[0]+coef[1]*temperatures+coef[2]/temperatures**2+coef[3]*temperatures**2
                        else:raise ValueError('unsupported_coefficient_count')
                    if not np.all(np.isfinite(values)) or np.any(np.asarray(values)<=0):raise ValueError('nonpositive_or_nonfinite_target')
                except (ValueError,TypeError,KeyError,OverflowError) as exc:status=str(exc)
            curation.append(dict(**base,status=status or 'retained',n_generated_grid_points=(len(values) if not status else 0),
                                 coefficients=json.dumps(p.get('values',p.get('value',''))),temperature_range=json.dumps(p.get('range',[]))))
            if status:continue
            for temp,value in zip(temperatures,values):
                x=np.concatenate([feature,[temp]]) if prop!='melt' else feature
                records.append(dict(**base,temperature_K=temp,target_value=float(value),features=x.tolist()))
    return pd.DataFrame(records),pd.DataFrame(curation),pd.DataFrame(source_ledger),manual

def estimators():
    return {'median':DummyRegressor(strategy='median'),
            'ridge':make_pipeline(StandardScaler(),Ridge(alpha=10.)),
            'extra_trees':ExtraTreesRegressor(n_estimators=80,min_samples_leaf=3,max_features=.8,random_state=SEED,n_jobs=1)}

def weights(frame):
    # Equal total weight per source component, equal curve weight within source.
    point_count=frame.groupby('curve_id').curve_id.transform('size').to_numpy(float)
    curve_counts=frame[['publication_component','curve_id']].drop_duplicates().groupby('publication_component').size()
    source_curve_counts=frame.publication_component.map(curve_counts).to_numpy(float)
    w=1/(point_count*source_curve_counts)
    return w/w.mean()

def fit_model(estimator,X,y,w):
    model=clone(estimator)
    if 'ridge' in model.get_params():model.fit(X,y,ridge__sample_weight=w)
    else:model.fit(X,y,sample_weight=w)
    return model

def positive_exp(values):
    """No outcome-based clipping: overflow/underflow becomes explicit abstention."""
    with np.errstate(over='ignore',under='ignore',invalid='ignore'):
        return np.exp(np.asarray(values,float))

def errors(frame,pred,groups,native_log_prediction=None):
    err=frame.target_value.to_numpy(float)-np.asarray(pred)
    with np.errstate(over='ignore',invalid='ignore'): squared=err**2
    curve=pd.DataFrame({'curve':frame.curve_id.to_numpy(),'abs':abs(err),'sq':squared}).groupby('curve').mean()
    source=pd.DataFrame({'group':groups,'abs':abs(err),'sq':squared}).groupby('group').mean()
    publication=pd.DataFrame({'pub':frame.publication_component.to_numpy(),'abs':abs(err)}).groupby('pub').mean()
    raw_finite=bool(np.all(np.isfinite(pred)))
    logpred=np.asarray(native_log_prediction,float) if native_log_prediction is not None else np.full(len(pred),np.nan)
    if native_log_prediction is None:
        good=(np.asarray(pred)>0)&np.isfinite(pred)
        logpred[good]=np.log(np.asarray(pred)[good])
    logy=np.log(frame.target_value.to_numpy(float));logerr=abs(logy-logpred)
    log_finite=bool(np.all(np.isfinite(logpred)))
    logsource=pd.DataFrame({'group':groups,'err':logerr}).groupby('group').err.mean()
    logpub=pd.DataFrame({'pub':frame.publication_component.to_numpy(),'err':logerr}).groupby('pub').err.mean()
    return dict(point_MAE=float(np.mean(abs(err))),curve_macro_MAE=float(curve['abs'].mean()),
                publication_macro_MAE=float(publication['abs'].mean()),
                blocking_component_macro_MAE=float(source['abs'].mean()),blocking_component_macro_RMSE=float(np.sqrt(source['sq'].mean())),
                point_R2=float(r2_score(frame.target_value,pred)) if len(frame)>1 and raw_finite else np.nan,
                nonfinite_or_nonpositive_prediction_fraction=float(np.mean(~np.isfinite(pred)|(np.asarray(pred)<=0))),
                log_R2=float(r2_score(logy,logpred)) if len(frame)>1 and log_finite else np.nan,
                log_MAE=float(logerr.mean()) if log_finite else np.nan,
                publication_macro_log_MAE=float(logpub.mean()) if log_finite else np.nan,
                blocking_component_macro_log_MAE=float(logsource.mean()) if log_finite else np.nan)

def select_model(frame,X,y,groups):
    ng=len(np.unique(groups));choices={}
    if ng<2:return 'median',{'median':np.nan}
    cv=GroupKFold(n_splits=min(3,ng))
    for name,est in estimators().items():
        pred=np.full(len(y),np.nan)
        for tr,te in cv.split(X,y,groups):
            pred[te]=fit_model(est,X[tr],y[tr],weights(frame.iloc[tr])).predict(X[te])
        # y and model predictions are on the declared fitting scale: log viscosity
        # measures multiplicative error; all other targets keep physical-unit MAE.
        choices[name]=float(pd.DataFrame({'group':groups,'err':abs(y-pred)}).groupby('group').err.mean().mean())
    return min(choices,key=choices.get),choices

def applicability(frame,X,fit_indices,test_indices,include_temperature):
    # Fit solely on fitting curves; density grids cannot serve as five AD neighbors.
    shape=X[:,:-1] if include_temperature else X
    fitted=frame.iloc[fit_indices].copy();fitted['_pos']=fit_indices
    centroids=np.vstack([shape[g._pos.to_numpy()].mean(axis=0) for _,g in fitted.groupby('curve_id')])
    scaler=StandardScaler().fit(centroids);Z=scaler.transform(centroids)
    if len(Z)<2:return np.zeros(len(test_indices),bool),np.full(len(test_indices),np.inf),np.nan
    nn=NearestNeighbors(n_neighbors=2).fit(Z)
    threshold=float(np.quantile(nn.kneighbors(Z)[0][:,1],.95))
    distance=nn.kneighbors(scaler.transform(shape[test_indices]),n_neighbors=1)[0][:,0]
    seen=np.any(X[fit_indices,:len(ELEMENTS)]>0,axis=0)
    no_unseen=~np.any((X[test_indices,:len(ELEMENTS)]>0)&~seen,axis=1)
    accepted=(distance<=threshold+1e-12)&no_unseen
    if include_temperature:
        accepted &= (X[test_indices,-1]>=X[fit_indices,-1].min())&(X[test_indices,-1]<=X[fit_indices,-1].max())
    return accepted,distance,threshold

def evaluate(frame,target,scheme):
    frame=frame.reset_index(drop=True);X=np.asarray(frame.features.tolist(),float);y=frame.target_value.to_numpy(float)
    log_fit=(target=='viscosity_mPa_s')
    native_y=np.log(y) if log_fit else y
    fitting_scale='natural_log_viscosity' if log_fit else 'physical_units'
    groups=graph_groups(frame,joint=(scheme=='joint_publication_formula'))
    sizes=Counter(groups);ng=len(sizes);largest=max(sizes.values())/len(frame)
    feasibility=dict(target=target,validation_scheme=scheme,n_publication_components=frame.publication_component.nunique(),
                     n_blocking_components=ng,n_source_curves=frame.curve_id.nunique(),n_generated_grid_points=len(frame),
                     largest_component_point_fraction=largest,component_sizes_descending=json.dumps(sorted(sizes.values(),reverse=True)),
                     status=('evaluated_imbalanced_components' if largest>.5 else 'evaluated') if ng>=8 else 'inadequate_fewer_than_8_blocking_components')
    if ng<8:return [],[],[],feasibility
    folds=[];oof=[];metrics=[]
    cv=GroupKFold(n_splits=min(5,ng))
    for fold,(outer_fit,test) in enumerate(cv.split(X,y,groups),1):
        fit_rel,cal_rel=next(GroupShuffleSplit(n_splits=1,test_size=.30,random_state=SEED+fold).split(X[outer_fit],y[outer_fit],groups[outer_fit]))
        fit=outer_fit[fit_rel];cal=outer_fit[cal_rel]
        assert not(set(groups[fit])&set(groups[cal]) or set(groups[fit])&set(groups[test]) or set(groups[cal])&set(groups[test]))
        # Explicitly verify publication disjointness in both schemes, plus chemistry for joint.
        for column in ['publication_component']+(['formula_system'] if scheme=='joint_publication_formula' else []):
            a,b,c=(set(frame.iloc[idx][column]) for idx in [fit,cal,test]);assert not(a&b or a&c or b&c)
        selected,inner_scores=select_model(frame.iloc[fit],X[fit],native_y[fit],groups[fit])
        models={name:fit_model(est,X[fit],native_y[fit],weights(frame.iloc[fit])) for name,est in estimators().items()}
        selected_model=models[selected];native_pred=selected_model.predict(X[test]);cpred=selected_model.predict(X[cal])
        pred=positive_exp(native_pred) if log_fit else native_pred
        cal_scores=pd.DataFrame({'group':groups[cal],'residual':abs(native_y[cal]-cpred)}).groupby('group').residual.max().to_numpy()
        accepted,distance,ad_threshold=applicability(frame,X,fit,test,not target.startswith('melting_temperature_K'))
        for name,model in models.items():
            mp=model.predict(X[test]);rawmp=positive_exp(mp) if log_fit else mp
            metrics.append(dict(target=target,validation_scheme=scheme,fold=fold,model=name,fitting_scale=fitting_scale,
                                historical_raw_scale_baseline=target.endswith('_raw_scale_baseline'),selected_by_inner_fit=(name==selected),
                                **errors(frame.iloc[test],rawmp,groups[test],mp if log_fit else None)))
        base=dict(target=target,validation_scheme=scheme,fold=fold,selected_model=selected,
                  fitting_scale=fitting_scale,inner_selection_criterion=('blocking_component_macro_absolute_natural_log_error' if log_fit else 'blocking_component_macro_absolute_physical_error'),
                  inner_blocking_component_macro_MAE=json.dumps(inner_scores,sort_keys=True),n_fit_groups=len(set(groups[fit])),
                  fit_blocking_component_ids=json.dumps(sorted(set(groups[fit]))),
                  calibration_blocking_component_ids=json.dumps(sorted(set(groups[cal]))),
                  test_blocking_component_ids=json.dumps(sorted(set(groups[test]))),
                  fit_publication_ids=json.dumps(sorted(set(frame.iloc[fit].publication_component))),
                  calibration_publication_ids=json.dumps(sorted(set(frame.iloc[cal].publication_component))),
                  test_publication_ids=json.dumps(sorted(set(frame.iloc[test].publication_component))),
                  n_calibration_groups=len(cal_scores),n_test_groups=len(set(groups[test])),n_fit_curves=frame.iloc[fit].curve_id.nunique(),
                  n_calibration_curves=frame.iloc[cal].curve_id.nunique(),n_test_curves=frame.iloc[test].curve_id.nunique(),
                  ad_threshold=ad_threshold,ad_acceptance_fraction=float(accepted.mean()),**errors(frame.iloc[test],pred,groups[test],native_pred if log_fit else None))
        for coverage in COVERAGES:
            q,rank=group_quantile(cal_scores,coverage)
            lower=positive_exp(native_pred-q) if log_fit else pred-q
            upper=positive_exp(native_pred+q) if log_fit else pred+q
            radius=float(positive_exp(q)) if log_fit else np.nan
            finite=np.isfinite(q)&np.isfinite(lower)&np.isfinite(upper)&np.isfinite(pred)&(pred>0)
            covered=(y[test]>=lower)&(y[test]<=upper)
            released=accepted&finite
            group_covered=pd.DataFrame({'group':groups[test],'covered':covered}).groupby('group').covered.all()
            folds.append(dict(**base,nominal_coverage=coverage,conformal_rank=rank,conformal_half_width=q,
                              conformal_score_scale=fitting_scale,multiplicative_radius=radius,
                              interval_status=('abstain_insufficient_calibration_groups' if not np.isfinite(q) else
                                               'finite_log_group_max' if log_fit and finite.all() else
                                               'abstain_nonrepresentable_or_nonpositive_prediction' if not finite.all() else 'finite_group_max'),
                              finite_interval_fraction=float(finite.mean()),
                              point_coverage=float(covered.mean()),whole_component_coverage=float(group_covered.mean()),
                              accepted_point_coverage=(float(covered[released].mean()) if released.any() else np.nan)))
            for j,idx in enumerate(test):
                row=frame.iloc[idx]
                oof.append(dict(target=target,validation_scheme=scheme,fold=fold,nominal_coverage=coverage,
                                curve_id=row.curve_id,publication_component=row.publication_component,blocking_component=groups[idx],
                                formula_system=row.formula_system,temperature_K=row.temperature_K,observed_database_target=y[idx],
                                fitting_scale=fitting_scale,log_prediction=(native_pred[j] if log_fit else
                                    float(np.log(pred[j])) if np.isfinite(pred[j]) and pred[j]>0 else np.nan),
                                prediction=pred[j],lower=lower[j],upper=upper[j],covered=bool(covered[j]),
                                conformal_score=q,multiplicative_radius=radius,
                                finite_interval=bool(finite[j]),ad_accepted=bool(accepted[j]),ad_distance=distance[j],
                                prediction_status=('released_diagnostic' if released[j] else 'abstain_insufficient_calibration_groups' if not np.isfinite(q)
                                    else 'abstain_numeric_or_nonpositive_prediction' if not finite[j] else 'abstain_fit_only_applicability'),
                                released_diagnostic_prediction=bool(released[j])))
    return folds,oof,metrics,feasibility

def run(root):
    root=Path(root);out=root/'outputs/tables';out.mkdir(parents=True,exist_ok=True)
    records,curation,sources,manual=build_records(root)
    prefix='core_thermophysical_v3_'
    curation.to_csv(out/(prefix+'record_ledger.csv'),index=False,encoding='utf-8-sig')
    sources.to_csv(out/(prefix+'publication_ledger.csv'),index=False,encoding='utf-8-sig')
    folds=[];oof=[];models=[];status=[]
    for prop,(target,unit) in TARGETS.items():
        df=records[records.target==target].copy()
        if df.empty:
            status.append(dict(target=target,status='unsupported_or_no_retained_records',unit=unit,n_source_curves=0));continue
        variants=[(target,df)]
        if prop=='melt':variants.append((target+'_literature_only',df[df.target_origin!='calculated_MSTDB_TC'].copy()))
        if prop=='viscosity':variants.append((target+'_raw_scale_baseline',df.copy()))
        for label,sub in variants:
            for scheme in ['publication_component','joint_publication_formula']:
                print(f'{label}: {scheme}; {sub.curve_id.nunique()} curves, {sub.publication_component.nunique()} publications',flush=True)
                a,b,c,d=evaluate(sub,label,scheme);folds.extend(a);oof.extend(b);models.extend(c);status.append(d)
    f=pd.DataFrame(folds);p=pd.DataFrame(oof);m=pd.DataFrame(models);s=pd.DataFrame(status)
    f.to_csv(out/(prefix+'folds.csv'),index=False,encoding='utf-8-sig')
    p.to_csv(out/(prefix+'oof_predictions.csv'),index=False,encoding='utf-8-sig')
    m.to_csv(out/(prefix+'model_comparison.csv'),index=False,encoding='utf-8-sig')
    s.to_csv(out/(prefix+'status.csv'),index=False,encoding='utf-8-sig')
    summary=[]
    if len(p):
        for (target,scheme,coverage),g in p.groupby(['target','validation_scheme','nominal_coverage']):
            finite=g.finite_interval.to_numpy(bool);err=abs(g.observed_database_target-g.prediction)
            group_cov=g.groupby('blocking_component').covered.all()
            finite_group=g.groupby('blocking_component').finite_interval.all()
            curve_errors=pd.DataFrame({'curve':g.curve_id,'err':err}).groupby('curve').err.mean()
            source_errors=pd.DataFrame({'source':g.blocking_component,'err':err}).groupby('source').err.mean()
            publication_errors=pd.DataFrame({'pub':g.publication_component,'err':err}).groupby('pub').err.mean()
            accepted=g.released_diagnostic_prediction.to_numpy(bool)
            eframe=pd.DataFrame({'target_value':g.observed_database_target,'curve_id':g.curve_id,'publication_component':g.publication_component})
            logmetrics=errors(eframe,g.prediction.to_numpy(),g.blocking_component.to_numpy(),g.log_prediction.to_numpy())
            summary.append(dict(target=target,validation_scheme=scheme,nominal_coverage=coverage,n_source_curves=g.curve_id.nunique(),
                fitting_scale=g.fitting_scale.iloc[0],historical_raw_scale_baseline=target.endswith('_raw_scale_baseline'),
                n_blocking_components=g.blocking_component.nunique(),n_generated_grid_points=len(g),point_MAE=float(err.mean()),
                curve_macro_MAE=float(curve_errors.mean()),publication_macro_MAE=float(publication_errors.mean()),
                blocking_component_macro_MAE=float(source_errors.mean()),point_R2=logmetrics['point_R2'],
                log_R2=logmetrics['log_R2'],log_MAE=logmetrics['log_MAE'],
                publication_macro_log_MAE=logmetrics['publication_macro_log_MAE'],blocking_component_macro_log_MAE=logmetrics['blocking_component_macro_log_MAE'],
                nonfinite_or_nonpositive_prediction_fraction=logmetrics['nonfinite_or_nonpositive_prediction_fraction'],
                finite_interval_fraction=float(finite.mean()),finite_component_fraction=float(finite_group.mean()),
                point_coverage_including_infinite=float(g.covered.mean()),whole_component_coverage_including_infinite=float(group_cov.mean()),
                finite_only_point_coverage=float(g.loc[finite,'covered'].mean()) if finite.any() else np.nan,
                finite_only_whole_component_coverage=float(group_cov[finite_group].mean()) if finite_group.any() else np.nan,
                finite_mean_interval_width=float((g.loc[finite,'upper']-g.loc[finite,'lower']).mean()) if finite.any() else np.nan,
                finite_mean_multiplicative_radius=float(g.loc[finite,'multiplicative_radius'].mean()) if finite.any() and target=='viscosity_mPa_s' else np.nan,
                finite_mean_multiplicative_width_factor=float((g.loc[finite,'multiplicative_radius']**2).mean()) if finite.any() and target=='viscosity_mPa_s' else np.nan,
                ad_acceptance_fraction=float(g.ad_accepted.mean()),released_diagnostic_fraction=float(accepted.mean()),
                released_diagnostic_point_coverage=float(g.loc[accepted,'covered'].mean()) if accepted.any() else np.nan))
    pd.DataFrame(summary).to_csv(out/(prefix+'summary.csv'),index=False,encoding='utf-8-sig')
    card=dict(version='v3',seed=SEED,n_trees=80,nominal_coverages=COVERAGES,
        source='bundled MSTDB-TP JSON evaluated records, full-precision coefficients',
        raw_zip_sha256=hashlib.sha256((root/'data/raw_databases/msd-tp-master.zip').read_bytes()).hexdigest(),
        independence_unit='explicit publication identity connected component; joint experiment additionally unites shared formula systems',
        weighting='equal publication-component total training weight, equal source-curve weight within publication; inner selection blocking-component macro MAE on declared fitting scale',
        calibration='one maximum absolute residual per whole calibration blocking component on declared fitting scale; exact kth order statistic, infinite if k>G',
        viscosity_fit_scale='natural log of positive viscosity; all fixed candidate models fit log mu and inner selection uses component-macro absolute log-error',
        viscosity_interval='exp(log_prediction +/- q_log); multiplicative radius exp(q_log); exact infinite rank gives unbounded positive interval and abstention',
        viscosity_rationale='network-forming liquids span orders of magnitude; equal log-error treats comparable multiplicative errors equally. This physical criterion applies to every viscosity record, retains BeF2 and reports unchanged raw-scale baseline on identical source splits.',
        exponentiation_policy='NumPy exponentiation without data-based clipping; nonfinite/nonpositive point predictions and nonrepresentable interval endpoints explicitly abstain',
        coverage_scope='simultaneous coverage of the specified finite five-point grid within a new exchangeable blocking component; not continuous-temperature bands or arbitrary chemistry-shift guarantees',
        applicability='heuristic fit-only curve-centroid chemistry distance plus unseen-element and fit-temperature-range rejection; post-selection coverage is empirical only',
        composition_basis='database molar-fraction convention corroborated by primary density-transfer paper and mixture molecular weights; discrepancies retained as ledger flags',
        candidate_status='abstain_shortlist_composition_basis_not_authoritatively_crosswalked; no candidate predictions produced',
        surface_tension_status='unsupported because equation/sign/unit are absent in bundled README; no guessed relation',
        engineering_firewall='no predicted property or interval alters qualification, action evidence, selection gates, or engineering feasibility',
        historical_baseline='ai_property_model_v2.py and existing outputs remain historical; its pooled rowwise conformal is superseded',
        manual_source_aliases=manual,
        primary_methods_sources=['https://arxiv.org/abs/1604.04173','https://arxiv.org/abs/2306.06342','https://doi.org/10.1214/23-AOS2276',
                                'https://info.ornl.gov/sites/publications/Files/Pub222614.pdf','https://pmc.ncbi.nlm.nih.gov/articles/PMC12677718/'])
    (out/(prefix+'model_card.json')).write_text(json.dumps(card,indent=2,ensure_ascii=False),encoding='utf-8')
    review='''# Thermophysical v3 methods and interpretation

This standalone diagnostic supersedes the historical v2 uncertainty calculation.
The predictors remain independent of every engineering qualification and action gate.

Full-precision JSON supplies density, viscosity, conductivity, and molar heat-capacity
relations and applicable temperature ranges. Equation and unit conventions are taken
from the bundled MSTDB-TP README. Each correlation supplies five deterministic grid
values, labelled as generated targets, with equal curve weight within each equally
weighted source component. These are not five independent experiments. Surface
tension is unsupported because the bundled README does not define its relation/unit.
Heat capacity is retained only with a positive nondegenerate applicable range.

The source ledger joins explicit DOIs/URLs and exact normalized citation aliases.
Yingling2023 title/article106974 variants are explicitly joined to
10.1016/j.jct.2022.106974. Text-only full references remain conservative identities;
the ledger is not a proof that all underlying laboratory/compilation overlaps are known.
Publication components are the first blocking unit. A second experiment unites shared
formula systems and publications transitively, preserving giant components intact.
Fixed five-fold outer tests use median, ridge(alpha10), and ExtraTrees(80trees).
Only inner fitting groups select a model by macro blocking-component MAE. Calibration sources
are held out before selection. Actual fit/calibration/test identities are in folds.csv.

All viscosity candidates fit natural log(mu), using the same curves, weights, source
splits and fixed candidate family. Inner selection uses macro absolute log-error;
calibration uses whole-component maximum absolute log-residual. Intervals become
[exp(log_prediction-q_log),exp(log_prediction+q_log)], with multiplicative radius
exp(q_log). No outcome-based clipping is performed; numeric overflow/underflow of
point predictions, nonpositive predictions, and nonrepresentable finite endpoints
cause explicit abstention. The declared log-scale criterion reflects the orders of
magnitude separating network-forming and ordinary ionic melts: a comparable ratio
error receives comparable importance throughout the corpus. It is not chosen to
maximize a reported test R2. Raw-space MAE and R2 remain visible alongside log MAE,
log R2 and multiplicative interval width. An explicitly historical raw-scale viscosity
baseline is recomputed on identical source splits, preserving the previous criterion.
Other targets continue fitting and calibrating in their physical units. The log model
does not establish universal BeF2 or new-chemistry extrapolation accuracy.

For each calibration component, the score is the largest absolute residual on the
declared fitting scale over its
entire generated grid. With G components and desired coverage c, k=ceil((G+1)c).
The kth ordered score is used exactly; k>G produces infinity and an explicit abstention.
90% needs at least9 calibration components, and95% at least19, for a finite band.
Whole-component and point coverage, finite-only coverage, and the proportion of finite
intervals are reported separately. Infinite bands must never be advertised as useful
100% coverage. Under exchangeable calibration/new components this construction covers
the specified finite grid jointly within a new component. It is not a continuous curve
band or a guarantee for arbitrary chemistry/source distribution shift.

Applicability scaling, curve-neighbor threshold, observed elements, and temperature
support use fitting data alone. Applicability is a heuristic rejection rule. Coverage
among released diagnostic predictions is empirical; ordinary marginal conformal
coverage does not establish coverage after applicability selection. Shortlist candidates
are not predicted because their weight/mole-fraction bases have not been authoritatively
crosswalked. Predictions never impute missing engineering evidence.

The ORNL report explains that thermodynamically assessed multicomponent melting
temperatures are calculated with Thermochimica/MSTDB-TC, and distinguishes literature
values. Accordingly calculated-inclusive and literature-only melting diagnostics are
reported separately. Literature-only does not imply every datum is a direct experiment.
Database mixture fractions follow the molar convention used by the primary density
model below; mixture-molar-weight discrepancies remain visible in the row ledger.
Descriptors use chemically computed molecular weights, not potentially erroneous
database molecular-weight fields. Records with more than5% discrepancy between
database and chemically implied molecular weights are quarantined independently of
any model error. LiCl-UCl4(0.8-0.2) has the molecular weight for reversed fractions;
neither the composition nor the metadata is silently corrected.

The extremely large BeF2 viscosity is retained as a verified network-forming-liquid
target. The primary2025reference-correlation paper(Table6, Eq2) confirms the exact
JSON Arrhenius coefficient pair, applicable range, and cP unit(equivalent to mPa s).
It is therefore a documented source of predictive difficulty, not a residual-driven
exclusion. https://www.osti.gov/biblio/3002723 (DOI10.1063/5.0264576).

Primary methodological and provenance sources:

- Lei et al., Distribution-Free Predictive Inference for Regression:
  https://arxiv.org/abs/1604.04173
- Lee, Barber, Willett, Distribution-free inference with hierarchical data:
  https://arxiv.org/abs/2306.06342
- Barber et al., Conformal prediction beyond exchangeability:
  https://doi.org/10.1214/23-AOS2276
- Jin and Ren, Selection-conditional conformal prediction:
  https://academic.oup.com/jrsssb/article/87/4/1239/8113856
- ORNL/TM-2024/3575, MSTDB-TP v3.1 overview:
  https://info.ornl.gov/sites/publications/Files/Pub222614.pdf
- Toward a Generalizable Prediction Model of Molten Salt Mixture Density with
  Chemistry-Informed Transfer Learning (primary study; explicitly uses molar fractions):
  https://pmc.ncbi.nlm.nih.gov/articles/PMC12677718/
'''
    (out/(prefix+'method_review.md')).write_text(review,encoding='utf-8')
    qc={'status':'PASS_WITH_EXPLICIT_LIMITATIONS','source_disjoint_assertions':'passed_in_all_evaluated_folds',
        'engineering_evidence_imputed':False,'candidate_predictions_produced':False,'curation_counts':curation.status.value_counts().to_dict(),
        'retained_source_curves':int(curation.status.eq('retained').sum()),'n_generated_grid_points':len(records),
        'infinite_interval_folds':int((~np.isfinite(f.conformal_half_width)).sum()) if len(f) else 0,
        'nonrepresentable_or_nonpositive_prediction_folds':int(f.interval_status.eq('abstain_nonrepresentable_or_nonpositive_prediction').sum()) if len(f) else 0,
        'interpretation':'Infinite intervals and insufficient targets are explicit abstentions; PASS does not mean scientific readiness for all targets.'}
    (out/(prefix+'quality_control.json')).write_text(json.dumps(qc,indent=2),encoding='utf-8')
    return summary
