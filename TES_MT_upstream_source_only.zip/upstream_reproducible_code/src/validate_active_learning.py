from __future__ import annotations

import json
import argparse
from pathlib import Path
import pandas as pd
import gzip

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description="Validate active-learning outputs")
parser.add_argument("--tables", type=Path, default=ROOT / "outputs" / "tables")
parser.add_argument("--qc", type=Path, default=None)
args = parser.parse_args()
OUT = args.tables
QC = args.qc or OUT.parent / "qc"
QC.mkdir(parents=True, exist_ok=True)

required = [
    "active_learning_strategy_summary.csv",
    "active_learning_posterior_trajectory.csv",
    "active_learning_recommended_sequences.csv",
    "active_learning_statistical_tests.csv",
    "active_learning_action_trace.csv.gz",
]
errors = []
for name in required:
    if not (OUT / name).exists():
        errors.append(f"missing {name}")
status_path = QC / "ACTIVE_LEARNING_STATUS.json"
if not status_path.exists():
    errors.append("missing ACTIVE_LEARNING_STATUS.json")
else:
    status = json.loads(status_path.read_text(encoding="utf-8"))
    if status.get("status") != "PASS":
        errors.append(f"status={status.get('status')}")
    if int(status.get("mc_iterations", 0)) < 100:
        errors.append(f"unexpected mc_iterations={status.get('mc_iterations')}")
if not errors:
    summary = pd.read_csv(OUT / "active_learning_strategy_summary.csv")
    if set(summary.strategy) != {"random", "greedy_unlock", "eig", "ei"}:
        errors.append("strategy coverage incomplete")
    if set(summary.budget_actions) != set(range(7)):
        errors.append("budget coverage incomplete")
    if summary.no_selection_frequency.min() < -1e-12 or summary.no_selection_frequency.max() > 1 + 1e-12:
        errors.append("no-selection frequency outside [0,1]")
    required_summary = {
        "mean_formal_candidate_count", "selection_event_frequency",
        "formal_candidate_count_ci95_low", "formal_candidate_count_ci95_high",
        "mean_cumulative_cost", "selection_improvement_per_cost",
    }
    if not required_summary.issubset(summary.columns):
        errors.append(f"summary columns missing: {sorted(required_summary - set(summary.columns))}")
    tests = pd.read_csv(OUT / "active_learning_statistical_tests.csv")
    if tests.empty or not tests.p_value.between(0, 1).all():
        errors.append("statistical test table invalid")
    trace = pd.read_csv(OUT / "active_learning_action_trace.csv.gz", compression="gzip")
    required_trace = {
        "formal_candidate_count", "selection_event", "winner_system_id",
        "posterior_entropy_before", "posterior_entropy_after", "cumulative_cost_units",
    }
    if not required_trace.issubset(trace.columns):
        errors.append(f"trace columns missing: {sorted(required_trace - set(trace.columns))}")
    if not trace.empty and (trace.formal_candidate_count < 0).any():
        errors.append("negative formal candidate count")
    if "trace_rows" in status and int(status["trace_rows"]) != len(trace):
        errors.append(f"trace row count mismatch: status={status['trace_rows']} read={len(trace)}")
result = {"status": "PASS" if not errors else "FAIL", "errors": errors}
(QC / "ACTIVE_LEARNING_VALIDATION.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
print(json.dumps(result, indent=2))
if errors:
    raise SystemExit(1)
