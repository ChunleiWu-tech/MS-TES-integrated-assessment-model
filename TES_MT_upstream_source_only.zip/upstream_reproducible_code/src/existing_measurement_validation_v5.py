"""Training-only response shrinkage, condition locators and material case chain."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import evidence_certificate_model as beliefs

ALPHAS=(0.,.25,.5,.75,1.)

def device_shrinkage(out):
    obs=pd.read_csv(out/'core_existing_v4_device_observations.csv')
    old=pd.read_csv(out/'core_existing_v4_device_transfer_predictions.csv')
    base=obs[obs.material.eq('base')].set_index(['source_id','direction','hot_C','cold_C'])
    nonbase=obs[~obs.material.eq('base')].copy()
    nonbase['base_power']=[base.loc[(r.source_id,r.direction,r.hot_C,r.cold_C),'power_kW_m3'] for r in nonbase.itertuples()]
    nonbase['ratio']=nonbase.power_kW_m3/nonbase.base_power
    rows=[];selection=[]
    for mid,g in old.groupby('model_id',sort=True):
        first=g.iloc[0];ids=json.loads(first.training_observation_ids)
        train=nonbase[nonbase.observation_id.isin(ids)].copy()
        assert set(ids)==set(train.observation_id)
        scores={}
        for alpha in ALPHAS:
            errors=[]
            for trajectory,test in train.groupby('thermal_trajectory_group'):
                fit=train[train.thermal_trajectory_group.ne(trajectory)]
                if fit.empty:raise ValueError('Insufficient training trajectories for shrinkage selection')
                factor=1+alpha*(float(fit.ratio.median())-1)
                errors.append(float((100*abs(factor/test.ratio-1)).mean()))
            scores[alpha]=float(np.mean(errors))
        # Equal errors prefer the simpler identity rule. Heldout outcomes are absent.
        alpha=min(ALPHAS,key=lambda a:(scores[a],a))
        factor=1+alpha*(float(train.ratio.median())-1)
        selection.append(dict(model_id=mid,split_type=first.split_type,material=first.material,direction=first.direction,
            training_ids=json.dumps(ids),training_trajectories=train.thermal_trajectory_group.nunique(),
            selected_alpha=alpha,fitted_factor=factor,inner_macro_trajectory_MAPE=json.dumps(scores)))
        for r in g.itertuples():
            prediction=factor*r.heldout_base_control_kW_m3
            rows.append(dict(model_id=mid,split_type=r.split_type,heldout_source_doi=r.heldout_source_doi,
                observation_id=r.heldout_observation_id,trajectory=r.thermal_trajectory_group,material=r.material,direction=r.direction,
                observed_power=r.observed_composite_kW_m3,identity_power=r.heldout_base_control_kW_m3,
                legacy_prediction=r.predicted_composite_kW_m3,shrinkage_prediction=prediction,selected_alpha=alpha,
                shrinkage_abs_percent_error=100*abs(prediction/r.observed_composite_kW_m3-1),
                legacy_abs_percent_error=abs(r.model_minus_observed_percent),identity_abs_percent_error=abs(r.identity_transfer_error_percent),
                supported_transfer=False,measured_heldout_base_required=True))
    p=pd.DataFrame(rows);summaries=[]
    for key,g in p.groupby(['split_type','direction']):
        for label in ('identity','legacy','shrinkage'):
            col=label+'_abs_percent_error'
            summaries.append(dict(split_type=key[0],direction=key[1],model=label,dependent_endpoints=len(g),
                publications=g.heldout_source_doi.nunique(),trajectory_groups=g.trajectory.nunique(),
                endpoint_MAPE=float(g[col].mean()),trajectory_macro_MAPE=float(g.groupby('trajectory')[col].mean().mean()),
                source_macro_MAPE=float(g.groupby('heldout_source_doi')[col].mean().mean()),
                source_material_macro_MAPE=float(g.groupby('model_id')[col].mean().mean())))
    for label,data in [('device_predictions',p),('device_selection',pd.DataFrame(selection)),('device_summary',pd.DataFrame(summaries))]:
        data.to_csv(out/('core_existing_v5_'+label+'.csv'),index=False)
    return pd.DataFrame(summaries)

def evidence_case(root):
    out=root/'outputs/tables';props=pd.read_csv(root/'data/input/core_candidate_property_registry.csv')
    cases=beliefs.load_candidates(root);ledger=pd.read_csv(out/'core_certificate_case_ledger.csv')
    corr=pd.read_csv(out/'core_existing_v4_corrosion_conditions.csv');duties=pd.read_csv(root/'config/core_system_benchmarks.csv')
    strict=[]
    for row in ledger.itertuples():
        # Only initially accepted memberships are challenged here; unresolved
        # memberships retain their original status. Absence of a locator is
        # missing evidence, not proof of incompatible chemistry.
        accepted=row.initial_state=='model_qualified'
        matching=corr[corr.system_id.eq(row.system_id)]
        if accepted:assert matching.empty
        strict.append(dict(case_id=row.case_id,system_id=row.system_id,duty=row.scenario,
            baseline_state=row.initial_state,strict_locator_state='undetermined' if accepted else row.initial_state,
            initially_accepted=accepted,matched_quantified_corrosion_rows=len(matching),
            strict_rule='Reopen accepted corrosion when no exact composition-alloy-exposure quantified locator is supplied',
            physical_exclusion_preserved=row.structurally_excluded,
            new_gate_probability_estimated=False,new_planning_probability='not supplied; no probabilistic plan inferred'))
    s=pd.DataFrame(strict);s.to_csv(out/'core_existing_v5_locator_sensitivity.csv',index=False)
    detail=[]
    solar_id=int(ledger.loc[ledger.system_id.eq('solar_salt_ss60')&ledger.scenario.eq('industrial_medium_heat'),'case_id'].iloc[0])
    for cid in (2,solar_id):
        c=cases[cid];prop=props[props.system_id.eq(c.system_id)].iloc[0];d=duties[duties.scenario.eq(c.scenario)].iloc[0]
        detail.append(dict(case_id=cid,system_id=c.system_id,duty=c.scenario,composition=prop.composition,
            cold_C=d.fixed_Tcold_C,hot_C=d.fixed_Thot_C,melting_C=prop.Tm_C,practical_upper_C=prop.Tmax_practical_C,
            cp_domain_C=json.dumps([prop.cp_Tmin_C,prop.cp_Tmax_C]),density_domain_C=json.dumps([prop.rho_Tmin_C,prop.rho_Tmax_C]),
            property_sources=prop.source_ids,property_class=prop.property_data_class,
            initial_state=ledger.loc[ledger.case_id.eq(cid),'initial_state'].iloc[0],
            unresolved_tasks=';'.join(beliefs.GATES[a] for a in c.required),
            task_cost_total=float(c.costs.sum()),task_prerequisites=json.dumps(c.predecessors.tolist()),
            corrosion_evidence='No exact composition-alloy-duty rate locator in retained 26-endpoint set',
            device_transfer='Device coefficients measured below industrial duty; no transfer to250-450C qualification or certificate reward',
            device_reward_coupled=False))
    pd.DataFrame(detail).to_csv(out/'core_existing_v5_material_case.csv',index=False)
    return s

def run(root):
    root=Path(root);out=root/'outputs/tables';summary=device_shrinkage(out);strict=evidence_case(root)
    settings=dict(version='v5',new_experiments=0,
        device_selection='Alpha0/0.25/0.5/0.75/1; leave-one-hot-trajectory-out within training publication; macro trajectory MAPE; ties prefer smaller alpha',
        device_scope='Retrospective conditional response challenge; two same-group publications; measured heldout base; no source-harmonized calibrated transfer claim',
        strict_scope='Sensitivity reopening corrosion for four commercial-experience accepted memberships; unlocated evidence does not establish failure',
        strict_initial_accepted=int(strict.strict_locator_state.eq('model_qualified').sum()),strict_undetermined=int(strict.strict_locator_state.eq('undetermined').sum()),
        model_source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),status='PASS')
    (out/'core_existing_v5_quality_control.json').write_text(json.dumps(settings,indent=2),encoding='utf-8')
    print(summary.to_string(index=False));print(settings)

if __name__=='__main__':run(Path(__file__).resolve().parents[1])
