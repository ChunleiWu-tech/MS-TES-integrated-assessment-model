"""Cost-constrained, weighted evidence-certificate planning.

Elicited gate probabilities and perfect disclosed gates are conditional model
assumptions. Exact local rectangular DP is distinguished from the separable
portfolio scheduler and from a small-instance exact shared-budget oracle.
"""
from __future__ import annotations
from functools import lru_cache
from itertools import product
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
import numpy as np
import pandas as pd

_SPEC = importlib.util.spec_from_file_location("certificate_v4_v3_readonly", Path(__file__).with_name("evidence_certificate_model.py"))
v3 = importlib.util.module_from_spec(_SPEC)
sys.modules[_SPEC.name] = v3
_SPEC.loader.exec_module(v3)

UNIT = .5
COST_BUDGETS = (4., 8., 12.)
OBJECTIVES = (("pass1_fail1", 1., 1.), ("pass2_fail1", 2., 1.))
POLICIES = ("random", "cheapest", "greedy_cert", "point", "robust", "robust_continue")
PENALTY = .05
SEED = 361003


def integer_costs(costs):
    costs = np.asarray(costs, float)
    ticks = np.rint(costs / UNIT).astype(int)
    if np.any(ticks <= 0) or not np.allclose(ticks * UNIT, costs, atol=1e-12, rtol=0):
        raise ValueError("Costs must be positive exact half-unit multiples")
    return ticks


def budget_ticks(budget):
    ticks = int(round(float(budget) / UNIT))
    if ticks < 0 or abs(ticks * UNIT-float(budget)) > 1e-12:
        raise ValueError("Budget must be a nonnegative exact half-unit multiple")
    return ticks


def local_dp(conditionals, costs, max_ticks, predecessors=None, pass_reward=1., fail_reward=1., penalty=PENALTY):
    """Exact local robust value with hard remaining cost and optional stop.

    One failed gate resolves the AND rule; an all-pass history resolves it
    positively. Different certificate rewards are fixed before evaluation.
    A conditional scenario can vary at each history (rectangular ambiguity).
    """
    costs = np.asarray(costs, float); ticks = integer_costs(costs)
    k = len(costs); full = (1 << k)-1
    pred = np.zeros(k, int) if predecessors is None else np.asarray(predecessors, int)
    p = np.asarray(conditionals, float)
    if p.shape[1:] != (1 << k, k) or np.any((p < 0) | (p > 1)):
        raise ValueError("Conditional gate probability shape/range invalid")
    value = np.zeros((max_ticks+1, 1 << k)); value[:, full] = pass_reward
    scores = np.full((max_ticks+1, 1 << k, k), -np.inf)
    for b in range(max_ticks+1):
        for state in range(full):
            for a in range(k):
                if ticks[a] > b or state & (1 << a) or (state & pred[a]) != pred[a]: continue
                pa = p[:, state, a]
                scores[b, state, a] = np.min((1-pa)*fail_reward + pa*value[b-ticks[a], state | (1 << a)] - penalty*costs[a])
            value[b, state] = max(0., float(np.max(scores[b, state])))
    return value, scores


def prepare(case, max_ticks):
    vectors = np.array(list(product(*zip(case.low, case.high))) + [tuple(case.mid)], float)
    distributions = np.array([v3.joint_mass(vector, rho, anti)
                              for _, rho, anti in v3.FAMILY for vector in vectors])
    p, support = v3.conditional_table(distributions, case.k)
    # Point benchmark matches the central positive035 member of robust family.
    point_index = len(vectors) + len(vectors)-1
    scores = {}; values = {}
    for name, wp, wf in OBJECTIVES:
        for policy, table in (("point", p[[point_index]]), ("robust", p)):
            value, q = local_dp(table, case.costs, max_ticks, case.predecessors, wp, wf)
            scores[(name, policy)] = q; values[(name, policy)] = value
        greedy = np.full_like(scores[(name, "point")], -np.inf)
        for state in range((1 << case.k)-1):
            remaining = case.k-int(state).bit_count()
            for a in range(case.k):
                if state & (1 << a) or (state & case.predecessors[a]) != case.predecessors[a]: continue
                pa = p[point_index, state, a]
                net = (1-pa)*wf + pa*wp*(remaining == 1) - PENALTY*case.costs[a]
                greedy[integer_costs(case.costs)[a]:, state, a] = net/case.costs[a]
        scores[(name, "greedy_cert")] = greedy
    return {"p": p, "point_index": point_index, "scores": scores, "values": values}


def simulate(cases, fits, truth, budget, objective, seed=SEED, trace_sample=20):
    """Independent optimization from initial state for one hard cost budget.

    Every selected task has one candidate, one gate and one duty. Truth is read
    only after scores and selection. No cross-duty outcome transfer is assumed.
    """
    n, nc = truth.shape; rows = np.arange(n); B = budget_ticks(budget)
    ticks = [integer_costs(c.costs) for c in cases]
    output = {key: np.zeros((len(POLICIES), n), np.int16) for key in ("spent_ticks", "pass", "fail", "undetermined", "actions")}
    traces = []
    for pi, policy in enumerate(POLICIES):
        states = np.zeros((n, nc), np.int16); failed = np.zeros((n, nc), bool)
        spent = np.zeros(n, np.int16); actions = np.zeros(n, np.int16); stopped = np.zeros(n, bool)
        rng = np.random.default_rng(seed + pi*7919)
        for step in range(min(B, sum(c.k for c in cases))):
            remaining = B-spent; score_columns = []; tasks = []
            for ci, case in enumerate(cases):
                for a in range(case.k):
                    available = (~failed[:, ci] & ~stopped & ((states[:, ci] & (1 << a)) == 0)
                                 & ((states[:, ci] & case.predecessors[a]) == case.predecessors[a]) & (ticks[ci][a] <= remaining))
                    if policy == "random": score = rng.random(n)
                    elif policy == "cheapest": score = np.full(n, -case.costs[a], float)
                    else:
                        source_policy = "robust" if policy == "robust_continue" else policy
                        score = fits[ci]["scores"][(objective, source_policy)][remaining, states[:, ci], a].copy()
                    score[~available] = -np.inf
                    # Preserve exact stop eligibility on the unperturbed score.
                    score_columns.append(score); tasks.append((ci, a))
            raw_scores = np.asarray(score_columns).T
            if not tasks: break
            tie = np.array([cases[c].costs[a]*1e-10 + a*1e-12 + c*1e-14 for c, a in tasks])
            chosen = (raw_scores-tie).argmax(axis=1)
            best = raw_scores[rows, chosen]
            active = np.isfinite(best) & ~stopped
            if policy in ("point", "robust", "greedy_cert"): active &= best > 0.
            stopped |= ~active
            if not active.any(): break
            for ti, (ci, a) in enumerate(tasks):
                selected = active & (chosen == ti)
                if not selected.any(): continue
                outcome = (truth[:, ci] & (1 << a)) != 0
                for world in np.flatnonzero(selected[:trace_sample]):
                    traces.append({"world_id": int(world), "policy": policy, "action_index": int(actions[world]+1),
                                   "case_local_index": ci, "system_id": cases[ci].system_id,
                                   "gate": v3.GATES[int(cases[ci].required[a])], "state_before": int(states[world, ci]),
                                   "predecessor_mask": int(cases[ci].predecessors[a]), "remaining_ticks_before": int(remaining[world]),
                                   "task_cost_ticks": int(ticks[ci][a]), "observed_pass": bool(outcome[world])})
                states[selected & outcome, ci] |= 1 << a
                failed[selected & ~outcome, ci] = True
                spent[selected] += ticks[ci][a]; actions[selected] += 1
        passed = np.column_stack([states[:, ci] == (1 << c.k)-1 for ci, c in enumerate(cases)])
        output["spent_ticks"][pi] = spent; output["pass"][pi] = passed.sum(axis=1)
        output["fail"][pi] = failed.sum(axis=1); output["undetermined"][pi] = nc-passed.sum(axis=1)-failed.sum(axis=1)
        output["actions"][pi] = actions
        if np.max(spent, initial=0) > B: raise AssertionError("Hard cost budget exceeded")
    return output, traces


def portfolio_oracle(tables, costs, predecessors, max_ticks, pass_reward=1., fail_reward=1., penalty=PENALTY):
    """Exact shared-budget small-portfolio DP for rectangular conditionals.

    Assumes independent candidate processes, within-candidate dependence as
    supplied, and one task per candidate/gate. -1 means fail certificate; a
    full bit mask means pass certificate. Rewards are assigned on transition.
    """
    nc = len(tables); ks = [len(c) for c in costs]
    ticks = [integer_costs(c) for c in costs]
    full = [(1 << k)-1 for k in ks]
    local = [local_dp(p, c, max_ticks, pred, pass_reward, fail_reward, penalty)[1]
             for p, c, pred in zip(tables, costs, predecessors)]

    def legal(states, b):
        for ci, state in enumerate(states):
            if state < 0 or state == full[ci]: continue
            for a in range(ks[ci]):
                if ticks[ci][a] <= b and not state & (1 << a) and (state & predecessors[ci][a]) == predecessors[ci][a]:
                    yield ci, a

    @lru_cache(None)
    def exact(states, b):
        best = 0.
        for ci, a in legal(states, b):
            pa = tables[ci][:, states[ci], a]
            child = states[ci] | (1 << a)
            passed = list(states); passed[ci] = child
            failed = list(states); failed[ci] = -1
            pos = (pass_reward if child == full[ci] else 0.) + exact(tuple(passed), b-ticks[ci][a])
            neg = fail_reward + exact(tuple(failed), b-ticks[ci][a])
            q = float(np.min((1-pa)*neg + pa*pos - penalty*costs[ci][a]))
            best = max(best, q)
        return best

    @lru_cache(None)
    def separable(states, b):
        tasks = list(legal(states, b))
        if not tasks: return 0.
        ranked = sorted(tasks, key=lambda t: (-local[t[0]][b, states[t[0]], t[1]], costs[t[0]][t[1]], t[1], t[0]))
        ci, a = ranked[0]
        if local[ci][b, states[ci], a] <= 0: return 0.
        pa = tables[ci][:, states[ci], a]; child = states[ci] | (1 << a)
        passed = list(states); passed[ci] = child
        failed = list(states); failed[ci] = -1
        pos = (pass_reward if child == full[ci] else 0.) + separable(tuple(passed), b-ticks[ci][a])
        neg = fail_reward + separable(tuple(failed), b-ticks[ci][a])
        return float(np.min((1-pa)*neg + pa*pos - penalty*costs[ci][a]))
    start = (0,)*nc
    return {"exact_value": exact(start, max_ticks), "separable_value": separable(start, max_ticks),
            "exact_states_evaluated": exact.cache_info().currsize, "separable_states_evaluated": separable.cache_info().currsize}


def small_oracle_study():
    rng = np.random.default_rng(461003); rows = []
    for instance in range(12):
        nc = 2 + instance % 2; k = 2 + (instance//2) % 2
        tables = []; costs = []; preds = []
        for ci in range(nc):
            marginal = rng.uniform(.25, .8, k)
            masses = np.array([v3.joint_mass(marginal, rho) for rho in (0., .35)])
            tables.append(v3.conditional_table(masses, k)[0])
            costs.append(rng.choice(np.array([.5, 2., 2.5, 3.]), k))
            pred = np.zeros(k, int)
            if instance % 3 == 0: pred[-1] = 1
            preds.append(pred)
        for budget in COST_BUDGETS:
            for objective, wp, wf in OBJECTIVES:
                result = portfolio_oracle(tables, costs, preds, budget_ticks(budget), wp, wf)
                exact = result["exact_value"]; heuristic = result["separable_value"]
                rows.append({"instance": instance, "candidates": nc, "gates_per_candidate": k,
                             "objective": objective, "cost_budget": budget, "cost_penalty": PENALTY,
                             **result, "absolute_optimality_gap": exact-heuristic,
                             "relative_optimality_gap": (exact-heuristic)/exact if exact > 0 else 0.,
                             "scope": "small elicited instances; exact rectangular joint-candidate oracle, not empirical material outcomes"})
    return pd.DataFrame(rows)


def mc(values):
    values = np.asarray(values, float)
    mean = float(values.mean()); half = 1.959963984540054*float(values.std(ddof=1))/np.sqrt(len(values)) if len(values)>1 else 0.
    return mean, mean-half, mean+half


def run_study(root, n_draws=20000, process_names=None, trace_sample=20):
    root = Path(root); out = root/"outputs/tables"; raw = root/"outputs/certificate_budget_v4"
    out.mkdir(parents=True, exist_ok=True); raw.mkdir(parents=True, exist_ok=True)
    cases_all = v3.load_candidates(root); ids_active = [i for i,c in enumerate(cases_all) if c.k and not c.structurally_excluded]
    fits_all = {i: prepare(cases_all[i], budget_ticks(max(COST_BUDGETS))) for i in ids_active}
    duties = list(dict.fromkeys(c.scenario for c in cases_all)); summaries = []; comparisons = []; traces_all = []
    processes = [(si,s) for si,s in enumerate(v3.PROCESS_SCENARIOS) if process_names is None or s[0] in process_names]
    for si, process in processes:
        pooled = {(objective, budget): {key: np.zeros((len(POLICIES), n_draws), np.int16)
                  for key in ("spent_ticks","pass","fail","undetermined","actions")}
                  for objective, _, _ in OBJECTIVES for budget in COST_BUDGETS}
        for di, duty in enumerate(duties):
            ids = [i for i in ids_active if cases_all[i].scenario == duty]
            if not ids: continue
            cases = [cases_all[i] for i in ids]; fits = [fits_all[i] for i in ids]
            rng = np.random.default_rng(SEED+100003*si+1009*di)
            truth = np.column_stack([np.minimum(np.searchsorted(np.cumsum(v3.process_mass(c, process)), rng.random(n_draws)), (1 << c.k)-1) for c in cases])
            np.savez_compressed(raw/f"{process[0]}__{duty}__truth.npz", truth=truth, case_ids=np.array(ids), world_id=np.arange(n_draws))
            for objective, wp, wf in OBJECTIVES:
                for budget in COST_BUDGETS:
                    arrays, traces = simulate(cases, fits, truth, budget, objective, SEED+si*100003+di*1009, trace_sample)
                    for t in traces:
                        traces_all.append({"process_scenario": process[0], "duty": duty, "objective": objective, "cost_budget": budget, **t})
                    for key, arr in arrays.items(): pooled[(objective,budget)][key] += arr
                    np.savez_compressed(raw/f"{process[0]}__{duty}__{objective}__budget{budget:g}.npz", **arrays)
                    for pi, policy in enumerate(POLICIES):
                        metrics = {"burden": arrays["spent_ticks"][pi]*UNIT, "pass": arrays["pass"][pi], "fail": arrays["fail"][pi],
                                   "undetermined": arrays["undetermined"][pi], "actions": arrays["actions"][pi]}
                        metrics["weighted_utility"] = wp*metrics["pass"]+wf*metrics["fail"]-PENALTY*metrics["burden"]
                        row = {"process_scenario": process[0], "duty": duty, "objective": objective, "pass_reward": wp, "fail_reward": wf,
                               "cost_penalty": PENALTY, "policy": policy, "cost_budget_per_duty": budget,
                               "active_cases": len(ids), "worlds": n_draws, "actual_max_burden": float(metrics["burden"].max()),
                               "hard_budget_scope": "one stated duty; independently reoptimized initial policy at each cost cap"}
                        for key, values in metrics.items():
                            mean, lo, hi = mc(values); row.update({f"mean_{key}":mean,f"{key}_mc95_lower":lo,f"{key}_mc95_upper":hi})
                        summaries.append(row)
        for objective, wp, wf in OBJECTIVES:
            for budget in COST_BUDGETS:
                arrays = pooled[(objective,budget)]
                np.savez_compressed(raw/f"{process[0]}__pooled__{objective}__budget{budget:g}.npz", **arrays)
                utility = wp*arrays["pass"]+wf*arrays["fail"]-PENALTY*arrays["spent_ticks"]*UNIT
                for pi, policy in enumerate(POLICIES):
                    metrics = {"burden":arrays["spent_ticks"][pi]*UNIT, "pass":arrays["pass"][pi],"fail":arrays["fail"][pi],
                               "undetermined":arrays["undetermined"][pi],"actions":arrays["actions"][pi],"weighted_utility":utility[pi]}
                    row = {"process_scenario":process[0],"duty":"pooled","objective":objective,"pass_reward":wp,"fail_reward":wf,
                           "cost_penalty":PENALTY,"policy":policy,"cost_budget_per_duty":budget,"active_cases":len(ids_active),"worlds":n_draws,
                           "actual_max_burden":float(metrics["burden"].max()),"hard_budget_scope":f"sum of {len(duties)} separate duty budgets; maximum aggregate {len(duties)*budget:g}"}
                    for key, values in metrics.items():
                        mean, lo, hi = mc(values); row.update({f"mean_{key}":mean,f"{key}_mc95_lower":lo,f"{key}_mc95_upper":hi})
                    summaries.append(row)
                    for reference in ("random", "point", "robust_continue"):
                        ri = POLICIES.index(reference)
                        if pi == ri: continue
                        for metric, values in (("weighted_utility",utility[pi]-utility[ri]),("pass",arrays["pass"][pi].astype(float)-arrays["pass"][ri]),
                                              ("fail",arrays["fail"][pi].astype(float)-arrays["fail"][ri]),("burden",(arrays["spent_ticks"][pi]-arrays["spent_ticks"][ri])*UNIT)):
                            mean, lo, hi = mc(values)
                            comparisons.append({"process_scenario":process[0],"objective":objective,"cost_budget_per_duty":budget,"policy":policy,
                                                "reference":reference,"metric":metric,"paired_difference":mean,"mc95_lower":lo,"mc95_upper":hi,
                                                "worlds":n_draws,"interval_scope":"paired Monte Carlo sampling interval conditional on fixed process scenario"})
        print("V4 hard-budget study:",process[0],"completed",flush=True)
    summary = pd.DataFrame(summaries); paired = pd.DataFrame(comparisons)
    summary.to_csv(out/"core_certificate_v4_strategy_summary.csv",index=False)
    paired.to_csv(out/"core_certificate_v4_paired_comparisons.csv",index=False)
    pd.DataFrame(traces_all).to_csv(out/"core_certificate_v4_history_sample20.csv",index=False)
    oracle = small_oracle_study(); oracle.to_csv(out/"core_certificate_v4_small_portfolio_oracle.csv",index=False)
    status = {"status":"PASS","method":"hard-cost-budget-weighted-certificate-v4","worlds_per_process_per_duty":n_draws,
              "process_scenarios":[s[0] for _,s in processes],"policies":POLICIES,"objectives":OBJECTIVES,"cost_penalty":PENALTY,
              "cost_unit":UNIT,"budgets_per_duty":COST_BUDGETS,"duties":len(duties),"active_cases":len(ids_active),"seed":SEED,
              "model_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "hard_budget":"integer half-unit accounting; task is blocked when unaffordable; each budget starts from initial state",
              "raw_axes":["policy in declared order","world_id"],"raw_spent_ticks_unit":UNIT,
              "truth_provenance":"deterministically regenerated with unchanged V3 process scenarios, seed and case order; not laboratory outcomes",
              "pass_fail_semantics":"perfect disclosed model-gate outcomes; no experimental reliability guarantee",
              "probability_provenance":"elicited finite scenario family; not empirical gate success/error calibration",
              "optimality_scope":"exact local rectangular DP; separable scheduling is approximate; oracle comparisons cover only small declared instances",
              "dependence_scope":"within-candidate joint dependence; separate candidate/duty truths assumed independent; no automatic outcome transfer",
              "interval_scope":"95% Monte Carlo sampling intervals conditional on process scenario, not population confidence intervals",
              "history_scope":f"first {min(trace_sample,n_draws)} world IDs per policy/duty/scenario/objective/budget, not all world histories",
              "small_oracle_instances":len(oracle),"max_small_oracle_gap":float(oracle.absolute_optimality_gap.max()),
              "noisy_measurement_scope":"not evaluated; perfect gate observation assumption retained explicitly"}
    (raw/"STATUS.json").write_text(json.dumps(status,indent=2),encoding="utf-8")
    return status
