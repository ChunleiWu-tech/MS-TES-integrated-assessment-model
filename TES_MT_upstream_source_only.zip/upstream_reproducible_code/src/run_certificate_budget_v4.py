"""Run the separate hard-cost V4 study without changing the V3 pipeline."""
import argparse
from pathlib import Path
from certificate_budget_v4 import run_study

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--worlds",type=int,default=20000)
    parser.add_argument("--process",action="append",default=None)
    parser.add_argument("--trace-sample",type=int,default=20)
    args=parser.parse_args()
    run_study(args.root,args.worlds,args.process,args.trace_sample)
