from pathlib import Path
import argparse
import json
from evidence_certificate_model import run_study

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--draws", type=int, default=20000)
    parser.add_argument("--max-actions", type=int, default=6)
    parser.add_argument("--seed", type=int, default=361003)
    args = parser.parse_args()
    print(json.dumps(run_study(Path(__file__).resolve().parents[1], args.draws, args.max_actions, args.seed), indent=2))
    from summarize_certificate_contrasts import main as summarize_contrasts
    summarize_contrasts()
