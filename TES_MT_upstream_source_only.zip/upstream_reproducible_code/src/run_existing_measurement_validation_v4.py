from pathlib import Path
import json
from existing_measurement_validation_v4 import run

if __name__=='__main__':
    print(json.dumps(run(Path(__file__).resolve().parents[1]),ensure_ascii=False,indent=2))
