"""Existing measured evidence: identifiable checks, abstention and counterexamples.

No engineering index is a response label. No multi-gate outcomes are invented.
Device response factors below are a new, deliberately small diagnostic surrogate,
not a validation of the certificate planner or a fitted plant-performance model.
All original inputs remain unchanged. Independent experimental units are not
recovered from published endpoint means; publication clusters are explicit.
"""
from __future__ import annotations
import csv, hashlib, itertools, json, math, statistics
from pathlib import Path

# Each uncertainty value was verified in that publication's own methods.
# No value is transferred merely because the authors or apparatus overlap.
POWER_UNCERTAINTY_SUPPORT={
 'XIAO_2020':('10.1016/j.energy.2019.116593',.0236,'Section 2.3.3, accepted manuscript PDF p.16'),
 'XIAO_2023':('10.1016/j.enbenv.2021.08.003',.0236,'Section 2.3, printed p.77, published PDF p.4')}

def read_csv(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))

def write_csv(p,rows):
    if not rows:raise ValueError(f'Empty evidence table: {p.name}')
    keys=list(dict.fromkeys(k for r in rows for k in r))
    with p.open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)

def cp_integral(r,lo,hi):
    a,b=float(r['cp_a']),float(r['cp_b']);m=r['cp_model']
    if m=='constant':return a*(hi-lo)
    if m=='linear_C':return a*(hi-lo)+b*(hi*hi-lo*lo)/2
    if m in ('linear_K','linear_molar_K'):
        val=a*(hi-lo)+b*((hi+273.15)**2-(lo+273.15)**2)/2
        return val/float(r['cp_mw_g_mol']) if m=='linear_molar_K' else val
    raise ValueError('Unsupported Cp equation; no scalar fallback: '+m)

def corrosion_tables(raw):
    # Endpoint is deliberately absent from the condition key: penetration and
    # mass loss in one alloy exposure are correlated endpoints, not new runs.
    condition_fields=('doi','composition_json','basis','additive','additive_wt_pct',
                      'alloy','temperature_C','duration_h','atmosphere','flow_regime','purification')
    def key(r):
        comp=json.dumps(json.loads(r['composition_json']),sort_keys=True,separators=(',',':'))
        return tuple(comp if f=='composition_json' else r[f] for f in condition_fields)
    conditions=[];holdouts=[];ids={}
    for r in raw:
        k=key(r);ids.setdefault(k,f"CORR_CONDITION_{len(ids)+1:03}")
        factor={'mm/year':1000.,'um/year':1.}[r['reported_unit']]
        c=dict(r,reported_condition_id=ids[k],normalized_rate_um_per_year=float(r['reported_value'])*factor,
               normalized_spread_um_per_year=float(r['reported_spread'])*factor if r['reported_spread'] else '',
               reported_spread_sensitivity_low_um_per_year=(float(r['reported_value'])-float(r['reported_spread']))*factor if r['reported_spread'] else '',
               reported_spread_sensitivity_high_um_per_year=(float(r['reported_value'])+float(r['reported_spread']))*factor if r['reported_spread'] else '',
               spread_interpretation='Reported spread sensitivity only; no assigned SD or confidence level' if r['reported_spread'] else 'No numerical dispersion supplied',
               numerical_target_status='point_rate' if r['relation']=='point' else 'censored_upper_bound',
               experimental_unit_scope='Published endpoint means/bounds; coupon-level observations unavailable',
               rate_scope='Annualized exposure-specific rate; not annual exposure, lifetime or reliability probability')
        conditions.append(c)
        # Exact same conditions AND endpoint/relation, with a distinct DOI.
        candidates=[x for x in raw if x['doi']!=r['doi'] and key(x)[1:]==k[1:]
                    and x['endpoint']==r['endpoint'] and x['relation']==r['relation']=='point']
        other=[x for x in raw if x['doi']!=r['doi']]
        def mismatches(x):
            keys=key(x)
            return [f for i,f in enumerate(condition_fields) if i>0 and keys[i]!=k[i]]+(['endpoint'] if x['endpoint']!=r['endpoint'] else [])+(['relation_or_censored_target'] if x['relation']!=r['relation'] or r['relation']!='point' else [])
        nearest=min(other,key=lambda x:(len(mismatches(x)),x['observation_id']))
        holdouts.append(dict(observation_id=r['observation_id'],heldout_doi=r['doi'],
                reported_condition_id=ids[k],endpoint=r['endpoint'],relation=r['relation'],
                matched_other_publication_records=len(candidates),predicted_rate_um_per_year='',
                validation_status='abstain_no_exact_condition_source_support' if not candidates else 'eligible_reference_only_no_model_fitted',
                excluded_source_doi=r['doi'],matching_fields='Exact composition/basis, additive, alloy, T, exposure, atmosphere, flow, purification, endpoint',
                nearest_other_source_observation=nearest['observation_id'],nearest_other_source_doi=nearest['doi'],
                transfer_rejection_reasons=';'.join(mismatches(nearest)),
                uncertainty_scope='No model interval generated from credibility indices or bound-only labels'))
    by={r['observation_id']:r for r in conditions};counter=[]
    for alloy in ('304','316L','310S','347H'):
        a=by[f'H26_KNC500_{alloy}'];b=by[f'H26_KNC700_{alloy}']
        counter.append(dict(counterexample_id='CORR_TEMP_'+alloy,kind='temperature_transfer_counterexample',
            reference_observation=a['observation_id'],challenge_observation=b['observation_id'],
            reference_value=float(a['normalized_rate_um_per_year']),challenge_value=float(b['normalized_rate_um_per_year']),
            unit='um/year',challenge_over_reference=float(b['normalized_rate_um_per_year'])/float(a['normalized_rate_um_per_year']),
            source_dois=a['doi'],control_scope='Same salt, alloy, 480 h exposure, air, static and reported purification; 500 versus 700 C',
            conclusion='Condition-blind constant-rate transfer fails; one publication counterexample, not independent predictive validation',
            uncertainty_scope='Published means, n=3 per endpoint; individual repeats and dispersion unavailable'))
    for label in ('310','800','C276'):
        a=by[f'D18_{label}_M'];b=by[f'D18_{label}_D']
        counter.append(dict(counterexample_id='CORR_ENDPOINT_'+label,kind='endpoint_semantics_counterexample',
            reference_observation=a['observation_id'],challenge_observation=b['observation_id'],
            reference_value=float(a['normalized_rate_um_per_year']),challenge_value=float(b['normalized_rate_um_per_year']),
            unit='um/year',challenge_over_reference=float(b['normalized_rate_um_per_year'])/float(a['normalized_rate_um_per_year']),
            source_dois=a['doi'],control_scope='Same reported alloy/exposure condition; mass-loss-equivalent and penetration-depth rates',
            conclusion='Different endpoints cannot be pooled or counted as independent exposures',uncertainty_scope='No endpoint covariance or raw replicates'))
    for label in ('310','800'):
        a=by[f'D18_{label}_M'];b=by[f'G22_{label}_500']
        counter.append(dict(counterexample_id='CORR_SOURCE_TRANSFER_'+label,kind='confounded_source_transfer_challenge',
            reference_observation=a['observation_id'],challenge_observation=b['observation_id'],
            reference_value=float(a['normalized_rate_um_per_year']),challenge_value=float(b['normalized_rate_um_per_year']),
            unit='um/year',challenge_over_reference=float(b['normalized_rate_um_per_year'])/float(a['normalized_rate_um_per_year']),
            reference_over_challenge=float(a['normalized_rate_um_per_year'])/float(b['normalized_rate_um_per_year']),
            source_dois=a['doi']+';'+b['doi'],control_scope='Same named alloy, 700 C and 500 h; composition, purification, Mg inhibitor and gas purity differ',
            conclusion='Salt-family/alloy/T/exposure-only transfer overpredicts; this contrast cannot isolate a causal purification effect',
            uncertainty_scope='No harmonized replicate dispersion; no causal confidence interval'))
    return conditions,holdouts,counter

def device_points(data):
    rows=[];order=data['material_order']
    for s in data['studies']:
        supported_doi,u,unc_locator=POWER_UNCERTAINTY_SUPPORT[s['source_id']]
        if s['doi']!=supported_doi or float(s['reported_power_uncertainty_fraction'])!=u:
            raise ValueError('Power uncertainty/source applicability mismatch: '+s['source_id'])
        for j,hot in enumerate(s['hot_C']):
            for m,material in enumerate(order):
                group=f"{s['source_id']}:{material}:hot{hot}"
                common=dict(source_id=s['source_id'],doi=s['doi'],chemistry=s['chemistry'],material=material,hot_C=hot,
                    thermal_trajectory_group=group,reported_uncertainty_fraction=float(s['reported_power_uncertainty_fraction']),
                    uncertainty_verified_in_source=True,uncertainty_source_locator=unc_locator,uncertainty_primary_url=s['url'],
                    uncertainty_scope=s['uncertainty_interpretation'],boundary=s['boundary'],locator=s['locator'],source_conflict=s['source_conflict'],
                    target_semantics='Published volumetric mean power derived from apparent enthalpy and duration; not instantaneous power capacity')
                rows.append(dict(common,observation_id=group+':charge',direction='charge',cold_C=s['charge_initial_C'],
                            power_kW_m3=s['charge_power'][j][m]))
                for k,cold in enumerate(s['cold_C']):
                    rows.append(dict(common,observation_id=group+f':discharge{cold}',direction='discharge',cold_C=cold,
                                power_kW_m3=s['discharge_power'][k][j][m]))
    return rows

def device_transfer_tables(points,data):
    base={(r['source_id'],r['direction'],r['hot_C'],r['cold_C']):r for r in points if r['material']=='base'}
    composite=[r for r in points if r['material']!='base'];predictions=[];summaries=[];counter=[]
    def model(train,test,split,mid):
        # Training uses only training composite endpoints and their paired base.
        ratios=[r['power_kW_m3']/base[(r['source_id'],r['direction'],r['hot_C'],r['cold_C'])]['power_kW_m3'] for r in train]
        factor=statistics.median(ratios);u=float(train[0]['reported_uncertainty_fraction'])
        factor_lo=statistics.median(x*(1-u)/(1+u) for x in ratios);factor_hi=statistics.median(x*(1+u)/(1-u) for x in ratios)
        for r in test:
            b=base[(r['source_id'],r['direction'],r['hot_C'],r['cold_C'])];ub=float(b['reported_uncertainty_fraction']);ut=float(r['reported_uncertainty_fraction'])
            predicted=factor*b['power_kW_m3'];obs=r['power_kW_m3'];lo=factor_lo*b['power_kW_m3']*(1-ub);hi=factor_hi*b['power_kW_m3']*(1+ub)
            predictions.append(dict(model_id=mid,split_type=split,training_source_doi=train[0]['doi'],heldout_source_doi=r['doi'],
                training_observation_ids=json.dumps([t['observation_id'] for t in train]),heldout_observation_id=r['observation_id'],
                material=r['material'],direction=r['direction'],heldout_hot_C=r['hot_C'],heldout_cold_C=r['cold_C'],
                training_hot_min_C=min(x['hot_C'] for x in train),training_hot_max_C=max(x['hot_C'] for x in train),
                training_cold_min_C=min(x['cold_C'] for x in train),training_cold_max_C=max(x['cold_C'] for x in train),
                training_target_endpoints=len(train),training_publications=len({x['doi'] for x in train}),
                fitted_median_response_factor=factor,response_factor_sensitivity_low=factor_lo,response_factor_sensitivity_high=factor_hi,
                heldout_base_control_kW_m3=b['power_kW_m3'],observed_composite_kW_m3=obs,predicted_composite_kW_m3=predicted,
                model_minus_observed_percent=100*(predicted/obs-1),identity_transfer_error_percent=100*(b['power_kW_m3']/obs-1),
                predicted_sensitivity_low_kW_m3=lo,predicted_sensitivity_high_kW_m3=hi,
                observed_sensitivity_low_kW_m3=obs*(1-ut),observed_sensitivity_high_kW_m3=obs*(1+ut),
                deterministic_envelopes_overlap=lo<=obs*(1+ut) and hi>=obs*(1-ut),
                supported_prediction_transfer_allowed=False,diagnostic_extrapolation_retained=True,
                transfer_rejection_reasons='heldout chemistry differs;hot temperature outside training domain;cold endpoint/ambient boundary not harmonized' if split=='leave_publication_out' else 'heldout hot temperature outside training domain;shared-publication evidence is not a source-independent validation',
                thermal_trajectory_group=r['thermal_trajectory_group'],
                interpretation='Conditional relative-response challenge using measured heldout base control; heldout composite target never fitted',
                domain_scope='Cross-chemistry and temperature extrapolation; same research group/architecture' if split=='leave_publication_out' else 'Within-publication high-temperature extrapolation; no source independence',
                uncertainty_scope='Published power uncertainties propagated as deterministic sensitivity scenarios; not predictive confidence intervals'))
        subset=[p for p in predictions if p['model_id']==mid]
        summaries.append(dict(model_id=mid,split_type=split,material=test[0]['material'],direction=test[0]['direction'],
            training_doi=train[0]['doi'],heldout_doi=test[0]['doi'],fitted_response_factor=factor,
            heldout_dependent_endpoints=len(test),heldout_thermal_trajectory_groups=len({r['thermal_trajectory_group'] for r in test}),
            source_disjoint=split=='leave_publication_out',hot_domain_overlap=False,
            mean_signed_error_percent=statistics.mean(p['model_minus_observed_percent'] for p in subset),
            mean_absolute_error_percent=statistics.mean(abs(p['model_minus_observed_percent']) for p in subset),
            max_absolute_error_percent=max(abs(p['model_minus_observed_percent']) for p in subset),
            identity_mean_absolute_error_percent=statistics.mean(abs(p['identity_transfer_error_percent']) for p in subset),
            deterministic_envelope_overlap_count=sum(p['deterministic_envelopes_overlap'] for p in subset),
            statistical_interval_available=False,independent_laboratory_validation=False,
            model_role='New diagnostic ratio surrogate, not certificate planner or plant simulation'))
    for source in [s['source_id'] for s in data['studies']]:
        for material in data['material_order'][1:]:
            for direction in ('charge','discharge'):
                train=[r for r in composite if r['source_id']!=source and r['material']==material and r['direction']==direction]
                test=[r for r in composite if r['source_id']==source and r['material']==material and r['direction']==direction]
                model(train,test,'leave_publication_out',f'LOPO:{source}:{material}:{direction}')
                hot=max(r['hot_C'] for r in test)
                train=[r for r in test if r['hot_C']<hot];heldout=[r for r in test if r['hot_C']==hot]
                model(train,heldout,'hold_high_temperature_domain',f'TEMP:{source}:{material}:{direction}')
    for r in composite:
        if r['material']!='alumina_copper_foam' or r['direction']!='discharge':continue
        b=base[(r['source_id'],r['direction'],r['hot_C'],r['cold_C'])];charge=next(x for x in composite if x['source_id']==r['source_id'] and x['material']==r['material'] and x['direction']=='charge' and x['hot_C']==r['hot_C'])
        bc=base[(r['source_id'],'charge',r['hot_C'],charge['cold_C'])];rc=charge['power_kW_m3']/bc['power_kW_m3'];rd=r['power_kW_m3']/b['power_kW_m3'];u=r['reported_uncertainty_fraction']
        counter.append(dict(counterexample_id='DEVICE_DIRECTION:'+r['observation_id'],kind='direction_transfer_counterexample',
             reference_observation=charge['observation_id'],challenge_observation=r['observation_id'],
             reference_value=rc,challenge_value=rd,unit='response ratio versus same-paper base control',source_dois=r['doi'],
             charge_response_low=rc*(1-u)/(1+u),discharge_response_high=rd*(1+u)/(1-u),
             charge_response_high=rc*(1+u)/(1-u),discharge_response_low=rd*(1-u)/(1+u),
             charge_sensitivity_class='increase' if rc*(1-u)/(1+u)>1 else 'decrease' if rc*(1+u)/(1-u)<1 else 'crosses_one',
             discharge_sensitivity_class='increase' if rd*(1-u)/(1+u)>1 else 'decrease' if rd*(1+u)/(1-u)<1 else 'crosses_one',
             control_scope='Same reported material/hot endpoint; different charge and natural-air discharge boundaries',
             conclusion='Charge enhancement does not imply discharge enhancement; correlated endpoints, not independent experiments',
             uncertainty_scope='Deterministic reported-power sensitivity; shared controls and thermal trajectories'))
    return predictions,summaries,counter

def enthalpy_tables(raw,meta,registry):
    cp=next(r for r in registry if r['system_id']==meta['system_id']);lo,hi=float(cp['cp_Tmin_C']),float(cp['cp_Tmax_C'])
    points=[]
    for i,r in enumerate(raw):
        t=float(r['temperature_K'])-273.15;eligible=r['reported_phase']=='liquid' and lo<=t<=hi
        points.append(dict(r,observation_id=f'WU2025:{i:02}',temperature_C=t,source_doi=meta['doi'],
            eligible_shared_liquid_domain=eligible,eligibility_reason='inside_registered_liquid_Cp_domain' if eligible else 'solid_or_outside_registered_Cp_domain',
            measured_replicate_n=3,raw_replicates_available=False,
            independent_unit_scope='One source and composition; published temperature-point means, dependence unknown'))
    eligible=[r for r in points if r['eligible_shared_liquid_domain']];rows=[]
    for a,b in itertools.combinations(eligible,2):
        low,high=a['temperature_C'],b['temperature_C'];observed=float(b['enthalpy_from_298_15K_J_g'])-float(a['enthalpy_from_298_15K_J_g']);model=cp_integral(cp,low,high)
        repeat=float(meta['reported_repeatability_fraction'])*(abs(float(a['enthalpy_from_298_15K_J_g']))+abs(float(b['enthalpy_from_298_15K_J_g'])))
        scale=float(meta['calibration_relative_deviation'])*observed
        rows.append(dict(low_observation_id=a['observation_id'],high_observation_id=b['observation_id'],low_C=low,high_C=high,
            observed_enthalpy_kJ_kg=observed,predicted_enthalpy_kJ_kg=model,model_minus_observed_percent=100*(model/observed-1),
            model_mean_cp_J_gK=model/(high-low),observed_mean_cp_J_gK=observed/(high-low),
            mass_for_1kWh_predicted_kg=3600/model,mass_for_1kWh_observed_kg=3600/observed,
            fixed_energy_mass_error_percent=100*(observed/model-1),primary_full_interval=a is eligible[0] and b is eligible[-1],
            shared_scale_sensitivity_kJ_kg=scale,opposite_endpoint_deviation_sensitivity_sum_kJ_kg=repeat,
            observed_sensitivity_low_kJ_kg=observed-scale-repeat,observed_sensitivity_high_kJ_kg=observed+scale+repeat,
            registered_cp_sensitivity_fraction=float(cp['cp_rel_unc']),registered_cp_model=cp['cp_model'],registered_cp_a=cp['cp_a'],registered_cp_b=cp['cp_b'],
            model_source_ids=cp['source_ids'],heldout_source_doi=meta['doi'],model_fitted_to_challenge=False,
            uncertainty_scope='Disclosed deterministic calibration/repeatability scenarios; endpoint correlations and sample-specific combined uncertainty unavailable',
            independence_scope='One independent publication/composition challenge; endpoint-pair intervals share observations',
            source_independence_evidence='Metadata records non-use in baseline construction; DOI absent from equation source IDs; retrospective challenge, not prospective blinding'))
    return points,rows

def run(root:Path):
    inp=root/'data/input';out=root/'outputs/tables';out.mkdir(parents=True,exist_ok=True)
    files=['engineering_corrosion_observations.csv','application_experiments.json','external_wu2025_enthalpy.csv','external_wu2025_metadata.json','core_candidate_property_registry.csv']
    hashes={n:hashlib.sha256((inp/n).read_bytes()).hexdigest() for n in files}
    corrosion=read_csv(inp/files[0]);data=json.loads((inp/files[1]).read_text(encoding='utf-8'));meta=json.loads((inp/files[3]).read_text(encoding='utf-8'))
    corr,holdouts,counter=corrosion_tables(corrosion);powers=device_points(data);preds,summ,device_counter=device_transfer_tables(powers,data)
    epoints,eintervals=enthalpy_tables(read_csv(inp/files[2]),meta,read_csv(inp/files[4]));counter+=device_counter
    inventory=[dict(domain='corrosion',published_endpoint_records=len(corr),publication_clusters=len({r['doi'] for r in corr}),
        reported_condition_groups=len({r['reported_condition_id'] for r in corr}),units='um/year or mm/year normalized to um/year',
        identifiable_validation='Condition-aware source-holdout abstention and real-rate counterexamples',
        source_disjoint_supported_targets=sum(r['matched_other_publication_records']>0 for r in holdouts),
        limitations='No harmonized cross-publication same-condition point labels; no lifetime or joint-qualification target; bound-only values remain censored'),
       dict(domain='device_mean_power',published_endpoint_records=len(powers),publication_clusters=2,
        reported_condition_groups=len({r['thermal_trajectory_group'] for r in powers}),units='kW/m3 published volumetric mean power',
        identifiable_validation='Conditional held-publication response-factor extrapolation and held-hot-domain challenges',
        source_disjoint_supported_targets=0,conditional_source_disjoint_challenge_endpoints=sum(r['split_type']=='leave_publication_out' for r in preds),
        limitations='Two publications from same group/architecture; temperature/chemistry shift; measured heldout base control required; correlated endpoints and derived mean powers'),
       dict(domain='solar_salt_enthalpy',published_endpoint_records=len(epoints),publication_clusters=1,reported_condition_groups=1,
        units='J/g enthalpy differences equal kJ/kg; temperatures converted K to C',
        identifiable_validation='Previously unused publication versus independently specified same-composition Cp equation; no refit',
        source_disjoint_supported_targets=1,eligible_temperature_means=sum(r['eligible_shared_liquid_domain'] for r in epoints),
        limitations='One composition/source; all paired intervals dependent; no density, device, ranking or joint engineering validation'),
       dict(domain='joint_engineering_qualification',published_endpoint_records=0,publication_clusters=0,reported_condition_groups=0,
        units='No true joint observed label',identifiable_validation='Unavailable',source_disjoint_supported_targets=0,
        limitations='No complete same-material/duty multi-gate ground truth. No synthetic labels, availability proxies or credibility scores introduced as observations')]
    frames={'evidence_inventory':inventory,'corrosion_conditions':corr,'corrosion_source_holdout':holdouts,'counterexamples':counter,
            'device_observations':powers,'device_transfer_predictions':preds,'device_transfer_summary':summ,
            'enthalpy_observations':epoints,'enthalpy_intervals':eintervals}
    manifest=[dict(input_file=n,sha256=h,mutation_allowed=False) for n,h in hashes.items()]
    frames['input_receipt']=manifest
    for name,rows in frames.items():write_csv(out/f'core_existing_v4_{name}.csv',rows)
    if hashes!={n:hashlib.sha256((inp/n).read_bytes()).hexdigest() for n in files}:raise RuntimeError('Inputs changed during validation construction')
    return {'tables':{k:len(v) for k,v in frames.items()},'inputs_unchanged':True,'empirical_joint_qualification_labels':0,
        'primary_enthalpy':next(r for r in eintervals if r['primary_full_interval']),
        'interpretation':'Source-grain evidence audit and scoped real-data challenges; no empirical validation of the certificate policy, probabilistic qualification or plant lifetime'}
