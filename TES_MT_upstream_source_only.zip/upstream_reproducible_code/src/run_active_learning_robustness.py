from __future__ import annotations

"""Run the requested sensitivity, ablation, cross-duty and baseline analyses.

The robustness suite intentionally writes each case to its own directory and
does not overwrite the canonical active-learning result.  Traces are disabled by
default because the main 20,000-draw trace is already the reproducibility record;
all case-level aggregate tables and run metadata are retained.
"""

import argparse
import json
import os
import sys
from pathlib import Path

import pandas as pd

SRC = Path(__file__).resolve().parent
ROOT = SRC.parent
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))
from active_learning_engine import STRATEGIES, run


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Active-learning robustness suite")
    parser.add_argument("--draws", type=int, default=int(os.environ.get("TES_ROBUSTNESS_MC", "1000")))
    parser.add_argument("--seed", type=int, default=861127)
    parser.add_argument("--max-actions", type=int, default=6)
    parser.add_argument("--output-dir", type=Path, default=None, help="Root directory for case outputs")
    parser.add_argument("--only", nargs="*", default=None, help="Optional case labels")
    return parser.parse_args()


def cases() -> list[dict]:
    all_strategies = tuple(STRATEGIES)
    return [
        {"label": "baseline", "kind": "reference", "strategies": all_strategies},
        {"label": "budget_six_action_horizon", "kind": "budget", "max_actions": 6, "strategies": all_strategies},
        {"label": "cost_multiplier_075", "kind": "cost", "action_cost_multiplier": 0.75, "strategies": all_strategies},
        {"label": "cost_multiplier_125", "kind": "cost", "action_cost_multiplier": 1.25, "strategies": all_strategies},
        {
            "label": "cost_action_specific",
            "kind": "cost",
            "action_cost_override": {"a3_corrosion_test": 6.0, "a7_data_completeness": 1.0},
            "strategies": all_strategies,
        },
        {"label": "prior_strength_06", "kind": "prior", "prior_strength": 6.0, "strategies": all_strategies},
        {"label": "prior_strength_24", "kind": "prior", "prior_strength": 24.0, "strategies": all_strategies},
        {"label": "prior_shift_minus_010", "kind": "prior", "prior_shift": -0.10, "strategies": all_strategies},
        {"label": "prior_shift_plus_010", "kind": "prior", "prior_shift": 0.10, "strategies": all_strategies},
        {
            "label": "objective_selection_event",
            "kind": "objective",
            "objective": "selection_event_reduction",
            "strategies": all_strategies,
        },
        {
            "label": "objective_information_per_cost",
            "kind": "objective",
            "objective": "information_per_cost",
            "strategies": all_strategies,
        },
        {"label": "ablation_no_eig", "kind": "ablation", "strategies": ("random", "greedy_unlock", "ei")},
        {"label": "ablation_no_ei", "kind": "ablation", "strategies": ("random", "greedy_unlock", "eig")},
        {
            "label": "ablation_no_posterior_update",
            "kind": "ablation",
            "strategies": ("random", "greedy_unlock", "eig", "ei"),
            "posterior_update": False,
        },
        {
            "label": "cross_duty_coal_flexibility",
            "kind": "cross_duty",
            "scenarios": {"coal_flexibility_storage"},
            "strategies": all_strategies,
        },
        {
            "label": "cross_duty_csp",
            "kind": "cross_duty",
            "scenarios": {"csp_sensible_storage"},
            "strategies": all_strategies,
        },
        {
            "label": "cross_duty_industrial_heat",
            "kind": "cross_duty",
            "scenarios": {"industrial_medium_heat"},
            "strategies": all_strategies,
        },
        {
            "label": "uniform_budget_baseline",
            "kind": "baseline",
            "strategies": ("random", "greedy_unlock", "uniform_budget"),
        },
    ]


def main() -> None:
    args = parse_args()
    out_root = args.output_dir or (ROOT / "outputs" / "robustness")
    out_root.mkdir(parents=True, exist_ok=True)
    selected = set(args.only) if args.only else None
    records: list[pd.DataFrame] = []
    tests: list[pd.DataFrame] = []
    run_status: list[dict] = []
    for case_index, case in enumerate(cases()):
        if selected and case["label"] not in selected:
            continue
        label = case["label"]
        case_root = out_root / label
        table_dir = case_root / "tables"
        qc_dir = case_root / "qc"
        kwargs = {key: value for key, value in case.items() if key not in {"label", "kind", "strategies"}}
        status = run(
            ROOT,
            n_draws=args.draws,
            seed=args.seed + 1009 * case_index,
            max_actions=int(kwargs.pop("max_actions", args.max_actions)),
            output_dir=table_dir,
            qc_dir=qc_dir,
            strategies=tuple(case["strategies"]),
            write_trace=False,
            **kwargs,
        )
        summary_path = table_dir / "active_learning_strategy_summary.csv"
        tests_path = table_dir / "active_learning_statistical_tests.csv"
        summary = pd.read_csv(summary_path)
        summary.insert(0, "case", label)
        summary.insert(1, "case_type", case["kind"])
        records.append(summary)
        if tests_path.exists():
            test = pd.read_csv(tests_path)
            if not test.empty:
                test.insert(0, "case", label)
                test.insert(1, "case_type", case["kind"])
                tests.append(test)
        run_status.append({"case": label, "case_type": case["kind"], "status": status})

    if not records:
        raise SystemExit("No robustness cases selected")
    combined = pd.concat(records, ignore_index=True)
    combined.to_csv(out_root / "active_learning_robustness_summary.csv", index=False)
    if tests:
        pd.concat(tests, ignore_index=True).to_csv(out_root / "active_learning_robustness_tests.csv", index=False)
    metadata = {
        "status": "PASS",
        "draws_per_case": args.draws,
        "seed": args.seed,
        "max_actions": args.max_actions,
        "cases_completed": len(run_status),
        "cases": run_status,
    }
    (out_root / "ACTIVE_LEARNING_ROBUSTNESS_STATUS.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps({"status": "PASS", "cases_completed": len(run_status), "draws_per_case": args.draws}, indent=2))


if __name__ == "__main__":
    main()



