"""Finite evidence assessment with explicit dependence and abstention.

The probabilities are elicited planning assumptions, never experimental labels.
Exact backward induction applies to one candidate and a rectangular conditional
scenario family. Scheduling across candidates is a separable heuristic.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from itertools import product
from pathlib import Path
import json
import numpy as np
import pandas as pd
from numpy.polynomial.hermite import hermgauss
from scipy.special import ndtr, ndtri

GATES = ("thermal_cp", "thermal_density", "corrosion", "cycling_phase",
         "containment", "literature_replication", "data_completeness")
COSTS = np.array([2., 2., 3., 2., 2.5, 2., .5])
ENGINEERING = {
    "corrosion": ("corrosion_compatibility", "gap_corrosion"),
    "cycling_phase": ("cycling_phase_stability", "gap_cycling_phase"),
    "containment": ("containment_validation", "gap_containment"),
    "literature_replication": ("literature_replication", "gap_literature_validation"),
    "data_completeness": ("data_completeness", "gap_data_completeness"),
}
# Existing evidence-action graph: containment follows corrosion; independent
# replication follows data completion. Already accepted baseline gates satisfy
# their prerequisite. Atomic cycling has no universal predecessor.
PREREQUISITES = {4: (2,), 5: (6,)}
FAMILY = (("independent", 0., False), ("positive_035", .35, False),
          ("positive_070", .70, False), ("antagonistic_035", .35, True))
POLICIES = ("random", "ei_proxy", "entropy", "greedy_resolution", "rcp_point",
            "greedy_stop", "rcp_independent", "rcp_cost0", "rcp_l025", "rcp", "rcp_continue", "rcp_l100")
LAMBDAS = {"rcp_point": .05, "rcp_independent": .05, "rcp_cost0": 0.,
           "rcp_l025": .025, "rcp": .05, "rcp_continue": .05, "rcp_l100": .10}


def atoms(k: int) -> np.ndarray:
    return ((np.arange(2**k)[:, None] >> np.arange(k)) & 1).astype(bool)


def joint_mass(p, rho=0., antagonistic=False, quadrature=96):
    """One-factor Gaussian gate model; alternating loadings admit antagonism.

    Correlation = l l' + diag(1-l^2), hence positive semidefinite. Numerical
    integration is deterministic; mass and marginal errors are checked.
    """
    p = np.asarray(p, float); truth = atoms(len(p))
    if rho == 0:
        mass = np.prod(np.where(truth, p, 1-p), axis=1)
    else:
        z, w = hermgauss(quadrature); z = np.sqrt(2)*z
        signs = (-1.)**np.arange(len(p)) if antagonistic else np.ones(len(p))
        loading = np.sqrt(rho)*signs
        conditional = ndtr((ndtri(p)[None, :]-z[:, None]*loading)/np.sqrt(1-rho))
        mass = np.prod(np.where(truth[None, :, :], conditional[:, None, :],
                                1-conditional[:, None, :]), axis=2).T @ (w/np.sqrt(np.pi))
    mass = np.maximum(mass, 0.); mass /= mass.sum()
    return mass


def frechet_bounds(low, high):
    """Sharp conjunction bounds given marginal bounds, no dependence choice."""
    low = np.asarray(low, float); high = np.asarray(high, float)
    if not len(low): return 1., 1.
    return float(max(0., low.sum()-(len(low)-1))), float(np.min(high))


def conditional_table(masses: np.ndarray, k: int):
    world = np.arange(2**k); states = np.arange(2**k)
    compatible = ((world[None, :] & states[:, None]) == states[:, None]).astype(float)
    support = masses @ compatible.T
    p = np.empty((len(masses), 2**k, k))
    for a in range(k):
        p[:, :, a] = support[:, states | (1 << a)]/np.maximum(support, 1e-300)
    # Zero-support histories cannot manufacture experimental certificates.
    if np.any(support <= 0):
        raise ValueError("Numerical joint support vanished; increase integration accuracy")
    return np.clip(p, 0., 1.), support


def bellman(p: np.ndarray, costs, budget: int, cost_penalty: float, predecessors=None):
    """Exact local max-min DP for the rectangular hull of given conditionals.

    Certificate reward is one for observed all-pass or any-fail, zero for
    undetermined. Stop is available. Burden is ordinal, not monetary cost.
    """
    costs = np.asarray(costs, float); k = len(costs); full = 2**k-1
    predecessors = np.zeros(k, int) if predecessors is None else np.asarray(predecessors, int)
    value = np.zeros((budget+1, 2**k)); value[:, full] = 1.
    q = np.full((budget+1, 2**k, k), -np.inf)
    for b in range(1, budget+1):
        for s in range(full):
            for a in range(k):
                if s & (1 << a) or (s & predecessors[a]) != predecessors[a]: continue
                prob = p[:, s, a]
                q[b, s, a] = np.min((1-prob)+prob*value[b-1, s | (1 << a)]
                                    -cost_penalty*costs[a])
            value[b, s] = max(0., np.max(q[b, s]))
    return value, q


@dataclass
class Candidate:
    scenario: str
    scenario_label: str
    system_id: str
    display: str
    required: np.ndarray
    low: np.ndarray
    mid: np.ndarray
    high: np.ndarray
    structurally_excluded: bool = False

    @property
    def k(self): return len(self.required)

    @property
    def costs(self): return COSTS[self.required]

    @property
    def predecessors(self):
        local = {int(g): a for a, g in enumerate(self.required)}
        return np.asarray([sum(1 << local[g] for g in PREREQUISITES.get(int(gate), ()) if g in local)
                           for gate in self.required], int)


def _number(x):
    try: return float(x)
    except (ValueError, TypeError): return np.nan


def _coverage(row, prefix, lo, hi):
    a = _number(row.get(prefix+"_Tmin_C")); b = _number(row.get(prefix+"_Tmax_C"))
    if not np.isfinite(a+b) or hi <= lo: return 0.
    return float(np.clip(max(0., min(b, hi)-max(a, lo))/(hi-lo), 0., 1.))


def load_candidates(root: Path):
    """Use current evidence rules and duty conditions without ML imputation."""
    inp = root/"data/input"; cfg = root/"config"
    membership = pd.read_csv(inp/"core_candidate_scenario_membership.csv")
    atomic = pd.read_csv(inp/"core_atomic_engineering_credibility_registry.csv")
    props = pd.read_csv(inp/"core_candidate_property_registry.csv")
    services = pd.read_csv(cfg/"core_system_benchmarks.csv")
    all_rows = membership.merge(atomic, on=["scenario", "scenario_label", "system_id", "display_system"],
                                validate="one_to_one").merge(props, on=["system_id", "display_system"], validate="many_to_one")
    cases = []
    for _, row in all_rows.iterrows():
        duty = services.loc[services.scenario.eq(row.scenario)].iloc[0]
        known = np.ones(7, bool); low = np.zeros(7); mid = np.zeros(7); high = np.zeros(7)
        excluded = bool(row.nonclosable_direct_risk)
        if str(duty.service_mode) == "sensible":
            lo, hi = float(duty.fixed_Tcold_C), float(duty.fixed_Thot_C)
            for g, prefix in [(0, "cp"), (1, "rho")]:
                coverage = _coverage(row, prefix, lo, hi); known[g] = coverage >= .999
                mode = .25+.65*coverage
                low[g], mid[g], high[g] = max(.03, mode-.2), mode, min(.99, mode+.2)
            tm, tmax = _number(row.Tm_C), _number(row.Tmax_practical_C)
            excluded |= (np.isfinite(tm) and tm > lo) or (np.isfinite(tmax) and tmax < hi)
        else:
            tm = _number(row.Tm_C)
            excluded |= np.isfinite(tm) and not float(duty.phase_target_min_C) <= tm <= float(duty.phase_target_max_C)
        for g in range(2, 7):
            prefix, gap = ENGINEERING[GATES[g]]
            known[g] = not bool(row[gap])
            low[g], mid[g], high[g] = [float(row[prefix+"_"+s]) for s in ["low", "mid", "high"]]
        required = np.flatnonzero(~known)
        cases.append(Candidate(str(row.scenario), str(row.scenario_label), str(row.system_id),
                               str(row.display_system), required, low[required],
                               ((low+mid+high)/3)[required], high[required], bool(excluded)))
    return cases


def prepare_candidate(case: Candidate, max_actions=6):
    k = case.k
    if not k or case.structurally_excluded: return None
    vertices = np.array(list(product(*zip(case.low, case.high))), float)
    vectors = np.vstack([vertices, case.mid]); masses = []; labels = []
    for name, rho, anti in FAMILY:
        for j, vector in enumerate(vectors):
            masses.append(joint_mass(vector, rho, anti)); labels.append((name, j))
    masses = np.asarray(masses); p, support = conditional_table(masses, k)
    centre = len(vectors)-1
    nominal_index = labels.index(("independent", centre))
    dependent_index = labels.index(("positive_035", centre))
    independent_indices = [i for i, (name, _) in enumerate(labels) if name == "independent"]
    qs = {}
    for policy, penalty in LAMBDAS.items():
        chosen_p = p[[dependent_index]] if policy == "rcp_point" else p[independent_indices] if policy == "rcp_independent" else p
        _, qs[policy] = bellman(chosen_p, case.costs, max_actions, penalty, case.predecessors)
    p0 = p[nominal_index]; q_all = masses[nominal_index, -1]/support[nominal_index]
    for policy in ["ei_proxy", "entropy", "greedy_resolution", "greedy_stop"]:
        score = np.full((max_actions+1, 2**k, k), -np.inf)
        for s in range(2**k-1):
            remaining = k-int(s).bit_count()
            for a in range(k):
                if s & (1 << a) or (s & case.predecessors[a]) != case.predecessors[a]: continue
                pa = p0[s, a]
                if policy == "ei_proxy": v = q_all[s]/case.costs[a]
                elif policy == "entropy":
                    v = -(pa*np.log(max(pa, 1e-300))+(1-pa)*np.log(max(1-pa, 1e-300)))/case.costs[a]
                elif policy == "greedy_stop": v = (1-pa)+pa*(remaining == 1)-.05*case.costs[a]
                else: v = ((1-pa)+pa*(remaining == 1))/case.costs[a]
                score[1:, s, a] = v
        qs[policy] = score
    return {"masses": masses, "labels": labels, "p": p, "support": support, "scores": qs}


PROCESS_SCENARIOS = (
    ("central_independent", "mid", 0., False, 0.),
    ("central_positive035", "mid", .35, False, 0.),
    ("central_positive070", "mid", .70, False, 0.),
    ("central_antagonistic", "mid", .35, True, 0.),
    ("low_corner", "low", .35, False, 0.),
    ("high_corner", "high", .35, False, 0.),
    ("mixed_corner", "mixed", .35, True, 0.),
    ("probability_downshift", "mid", .35, False, -.15),
    ("probability_upshift", "mid", .35, False, .15),
    ("dependence_outside_family", "mid", .90, False, 0.),
)


def process_mass(case, scenario):
    _, location, rho, anti, shift = scenario
    vector = getattr(case, location) if location in ["low", "mid", "high"] else np.where(np.arange(case.k) % 2, case.high, case.low)
    return joint_mass(np.clip(vector+shift, .005, .995), rho, anti, quadrature=192)


def simulate_duty(cases, prepared, truth, policies, max_actions, seed, trace_collector=None, trace_sample=20):
    """Shared truth arrays; one task assesses one candidate and one gate."""
    n_draws, n_cases = truth.shape; rows = np.arange(n_draws)
    costs_out = np.zeros((len(policies), n_draws, max_actions+1), np.float32)
    resolved_out = np.zeros_like(costs_out, dtype=np.uint8)
    qualified_out = np.zeros_like(costs_out, dtype=np.uint8)
    for pi, policy in enumerate(policies):
        states = np.zeros((n_draws, n_cases), np.int16); failed = np.zeros_like(states, bool)
        stopped = np.zeros(n_draws, bool); burden = np.zeros(n_draws)
        rng = np.random.default_rng(seed+pi*7919)
        for step in range(max_actions):
            b = max_actions-step; task_scores = []; task_candidates = []; task_gates = []
            for c, case in enumerate(cases):
                for a in range(case.k):
                    available = (~failed[:, c] & ((states[:, c] & (1 << a)) == 0) & ~stopped
                                 & ((states[:, c] & case.predecessors[a]) == case.predecessors[a]))
                    if policy == "random": score = rng.random(n_draws)
                    else: score = prepared[c]["scores"][policy][b, states[:, c], a].copy()
                    score[~available] = -np.inf
                    # Lowest cost is an explicit deterministic tie break.
                    score[np.isfinite(score)] -= case.costs[a]*1e-10+a*1e-12+c*1e-14
                    task_scores.append(score); task_candidates.append(c); task_gates.append(a)
            score_matrix = np.asarray(task_scores).T
            chosen = score_matrix.argmax(axis=1); best = score_matrix[rows, chosen]
            active = np.isfinite(best) & ~stopped
            if ((policy.startswith("rcp") and policy != "rcp_continue" and LAMBDAS[policy] > 0)
                    or policy == "greedy_stop"): active &= best > 0.
            stopped |= ~active
            for ti, (c, a) in enumerate(zip(task_candidates, task_gates)):
                sel = active & (chosen == ti)
                result = (truth[:, c] & (1 << a)) != 0
                if trace_collector is not None:
                    for world_id in np.flatnonzero(sel[:trace_sample]):
                        before = int(states[world_id, c]); after = before | (1 << a) if result[world_id] else before
                        cp = prepared[c]["p"][:, before, a]
                        trace_collector.append({"scenario": cases[c].scenario, "policy": policy, "world_id": int(world_id),
                            "trajectory_step": step+1, "planning_horizon_actions": max_actions,
                            "system_id": cases[c].system_id, "gate": GATES[cases[c].required[a]],
                            "local_gate_index": a, "passed_mask_before": before, "passed_mask_after": after,
                            "predecessor_mask": int(cases[c].predecessors[a]), "generated_disclosed_result": int(result[world_id]),
                            "state_after": "fail_certificate" if not result[world_id] else "pass_certificate" if after == 2**cases[c].k-1 else "undetermined",
                            "task_burden": float(cases[c].costs[a]), "cumulative_duty_burden": float(burden[world_id]+cases[c].costs[a]),
                            "conditional_planning_probability_lower": float(cp.min()),
                            "conditional_planning_probability_upper": float(cp.max()),
                            "truth_origin": "generated process scenario, perfect model-gate disclosure; no laboratory observation"})
                states[sel & result, c] |= (1 << a); failed[sel & ~result, c] = True
                burden[sel] += cases[c].costs[a]
            passed = np.column_stack([states[:, c] == 2**case.k-1 for c, case in enumerate(cases)])
            costs_out[pi, :, step+1] = burden
            resolved_out[pi, :, step+1] = (failed | passed).sum(axis=1)
            qualified_out[pi, :, step+1] = passed.sum(axis=1)
    return costs_out, resolved_out, qualified_out


def _mc(values):
    values = np.asarray(values, float); mean = values.mean()
    half = 1.959963984540054*values.std(ddof=1)/np.sqrt(len(values))
    return float(mean), float(mean-half), float(mean+half)


def run_study(root: Path, n_draws=20000, max_actions=6, seed=361003):
    out = root/"outputs/tables"; qc = root/"outputs/qc"; raw = root/"outputs/certificate_planning"
    for p in [out, qc, raw]: p.mkdir(parents=True, exist_ok=True)
    candidates = load_candidates(root); prepared = {}; ledger = []; bound_rows = []; task_rows = []; beliefs = {}; traces = []
    for ci, case in enumerate(candidates):
        eligible = not case.structurally_excluded and case.k > 0
        if eligible:
            prepared[ci] = prepare_candidate(case, max_actions)
            beliefs[f"case_{ci}_joint_mass"] = prepared[ci]["masses"]
            beliefs[f"case_{ci}_conditional_probabilities"] = prepared[ci]["p"]
        if eligible:
            for a, gate in enumerate(case.required):
                task_rows.append({"task_id": f"{case.scenario}:{case.system_id}:{GATES[gate]}",
                                  "case_id": ci, "scenario": case.scenario, "system_id": case.system_id,
                                  "gate": GATES[gate], "burden_units": float(case.costs[a]),
                                  "predecessor_gates": ";".join(GATES[g] for g in PREREQUISITES.get(int(gate), ())),
                                  "scope": "one material-gate task in one stated duty; no automatic cross-material or cross-duty transfer",
                                  "cost_provenance": "elicited ordinal planning cost, not measured time or currency"})
        lower, upper = frechet_bounds(case.low, case.high)
        ledger.append({"case_id": ci, "scenario": case.scenario, "system_id": case.system_id,
                       "display_system": case.display, "unknown_gates": case.k,
                       "structurally_excluded": case.structurally_excluded,
                       "initial_state": "excluded" if case.structurally_excluded else "model_qualified" if not case.k else "undetermined",
                       "required_gates": ";".join(GATES[a] for a in case.required),
                       "planning_marginal_low": json.dumps(case.low.tolist()),
                       "planning_marginal_central": json.dumps(case.mid.tolist()),
                       "planning_marginal_high": json.dumps(case.high.tolist()),
                       "local_predecessor_masks": json.dumps(case.predecessors.tolist()),
                       "complete_route_actions": case.k, "complete_route_burden": float(case.costs.sum()),
                       "pass_certificate_reachable_at_six_actions": not case.structurally_excluded and case.k <= max_actions,
                       "planning_marginal_provenance": "elicited evidence-rule intervals; not observed gate pass rates"})
        bound_rows.append({"case_id": ci, "scenario": case.scenario, "system_id": case.system_id,
                           "unknown_gates": case.k, "elicited_frechet_lower": 0. if case.structurally_excluded else lower,
                           "elicited_frechet_upper": 0. if case.structurally_excluded else upper,
                           "independent_central_product": 0. if case.structurally_excluded else float(np.prod(case.mid)),
                           "empirically_unidentified_lower": 0. if case.k or case.structurally_excluded else 1.,
                           "empirically_unidentified_upper": 0. if case.structurally_excluded else 1.,
                           "scope": "conditional on stated marginal intervals; not confidence intervals"})
    pd.DataFrame(ledger).to_csv(out/"core_certificate_case_ledger.csv", index=False)
    pd.DataFrame(task_rows).to_csv(out/"core_certificate_task_ledger.csv", index=False)
    pd.DataFrame(bound_rows).to_csv(out/"core_certificate_probability_bounds.csv", index=False)
    np.savez_compressed(raw/"planning_joint_beliefs.npz", **beliefs)
    summaries = []; comparisons = []
    duties = list(dict.fromkeys(c.scenario for c in candidates)); active_n = len(prepared)
    for si, scenario in enumerate(PROCESS_SCENARIOS):
        pooled = [np.zeros((len(POLICIES), n_draws, max_actions+1), dt) for dt in [np.float32, np.uint8, np.uint8]]
        duty_arrays = [np.zeros((len(duties), len(POLICIES), n_draws, max_actions+1), dt) for dt in [np.float32, np.uint8, np.uint8]]
        full_truth = np.full((n_draws, len(candidates)), 255, np.uint8)
        for di, duty in enumerate(duties):
            ids = [i for i, c in enumerate(candidates) if c.scenario == duty and i in prepared]
            if not ids: continue
            cases = [candidates[i] for i in ids]; fits = [prepared[i] for i in ids]
            rng = np.random.default_rng(seed+100003*si+1009*di)
            truth = np.column_stack([np.minimum(np.searchsorted(np.cumsum(process_mass(c, scenario)), rng.random(n_draws)), 2**c.k-1) for c in cases])
            full_truth[:, ids] = truth
            example = []
            arrays = simulate_duty(cases, fits, truth, POLICIES, max_actions, seed+si*100003+di*1009, example)
            for row in example: row["process_scenario"] = scenario[0]
            traces.extend(example)
            for j in range(3): pooled[j] += arrays[j]
            for j in range(3): duty_arrays[j][di] = arrays[j]
            for pi, policy in enumerate(POLICIES):
                for b in range(max_actions+1):
                    summaries.append({"process_scenario": scenario[0], "scenario": duty, "policy": policy, "trajectory_step": b,
                                      "planning_horizon_actions": max_actions,
                                      "active_cases": len(ids), "mean_burden": float(arrays[0][pi, :, b].mean()),
                                      "mean_new_certificates": float(arrays[1][pi, :, b].mean()),
                                      "mean_new_pass_certificates": float(arrays[2][pi, :, b].mean()),
                                      "mean_undetermined": float(len(ids)-arrays[1][pi, :, b].mean())})
        for pi, policy in enumerate(POLICIES):
            for b in range(max_actions+1):
                c = pooled[0][pi, :, b]; r = pooled[1][pi, :, b]; p = pooled[2][pi, :, b]
                cm, clo, chi = _mc(c); rm, rlo, rhi = _mc(r); pm, plo, phi = _mc(p)
                summaries.append({"process_scenario": scenario[0], "scenario": "pooled", "policy": policy, "trajectory_step": b,
                                  "planning_horizon_actions": max_actions,
                                  "active_cases": active_n, "mean_burden": cm, "burden_mc95_lower": clo, "burden_mc95_upper": chi,
                                  "mean_new_certificates": rm, "certificates_mc95_lower": rlo, "certificates_mc95_upper": rhi,
                                  "mean_new_pass_certificates": pm, "pass_mc95_lower": plo, "pass_mc95_upper": phi,
                                  "mean_undetermined": active_n-rm, "certificate_coverage": rm/active_n,
                                  "mean_fixed_penalty_utility": float((r-.05*c).mean())})
            delta_r = pooled[1][pi, :, -1].astype(float)-pooled[1][0, :, -1]
            delta_c = pooled[0][pi, :, -1].astype(float)-pooled[0][0, :, -1]
            delta_u = delta_r-.05*delta_c
            for metric, values in [("certificates", delta_r), ("burden", delta_c), ("utility_lambda005", delta_u)]:
                mean, lo, hi = _mc(values)
                comparisons.append({"process_scenario": scenario[0], "policy": policy, "reference": "random", "metric": metric,
                                    "paired_difference": mean, "mc95_lower": lo, "mc95_upper": hi,
                                    "n_common_worlds": n_draws, "interval_scope": "paired Monte Carlo sampling interval conditional on process scenario"})
        np.savez_compressed(raw/(scenario[0]+"_paired_worlds.npz"), burden=pooled[0], certificates=pooled[1], passed=pooled[2],
                            duty_burden=duty_arrays[0], duty_certificates=duty_arrays[1], duty_passed=duty_arrays[2],
                            generated_truth_bitmasks=full_truth)
        print("Certificate study:", scenario[0], "completed", flush=True)
    pd.DataFrame(summaries).to_csv(out/"core_certificate_strategy_summary.csv", index=False)
    pd.DataFrame(comparisons).to_csv(out/"core_certificate_paired_comparisons.csv", index=False)
    pd.DataFrame(traces).to_csv(raw/"disclosure_examples.csv.gz", index=False, compression="gzip")
    status = {"status": "PASS", "method": "joint-evidence-certificate-planning-v3", "seed": seed,
              "worlds_per_process_scenario_per_duty": n_draws, "process_scenarios": len(PROCESS_SCENARIOS),
              "duties": len(duties), "candidate_duty_cases": len(candidates), "initially_undetermined_actionable_cases": active_n,
              "policies": list(POLICIES), "max_actions": max_actions, "cost_penalties": LAMBDAS,
              "task_count": len(task_rows), "precedence": {GATES[a]: [GATES[g] for g in pred] for a, pred in PREREQUISITES.items()},
              "pooled_budget_scope": "sum of seven separately budgeted duties; b actions per duty, at most 7b total, not one global b-task budget",
              "stopping_comparison": "rcp_continue shares certificate-only mandatory continuation with random/EI/entropy/greedy; rcp and greedy_stop add explicit net-value stopping",
              "planning_dependence_family": FAMILY, "marginal_family": "all low/high vertices plus central mean vector",
              "stopping": "all-pass or any-fail certificate; optional stop if local net certificate value nonpositive",
              "certificate_semantics": "perfect disclosed model-gate outcomes, not empirically verified physical qualification",
              "probability_provenance": "elicited planning bounds; never inferred from property availability or imputed by ML",
              "robust_scope": "exact single-candidate rectangular conditional scenario DP; separable portfolio heuristic, no global optimality",
              "empirical_status": "conditional simulation only; no new laboratory gate outcomes",
              "raw_array_axes": ["policy in listed order", "paired world_id", "disclosure checkpoint 0..6 under six-action planning horizon"],
              "duties_in_raw_order": duties, "generated_truth_axes": ["paired world_id", "case_id in ledger"],
              "generated_truth_sentinel": "255 means not an actionable initially undetermined case",
              "disclosure_examples": "first 20 paired worlds per scenario/duty/policy; full truth and per-duty outcome arrays retained",
              "cross_case_dependence": "process draws independent between material-duty cases; within-case gate dependence varies by declared scenario",
              "trajectory_scope": "prefix checkpoints of one six-action-horizon policy, not separately reoptimized budget-b policies",
              "runtime_qualification": "20,000 generated worlds are not 20,000 independent material experiments"}
    (qc/"EVIDENCE_CERTIFICATE_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    return status
