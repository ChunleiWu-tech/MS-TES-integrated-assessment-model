from __future__ import annotations

"""Uncertainty-aware sequential evidence acquisition for TES qualification.

This module is deliberately independent of the frozen selection model.  It treats
qualification as a partially observed, finite-horizon decision problem and uses
the existing triangular evidence intervals as priors.  A log-normal perturbation
is applied only when drawing latent evidence reliability; it is not described as
experimental uncertainty.
"""

from dataclasses import dataclass
from pathlib import Path
import gzip
import json
import math
import os
import warnings
from collections import defaultdict

import numpy as np
import pandas as pd
from scipy.special import betaln, digamma
from scipy.stats import wilcoxon

DIMENSIONS = (
    "thermal_cp", "thermal_density", "corrosion", "cycling_phase",
    "containment", "literature_replication", "data_completeness",
)
ATOMIC_TO_DIM = {
    "corrosion": "corrosion_compatibility",
    "cycling_phase": "cycling_phase_stability",
    "containment": "containment_validation",
    "literature_replication": "literature_replication",
    "data_completeness": "data_completeness",
}
ACTIONS = (
    ("a1_cp_full_range", "Full-range heat-capacity measurement", "thermal_cp", 2.0),
    ("a2_density_full_range", "Full-range density measurement", "thermal_density", 2.0),
    ("a3_corrosion_test", "Corrosion compatibility test", "corrosion", 3.0),
    ("a4_cycle_phase_test", "Cycling/phase-stability test", "cycling_phase", 2.0),
    ("a5_containment_validation", "Containment validation", "containment", 2.5),
    ("a6_independent_replication", "Independent replication", "literature_replication", 2.0),
    ("a7_data_completeness", "Data-integrity completion audit", "data_completeness", 0.5),
)
ACTION_INDEX = {row[0]: i for i, row in enumerate(ACTIONS)}
DIM_INDEX = {name: i for i, name in enumerate(DIMENSIONS)}
STRATEGIES = ("random", "greedy_unlock", "eig", "ei")
OPTIONAL_STRATEGIES = STRATEGIES + ("uniform_budget",)


@dataclass
class Problem:
    scenario: str
    scenario_label: str
    members: list[str]
    display: list[str]
    prior_low: np.ndarray
    prior_mid: np.ndarray
    prior_high: np.ndarray
    resolved0: np.ndarray
    impossible: np.ndarray
    value: np.ndarray
    action_dim: np.ndarray
    action_cost: np.ndarray
    action_id: list[str]
    action_label: list[str]
    prior_strength: float = 12.0


def _triangular_mean_variance(low: np.ndarray, mode: np.ndarray, high: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mean = (low + mode + high) / 3.0
    var = (low * low + mode * mode + high * high - low * mode - low * high - mode * high) / 18.0
    return mean, np.maximum(var, 1e-9)


def _beta_from_triangular(low: np.ndarray, mode: np.ndarray, high: np.ndarray, strength: float = 12.0) -> tuple[np.ndarray, np.ndarray]:
    mean, _ = _triangular_mean_variance(low, mode, high)
    # A fixed pseudo-sample size makes the registered analytical interval a
    # transparent prior rather than pretending it is a confidence interval.
    mean = np.clip(mean, 1e-4, 1 - 1e-4)
    return mean * strength, (1.0 - mean) * strength


def _beta_entropy(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return betaln(a, b) - (a - 1.0) * digamma(a) - (b - 1.0) * digamma(b)


def _coverage(row: pd.Series, prefix: str, lo: float, hi: float) -> float:
    a, b = row.get(f"{prefix}_Tmin_C"), row.get(f"{prefix}_Tmax_C")
    if not np.isfinite(a) or not np.isfinite(b) or hi <= lo:
        return 0.0
    return float(np.clip(max(0.0, min(float(b), hi) - max(float(a), lo)) / (hi - lo), 0.0, 1.0))


def _property_prior(coverage: float) -> tuple[float, float, float]:
    # Prior success of a targeted full-range measurement.  These are decision
    # priors, not measurement-error bars; they encode how much of the required
    # interval is already supported in the registered source ledger.
    mid = 0.25 + 0.65 * float(np.clip(coverage, 0.0, 1.0))
    low = max(0.03, mid - 0.20)
    high = min(0.99, mid + 0.20)
    return low, mid, high


def _safe_float(x: object, fallback: float = np.nan) -> float:
    try:
        v = float(x)
    except (TypeError, ValueError):
        return fallback
    return v if np.isfinite(v) else fallback


def _adjust_interval(low: float, mode: float, high: float, shift: float) -> tuple[float, float, float]:
    """Apply a bounded prior-location sensitivity shift while preserving order."""
    values = np.clip(np.asarray([low, mode, high], dtype=float) + float(shift), 1e-4, 0.9999)
    values.sort()
    return float(values[0]), float(values[1]), float(values[2])


def _candidate_value(row: pd.Series, service: pd.Series) -> float:
    mode = str(service.service_mode)
    if mode == "latent":
        latent = _safe_float(row.get("latent_J_g"))
        return latent if np.isfinite(latent) else 0.0
    lo = _safe_float(service.get("fixed_Tcold_C"))
    hi = _safe_float(service.get("fixed_Thot_C"))
    cp = _safe_float(row.get("cp_a"))
    rho_a = _safe_float(row.get("rho_a"))
    rho_b = _safe_float(row.get("rho_b"), 0.0)
    if np.isfinite(lo) and np.isfinite(hi) and np.isfinite(cp) and np.isfinite(rho_a):
        mid = (lo + hi) / 2.0 + 273.15
        rho = rho_a + rho_b * mid if str(row.get("rho_model")) == "linear_K" else rho_a
        return max(0.0, cp * (hi - lo) / 3600.0 * rho)
    reported = _safe_float(row.get("reported_energy_density_MJ_m3"))
    return reported if np.isfinite(reported) else 0.0


def _rank_value(values: np.ndarray) -> np.ndarray:
    if len(values) == 0:
        return values
    finite = np.isfinite(values)
    out = np.full(len(values), 0.5, dtype=float)
    if finite.any():
        v = values[finite]
        lo, hi = float(v.min()), float(v.max())
        out[finite] = 0.5 if hi - lo < 1e-12 else (v - lo) / (hi - lo)
    return out


def load_problems(
    root: Path,
    scenario_filter: set[str] | None = None,
    prior_strength: float = 12.0,
    prior_shift: float = 0.0,
    action_cost_multiplier: float = 1.0,
    action_cost_override: dict[str, float] | None = None,
) -> list[Problem]:
    inp = root / "data" / "input"
    cfg = root / "config"
    membership = pd.read_csv(inp / "core_candidate_scenario_membership.csv")
    atomic = pd.read_csv(inp / "core_atomic_engineering_credibility_registry.csv")
    props = pd.read_csv(inp / "core_candidate_property_registry.csv")
    services = pd.read_csv(cfg / "core_system_benchmarks.csv")
    if scenario_filter:
        membership = membership[membership.scenario.isin(scenario_filter)].copy()
    problems: list[Problem] = []
    for scenario, group in membership.groupby("scenario", sort=False):
        service = services.loc[services.scenario.eq(scenario)].iloc[0]
        merged = group.merge(atomic, on=["scenario", "scenario_label", "system_id", "display_system"], how="left", validate="one_to_one")
        merged = merged.merge(props, on=["system_id", "display_system"], how="left", validate="many_to_one").reset_index(drop=True)
        n = len(merged)
        low = np.zeros((n, len(DIMENSIONS)), dtype=float)
        mid = np.zeros_like(low)
        high = np.zeros_like(low)
        resolved = np.ones_like(low, dtype=bool)
        impossible = merged.nonclosable_direct_risk.astype(bool).to_numpy(copy=True)
        raw_value = np.zeros(n, dtype=float)
        for j, row in merged.iterrows():
            service_mode = str(service.service_mode)
            cp_cov = density_cov = 1.0
            if service_mode == "sensible":
                tlo, thi = float(service.fixed_Tcold_C), float(service.fixed_Thot_C)
                cp_cov = _coverage(row, "cp", tlo, thi)
                density_cov = _coverage(row, "rho", tlo, thi)
                resolved[j, DIM_INDEX["thermal_cp"]] = cp_cov >= 0.999
                resolved[j, DIM_INDEX["thermal_density"]] = density_cov >= 0.999
                # A decomposition/phase limit outside the duty is a direct risk;
                # no evidence-collection action is allowed to override it.
                tm = _safe_float(row.get("Tm_C"))
                tmax = _safe_float(row.get("Tmax_practical_C"))
                if (np.isfinite(tm) and tm > tlo) or (np.isfinite(tmax) and tmax < thi):
                    impossible[j] = True
            else:
                resolved[j, DIM_INDEX["thermal_cp"]] = True
                resolved[j, DIM_INDEX["thermal_density"]] = True
                pmin, pmax = float(service.phase_target_min_C), float(service.phase_target_max_C)
                tm = _safe_float(row.get("Tm_C"))
                if np.isfinite(tm) and not (pmin <= tm <= pmax):
                    impossible[j] = True
            for dim in ("thermal_cp", "thermal_density"):
                if dim == "thermal_cp":
                    l, m, h = _property_prior(cp_cov)
                else:
                    l, m, h = _property_prior(density_cov)
                c = DIM_INDEX[dim]
                low[j, c], mid[j, c], high[j, c] = _adjust_interval(l, m, h, prior_shift)
            for dim, source in ATOMIC_TO_DIM.items():
                c = DIM_INDEX[dim]
                prefix = source
                l = _safe_float(row.get(f"{prefix}_low"), 0.1)
                m = _safe_float(row.get(f"{prefix}_mid"), l)
                h = _safe_float(row.get(f"{prefix}_high"), m)
                low[j, c], mid[j, c], high[j, c] = _adjust_interval(l, m, h, prior_shift)
                gap_col = {
                    "corrosion": "gap_corrosion",
                    "cycling_phase": "gap_cycling_phase",
                    "containment": "gap_containment",
                    "literature_replication": "gap_literature_validation",
                    "data_completeness": "gap_data_completeness",
                }[dim]
                resolved[j, c] = not bool(row.get(gap_col, False))
            raw_value[j] = _candidate_value(row, service)
        costs = np.array([x[3] for x in ACTIONS], dtype=float) * float(action_cost_multiplier)
        if action_cost_override:
            for action_id, cost in action_cost_override.items():
                if action_id not in ACTION_INDEX:
                    raise ValueError(f"Unknown action cost override: {action_id}")
                costs[ACTION_INDEX[action_id]] = float(cost)
        problems.append(Problem(
            scenario=str(scenario), scenario_label=str(service.scenario_label),
            members=merged.system_id.astype(str).tolist(), display=merged.display_system.astype(str).tolist(),
            prior_low=np.clip(low, 1e-4, 0.9999), prior_mid=np.clip(mid, 1e-4, 0.9999), prior_high=np.clip(high, 1e-4, 0.9999),
            resolved0=resolved, impossible=impossible, value=_rank_value(raw_value),
            action_dim=np.array([DIM_INDEX[x[2]] for x in ACTIONS], dtype=int),
            action_cost=costs,
            action_id=[x[0] for x in ACTIONS], action_label=[x[1] for x in ACTIONS],
            prior_strength=float(prior_strength),
        ))
    return problems


def _initial_posterior(problem: Problem) -> tuple[np.ndarray, np.ndarray]:
    a = np.zeros_like(problem.prior_mid)
    b = np.zeros_like(problem.prior_mid)
    for c in range(problem.prior_mid.shape[1]):
        a[:, c], b[:, c] = _beta_from_triangular(
            problem.prior_low[:, c], problem.prior_mid[:, c], problem.prior_high[:, c], problem.prior_strength
        )
    return a, b


def _draw_world(problem: Problem, rng: np.random.Generator, lognormal_sigma: float = 0.08) -> tuple[np.ndarray, np.ndarray]:
    n, g = problem.prior_mid.shape
    truth = np.empty((n, g), dtype=float)
    obs = np.empty((n, g), dtype=bool)
    for j in range(n):
        for c in range(g):
            p = rng.triangular(problem.prior_low[j, c], problem.prior_mid[j, c], problem.prior_high[j, c])
            p = float(np.clip(p * rng.lognormal(mean=0.0, sigma=lognormal_sigma), 1e-4, 0.9999))
            truth[j, c] = p
            obs[j, c] = bool(rng.random() < p)
    return truth, obs


def _qualification_probability(resolved: np.ndarray, p: np.ndarray, impossible: np.ndarray) -> np.ndarray:
    # Resolved gates are certain; unresolved gates retain their posterior mean.
    q = np.where(resolved, 1.0, np.clip(p, 1e-8, 1.0)).prod(axis=1)
    q[impossible] = 0.0
    return q


def _actual_eligible(resolved: np.ndarray, impossible: np.ndarray) -> np.ndarray:
    out = resolved.all(axis=1)
    out[impossible] = False
    return out


def _greedy_score(resolved: np.ndarray, p: np.ndarray, action_dim: int, value: np.ndarray, impossible: np.ndarray) -> float:
    unresolved = ~resolved
    target = unresolved[:, action_dim] & ~impossible
    other = resolved.copy()
    other[:, action_dim] = True
    # Greedy unlock counts only candidates for which this is the final missing gate.
    final = target & other.all(axis=1)
    return float(np.sum(p[final, action_dim] * (1.0 + value[final])))


def _ei_score(resolved: np.ndarray, p: np.ndarray, action_dim: int, value: np.ndarray, impossible: np.ndarray) -> float:
    unresolved = ~resolved
    target = unresolved[:, action_dim] & ~impossible
    other_probability = np.where(resolved, 1.0, np.clip(p, 1e-8, 1.0))
    other_probability[:, action_dim] = 1.0
    q_other = other_probability.prod(axis=1)
    return float(np.sum(target * p[:, action_dim] * q_other * (1.0 + value)))


def _eig_score(alpha: np.ndarray, beta: np.ndarray, resolved: np.ndarray, action_dim: int, impossible: np.ndarray, value: np.ndarray) -> float:
    mask = ~resolved[:, action_dim] & ~impossible
    if not mask.any():
        return 0.0
    a, b = alpha[mask, action_dim], beta[mask, action_dim]
    p = a / (a + b)
    prior_h = _beta_entropy(a, b)
    post1 = _beta_entropy(a + 1.0, b)
    post0 = _beta_entropy(a, b + 1.0)
    gain = prior_h - (p * post1 + (1.0 - p) * post0)
    return float(np.sum(np.maximum(gain, 0.0) * (1.0 + value[mask])))


def _choose(
    strategy: str,
    available: list[int],
    resolved: np.ndarray,
    p: np.ndarray,
    alpha: np.ndarray,
    beta: np.ndarray,
    problem: Problem,
    impossible: np.ndarray,
    rng: np.random.Generator,
    objective: str = "formal_candidate_count",
) -> int:
    if strategy == "random":
        return int(rng.choice(available))
    if strategy == "uniform_budget":
        return int(min(available))
    scores = []
    for action in available:
        dim = int(problem.action_dim[action])
        if strategy == "greedy_unlock":
            score = _greedy_score(resolved, p, dim, problem.value, impossible)
        elif strategy == "eig":
            score = _eig_score(alpha, beta, resolved, dim, impossible, problem.value)
        else:
            score = _ei_score(resolved, p, dim, problem.value, impossible)
        if objective == "information_per_cost" and strategy == "eig":
            score /= max(problem.action_cost[action], 1e-9)
        elif objective == "selection_event_reduction" and strategy in {"eig", "ei"}:
            score = _greedy_score(resolved, p, dim, problem.value, impossible)
        scores.append(score)
    scores = np.asarray(scores, dtype=float)
    best = [available[i] for i, score in enumerate(scores) if score >= scores.max() - 1e-12]
    return int(min(best, key=lambda action: (problem.action_cost[action], action)))


def simulate_problem(
    problem: Problem,
    n_draws: int,
    seed: int,
    max_actions: int = 6,
    lognormal_sigma: float = 0.08,
    strategies: tuple[str, ...] = STRATEGIES,
    objective: str = "formal_candidate_count",
    posterior_update: bool = True,
) -> dict:
    rng_world = np.random.default_rng(seed)
    worlds = [_draw_world(problem, rng_world, lognormal_sigma) for _ in range(n_draws)]
    summaries: list[dict] = []
    full: dict[str, dict[str, np.ndarray]] = {}
    posterior_acc = defaultdict(lambda: [0.0, 0.0, 0.0, 0.0, 0.0, 0])
    base_eligible = _actual_eligible(problem.resolved0.copy(), problem.impossible.copy())
    base_count = int(base_eligible.sum())
    base_event = int(base_count > 0)
    base_winner = int(np.argmax(np.where(base_eligible, problem.value, -np.inf))) if base_event else -1
    for strategy_index, strategy in enumerate(strategies):
        rng = np.random.default_rng(seed + 7919 * (strategy_index + 1))
        action_trace = np.full((n_draws, max_actions), -1, dtype=np.int8)
        outcome_trace = np.full((n_draws, max_actions), -1, dtype=np.int16)
        target_trace = np.zeros((n_draws, max_actions), dtype=np.int16)
        eligible_trace = np.full((n_draws, max_actions), base_count, dtype=np.int16)
        formal_trace = np.full((n_draws, max_actions), base_count, dtype=np.int16)
        selection_event_trace = np.full((n_draws, max_actions), base_event, dtype=np.int8)
        winner_trace = np.full((n_draws, max_actions), base_winner, dtype=np.int16)
        available_trace = np.zeros((n_draws, max_actions), dtype=np.int8)
        cost_trace = np.zeros((n_draws, max_actions), dtype=float)
        no_selection = np.full((n_draws, max_actions), not bool(base_event), dtype=bool)
        entropy_before_trace = np.full((n_draws, max_actions), np.nan, dtype=np.float32)
        entropy_after_trace = np.full((n_draws, max_actions), np.nan, dtype=np.float32)
        for draw in range(n_draws):
            _, observations = worlds[draw]
            resolved = problem.resolved0.copy()
            impossible = problem.impossible.copy()
            alpha, beta = _initial_posterior(problem)
            used: set[int] = set()
            for step in range(max_actions):
                p = alpha / (alpha + beta)
                available = [a for a in range(len(ACTIONS)) if a not in used and np.any((~resolved[:, problem.action_dim[a]]) & ~impossible)]
                available_trace[draw, step] = len(available)
                if not available:
                    break
                chosen = _choose(strategy, available, resolved, p, alpha, beta, problem, impossible, rng, objective=objective)
                used.add(chosen)
                dim = int(problem.action_dim[chosen])
                mask = (~resolved[:, dim]) & (~impossible)
                prior_predictive = float(np.mean(p[mask, dim])) if mask.any() else np.nan
                entropy_before = float(np.mean(_beta_entropy(alpha[mask, dim], beta[mask, dim]))) if mask.any() else np.nan
                y = observations[:, dim].copy()
                # A positive measurement closes the gate. A negative result is
                # an observed disqualifier and cannot be treated as a pass.
                resolved[mask & y, dim] = True
                impossible[mask & (~y)] = True
                if posterior_update:
                    alpha[mask, dim] += y[mask].astype(float)
                    beta[mask, dim] += (~y[mask]).astype(float)
                post_p = alpha[mask, dim] / (alpha[mask, dim] + beta[mask, dim]) if mask.any() else np.array([])
                entropy_after = float(np.mean(_beta_entropy(alpha[mask, dim], beta[mask, dim]))) if mask.any() else np.nan
                posterior_acc[(strategy, step + 1, chosen)][0] += np.nansum(p[mask, dim])
                posterior_acc[(strategy, step + 1, chosen)][1] += np.sum(y[mask])
                posterior_acc[(strategy, step + 1, chosen)][2] += np.nansum(post_p)
                posterior_acc[(strategy, step + 1, chosen)][3] += np.nansum(entropy_before)
                posterior_acc[(strategy, step + 1, chosen)][4] += np.nansum(entropy_after)
                posterior_acc[(strategy, step + 1, chosen)][5] += int(mask.sum())
                eligible = _actual_eligible(resolved, impossible)
                winner = int(np.argmax(np.where(eligible, problem.value, -np.inf))) if eligible.any() else -1
                action_trace[draw, step] = chosen
                outcome_trace[draw, step] = int(y[mask].sum()) if mask.any() else -1
                target_trace[draw, step] = int(mask.sum())
                eligible_trace[draw, step] = int(eligible.sum())
                formal_trace[draw, step] = int(eligible.sum())
                selection_event_trace[draw, step] = int(eligible.any())
                winner_trace[draw, step] = winner
                cost_trace[draw, step] = problem.action_cost[chosen] + (cost_trace[draw, step - 1] if step else 0.0)
                no_selection[draw, step] = not eligible.any()
                entropy_before_trace[draw, step] = entropy_before
                entropy_after_trace[draw, step] = entropy_after
            # If every remaining gate belongs only to a permanently failed or
            # physically impossible membership, no later action is available.
            # Carry the terminal state forward for all larger budgets.
            valid_steps = np.flatnonzero(action_trace[draw] >= 0)
            if len(valid_steps) and valid_steps[-1] + 1 < max_actions:
                last = int(valid_steps[-1])
                eligible_trace[draw, last + 1:] = eligible_trace[draw, last]
                formal_trace[draw, last + 1:] = formal_trace[draw, last]
                selection_event_trace[draw, last + 1:] = selection_event_trace[draw, last]
                winner_trace[draw, last + 1:] = winner_trace[draw, last]
                cost_trace[draw, last + 1:] = cost_trace[draw, last]
                no_selection[draw, last + 1:] = no_selection[draw, last]
            elif not len(valid_steps):
                eligible_trace[draw, :] = base_count
                formal_trace[draw, :] = base_count
                selection_event_trace[draw, :] = base_event
                winner_trace[draw, :] = base_winner
                no_selection[draw, :] = not bool(base_event)
        full[strategy] = {
            "eligible": eligible_trace,
            "formal": formal_trace,
            "selection_event": selection_event_trace,
            "winner": winner_trace,
            "cost": cost_trace,
            "actions": action_trace,
            "outcome": outcome_trace,
            "target": target_trace,
            "available": available_trace,
            "no": no_selection,
            "entropy_before": entropy_before_trace,
            "entropy_after": entropy_after_trace,
        }
        for budget in range(0, max_actions + 1):
            if budget == 0:
                eligible = np.full(n_draws, base_count, dtype=float)
                formal = np.full(n_draws, base_count, dtype=float)
                event = np.full(n_draws, base_event, dtype=float)
                cost = np.zeros(n_draws, dtype=float)
                nosel = event == 0
            else:
                eligible = eligible_trace[:, budget - 1].astype(float)
                formal = formal_trace[:, budget - 1].astype(float)
                event = selection_event_trace[:, budget - 1].astype(float)
                cost = cost_trace[:, budget - 1]
                nosel = no_selection[:, budget - 1]
            mean_eligible = float(eligible.mean())
            mean_formal = float(formal.mean())
            se = float(eligible.std(ddof=1) / math.sqrt(n_draws)) if n_draws > 1 else 0.0
            event_se = float(event.std(ddof=1) / math.sqrt(n_draws)) if n_draws > 1 else 0.0
            mean_cost = float(cost.mean())
            summaries.append({
                "scenario": problem.scenario, "scenario_label": problem.scenario_label, "strategy": strategy,
                "budget_actions": budget, "objective": objective, "posterior_update": bool(posterior_update),
                "mean_eligible_candidate_count": mean_eligible,
                "mean_formal_candidate_count": mean_formal,
                "mean_formal_selection_count": mean_formal,
                "formal_candidate_count_ci95_low": max(0.0, mean_formal - 1.96 * se),
                "formal_candidate_count_ci95_high": mean_formal + 1.96 * se,
                "selection_event_frequency": float(event.mean()),
                "selection_event_ci95_low": max(0.0, float(event.mean()) - 1.96 * event_se),
                "selection_event_ci95_high": min(1.0, float(event.mean()) + 1.96 * event_se),
                "no_selection_frequency": float(nosel.mean()),
                "no_selection_reduction": float((1.0 - base_event) - nosel.mean()),
                "mean_cumulative_cost": mean_cost,
                "selection_improvement_per_cost": (mean_formal - base_count) / mean_cost if mean_cost > 0 else 0.0,
                "selection_efficiency_per_cost": mean_formal / mean_cost if mean_cost > 0 else 0.0,
                "formal_candidate_efficiency_per_cost": mean_formal / mean_cost if mean_cost > 0 else 0.0,
                "mc_iterations": n_draws,
            })
    posterior_rows = []
    for (strategy, step, action), (prior_sum, y_sum, post_sum, entropy_before_sum, entropy_after_sum, count) in sorted(posterior_acc.items()):
        if count:
            posterior_rows.append({
                "scenario": problem.scenario, "scenario_label": problem.scenario_label, "strategy": strategy, "step": step,
                "action_id": problem.action_id[action], "action_label": problem.action_label[action],
                "mean_prior_predictive": prior_sum / count, "mean_observed_success": y_sum / count,
                "mean_posterior_mean": post_sum / count,
                "mean_entropy_before": entropy_before_sum / count,
                "mean_entropy_after": entropy_after_sum / count,
                "mean_entropy_reduction": (entropy_before_sum - entropy_after_sum) / count,
                "target_observations": count, "posterior_update": bool(posterior_update),
            })
    return {"summary": summaries, "posterior": posterior_rows, "full": full}


def _paired_test(x: np.ndarray, y: np.ndarray, seed: int | None = None) -> tuple[float, float, float, float]:
    d = np.asarray(x, dtype=float) - np.asarray(y, dtype=float)
    mean = float(d.mean())
    if len(d) > 1:
        se = float(d.std(ddof=1) / math.sqrt(len(d)))
        lo, hi = mean - 1.96 * se, mean + 1.96 * se
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                p = float(wilcoxon(d, zero_method="wilcox", alternative="two-sided", method="approx").pvalue)
            if not np.isfinite(p):
                p = 1.0
        except (ValueError, ZeroDivisionError):
            p = 1.0
    else:
        lo = hi = mean
        p = 1.0
    return mean, lo, hi, p


def run(
    root: Path,
    n_draws: int = 20000,
    seed: int = 760076,
    max_actions: int = 6,
    output_dir: Path | None = None,
    qc_dir: Path | None = None,
    scenarios: set[str] | None = None,
    strategies: tuple[str, ...] | None = None,
    action_cost_multiplier: float = 1.0,
    action_cost_override: dict[str, float] | None = None,
    prior_strength: float = 12.0,
    prior_shift: float = 0.0,
    lognormal_sigma: float = 0.08,
    objective: str = "formal_candidate_count",
    posterior_update: bool = True,
    write_trace: bool = True,
) -> dict:
    selected_strategies = tuple(strategies or STRATEGIES)
    unknown = set(selected_strategies) - set(OPTIONAL_STRATEGIES)
    if unknown:
        raise ValueError(f"Unknown strategies: {sorted(unknown)}")
    problems = load_problems(
        root,
        scenario_filter=scenarios,
        prior_strength=prior_strength,
        prior_shift=prior_shift,
        action_cost_multiplier=action_cost_multiplier,
        action_cost_override=action_cost_override,
    )
    out = Path(output_dir) if output_dir else root / "outputs" / "tables"
    qc = Path(qc_dir) if qc_dir else out.parent / "qc"
    out.mkdir(parents=True, exist_ok=True); qc.mkdir(parents=True, exist_ok=True)
    all_summaries, all_posteriors, all_tests, seq_rows = [], [], [], []
    trace_path = out / "active_learning_action_trace.csv.gz"
    if trace_path.exists():
        trace_path.unlink()
    trace_header = True
    trace_rows_written = 0
    trace_handle = gzip.open(trace_path, "wt", encoding="utf-8", newline="") if write_trace else None
    for index, problem in enumerate(problems):
        result = simulate_problem(
            problem, n_draws, seed + index * 10007, max_actions=max_actions,
            lognormal_sigma=lognormal_sigma, strategies=selected_strategies,
            objective=objective, posterior_update=posterior_update,
        )
        all_summaries.extend(result["summary"])
        all_posteriors.extend(result["posterior"])
        full = result["full"]
        trace_rows = []
        for strategy in selected_strategies:
            payload = full[strategy]
            for draw in range(n_draws):
                for step in range(max_actions):
                    action = int(payload["actions"][draw, step])
                    if action < 0:
                        continue
                    eligible = int(payload["eligible"][draw, step])
                    formal = int(payload["formal"][draw, step])
                    winner = int(payload["winner"][draw, step])
                    # Action scope is all still-unresolved memberships for this gate.
                    trace_rows.append({
                        "scenario": problem.scenario, "scenario_label": problem.scenario_label, "strategy": strategy, "draw_id": draw + 1,
                        "step": step + 1, "action_id": problem.action_id[action],
                        "action_label": problem.action_label[action], "action_cost_units": problem.action_cost[action],
                        "target_count": int(payload["target"][draw, step]),
                        "success_count": int(payload["outcome"][draw, step]) if payload["outcome"][draw, step] >= 0 else 0,
                        "eligible_candidate_count": eligible, "formal_candidate_count": formal,
                        "selection_event": int(payload["selection_event"][draw, step]),
                        "no_selection": int(payload["no"][draw, step]),
                        "winner_system_id": problem.members[winner] if winner >= 0 else "",
                        "winner_display": problem.display[winner] if winner >= 0 else "",
                        "cumulative_cost_units": float(payload["cost"][draw, step]),
                        "available_action_count": int(payload["available"][draw, step]),
                        "posterior_entropy_before": float(payload["entropy_before"][draw, step]),
                        "posterior_entropy_after": float(payload["entropy_after"][draw, step]),
                    })
        if trace_handle is not None and trace_rows:
            pd.DataFrame(trace_rows).to_csv(trace_handle, header=trace_header, index=False)
            trace_header = False
            trace_rows_written += len(trace_rows)
        for strategy in selected_strategies:
            for step in range(max_actions):
                actions = full[strategy]["actions"][:, step]
                actions = actions[actions >= 0]
                if len(actions):
                    counts = np.bincount(actions, minlength=len(ACTIONS))
                    chosen = int(np.argmax(counts))
                    seq_rows.append({
                        "scenario": problem.scenario, "scenario_label": problem.scenario_label,
                        "strategy": strategy, "step": step + 1, "recommended_action_id": problem.action_id[chosen],
                        "recommended_action_label": problem.action_label[chosen], "recommendation_frequency": float(counts[chosen] / len(actions)),
                        "action_entropy": float(-np.sum((counts[counts > 0] / len(actions)) * np.log(counts[counts > 0] / len(actions)))),
                    })
        random = full.get("random")
        for strategy in selected_strategies:
            if strategy == "random" or random is None:
                continue
            other = full[strategy]
            for budget in range(1, max_actions + 1):
                # Use formal-selection outcomes for the primary paired test and
                # eligible-candidate counts for the secondary test.
                m, lo, hi, p = _paired_test(other["formal"][:, budget - 1], random["formal"][:, budget - 1], seed + index + budget)
                me, elo, ehi, ep = _paired_test(other["eligible"][:, budget - 1], random["eligible"][:, budget - 1], seed + 100 + index + budget)
                all_tests.append({
                    "scenario": problem.scenario, "comparison": f"{strategy}_vs_random", "strategy": strategy,
                    "baseline": "random", "budget_actions": budget, "metric": "formal_selection_count",
                    "mean_delta": m, "ci95_low": lo, "ci95_high": hi, "p_value": p,
                    "eligible_count_mean_delta": me, "eligible_count_ci95_low": elo, "eligible_count_ci95_high": ehi,
                    "eligible_count_p_value": ep, "test": "paired Wilcoxon signed-rank",
                })
                nm, nlo, nhi, npv = _paired_test(other["no"][:, budget - 1], random["no"][:, budget - 1], seed + 200 + index + budget)
                all_tests.append({
                    "scenario": problem.scenario, "comparison": f"{strategy}_vs_random", "strategy": strategy,
                    "baseline": "random", "budget_actions": budget, "metric": "no_selection_indicator",
                    "mean_delta": nm, "ci95_low": nlo, "ci95_high": nhi, "p_value": npv,
                    "eligible_count_mean_delta": np.nan, "eligible_count_ci95_low": np.nan, "eligible_count_ci95_high": np.nan,
                    "eligible_count_p_value": np.nan, "test": "paired Wilcoxon signed-rank",
                })
        # A minimal contract makes paired comparisons explicit for the greedy
        # baseline too; EI and EIG are the main proposed policies.
        for strategy in ("eig", "ei"):
            if strategy not in full or "greedy_unlock" not in full:
                continue
            for budget in range(1, max_actions + 1):
                m, lo, hi, p = _paired_test(full[strategy]["formal"][:, budget - 1], full["greedy_unlock"]["formal"][:, budget - 1], seed + 500 + index + budget)
                all_tests.append({
                    "scenario": problem.scenario, "comparison": f"{strategy}_vs_greedy_unlock", "strategy": strategy,
                    "baseline": "greedy_unlock", "budget_actions": budget, "metric": "formal_selection_count",
                    "mean_delta": m, "ci95_low": lo, "ci95_high": hi, "p_value": p,
                    "eligible_count_mean_delta": np.nan, "eligible_count_ci95_low": np.nan, "eligible_count_ci95_high": np.nan,
                    "eligible_count_p_value": np.nan, "test": "paired Wilcoxon signed-rank",
                })
    if trace_handle is not None:
        trace_handle.close()
    pd.DataFrame(all_summaries).to_csv(out / "active_learning_strategy_summary.csv", index=False)
    pd.DataFrame(all_posteriors).to_csv(out / "active_learning_posterior_trajectory.csv", index=False)
    pd.DataFrame(seq_rows).to_csv(out / "active_learning_recommended_sequences.csv", index=False)
    pd.DataFrame(all_tests).to_csv(out / "active_learning_statistical_tests.csv", index=False)
    action_registry = pd.DataFrame(
        [
            {
                "action_id": action_id,
                "action_label": label,
                "dimension": dimension,
                "cost_units": cost,
                "scope": "all candidate-duty memberships in the selected duty",
            }
            for action_id, label, dimension, cost in ACTIONS
        ]
    )
    action_registry.to_csv(root / "config" / "active_learning_actions.csv", index=False)
    status = {
        "status": "PASS",
        "framework": "uncertainty-aware-active-learning-v2",
        "release_date": "2026-09-26",
        "scenarios": len(problems), "candidate_duty_memberships": int(sum(len(p.members) for p in problems)),
        "strategies": list(selected_strategies), "actions": len(ACTIONS), "max_budget_actions": max_actions,
        "mc_iterations": n_draws, "prior": "triangular low/mid/high pseudo-prior with configurable Beta strength and lognormal latent reliability perturbation",
        "prior_strength": prior_strength, "prior_shift": prior_shift, "lognormal_sigma": lognormal_sigma,
        "objective": objective, "posterior_update": bool(posterior_update),
        "action_cost_multiplier": action_cost_multiplier,
        "action_trace": trace_path.name if write_trace else None, "trace_rows": int(trace_rows_written),
        "statistical_test": "paired Wilcoxon signed-rank against random and greedy baselines",
        "output_directory": str(out),
    }
    (qc / "ACTIVE_LEARNING_STATUS.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    (out / "active_learning_run_metadata.json").write_text(json.dumps(status, indent=2), encoding="utf-8")
    return status


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    n = int(os.environ.get("TES_N_MC", "20000"))
    print(json.dumps(run(root, n_draws=n), indent=2))
