from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
QC = ROOT / "outputs" / "qc"
RELEASE_ID = "TES-EES-SCIENTIFIC-V5-20261004"

INITIAL = [
    "clean_generated_outputs.py",
    "check_env.py",
    "build_property_source_ledger.py",
    "validate_property_source_ledger.py",
    "validate_energy_reference.py",
    "run_upstream.py",
    "run_composite_coupling.py",
    "validate_composite_coupling.py",
    "run_model_upgrade_v2.py",
    "run_expanded_library_v3.py",
    "validate_expanded_library_v3.py",
    "write_mc_numerical_uncertainty.py",
    "validate_seed_registry.py",
    "build_postprocess_contract_tables.py",
    "write_scoring_audit.py",
]
SMOKE_TAIL = [
    "run_editorial_analysis.py",
    "validate_smoke_contract.py",
]
FULL_TAIL = [
    "run_editorial_analysis.py",
    "run_synthesis.py",
    "information_extensions.py",
    "presentation_extensions.py",
    "scientific_corrections.py",
    "run_validation.py",
    "run_innovation_validation.py",
    "run_high_density.py",
    "run_integrated_audit.py",
    "finalize_generation_provenance.py",
    "run_release_validation.py",
    "run_decision_boundary_analysis.py",
    "validate_decision_boundary.py",
    "run_statistical_analysis.py",
    "validate_statistical_analysis.py",
    "run_submission_synthesis.py",
    "run_joule_external_validation.py",
    "run_joule_claim_synthesis.py",
    "validate_submission.py",
    "validate_release_contract.py",
    "run_application_assessment.py",
    "run_active_learning.py",
    "validate_active_learning.py",
    "run_engineering_evidence.py",
    "validate_engineering_evidence.py",
    "run_external_enthalpy_validation.py",
    "run_traceability_audit.py",
    "run_thermophysical_v3.py",
    "run_evidence_certificates.py",
    "run_thermophysical_v4.py",
    "run_certificate_budget_v4.py",
    "run_existing_measurement_validation_v4.py",
    "thermophysical_model_v5.py",
    "certificate_budget_v5.py",
    "existing_measurement_validation_v5.py",
    "write_package_manifest.py",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Canonical OS-independent upstream workflow")
    parser.add_argument("--mode", choices=["full", "smoke"], default="full")
    parser.add_argument("--no-clean", action="store_true", help="Retain existing generated outputs; intended only for debugging.")
    parser.add_argument("--list", action="store_true", help="Print the exact stage list and exit.")
    parser.add_argument("--resume-from", default=None,
                        help="Resume a failed run from this exact stage, retaining a verified successful prefix")
    return parser.parse_args()


def write_status(payload: dict) -> None:
    QC.mkdir(parents=True, exist_ok=True)
    (QC / "pipeline_execution_status.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")


def main() -> None:
    args = parse_args()
    stages = INITIAL + (FULL_TAIL if args.mode == "full" else SMOKE_TAIL)
    if args.no_clean:
        stages = [stage for stage in stages if stage != "clean_generated_outputs.py"]
    if args.list:
        print("\n".join(stages))
        return

    env = os.environ.copy()
    env["TES_PIPELINE_MODE"] = args.mode
    env["TES_N_MC"] = "20000" if args.mode == "full" else "500"
    env.setdefault("PYTHONFAULTHANDLER", "1")
    env.setdefault("PYTHONUNBUFFERED", "1")
    for key in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
        env[key] = "1"

    started = time.time()
    stage_records: list[dict] = []
    resume_index = 0
    if args.resume_from:
        if not args.no_clean:
            raise SystemExit("--resume-from requires --no-clean")
        if args.resume_from not in stages:
            raise SystemExit("Unknown resume stage")
        previous = json.loads((QC/"pipeline_execution_status.json").read_text(encoding="utf-8"))
        resume_index = stages.index(args.resume_from)
        prefix = previous["stages"][:resume_index]
        if (previous["mode"] != args.mode or previous["mc_iterations"] != int(env["TES_N_MC"])
                or len(prefix) != resume_index
                or any(r["stage"] != stages[i] or r["returncode"] != 0 for i, r in enumerate(prefix))):
            raise SystemExit("Cannot reuse an unmatched or unsuccessful pipeline prefix")
        stage_records.extend(prefix)
    base = {
        "release_id": RELEASE_ID,
        "mode": args.mode,
        "mc_iterations": int(env["TES_N_MC"]),
        "python_executable": Path(sys.executable).name,
        "stage_count": len(stages),
        "resume_from": args.resume_from,
        "reused_successful_prefix_stages": stages[:resume_index],
        "executed_stages_this_invocation": stages[resume_index:],
        "stages": stage_records,
    }
    for index, stage in enumerate(stages, 1):
        if index <= resume_index:
            continue
        path = SRC / stage
        if not path.exists():
            base.update({"status": "FAIL", "failed_stage": stage, "error": "stage file missing", "elapsed_s": time.time() - started})
            write_status(base)
            raise SystemExit(f"Missing pipeline stage: {path}")
        print(f"\n=== [{index:02d}/{len(stages):02d}] {stage} ===", flush=True)
        t0 = time.time()
        result = subprocess.run([sys.executable, "-X", "faulthandler", "-u", str(path)], cwd=ROOT, env=env)
        record = {"index": index, "stage": stage, "returncode": result.returncode, "elapsed_s": round(time.time() - t0, 6)}
        stage_records.append(record)
        if result.returncode != 0:
            base.update({"status": "FAIL", "failed_stage": stage, "elapsed_s": round(time.time() - started, 6)})
            write_status(base)
            raise SystemExit(result.returncode)

    base.update({"status": "PASS", "failed_stage": None, "elapsed_s": round(time.time() - started, 6)})
    write_status(base)
    # The terminal status is itself supplied in the package. Refresh the
    # manifest after writing it so its hash describes the delivered bytes.
    if stages[-1] == "write_package_manifest.py":
        subprocess.run([sys.executable, str(SRC / stages[-1])], cwd=ROOT, env=env, check=True)
    print(json.dumps({"status": "PASS", "release_id": RELEASE_ID, "mode": args.mode, "mc_iterations": int(env["TES_N_MC"]), "elapsed_s": base["elapsed_s"]}, indent=2))


if __name__ == "__main__":
    main()
