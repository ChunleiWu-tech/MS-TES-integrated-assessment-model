"""Deterministic standalone v4 diagnostics; no pipeline or engineering mutation."""
import argparse
from pathlib import Path
from thermophysical_model_v4 import run

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    run(args.root)
