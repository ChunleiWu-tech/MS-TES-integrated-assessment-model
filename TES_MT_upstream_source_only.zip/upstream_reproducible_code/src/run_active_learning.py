from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(Path(__file__).resolve().parent) not in sys.path:
    sys.path.insert(0, str(Path(__file__).resolve().parent))
from active_learning_engine import run

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run uncertainty-aware active learning")
    parser.add_argument("--draws", type=int, default=int(os.environ.get("TES_N_MC", "20000")))
    parser.add_argument("--seed", type=int, default=760076)
    parser.add_argument("--max-actions", type=int, default=6)
    parser.add_argument("--output-dir", type=Path, default=None)
    parser.add_argument("--no-trace", action="store_true", help="Skip the large action trace")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    status = run(
        ROOT,
        n_draws=args.draws,
        seed=args.seed,
        max_actions=args.max_actions,
        output_dir=args.output_dir,
        write_trace=not args.no_trace,
    )
    print(json.dumps(status, indent=2))
