"""Deterministic standalone entry point; leaves the historical v2 pipeline intact."""
import argparse,json
from pathlib import Path
from thermophysical_model_v3 import run

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    args=parser.parse_args()
    result=run(args.root)
    print(json.dumps({'summary_rows':len(result),'output_directory':str(args.root/'outputs/tables')},indent=2))
