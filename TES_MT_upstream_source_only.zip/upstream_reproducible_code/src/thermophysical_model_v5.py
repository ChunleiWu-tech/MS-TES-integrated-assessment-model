"""Positive, temperature-decreasing density and fixed-fit source calibration.

Only fitting sources determine constitutive parameters and model selection.
The assessed database curves are deterministic targets, not experimental repeats.
"""
from pathlib import Path
import hashlib, json
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
from sklearn.ensemble import HistGradientBoostingRegressor
import thermophysical_model_v3 as base

SEEDS = (760076, 760177, 760278, 760379, 760480)
CAL_GROUPS = 19
MIN_FIT = 8
T_REF = 1000.0
T_SCALE = 1000.0


class ConstitutiveDensity:
    """rho=exp(a(x)-exp(b(x))*(T-Tref)/Tscale); x excludes temperature.

    Each fitting curve supplies a log-linear intercept and negative slope.
    Exponentiating the predicted slope parameter enforces positivity and a
    decreasing density at every representable temperature, before testing.
    """
    def __init__(self, kind):
        self.kind = kind

    def fit(self, frame):
        if self.kind=='monotone_boosting':
            x=np.asarray(frame.features.tolist(),float)
            self.model=HistGradientBoostingRegressor(max_iter=120,max_leaf_nodes=15,
                min_samples_leaf=15,l2_regularization=10.,learning_rate=.1,
                monotonic_cst=[0]*(x.shape[1]-1)+[-1],early_stopping=False,random_state=SEEDS[0])
            self.model.fit(x,np.log(frame.target_value.to_numpy()),sample_weight=base.weights(frame))
            return self
        rows = []
        for curve, g in frame.groupby('curve_id', sort=True):
            t = (g.temperature_K.to_numpy()-T_REF)/T_SCALE
            slope, intercept = np.polyfit(t, np.log(g.target_value.to_numpy()), 1)
            if slope >= 0:
                raise ValueError('Nondecreasing fitting source is outside this constitutive family')
            rows.append(dict(curve_id=curve, publication_component=g.publication_component.iloc[0],
                             features=g.features.iloc[0][:-1], a=intercept, b=np.log(-slope)))
        f = pd.DataFrame(rows)
        x = np.asarray(f.features.tolist(), float)
        w = base.weights(f)
        self.models = [base.fit_model(base.estimators()[self.kind], x, f[c].to_numpy(), w) for c in ('a','b')]
        return self

    def log_predict(self, x):
        if self.kind=='monotone_boosting':return self.model.predict(x)
        a, b = [m.predict(x[:,:-1]) for m in self.models]
        return a-base.positive_exp(b)*(x[:,-1]-T_REF)/T_SCALE

    def predict(self, x):
        return base.positive_exp(self.log_predict(x))


def select_density(frame, groups):
    choices = {}
    x = np.asarray(frame.features.tolist(), float)
    y = frame.target_value.to_numpy(float)
    for kind in list(base.estimators())+['monotone_boosting']:
        p = np.full(len(frame), np.nan)
        for tr, te in GroupKFold(n_splits=min(3,len(set(groups)))).split(x,y,groups):
            p[te] = ConstitutiveDensity(kind).fit(frame.iloc[tr]).predict(x[te])
        errors = pd.DataFrame({'g':groups,'e':abs(y-p)})
        choices[kind] = float(errors.groupby('g').e.mean().mean()) if np.isfinite(p).all() else np.inf
    return min(choices,key=choices.get), choices


def evaluate(frame, target, scheme, seed):
    frame = frame.reset_index(drop=True)
    x = np.asarray(frame.features.tolist(),float); y = frame.target_value.to_numpy(float)
    groups = base.graph_groups(frame, joint=scheme=='joint_publication_formula')
    ng = len(set(groups)); density = target=='density_kg_m3'; log_fit=target=='viscosity_mPa_s'
    native_y=np.log(y) if log_fit else y
    folds, predictions = [], []
    if ng < 2: return folds,predictions
    for fold,(outer,test) in enumerate(GroupKFold(n_splits=min(5,ng)).split(x,y,groups),1):
        order=np.random.default_rng(seed+fold).permutation(np.asarray(sorted(set(groups[outer])),object))
        supported=len(order)>=CAL_GROUPS+MIN_FIT
        cal=outer[np.isin(groups[outer],order[:CAL_GROUPS])] if supported else np.array([],int)
        fit=outer[~np.isin(groups[outer],order[:CAL_GROUPS])] if supported else np.array([],int)
        for column in ['publication_component']+(['formula_system'] if scheme=='joint_publication_formula' else []):
            sets=[set(frame.iloc[idx][column]) for idx in (fit,cal,test)]
            assert not any(sets[i]&sets[j] for i,j in ((0,1),(0,2),(1,2)))
        models={}; selection={}
        if supported:
            kind,scores=base.select_model(frame.iloc[fit],x[fit],native_y[fit],groups[fit])
            models['unconstrained']=base.fit_model(base.estimators()[kind],x[fit],native_y[fit],base.weights(frame.iloc[fit]))
            selection['unconstrained']=(kind,scores)
            if density:
                kind,scores=select_density(frame.iloc[fit].reset_index(drop=True),groups[fit])
                models['constitutive_density']=ConstitutiveDensity(kind).fit(frame.iloc[fit])
                selection['constitutive_density']=(kind,scores)
        for family in (['unconstrained','constitutive_density'] if density else ['unconstrained']):
            pred=np.full(len(test),np.nan); score=np.array([]); native_pred=pred.copy()
            if supported:
                model=models[family]
                native_pred=model.predict(x[test]); cal_pred=model.predict(x[cal])
                if log_fit: pred=base.positive_exp(native_pred)
                else: pred=native_pred.copy()
                residual=abs(native_y[cal]-cal_pred)
                score=pd.DataFrame({'g':groups[cal],'res':residual}).groupby('g').res.max().to_numpy()
                assert len(score)==CAL_GROUPS
            ad,dist,threshold=base.applicability(frame,x,fit,test,not target.startswith('melting_temperature_K')) if supported else (np.zeros(len(test),bool),np.full(len(test),np.nan),np.nan)
            for coverage in base.COVERAGES:
                q,rank=base.group_quantile(score,coverage) if supported else (np.nan,np.nan)
                lower=base.positive_exp(native_pred-q) if log_fit else pred-q
                upper=base.positive_exp(native_pred+q) if log_fit else pred+q
                finite=np.isfinite(pred)&(pred>0)&np.isfinite(lower)&np.isfinite(upper)
                covered=finite&(y[test]>=lower)&(y[test]<=upper)
                record=dict(target=target,validation_scheme=scheme,seed=seed,fold=fold,model_family=family,
                            nominal_coverage=coverage,allocation_supported=supported,n_fit_groups=len(set(groups[fit])),
                            n_calibration_groups=len(set(groups[cal])),n_test_groups=len(set(groups[test])),
                            selected_model=selection[family][0] if supported else '',
                            inner_scores=json.dumps(selection[family][1]) if supported else '{}',
                            conformal_rank=rank,conformal_half_width=q,ad_threshold=threshold)
                for label,idx in [('fit',fit),('calibration',cal),('test',test)]:
                    record[label+'_blocking_component_ids']=json.dumps(sorted(set(groups[idx])))
                    record[label+'_publication_ids']=json.dumps(sorted(set(frame.iloc[idx].publication_component)))
                folds.append(record)
                for j,idx in enumerate(test):
                    r=frame.iloc[idx]
                    predictions.append(dict(target=target,validation_scheme=scheme,seed=seed,fold=fold,
                        model_family=family,nominal_coverage=coverage,curve_id=r.curve_id,formula=r.formula,
                        composition=r.composition,publication_component=r.publication_component,blocking_component=groups[idx],
                        temperature_K=r.temperature_K,observed_database_target=y[idx],prediction=pred[j],
                        lower=lower[j],upper=upper[j],finite_interval=bool(finite[j]),covered=bool(covered[j]),
                        ad_accepted=bool(ad[j]),released_diagnostic_prediction=bool(ad[j]&finite[j]),
                        allocation_supported=supported,ad_distance=dist[j],conformal_score=q))
        print(target,scheme,seed,fold,'supported' if supported else 'abstain',flush=True)
    return folds,predictions


def summarize(p):
    rows=[]
    keys=['target','validation_scheme','seed','model_family','nominal_coverage']
    for key,g in p.groupby(keys):
        e=abs(g.observed_database_target-g.prediction)
        support=g.finite_interval; ng=g.blocking_component.nunique()
        source=g.assign(err=e).groupby('blocking_component')
        row=dict(zip(keys,key)); row.update(n_grid_points=len(g),n_curves=g.curve_id.nunique(),n_groups=ng,
            predicted_points=int(np.isfinite(g.prediction).sum()),finite_points=int(support.sum()),
            finite_entire_groups=int(source.finite_interval.all().sum()),point_MAE=float(e.mean()),
            source_macro_MAE=float(source.err.mean().mean()),point_coverage=float(g.covered.mean()),
            source_macro_point_coverage=float(source.covered.mean().mean()),
            whole_source_coverage=float(source.covered.all().mean()),
            wholly_finite_source_coverage=float(source.covered.all()[source.finite_interval.all()].mean()),
            allocation_supported_points=int(g.allocation_supported.sum()),
            mean_width=float((g.upper-g.lower)[support].mean()),
            finite_support_fraction=float(support.mean()))
        if key[0]=='density_kg_m3':
            increments=[np.diff(z.sort_values('temperature_K').prediction) for _,z in g.groupby('curve_id') if np.isfinite(z.prediction).all()]
            row.update(n_finite_curves=len(increments),n_increasing_curves=sum(bool(np.any(v>1e-9)) for v in increments),
                       largest_positive_step=max([0.]+[float(v.max()) for v in increments]))
        rows.append(row)
    return pd.DataFrame(rows)


def run(root):
    root=Path(root);out=root/'outputs/tables';out.mkdir(parents=True,exist_ok=True)
    records,ledger,sources,aliases=base.build_records(root)
    settings=dict(version='v5',seeds=SEEDS,primary_seed=SEEDS[0],calibration_groups=CAL_GROUPS,minimum_fit_groups=MIN_FIT,
        temperature_reference_K=T_REF,temperature_scale_K=T_SCALE,
        model_selection='Three fitting-only GroupKFold splits; blocking-component macro absolute error; fixed candidate settings',
        density_selection='Positive monotone family: median/ridge/ExtraTrees constitutive parameter regressors and log-density monotone histogram boosting; fitting-only selection',
        monotone_boosting_settings=dict(max_iter=120,max_leaf_nodes=15,min_samples_leaf=15,l2_regularization=10.,learning_rate=.1,early_stopping=False),
        development_scope='Retrospective source-blocked model development; candidate family extended after checking constitutive-model diagnostics; not a prospective untouched validation study',
        comparison='Identical outer tests, fitting and calibration sources for constrained/unconstrained and nominal90/95',
        density_positivity='exp(a(x)-exp(b(x))*(T-1000)/1000); no test-point sorting, clipping or outcome deletion',
        interval_scale='density and melting in physical units; viscosity natural logarithm',
        density_band='Additive grid bands may have negative lower endpoints; endpoints are not clipped or constitutive functions',
        exchangeability='Required for finite-sample interpretation; empirical source/chemistry tests do not establish arbitrary transfer guarantees',
        seed_stability='Five target-blind calibration allocations, overlapping outer tests; ranges are not independent confidence intervals',
        curve_target_status='Five deterministic grid values per assessed source correlation; not independent measured replicates',
        engineering_evidence_imputed=False,candidate_predictions_produced=False,
        input_sha256=hashlib.sha256((root/'data/raw_databases/msd-tp-master.zip').read_bytes()).hexdigest(),
        helper_sha256=hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest())
    # Write settings before fitting; none is selected by test outcomes.
    (out/'core_thermophysical_v5_model_card.json').write_text(json.dumps(settings,indent=2),encoding='utf-8')
    ledger.to_csv(out/'core_thermophysical_v5_record_ledger.csv',index=False)
    sources.to_csv(out/'core_thermophysical_v5_publication_ledger.csv',index=False)
    folds=[];predictions=[]
    for prop,(target,unit) in base.TARGETS.items():
        sub=records[records.target.eq(target)]
        if sub.empty:continue
        variants=[(target,sub)]
        if prop=='melt':variants.append((target+'_literature_only',sub[sub.target_origin.ne('calculated_MSTDB_TC')]))
        for label,frame in variants:
            for scheme in ['publication_component','joint_publication_formula']:
                for seed in (SEEDS if prop=='density' else SEEDS[:1]):
                    f,p=evaluate(frame,label,scheme,seed);folds.extend(f);predictions.extend(p)
    f=pd.DataFrame(folds);p=pd.DataFrame(predictions);s=summarize(p)
    for label,data in [('folds',f),('oof_predictions',p),('summary',s)]:
        data.to_csv(out/('core_thermophysical_v5_'+label+'.csv'),index=False)
    status=dict(status='PASS_WITH_EXPLICIT_LIMITATIONS',new_experiments=0,source_disjoint_assertions=True,
        fixed_fit_across_coverage_levels=True,physics_constraint_fitted=True,calibration_rank_clipped=False,
        finite_sample_scope='specified five-point grid of an exchangeable blocking component',
        unsupported_fold_allocations=int((~f.allocation_supported).sum()))
    (out/'core_thermophysical_v5_quality_control.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    print(s.to_string(index=False),flush=True)
    return s

if __name__=='__main__':run(Path(__file__).resolve().parents[1])
