"""Coverage-specific publication calibration allocation; diagnostic targets only.

The immutable v3 parser, source identities, quarantine and fitting primitives are
reused explicitly. No v3 output is overwritten and no engineering gate is read.
"""
from pathlib import Path
from collections import Counter
import hashlib, json, math
import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold
import thermophysical_model_v3 as base

SEED = base.SEED
COVERAGES = base.COVERAGES
MIN_FIT_GROUPS = 8
CALIBRATION_GROUPS = {0.90: 9, 0.95: 19}

METHODS = '''# Thermophysical v4: source-calibration allocation

This standalone module diagnoses existing database targets; it introduces no new
experiment and supplies no engineering qualification or action evidence. The v3
parser, conservative provenance graph, molecular-weight/unit quarantine, chemical
features, source-balanced weighting and fixed candidate family are read-only
dependencies. The v3 source hash is recorded; v3 outputs remain unchanged.

Full-precision JSON coefficients and stated applicable ranges define five fixed
temperature-grid values per source correlation. Five values are not five experiments.
Literature-only melting excludes the explicitly MSTDB-TC calculated labels, but does
not assert that every remaining assessed/tabulated value is a direct measurement.
Surface tension remains unsupported because its equation/sign/unit is not verified.
The retained heat-capacity data and conductivity data are too source-sparse for the
declared fitting-plus-calibration allocation. No equation, unit or target is invented.

Explicit DOI/URL and exact full-citation aliases define publication components;
text-only citations retain inspectable identities. Known Yingling aliases are joined
using verified article identity. The joint scheme joins publication and formula
systems transitively, preserving giant components. Unresolved compilation/laboratory
overlap remains a provenance limitation. These are publication identities, not proof
of independence between every original experiment underlying a compilation.

Fixed GroupKFold outer tests are identical to v3 for every previously evaluated target.
Within each outer training partition, sorted blocking-component identities are
permuted with the fixed seed+fold, without targets or test outcomes. For 90%, exactly
9 complete calibration components are reserved; for 95%, exactly19 are reserved.
At least8 fitting components must remain. These allocations are the predeclared
minimum solving ceil((G+1)c)<=G. With fewer than17 or27 outer training components,
respectively, the entire fold/coverage allocation abstains. All its test records are
saved with missing predictions and coverage, never counted as covered observations.
The same identity ordering is used for both coverages. Separate coverage-specific
fitting and nested model selection are necessary because fitting support changes.
Calibration and test components are excluded from all model selection/fitting.

The fitting-only inner GroupKFold compares a weighted median, ridge(alpha10), and
ExtraTrees(80trees) with fixed settings. Equal publication total weight and equal
curve weight within publication prevent large correlations/compilations from
dominating fitting. Model selection uses macro blocking-component absolute error.
All viscosity candidates fit natural log(mu), so proportional errors receive
comparable importance throughout the corpus; all other targets retain physical
units. A clearly historical raw-viscosity baseline uses identical outer tests and
coverage-specific allocations. BeF2 remains retained: its extreme viscosity is
supported by the primary reference correlation, not discarded for prediction error.

Each entire calibration component contributes one maximum absolute residual over
its generated grid on the declared fitting scale. The exact order statistic is
k=ceil((G+1)c), with infinity when k>G; no rank clipping occurs. The minimal supported
allocations above use the calibration maximum (k=G). Log-viscosity intervals are
exp(log_prediction +/- q), with multiplicative radius exp(q). Exponentiation is
not clipped using outcomes; numeric overflow/underflow and nonpositive physical
point predictions cause explicit diagnostic abstention. Negative physical predictions
remain in error summaries, so removing failed predictions cannot improve accuracy.

Finite support, entire-component support, empirical point coverage, and empirical
whole-component/publication coverage are reported separately. Whole-component
coverage requires every retained grid target and interval in that component to be
finite; excluding a partially failed giant component must remain visible in the
complete-component denominator. Giant components can make point support look high
while only a few independent blocking components are supported. A finite but
extremely wide band does not establish practical predictive utility. The number
of calibration components is not a number of independent experimental replications.

The exact rank has its finite-sample interpretation under exchangeability of new
and calibration component scores. Publication blocking alone cannot establish that
assumption. Size-balanced GroupKFold tests and chemistry-connected tests are empirical
stress tests, not certified arbitrary-distribution-shift coverage. Repeated outer
fits/calibration sets overlap, so these pooled diagnostic coverage rates are not
independent trials supporting a naive binomial confidence interval. Coverage after
the fit-only applicability filter is empirical, without a selection-conditional
guarantee. Applicability fitting uses fitting curve centroids, element support and
temperature range only. It never modifies an engineering gate.

The paired comparison file computes v3 and v4 errors on the identical v4-supported
outer test records. Comparison also displays each version's finite-support fraction;
partial-subset accuracy must not be advertised as full-corpus improvement. Density
temperature monotonicity is a diagnostic of source relations and held-out predictions;
there is no post hoc sorting, correction or fitted constraint. Candidate predictions
remain withheld because their mole/mass fraction crosswalk is not authoritative.

Primary methodological and provenance evidence:

- Lei et al., Distribution-Free Predictive Inference for Regression:
  https://arxiv.org/abs/1604.04173
- Lee, Barber and Willett, Distribution-free inference with hierarchical data:
  https://arxiv.org/abs/2306.06342
- Barber et al., Conformal prediction beyond exchangeability:
  https://doi.org/10.1214/23-AOS2276
- Jin and Ren, Selection-conditional conformal prediction:
  https://academic.oup.com/jrsssb/article/87/4/1239/8113856
- ORNL/TM-2024/3575, assessed versus calculated MSTDB-TP targets:
  https://info.ornl.gov/sites/publications/Files/Pub222614.pdf
- Primary chemistry-informed molten-salt density study, explicit molar convention:
  https://pmc.ncbi.nlm.nih.gov/articles/PMC12677718/
- Primary2025 BeF2 reference correlation, Eq2 and Table6 confirm stored coefficients,
  temperature range and cP=mPa s units: https://www.osti.gov/biblio/3002723
  DOI10.1063/5.0264576; original coefficients attributed to Moynihan/Cantor1968.
'''


def allocate(groups, outer_train, fold, coverage):
    """Predeclared, target-blind permutation, shared across the two coverages.

    Exact minimum G solves ceil((G+1)*c)<=G. Reserving additional groups would
    reduce fitting support and is not selected by observing a test outcome.
    """
    available = np.asarray(sorted(set(groups[outer_train])), dtype=object)
    order = np.random.default_rng(SEED + fold).permutation(available)
    required = CALIBRATION_GROUPS[coverage]
    if len(order) < required + MIN_FIT_GROUPS:
        return np.array([], int), np.array([], int), order, False
    calibration = set(order[:required])
    cal = outer_train[np.isin(groups[outer_train], list(calibration))]
    fit = outer_train[~np.isin(groups[outer_train], list(calibration))]
    return fit, cal, order, True


def evaluate(frame, target, scheme):
    frame = frame.reset_index(drop=True)
    X = np.asarray(frame.features.tolist(), float)
    y = frame.target_value.to_numpy(float)
    log_fit = target == 'viscosity_mPa_s'
    native_y = np.log(y) if log_fit else y
    scale = 'natural_log_viscosity' if log_fit else 'physical_units'
    groups = base.graph_groups(frame, joint=scheme == 'joint_publication_formula')
    sizes = Counter(groups)
    ng = len(sizes)
    status = dict(target=target, validation_scheme=scheme,
                  n_publication_components=frame.publication_component.nunique(),
                  n_blocking_components=ng, n_source_curves=frame.curve_id.nunique(),
                  n_generated_grid_points=len(frame),
                  largest_component_point_fraction=max(sizes.values())/len(frame),
                  component_sizes_descending=json.dumps(sorted(sizes.values(), reverse=True)),
                  status='outer_partitioned_coverage_specific_support' if ng >= 2 else 'inadequate_no_independent_outer_test')
    folds, oof, metrics = [], [], []
    if ng < 2:
        return folds, oof, metrics, status
    # Identical outer tests to v3 whenever v3 was evaluable; small targets also
    # receive complete outer ledgers, but never manufacture fitting support.
    for fold, (outer_train, test) in enumerate(GroupKFold(n_splits=min(5, ng)).split(X, y, groups), 1):
        for coverage in COVERAGES:
            fit, cal, order, supported = allocate(groups, outer_train, fold, coverage)
            rowbase = dict(target=target, validation_scheme=scheme, fold=fold,
                           nominal_coverage=coverage, fitting_scale=scale,
                           n_available_outer_training_groups=len(order),
                           required_calibration_groups=CALIBRATION_GROUPS[coverage],
                           minimum_fit_groups=MIN_FIT_GROUPS,
                           allocation_group_order=json.dumps(order.tolist()),
                           n_fit_groups=len(set(groups[fit])), n_calibration_groups=len(set(groups[cal])),
                           n_test_groups=len(set(groups[test])),
                           n_fit_curves=frame.iloc[fit].curve_id.nunique(),
                           n_calibration_curves=frame.iloc[cal].curve_id.nunique(),
                           n_test_curves=frame.iloc[test].curve_id.nunique(),
                           allocation_supported=supported)
            for label, idx in [('fit', fit), ('calibration', cal), ('test', test)]:
                rowbase[label+'_blocking_component_ids'] = json.dumps(sorted(set(groups[idx])))
                rowbase[label+'_publication_ids'] = json.dumps(sorted(set(frame.iloc[idx].publication_component)))
                rowbase[label+'_formula_system_ids'] = json.dumps(sorted(set(frame.iloc[idx].formula_system)))
            selected, inner_scores = '', {}
            native_pred = np.full(len(test), np.nan)
            pred = lower = upper = np.full(len(test), np.nan)
            accepted = np.zeros(len(test), bool)
            distance = np.full(len(test), np.nan)
            finite = np.zeros(len(test), bool)
            covered = np.full(len(test), np.nan)
            q, rank, radius, threshold = np.nan, np.nan, np.nan, np.nan
            reason = 'abstain_insufficient_independent_fit_and_calibration_groups'
            if supported:
                for column in ['publication_component'] + (['formula_system'] if scheme == 'joint_publication_formula' else []):
                    a, b, c = (set(frame.iloc[idx][column]) for idx in [fit, cal, test])
                    assert not (a & b or a & c or b & c)
                assert len(set(groups[fit])) >= MIN_FIT_GROUPS
                assert len(set(groups[cal])) == CALIBRATION_GROUPS[coverage]
                selected, inner_scores = base.select_model(frame.iloc[fit], X[fit], native_y[fit], groups[fit])
                models = {name: base.fit_model(est, X[fit], native_y[fit], base.weights(frame.iloc[fit]))
                          for name, est in base.estimators().items()}
                model = models[selected]
                native_pred = model.predict(X[test])
                pred = base.positive_exp(native_pred) if log_fit else native_pred
                scores = pd.DataFrame({'group': groups[cal], 'residual': abs(native_y[cal]-model.predict(X[cal]))}).groupby('group').residual.max().to_numpy()
                q, rank = base.group_quantile(scores, coverage)
                assert np.isfinite(q) and rank == len(scores)  # Exact maximum, never a clipped rank.
                lower = base.positive_exp(native_pred-q) if log_fit else pred-q
                upper = base.positive_exp(native_pred+q) if log_fit else pred+q
                radius = float(base.positive_exp(q)) if log_fit else np.nan
                finite = np.isfinite(lower) & np.isfinite(upper) & np.isfinite(pred) & (pred > 0)
                covered = ((y[test] >= lower) & (y[test] <= upper)).astype(float)
                accepted, distance, threshold = base.applicability(frame, X, fit, test, not target.startswith('melting_temperature_K'))
                reason = ('partly_abstain_nonrepresentable_or_nonpositive_prediction' if not finite.all() else
                          'finite_log_group_max' if log_fit else 'finite_group_max')
                for name, fitted in models.items():
                    mp = fitted.predict(X[test]); rawmp = base.positive_exp(mp) if log_fit else mp
                    metrics.append(dict(target=target, validation_scheme=scheme, fold=fold,
                                        nominal_coverage=coverage, model=name, selected_by_inner_fit=name == selected,
                                        fitting_scale=scale, **base.errors(frame.iloc[test], rawmp, groups[test], mp if log_fit else None)))
            released = accepted & finite
            extra = base.errors(frame.iloc[test], pred, groups[test], native_pred if log_fit else None) if supported else {}
            folds.append(dict(**rowbase, selected_model=selected,
                              inner_selection_criterion='blocking_component_macro_absolute_natural_log_error' if log_fit else 'blocking_component_macro_absolute_physical_error',
                              inner_blocking_component_macro_MAE=json.dumps(inner_scores, sort_keys=True),
                              conformal_rank=rank, conformal_half_width=q, multiplicative_radius=radius,
                              interval_status=reason, ad_threshold=threshold,
                              finite_interval_fraction=float(finite.mean()), **extra))
            for j, idx in enumerate(test):
                r = frame.iloc[idx]
                log_prediction = native_pred[j] if log_fit else (float(np.log(pred[j])) if np.isfinite(pred[j]) and pred[j] > 0 else np.nan)
                oof.append(dict(target=target, validation_scheme=scheme, fold=fold, nominal_coverage=coverage,
                                curve_id=r.curve_id, publication_component=r.publication_component,
                                blocking_component=groups[idx], formula_system=r.formula_system,
                                temperature_K=r.temperature_K, observed_database_target=y[idx],
                                allocation_supported=supported, fitting_scale=scale,
                                prediction=pred[j], log_prediction=log_prediction, lower=lower[j], upper=upper[j],
                                covered=covered[j], conformal_score=q, multiplicative_radius=radius,
                                finite_interval=bool(finite[j]), ad_accepted=bool(accepted[j]), ad_distance=distance[j],
                                prediction_status=('released_diagnostic' if released[j] else reason if not supported else
                                                   'abstain_numeric_or_nonpositive_prediction' if not finite[j] else 'abstain_fit_only_applicability'),
                                released_diagnostic_prediction=bool(released[j])))
    return folds, oof, metrics, status


def summary_table(p):
    rows = []
    for (target, scheme, coverage), g in p.groupby(['target', 'validation_scheme', 'nominal_coverage']):
        finite = g.finite_interval.to_numpy(bool)
        support = g.allocation_supported.to_numpy(bool)
        finite_group = g.groupby('blocking_component').finite_interval.all()
        supported_group = g.groupby('blocking_component').allocation_supported.all()
        supported_pub = g.groupby('publication_component').allocation_supported.all()
        # Only a completely finite component can contribute whole-component
        # coverage; NaN.all() on abstained records must not count as success.
        gcov = g.loc[finite].groupby('blocking_component').covered.min()
        pubfinite = g.groupby('publication_component').finite_interval.all()
        pubcov = g.loc[finite].groupby('publication_component').covered.min()
        sub = g.loc[support & np.isfinite(g.prediction.to_numpy())]
        metrics = base.errors(pd.DataFrame({'target_value': sub.observed_database_target,
                                            'curve_id': sub.curve_id, 'publication_component': sub.publication_component}),
                              sub.prediction.to_numpy(), sub.blocking_component.to_numpy(),
                              sub.log_prediction.to_numpy()) if len(sub) else {}
        accepted = g.released_diagnostic_prediction.to_numpy(bool)
        rows.append(dict(target=target, validation_scheme=scheme, nominal_coverage=coverage,
                         fitting_scale=g.fitting_scale.iloc[0], historical_raw_scale_baseline=target.endswith('_raw_scale_baseline'),
                         n_source_curves=g.curve_id.nunique(), n_generated_grid_points=len(g),
                         n_blocking_components=g.blocking_component.nunique(), n_publication_components=g.publication_component.nunique(),
                         allocation_supported_point_fraction=float(support.mean()),
                         allocation_supported_component_fraction=float(supported_group.mean()),
                         allocation_supported_publication_fraction=float(supported_pub.mean()),
                         n_supported_blocking_components=int(supported_group.sum()),
                         finite_interval_fraction=float(finite.mean()), finite_component_fraction=float(finite_group.mean()),
                         finite_publication_fraction=float(pubfinite.mean()),
                         finite_only_point_coverage=float(g.loc[finite, 'covered'].mean()) if finite.any() else np.nan,
                         finite_only_whole_component_coverage=float(gcov.reindex(finite_group[finite_group].index).mean()) if finite_group.any() else np.nan,
                         finite_only_whole_publication_coverage=float(pubcov.reindex(pubfinite[pubfinite].index).mean()) if pubfinite.any() else np.nan,
                         n_finite_blocking_components=int(finite_group.sum()),
                         finite_mean_interval_width=float((g.loc[finite, 'upper']-g.loc[finite, 'lower']).mean()) if finite.any() else np.nan,
                         finite_mean_multiplicative_radius=float(g.loc[finite, 'multiplicative_radius'].mean()) if finite.any() and target == 'viscosity_mPa_s' else np.nan,
                         ad_acceptance_fraction=float(g.ad_accepted.mean()), released_diagnostic_fraction=float(accepted.mean()),
                         released_diagnostic_point_coverage=float(g.loc[accepted, 'covered'].mean()) if accepted.any() else np.nan,
                         error_denominator='allocation-supported numerically finite predictions, including nonpositive failures', **metrics))
    return pd.DataFrame(rows)


def compare_v3(p, old, summary):
    keys = ['target', 'validation_scheme', 'fold', 'nominal_coverage', 'curve_id', '_T']
    new = p.copy(); old = old.copy()
    for df in [new, old]: df['_T'] = df.temperature_K.fillna(-1).round(10)
    paired = new.merge(old, on=keys, suffixes=('_v4', '_v3'), how='left', validate='one_to_one', indicator=True)
    # Every target evaluated by v3 must retain exactly its outer test identities.
    old_targets = set(old.target)
    assert paired.loc[paired.target.isin(old_targets), '_merge'].eq('both').all()
    rows = []
    for (target, scheme, coverage), g in paired.groupby(['target', 'validation_scheme', 'nominal_coverage']):
        eligible = g.allocation_supported & np.isfinite(g.prediction_v4) & g['_merge'].eq('both')
        sub = g.loc[eligible]
        row = dict(target=target, validation_scheme=scheme, nominal_coverage=coverage,
                   same_outer_test_identity_verified=bool(g['_merge'].eq('both').all()),
                   paired_supported_grid_points=len(sub), paired_supported_publications=sub.publication_component_v4.nunique(),
                   v3_finite_interval_fraction=float(g.finite_interval_v3.fillna(False).mean()),
                   v4_finite_interval_fraction=float(g.finite_interval_v4.mean()))
        if len(sub):
            frame = pd.DataFrame({'target_value': sub.observed_database_target_v4,
                                  'curve_id': sub.curve_id, 'publication_component': sub.publication_component_v4})
            for version in ['v3', 'v4']:
                e = base.errors(frame, sub['prediction_'+version].to_numpy(), sub.blocking_component_v4.to_numpy(), sub['log_prediction_'+version].to_numpy())
                row.update({version+'_paired_'+k: v for k, v in e.items()})
        rows.append(row)
    return pd.DataFrame(rows)


def density_monotonicity(p):
    """Diagnostic only: no post hoc sorting, clipping or constrained replacement."""
    rows = []
    d = p[p.target.eq('density_kg_m3') & p.allocation_supported]
    for key, g in d.groupby(['validation_scheme', 'nominal_coverage', 'curve_id']):
        g = g.sort_values('temperature_K')
        actual = np.diff(g.observed_database_target.to_numpy())
        predicted = np.diff(g.prediction.to_numpy())
        rows.append(dict(validation_scheme=key[0], nominal_coverage=key[1], curve_id=key[2],
                         publication_component=g.publication_component.iloc[0],
                         observed_relation_nonincreasing=bool(np.all(actual <= 1e-10)),
                         prediction_nonincreasing=bool(np.all(predicted <= 1e-10)),
                         maximum_predicted_step_increase_kg_m3=float(predicted.max())))
    return pd.DataFrame(rows)


def run(root):
    root = Path(root); out = root/'outputs/tables'; out.mkdir(parents=True, exist_ok=True)
    prefix = 'core_thermophysical_v4_'
    records, ledger, sources, manual = base.build_records(root)
    ledger.to_csv(out/(prefix+'record_ledger.csv'), index=False, encoding='utf-8-sig')
    sources.to_csv(out/(prefix+'publication_ledger.csv'), index=False, encoding='utf-8-sig')
    folds, predictions, models, statuses = [], [], [], []
    for prop, (target, unit) in base.TARGETS.items():
        df = records[records.target.eq(target)].copy()
        if df.empty:
            statuses.append(dict(target=target, unit=unit, status='unsupported_or_no_retained_records', n_source_curves=0)); continue
        variants = [(target, df)]
        if prop == 'melt': variants.append((target+'_literature_only', df[df.target_origin.ne('calculated_MSTDB_TC')].copy()))
        if prop == 'viscosity': variants.append((target+'_raw_scale_baseline', df.copy()))
        for label, sub in variants:
            for scheme in ['publication_component', 'joint_publication_formula']:
                print(f'{label}: {scheme}; {sub.curve_id.nunique()} curves', flush=True)
                f, p, m, s = evaluate(sub, label, scheme)
                folds.extend(f); predictions.extend(p); models.extend(m); statuses.append(s)
    f, p, m, s = map(pd.DataFrame, [folds, predictions, models, statuses])
    summary = summary_table(p)
    comparison = compare_v3(p, pd.read_csv(out/'core_thermophysical_v3_oof_predictions.csv'), summary)
    monotonic = density_monotonicity(p)
    for name, df in [('folds', f), ('oof_predictions', p), ('model_comparison', m), ('status', s),
                     ('summary', summary), ('v3_comparison', comparison), ('density_monotonicity', monotonic)]:
        df.to_csv(out/(prefix+name+'.csv'), index=False, encoding='utf-8-sig')
    card = json.loads((out/'core_thermophysical_v3_model_card.json').read_text(encoding='utf-8'))
    card.update(version='v4', allocation={'90%': {'calibration_groups': 9, 'minimum_fit_groups': 8},
                                         '95%': {'calibration_groups': 19, 'minimum_fit_groups': 8},
                                         'rule': 'sorted outer training identities; fixed seed+fold permutation independent of targets; first G calibration, remainder fitting; abstain if fewer than G+8'},
                coverage_specific_refitting=True, outer_tests='identical GroupKFold partitions to v3; added complete abstention ledgers for small targets',
                no_supported_group_fraction_is_success_rate=True,
                shared_v3_helpers='read-only parser, provenance graph, quarantine, feature and model primitives',
                helper_source_sha256=hashlib.sha256(Path(base.__file__).read_bytes()).hexdigest(),
                paired_comparison='v3 and v4 errors compared on identical v4-supported outer test points; conditional support explicitly reported',
                composition_basis='molar convention; >5% chemically implied versus stored molecular-weight discrepancy quarantined',
                density_monotonicity='diagnostic only, no fitted predictor modified after testing')
    card['empirical_validation_limit'] = ('Size-balanced GroupKFold and connected-chemistry tests do not certify exchangeability; pooled cross-validation rates are descriptive, not independent binomial trials or guaranteed selected coverage.')
    (out/(prefix+'model_card.json')).write_text(json.dumps(card, indent=2, ensure_ascii=False), encoding='utf-8')
    (out/(prefix+'method_review.md')).write_text(METHODS, encoding='utf-8')
    qc = dict(status='PASS_WITH_EXPLICIT_LIMITATIONS', retained_source_curves=int(ledger.status.eq('retained').sum()),
              n_generated_grid_points=len(records), curation_counts=ledger.status.value_counts().to_dict(),
              source_disjoint_assertions='passed_in_all_supported_folds',
              supported_folds=int(f.allocation_supported.sum()), abstained_folds=int((~f.allocation_supported).sum()),
              total_fold_coverage_allocations=len(f), engineering_evidence_imputed=False, candidate_predictions_produced=False,
              partly_numeric_or_nonpositive_prediction_folds=int(f.interval_status.eq('partly_abstain_nonrepresentable_or_nonpositive_prediction').sum()),
              exact_rank_clipped=False, density_constraint_imposed=False,
              interpretation='Finite intervals can remain wide; partial support and empirical coverage do not establish general chemistry transfer or engineering readiness.')
    (out/(prefix+'quality_control.json')).write_text(json.dumps(qc, indent=2), encoding='utf-8')
    return summary
