# Uncertainty-aware active-learning framework (v2)

**Release date:** 2026-09-26  
**Qualification environment:** supplied by the upstream and postprocess components in this integrated release.  
**Upgrade purpose:** add a sequential evidence-acquisition layer without changing the original non-compensatory gate rules.

## 1. Problem statement

The existing molten-salt assessment tells us whether a candidate-duty membership is supported by the evidence currently registered. The upgrade treats the next measurement as a decision problem: evidence is incomplete, actions have unequal costs, and a measurement can affect several memberships in the same duty.

For duty `d` and step `t`, the state is

`S_t = (D_t, Z_t, A_t, B_t, I_t)`

where:

- `D_t` is the evidence observed up to step `t`;
- `Z_t` is the gate-state matrix for the 36 candidate-duty memberships;
- `A_t, B_t` are Beta posterior parameters for the uncertain gate-success probabilities;
- `B_t` is the remaining action budget (the numerical experiments use 0–6 actions);
- `I_t` records hard, non-closable direct risks.

The state is a prospective simulation state. It must not be interpreted as new experimental evidence.

## 2. Actions and costs

The registered action space contains seven global measurement/verification campaigns:

| ID | Action | Dimension | Default cost units |
|---|---|---|---:|
| `a1_cp_full_range` | Full-range heat-capacity measurement | `thermal_cp` | 2.0 |
| `a2_density_full_range` | Full-range density measurement | `thermal_density` | 2.0 |
| `a3_corrosion_test` | Corrosion compatibility test | `corrosion` | 3.0 |
| `a4_cycle_phase_test` | Cycling/phase-stability test | `cycling_phase` | 2.0 |
| `a5_containment_validation` | Containment validation | `containment` | 2.5 |
| `a6_independent_replication` | Independent replication | `literature_replication` | 2.0 |
| `a7_data_completeness` | Data-integrity completion audit | `data_completeness` | 0.5 |

An action is global within the selected duty: one campaign produces a simulated observation for every still-unresolved, non-impossible membership. Costs are normalized burden units rather than monetary quotations.

## 3. Prior and posterior update

Existing low/mid/high triangular intervals are interpreted as decision priors. Their triangular mean is mapped to a Beta pseudo-prior with configurable strength `κ`:

`p̄ = (low + mid + high) / 3`

`α_0 = κ p̄`, `β_0 = κ (1 − p̄)`.

The default is `κ = 12`. This is an analytical pseudo-sample size, not a confidence interval and not a claim that the source ledger contains twelve observations.

For a simulated binary outcome `y_t ∈ {0,1}`:

`α_(t+1) = α_t + y_t`

`β_(t+1) = β_t + 1 − y_t`.

The posterior mean is `p_t = α_t/(α_t+β_t)`. A positive outcome closes that gate. A negative outcome is an observed disqualifier for that membership/action dimension in the prospective simulation. A registered `nonclosable_direct_risk` remains a hard exclusion and cannot be overturned by any action.

The latent truth is drawn from the registered triangular interval and receives a log-normal reliability perturbation (`σ = 0.08`) for Monte Carlo robustness. This perturbation is part of the simulation model, not a measurement-error estimate.

## 4. Qualification and rewards

For membership `i`, the formal candidate indicator is

`F_i(S_t) = 1[all seven gates are closed] × 1[nonclosable_direct_risk_i = 0]`.

The primary aggregate is the **formal candidate count**

`N_formal(S_t) = Σ_i F_i(S_t)`.

This is deliberately distinct from the **selection event**:

`E(S_t) = 1[N_formal(S_t) > 0]`.

Therefore:

- `formal_candidate_count` counts all formally qualified memberships;
- `selection_event` records whether at least one exists;
- `no_selection` is the complement of `selection_event`;
- `winner_system_id` reports the value-anchor winner among formal candidates, or `-1` when none exists.

This separation prevents the previous ambiguity in which “formal selection count” could be read either as a candidate count or as a binary event frequency.

The engine reports three compatible objective views:

1. `formal_candidate_count`: maximize expected number of formal candidates;
2. `selection_event_reduction`: prioritize actions that reduce no-selection probability;
3. `information_per_cost`: normalize the EIG score by action cost.

## 5. Policies

Four primary policies are compared on shared Monte Carlo worlds:

- **Random:** uniformly sample an available action.
- **Greedy unlock:** maximize the expected immediate final-gate unlock contribution.
- **EIG:** maximize expected Beta-posterior entropy reduction, weighted by the candidate value anchor.
- **EI:** maximize expected improvement in qualification probability, weighted by the candidate value anchor.

`uniform_budget` is an additional robustness baseline that follows the fixed action order rather than adapting to evidence.

The policies are myopic over a finite horizon of six actions. The experiment is not a claim of global optimality; it is an uncertainty-aware comparison of practical next-measurement rules.

## 6. Monte Carlo and paired tests

The canonical protocol contains 7 duties, 36 candidate-duty memberships, 4 primary strategies and budgets 0–6. The target is 20,000 draws per canonical strategy/duty combination. Random worlds are shared across strategies within a duty, which supports paired comparisons.

Outputs include:

- `active_learning_strategy_summary.csv`: budget–reward and efficiency statistics;
- `active_learning_action_trace.csv.gz`: one single gzip CSV stream containing each action, outcome, target count, posterior entropy before/after, formal candidate count, selection event, winner and cumulative cost;
- `active_learning_posterior_trajectory.csv`: mean posterior trajectory by duty, strategy, step and action;
- `active_learning_recommended_sequences.csv`: recommended sequences;
- `active_learning_statistical_tests.csv`: paired Wilcoxon tests versus `random` and, for EIG/EI, versus `greedy_unlock`.

The trace row count in `ACTIVE_LEARNING_STATUS.json` is the actual number of rows written and is re-read during validation. It is not a theoretical row-count estimate.

## 7. Robustness and ablation plan

The robustness runner writes each case to its own directory and never overwrites the canonical result. It covers:

- six-action budget horizon;
- global and action-specific cost perturbations;
- prior strength and prior-location shifts;
- alternate objectives;
- no-EIG and no-EI policy ablations;
- no-posterior-update ablation;
- coal-flexibility, CSP-sensible-storage and industrial-medium-heat cross-duty checks;
- uniform-budget baseline.

For the formal paper, all percentage differences and p-values must be taken from the final 20,000-draw canonical tables (and the registered robustness draw count), not from a smoke test.

## 8. Reproducibility and heavy-compute handoff

The independent directory `Active_Learning_Upgrade` contains the minimum code and input snapshot required to run this module on another Windows computer. Use:

```powershell
powershell -ExecutionPolicy Bypass -File .\RUN_ACTIVE_LEARNING.ps1 -Draws 20000 -RobustnessDraws 2000
```

The runner records Python/dependency metadata, stdout/stderr logs and a SHA-256 manifest. A 100-draw local run is intended only as a smoke test. If the 20,000-draw run is moved to a higher-specification computer, copy the whole package directory and bring back the complete run folder, including tables, trace, figures, logs, validation JSON and SHA-256 manifest.

## 9. Scope limitations

The upgraded layer is a decision simulation over the registered evidence ledger. It does not create new material measurements, does not relax the original direct-risk exclusions, and does not prove that EIG or EI is universally optimal. The case study is designed to test the framework under a finite budget; external validation remains necessary before operational deployment.
