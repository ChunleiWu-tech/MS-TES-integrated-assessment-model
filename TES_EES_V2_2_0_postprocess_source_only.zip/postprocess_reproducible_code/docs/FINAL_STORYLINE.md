# Scientific storyline

TES-EES-V2.2.0-20260909

Composition-specific evidence determines whether a material can be compared over the intended duty. Charging, delivery, capacity and circulation constraints then determine whether the measured enhancement changes a model design requirement.

## Main-figure sequence

1. Composition evidence defines the application comparison.
2. Complete-duty support changes material ranking.
3. Thermal and engineering constraints define different access regimes.
4. Pareto opportunity is broader than qualified material access.
5. Evidence dependencies determine measurement priorities.
6. Operating constraints govern the value of material enhancement.

## Complementary evidence

Supplementary Figures 1–7 resolve the library, property domains, pairwise comparisons and uncertainty. Figures 8–12 separate omission effects, score aggregation, readiness, evidence actions and diagnostic property-model validity. Figure 13 resolves nanoparticle and scaffold measurements. Figures 14–15 connect evidence actions and operating constraints. Figure 16 gives condition-specific corrosion and evidence-index sensitivity. Figure 17 supplies the independent calorimetric comparison.

The independent comparison uses previously unused Solar Salt enthalpy measurements over the shared 250–400 °C liquid interval. Its primary energy error is +3.86%, with a −3.72% fixed-energy material-mass error. The 36 endpoint intervals share nine measured means. They are not independent experiments. The retrospective chloride masking comparison remains separate. Constant-power chronological agreement is a numerical check, not device-scale validation.

The 0.504, 0.885 and 1.053 HITEC composite-to-base volume ratios describe prescribed 1/10, 8/16 and 8/2 h charge/delivery windows in a constant-power, lossless, capacity-constrained model. Nanoparticle fluids and stationary scaffolds retain their own experimental domains. No high-temperature engineering qualification is transferred from a lower-temperature device test.

## Panel and source map

FINAL_FIGURE_CAPTIONS.md contains the complete descriptions of all six main and seventeen supplementary figures. The final outputs/qa/figure_source_map.csv links all 23 figures to generated source tables. Data/Supplementary_Data in the submission package supplies criterion-level reasons, numerical checks and independent calorimetry provenance.
