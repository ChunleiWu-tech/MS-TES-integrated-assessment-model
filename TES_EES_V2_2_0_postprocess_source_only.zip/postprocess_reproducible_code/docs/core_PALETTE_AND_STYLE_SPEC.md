# core palette and style specification

- Native main-figure width: approximately 179 mm.
- Main panels: 4–6 per figure; balanced square layouts are preferred for dense multi-panel figures.
- Typography: Arial/Helvetica first; verify effective 6.5–7 pt labels at final journal width.
- Categorical colours are stable across figures; sequential scales are used only for ordered quantities and diverging scales only for signed effects.
- Legends are placed in true whitespace. Colour bars are horizontal when this reduces collision.
- Long category labels use horizontal bars. Sparse zero-rich matrices are replaced by ranked non-zero subsets, compositions or depth-response summaries.
- No ornamental gradients, 3-D effects or unsupported causal annotations.
