# Scientific storyline

TES-EES-V2.2.0-20260909

Composition-specific evidence determines whether a material can be compared over the intended duty. Charging, delivery, capacity and circulation constraints then determine whether the measured enhancement changes a model design requirement.

## Main-figure sequence

1. Composition evidence defines the application comparison.
2. Complete-duty support changes material ranking.
3. Thermal and engineering constraints define different access regimes.
4. Pareto opportunity is broader than qualified material access.
5. Evidence dependencies determine measurement priorities.
6. Operating constraints govern the value of material enhancement.

## Complementary evidence

Supplementary Figures 1–7 resolve the library, property domains, pairwise comparisons and uncertainty. Figures 8–12 separate omission effects, score aggregation, readiness, evidence actions and diagnostic property-model validity. Figure 13 resolves nanoparticle and scaffold measurements. Figures 14–15 connect evidence actions and operating constraints. Figure 16 gives condition-specific corrosion and evidence-index sensitivity. Figure 17 supplies the independent calorimetric comparison.

The independent comparison uses previously unused Solar Salt enthalpy measurements over the shared 250–400 °C liquid interval. Its primary energy error is +3.86%, with a −3.72% fixed-energy material-mass error. The 36 endpoint intervals share nine measured means. They are not independent experiments. The retrospective chloride masking comparison remains separate. Constant-power chronological agreement is a numerical check, not device-scale validation.

The 0.504, 0.885 and 1.053 HITEC composite-to-base volume ratios describe prescribed 1/10, 8/16 and 8/2 h charge/delivery windows in a constant-power, lossless, capacity-constrained model. Nanoparticle fluids and stationary scaffolds retain their own experimental domains. No high-temperature engineering qualification is transferred from a lower-temperature device test.

## Panel and source map

FINAL_FIGURE_CAPTIONS.md contains the complete descriptions of all six main and seventeen supplementary figures. The final outputs/qa/figure_source_map.csv links all 23 figures to generated source tables. Data/Supplementary_Data in the submission package supplies criterion-level reasons, numerical checks and independent calorimetry provenance.

# Final figure descriptions

TES-EES-V2.2.0-20260909

Figure 1. Composition evidence connects material eligibility to application-constrained design. (a) Separate reference-database and application-library inventories. Formula systems and exact compositions are different counting units. (b) The 33 distinct source–candidate links in the 15-composition engineering registry, grouped by evidence stream and salt family; ribbon widths represent link counts. (c) All ten joint-availability patterns across 142 exact compositions for melting temperature (Tₘ), upper stability limit (Upper), heat capacity (cₚ) and density (ρ). Filled circles indicate reported values. Burgundy identifies seven compositions with all four properties reported; availability alone does not establish validity over a duty. (d) Prescribed cold-to-hot intervals for sensible storage and target phase-transition windows for PCM350, PCM425 and PCM500. (e) Conditional retention at successive physical, quantitative, complete-duty and engineering-registry linkage. Each numerator is divided by the preceding-stage count, starting from 142 compositions × 7 duties = 994 pairs. The final 8/11 proportion is the intersection with a separately defined engineering registry.

Figure 2. Temperature-domain support changes material ranking before engineering qualification. (a) Pair counts after physical, quantitative and complete-duty requirements. (b) Volumetric heat capacity and viscosity at 300 °C for nine external nitrate formulations, normalized to Solar Salt. Numbers retain the source formulation identifiers. (c) Rank-one frequencies for all 11 complete-duty-supported candidate–duty pairs. Ca-nitrate denotes NaNO₃–KNO₃–Ca(NO₃)₂ (16:48:36 wt%); KNC denotes KNO₂–KNO₃–K₂CO₃; C–LiF denotes Na₂CO₃–Li₂CO₃–LiF. Binary carbonate is Na₂CO₃–Li₂CO₃. Cl-2025 is the 23.5:25.0:51.5 wt% NaCl–KCl–CaCl₂ formulation, compared with Cl-reference, the 40.8:7.5:51.7 mol% NaCl–KCl–CaCl₂ composition labelled NKCA in Supplementary Fig. 10. Its rank-one frequency is 0.05%. (d) Formal outcomes for the 15-composition engineering registry under balanced preferences. Panels c and d each use 20,000 draws but retain distinct sampling and eligibility specifications. (e) Complete-duty minus scalar rank-one frequency for sensible-storage duties. Rows include compositions or the no-candidate outcome with an absolute change of at least one percentage point in any duty. Zero denotes no change; grey cells denote absence from both quantitative comparisons. QNCC denotes NaNO₃–KNO₃–Na₂CO₃–NaCl. The no-candidate outcome belongs to the thermophysical comparison and differs from formal no-selection in (d).

Figure 3. Thermal headroom and evidence thresholds identify different stopping mechanisms. (a) Fractions of 90 coverage–evidence states per duty classified as robust, conditional or inaccessible. (b) No-selection response to minimum coverage; bands show approximate 90% Monte Carlo sampling intervals. (c) Evidence-threshold response using the same service colors as (b). (d) Signed limiting thermal headroom. Non-negative values meet the thermal criterion; hatched N/R cells lack an upper stability limit and are excluded from the numerical scale. Cl-2025 denotes the exact chloride formulation reported in 2025 and NC–Cl denotes Na₂CO₃–NaCl–KCl. HXLN and NKM-12 retain their source names. (e) Observed service-level regime types. Numbers give distinct joint regimes; dark outlines identify services with informative threshold maps.

Figure 4. Pareto membership and formal selection describe different outcomes. (a) Five within-duty performance–evidence maps and one interval-only panel for singleton duties. Filled markers lie on the representative frontier; error bars show marginal 5th–95th percentile draw ranges. Numbers identify the compositions listed in (c). (b) Pareto-membership frequencies with bootstrap 5th–95th percentile intervals, shown for memberships with frequencies of at least 1%. (c) Numbers of duties with Pareto membership ≥50% or formal selection ≥1%. (d) Intersections across all 36 candidate–duty memberships. Filled circles indicate Pareto membership ≥50%, decision-ready evidence and formal selection ≥1%, respectively. The small intersection distinguishes comparative opportunity from qualified access.

Figure 5. Uncertainty attribution and prerequisite closure identify measurement priorities. (a) Shapley variance shares for continuous top-two utility margins. (b) Shapley information shares for categorical selection outcomes. Services enter each panel only when its response is defined and variable. (c) The 12 largest non-zero losses of duty coverage caused by reported property domains. (d) Engineering-evidence unlock contributions summed across duties. These are decision-model contributions, not experimental success probabilities. (e) Median candidate–draw retention across combinations closing the same number of six gates: complete-duty support, corrosion, cycling, containment, replication and data completeness. Each denominator is the number of registered candidates in that duty multiplied by 20,000 draws. The full combination-specific minimum, median, mean and maximum remain in the associated source data. Closing a prerequisite changes the tested evidence scenario; it does not change a measured material property.

Figure 6. Conditional design consequences of reported material and device responses. (a) Composite-to-base charging and heat-release mean-power ratios for Solar Salt and HITEC. Circles denote 2 wt% alumina and diamonds denote alumina–copper-foam composites; repeated charging values share a source condition. (b) Model transfer-volume ratios against charge-to-delivery time for two foam comparisons. (c) Capacity-constrained model volume ratios for HITEC at 180→50 °C under three time-allocation scenarios. (d) Source-calculated extractable enthalpy per effective filled volume and mean heat-release power as the experimental endpoint changes. (e) Equal-duty pumping ratios under friction-exponent scenarios using two shear-conditioned apparent viscosities. (f) Incremental pumping electricity against assumed baseline pumping input. Device data describe central electrical heating and natural-air heat release. Nominal temperature endpoints are paired, but ambient conditions differ between material groups. Volumetric mean powers are fixed model coefficients, and delivery windows are prescribed scenarios rather than measured industrial heat services.

Supplementary Figure 1. Complete evidence-library audit

(a) Exact compositions by salt family. (b) Family-specific availability of melting temperature, upper stability, heat capacity, density, latent heat and cycling data. (c) Property-record counts against independent-source counts. (d) Composition-level material-boundary classes.

Formula systems are resolved to exact compositions before counting. Panel b uses the number of compositions in each family as its denominator. Property records and independent publications are counted separately.

The library resolves to 142 compositions: 37 chlorides, 27 nitrates and 22 carbonates form the largest groups. The 779 records partition into 194 unresolved, 45 excluded, two duplicate and 538 retained records. Panel d assigns 129 compositions within the material boundary, 12 conditionally and one outside it.

Broad chemical coverage coexists with sparse joint property and engineering evidence. A composition-level material boundary precedes the duty-specific thermal and property-domain tests in Fig. 1.

Supplementary Figure 2. Provenance linkage and candidate-specific credibility

(a) Component-set similarity and exact database linkage for the 15 engineering compositions. (b) Mean evidence scores for corrosion, cycling, containment, replication and data completeness.

Component-set similarity records shared chemical constituents. Exact linkage additionally requires the stated proportions and composition basis. Scores remain dimension specific and range from zero to one.

Eight compositions have zero component-set similarity to the compared database entries. Across the evidence matrix, corrosion support spans 0.15–0.90 and containment spans 0.35–0.86. Solar Salt and HITEC have corrosion scores of 0.90 but different containment and completeness scores.

Database proximity and engineering support are distinct. Their separate presentation prevents an adjacent formulation or one well-supported dimension from substituting for the target composition's evidence.

Supplementary Figure 3. Unique thermophysical profiles

Unique deterministic profiles describe thermal coverage, heat capacity, density, conductivity and complete-service energy for the engineering composition–duty memberships.

Exact duplicate vectors are collapsed and each property column is normalized independently. A shared zero-service row represents memberships without usable complete-service energy; merged labels identify identical profiles.

The same composition occupies different profiles across thermal duties. The repeated binary-carbonate and carbonate–LiF phase-change profiles contrast with their target-specific non-zero energy profiles.

Within-column contrasts show which property and thermal interval control a comparison. Values normalized in different columns have different physical denominators and are interpreted within their own property.

Supplementary Figure 4. Pairwise energy performance and raw-material boundary

(a) Three composition-pair energy-density superiority probabilities. (b) Conditional raw-material cost per unit of stored heat for ten composition–duty cases.

Pairwise probabilities use jointly comparable draws. Cost intervals propagate the component-price assumptions separately from energy superiority; points and bars represent medians and 5th–95th percentiles.<sup>40</sup>

HITEC exceeds Solar Salt in 41.39% of 5,900 industrial draws, equivalent to 58.61% in the opposite direction. Binary carbonate exceeds NKCA in the displayed PCM500 comparison. Median raw-material costs span 4.958–88.665 USD kWh⁻¹ of heat across the ten cases.

Close energy competition can coexist with different material-cost distributions. These prices describe the storage medium, while installed cost also depends on containment, heat exchange and auxiliaries.

Supplementary Figure 5. Complete-duty overclaim from partial intervals

Fourteen unique non-zero profiles pair thermal coverage with the excess energy assigned when partial overlap is treated as a complete duty. Repeated composition–target profiles share one row.

The horizontal coordinate is the partial-overlap energy overstatement in kWh m⁻³. The accompanying coverage label retains the fraction of the prescribed duty supported by the material state.

The displayed overstatement spans 34.1–252.4 kWh m⁻³. The largest value occurs for the merged carbonate–LiF PCM350/PCM500 profile; its complete-service coverage is zero.

A finite heat quantity over a partial interval does not establish the requested phase-change service. Keeping the coverage and energy denominators together prevents partial-duty energy from being interpreted as complete-duty capacity.

Supplementary Figure 6. Threshold sensitivity and convergence

(a) All 630 coverage–evidence states. (b) Expected counts of complete-duty-supported candidates as the evidence threshold changes. (c) Median and 95th-percentile modal-frequency errors from independent sampling checkpoints.

Each duty contributes 90 joint states. The reference analysis uses 20,000 matched draws; the independent checkpoints are compared with its modal frequencies.

Coal has 60 robust, 12 conditional and 18 inaccessible states; concentrating solar power and industrial heat each have 72 conditional and 18 inaccessible states. Their access disappears by an evidence threshold of 0.85. At 10,000 draws, the 95th-percentile modal-frequency error is 0.70 percentage points.

The threshold-induced change is larger than the observed sampling error. The full map distinguishes sensitivity to evidence requirements from Monte Carlo precision.

Supplementary Figure 7. Candidate-specific engineering-evidence intervals

Dimension-specific bounded evidence profiles for (a) corrosion, (b) cycling or phase stability and (c) containment. Profile labels identify unique intervals; n counts composition–duty memberships sharing each interval.

Exact duplicates are collapsed within each dimension. Points show interval midpoints and bars preserve their lower and upper evidence bounds.

The 36 memberships resolve to 12 corrosion, 14 cycling and ten containment profiles. Midpoints span 0.15–0.90, 0.45–0.82 and 0.35–0.86, respectively.

The three evidence dimensions have different ranges and orderings. Their separate intervals indicate whether a material needs compatibility, cycling or containment measurements to resolve its qualification.

Supplementary Figure 8. Omission sensitivity

(a) Changes in the modal-leader frequency and top-two frequency gap after candidate omission. (b) Five unique industrial source-omission outcome groups, comprising 12 single-source cases.

Each omission is evaluated against the same reference decision. Source cases are grouped only when their complete outcome vectors coincide. Entropy, leader frequency, frequency gap and utility margin retain their respective scales.

Removing HITEC produces the largest candidate-omission redistribution in industrial heat. Source-omission changes are smaller, with displayed top-two-gap shifts of approximately −0.03 to +0.02. No tested source omission changes the service-level interpretation.

The remaining competitors matter most where formal access already supports multiple materials. Source omission identifies dependence on individual evidence contributions within the specified registry.

Supplementary Figure 9. Credibility shortfall and aggregation sensitivity

(a) Sixteen distinct shortfall profiles across corrosion, cycling, containment, replication, completeness and burden. (b) Maximum changes in selection entropy and no-selection frequency under arithmetic and bottleneck aggregation relative to the primary geometric rule.

Shortfalls are expressed as shares of total log-credibility shortfall. Aggregation comparisons hold the physical and preference draws fixed, giving 14 service–model comparisons.

No-selection frequency changes by zero under both alternatives. Maximum entropy changes are 0.000217 and 0.000690 bits, both below the specified 0.005-bit comparison threshold.

The aggregation variants preserve the same hard gates, so unchanged no-selection frequency is a structural consequence. Their differences concern ordering within eligible sets, not an independent validation of the gates. Panel a identifies which evidence dimension contributes to each shortfall.

Supplementary Figure 10. Readiness profiles and candidate archetypes

(a) Eighteen unique readiness profiles. (b) Thermophysical full-duty support for four phase-change candidates at three targets. (c) Frequencies of multiple, single or no accessible candidates. (d) Two exploratory groups formed from performance, service, evidence, burden and selection robustness.

Exact duplicate readiness and multiplicity vectors are collapsed. Target-support probability in panel b is distinct from rank-one probability and formal selection. Clustering uses standardized features.

KNC has approximately 0.92 support at PCM350 and carbonate–LiF approximately 0.98 at PCM425. Both binary carbonate and NKCA have PCM500 support, despite no formal engineering selection there. Solar Salt has the widest formal service reach.

Target compatibility, engineering readiness and competition are separate quantities. Exploratory groups summarize the comparison without assigning additional eligibility.

Supplementary Figure 11. Complementary evidence-action diagnostics

(a) Ordinal action burden. (b) Evidence dimensions affected by each action. (c) Non-zero mean gate-pair synergies. (d) Combined-program effects beyond the sum of single-action effects.

Actions close only their named prerequisites. Combined and summed effects use the same selection-frequency scale. Burden is an ordinal planning measure, rather than monetary cost or experiment duration.

The largest mean pairwise synergy across duties is 0.067, with a maximum service-specific value of 0.25. Program non-additivity is 92.05, 98.35 and 76.24 percentage points for PCM350, PCM425 and PCM500, respectively.

Several unresolved prerequisites can make isolated tests ineffective for immediate selection. Ordered, combined evidence programs can reach a decision state unavailable to any single action.

Supplementary Figure 12. Formula-system-disjoint model diagnostics and candidate-invariant value audit

(a) Formula-group-disjoint and record-random model accuracy. (b) Independent coverage of nominal 90% prediction intervals. (c) Applicability of melting-temperature and density models to the 15 engineering compositions. (d) Formal frequencies under relative and benchmark-anchored value scales.

Formula systems are separated across fitting, calibration and test groups. Split-conformal intervals are evaluated on the independent groups; benchmark values remain fixed across candidate sets.<sup>45,46</sup>

Group-disjoint R² values are 0.50 and 0.92, compared with 0.83 and 0.97 for random records. Interval coverage is 93.9% and 90.3%, with mean widths of 522 K and 1,187 kg m⁻³. Two compositions lie inside both applicability domains. Value-scale outcomes agree in at least 93.2% of draws, with 100% retained-winner consistency.

Shared formula systems inflate apparent predictive accuracy. Independent-domain diagnostics identify where further measurements are most useful; measured evidence continues to determine formal eligibility.

Supplementary Figure 13. Composite-media evidence and system-response audit

(a) Composite-evidence counts. (b) Concentration-resolved liquid heat-capacity ratios. (c) Coupled heat-capacity–viscosity and conductivity-adjusted property indices. (d) Foam transfer ratios and expanded-graphite salt-fraction and corrosion ratios.<sup>31,33,34,47–50</sup>

Replicate standard deviations define independent 90% delta intervals where available. The multi-additive series uses a symmetric ±6% protocol-sensitivity scenario, motivated by the approximately 6% heat-capacity difference reported between DSC scans at 10 and 20 °C min⁻¹. Friction exponents span 0.25–1.0 over 20,000 draws. Panel c is a property-level diagnostic; Fig. 6e instead applies equal-duty flow scaling.

The 22 conditions yield 20 exact base links, 19 capacity responses and three capacity–viscosity pairs. One of 12 multi-additive formulations and one of four replicated SiO₂ concentrations retain a resolved capacity gain. The high-shear Solar Salt–SiO₂ index exceeds unity in 21.19% of exponent samples, versus zero at low shear. Foam charge and discharge ratios are 3.47 and 0.847 at 240→50 °C.

Qualification requires duty-wide rheology for mobile media, matched directional transfer tests for scaffolds, and composition-specific durability and compatibility for both.

Supplementary Figure 14. Precedence-valid evidence programs

(a) Evidence states and research routes. (b) Reachability of eligibility, selection of at least 1% and a change of leader. (c) Mean no-selection reduction across seven duties. (d) Newly eligible memberships against ordinal burden. (e) Candidate-specific frequency changes of at least one percentage point.

Actions retain corrosion-to-containment and completeness-to-replication precedence. Eligibility, no-selection and candidate-selection changes retain their own denominators. The all-evidence case is a specified upper-bound scenario.

The 36 memberships comprise 19 service/property-limited, nine without a tested route, four current selections and four evidence opportunities. The coordinated program reduces mean no-selection by 38.8 percentage points; the duty-relaxation case reduces it by 8.9. The nitrate–carbonate–chloride coal-duty candidate reaches 29.16% selection after coordinated closures.

The relevant experiment depends on the decision endpoint. Qualification gains identify research routes, while Fig. 6 determines whether the resulting material response could change an operating constraint.

Supplementary Figure 15. Application switching boundaries and numerical verification

(a) Eighteen foam transfer-volume crossover ratios. (b) Conditional volumetric-cost premiums. (c) Capacity-constrained analytical and chronological volumes. (d) Delivery-limited sizing understatement from charging-only enhancement.

Panel a applies the reported 2.36% mean-power uncertainty to numerator and denominator as bounds. Panel b assumes cost proportional to volume. Panel c uses 1 h and 15 min steps, constant power limits and a lossless energy balance. Panel d evaluates 1 − Rd/Rc.

Foam crossover ratios span 0.136–0.914. All 162 chronological cases agree with the analytical maximum within numerical tolerance. The volumetric-cost premium loses its positive value once the transfer-volume advantage disappears.

Directional power, capacity and time allocation jointly determine the material requirement. The chronological comparison establishes numerical consistency under the stated power and energy assumptions.

Supplementary Figure 16. Physical compatibility and evidence-index sensitivity

(a) KNC mass-loss rates at 500 and 700 °C for four stainless steels after 480 h in air; the dashed line is the 15 μm yr⁻¹ reference. (b) Paired mass-loss and penetration-derived rates for three alloys in 60:20:20 mol% MgCl₂–NaCl–KCl at 700 °C for 500 h under Ar. (c) Nitrate base and 10 wt% expanded-graphite observations in 316 steel after 1,440 h. The 300 °C composite rate is the published numerical endpoint. (d) Industrial-heat Solar Salt selection frequency across five evidence aggregations and weights, each using 20,000 matched draws.<sup>37,38,50</sup>

KNC rates rise by factors of 23.87–46.49 between the tested temperatures. In the chloride experiment, penetration-to-mass-loss ratios span 1.11–6.66. The nitrate–graphite rate is 2.6 μm yr⁻¹ at 300 °C, compared with 3.2 μm yr⁻¹ for its base; the base reaches 16.0 μm yr⁻¹ at 500 °C. Industrial Solar Salt selection spans 36.15–57.90%. The observations identify condition and endpoint dependence; the ranking grid separately identifies sensitivity to the assessment indices.

Supplementary Figure 17. Independent enthalpy comparison over a shared liquid interval

(a) Measured and model enthalpy increments from a common 250 °C reference. (b) Model-minus-measured increments for the eight higher endpoints. Horizontal bars apply the endpoint sensitivity scenario. (c) Signed errors for all 36 endpoint intervals; the diamond marks the complete 250–400 °C interval. (d) Calculated material masses for the same 1 kWh sensible-heat duty.<sup>41</sup>

The published Table 1 contains 19 Solar Salt enthalpy means. Nine liquid-state means fall within the unchanged heat-capacity domain. For an interval bounded by enthalpies Hₗ and Hₕ, measured capacity is Hₕ − Hₗ. The sensitivity half-width is 0.005|Hₕ − Hₗ| + 0.01(|Hₕ| + |Hₗ|). The first term applies the reported calibration deviation as a common-scale scenario; the second permits opposite endpoint perturbations using the reported repeatability. These scenarios do not specify a confidence level or measurement-error covariance.

Over 250–400 °C, the measured and model increments are 223.85 and 232.50 kJ kg⁻¹. The +3.86% energy bias implies a −3.72% mass bias at fixed energy. All-interval absolute errors span 0.02–28.21%; the intervals share the same nine observations. This comparison evaluates the specific-energy estimate and its material-mass consequence for Solar Salt over 250–400 °C.

## References

1. P. C. Verpoort, L. Gast, A. Hofmann and F. Ueckerdt, Impact of global heterogeneity of renewable energy supply on heavy industrial production and green value chains, Nat. Energy, 2024, 9, 491–503. https://doi.org/10.1038/s41560-024-01492-z.

2. T. Gilbert, A. K. Menon, C. Dames and R. Prasher, Heat source and application-dependent levelized cost of decarbonized heat, Joule, 2023, 7, 128–149. https://doi.org/10.1016/j.joule.2022.11.006.

3. C. Wang, F. Chen, L. Wang, H. Cao, L. Gao, S. Tian, W. Wang and Q. Sun, The flexibility of a molten salt thermal energy storage (TES)-integrated coal-fired power plant, Appl. Energy, 2025, 402, 126876. https://doi.org/10.1016/j.apenergy.2025.126876.

4. S. Trevisan, S. Pathi, J. Brown, B. Buchbjerg, A. B. Borrero and R. Guedez, Thermal performance and dynamic response assessment of an industrial molten salts based power-to-heat system, Energy Convers. Manage., 2025, 342, 120131. https://doi.org/10.1016/j.enconman.2025.120131.

5. M. Mehos, C. Turchi, J. Vidal, M. Wagner, Z. Ma, C. Ho, W. Kolb, C. Andraka and A. Kruizenga, Concentrating Solar Power Gen3 Demonstration Roadmap, NREL/TP-5500-67464, National Renewable Energy Laboratory, 2017. https://doi.org/10.2172/1338899.

6. A. Bonk, M. Braun, V. A. Sötz and T. Bauer, Solar Salt – Pushing an old material for energy storage to a new limit, Appl. Energy, 2020, 262, 114535. https://doi.org/10.1016/j.apenergy.2020.114535.

7. J. Steinbrecher, A. Hanke, M. Braun, T. Bauer and A. Bonk, Stabilization of Solar Salt at 650 °C – Thermodynamics and practical implications for thermal energy storage systems, Sol. Energy Mater. Sol. Cells, 2023, 258, 112411. https://doi.org/10.1016/j.solmat.2023.112411.

8. M. Luo, Y. Zhang, Y. Nie, B. Lu, S. Liu and J. Luo, Experimental investigation on the thermal performance of a pilot-scale single-tank high-temperature molten salt sensible thermal energy storage system, Energy, 2026, 342, 139686. https://doi.org/10.1016/j.energy.2025.139686.

9. G. J. Otero Rodriguez, D. de Figueiredo Luiz, H. Zondag, M. van der Pal, J.-A. Lycklama a Nijeholt, A. Battistella, S. De and R. de Boer, Utilizing Molten Salts as Heat Transfer Fluids for Heat Recovery in Electric Naphtha Crackers, ACS Sustainable Resour. Manage., 2026. https://doi.org/10.1021/acssusresmgt.5c00535.

10. R. Chesser, N. Termini, S. Henderson, D. Zhang, V. Glezakou and T. Birri, An Overview of the Molten Salt Thermal Properties Database–Thermophysical, Version 4.0 (MSTDB-TP V.4.0), ORNL/TM-2025/4159, Oak Ridge National Laboratory, 2025. https://doi.org/10.2172/3002157.

11. G. J. Janz, Data from: NIST Properties of Molten Salts Database (formerly SRD 27), National Institute of Standards and Technology, 1992. https://doi.org/10.18434/mds2-2298.

12. D. de Figueiredo Luiz, J. Boon, G. Otero Rodriguez and M. van Sint Annaland, Review of the molten salt technology and assessment of its potential to achieve an energy efficient heat management in a decarbonized chemical industry, Chem. Eng. J., 2024, 498, 155819. https://doi.org/10.1016/j.cej.2024.155819.

13. S. Ma, Q. Yang, Y. Li, C. Yan and X. Wang, A review on preparation, thermal transport properties, phase-change characteristics, and thermal stability of molten salts, J. Clean. Prod., 2024, 444, 141272. https://doi.org/10.1016/j.jclepro.2024.141272.

14. C. S. Turchi, J. Vidal and M. Bauer, Molten salt power towers operating at 600–650 °C: Salt selection and cost benefits, Sol. Energy, 2018, 164, 38–46. https://doi.org/10.1016/j.solener.2018.01.063.

15. X. Liu, F. Liang, S. Liu, G. Pan, J. Ding and J. Lu, NaCl-KCl-CaCl2 molten salts for high temperature heat storage: Experimental and deep learning molecular dynamics simulation study, Sol. Energy Mater. Sol. Cells, 2025, 280, 113275. https://doi.org/10.1016/j.solmat.2024.113275.

16. Y. Li, S. Wang and Q. Zhu, Preparation and study of quaternary molten salts for thermal energy storage applications, Sol. Energy Mater. Sol. Cells, 2025, 282, 113358. https://doi.org/10.1016/j.solmat.2024.113358.

17. X. Liu, Y. Zhong, J. Li, H. Wang and M. Wang, A study of thermal physical properties and molecular dynamics simulations of a high thermal stability sulfate molten salt, J. Energy Storage, 2025, 107, 114981. https://doi.org/10.1016/j.est.2024.114981.

18. H. Tian, T. Liu and W. Zhang, Thermal properties of Na2CO3–NaCl–KCl ternary eutectic salt for high-temperature thermal energy storage: Experimental and deep potential molecular dynamics combined, J. Chem. Phys., 2025, 163, 084503. https://doi.org/10.1063/5.0281150.

19. M. Castro-Quijada, D. Faundez, R. Rojas and A. Videla, Improving the working fluid based on a NaNO3-KNO3-NaCl-KCl molten salt mixture for concentrating solar power energy storage, Sol. Energy, 2022, 231, 464–472. https://doi.org/10.1016/j.solener.2021.11.058.

20. M. Botejara-Antúnez, J. Chaves, M. I. Lasanta, G. García-Martín, A. Rivero-Cacho, J. García-Sanz-Calcedo and F. J. Pérez, Environmental and thermophysical pre-selection of low-melting point molten salts for thermal energy storage in concentrated solar power systems, Appl. Therm. Eng., 2026, 301, 131694. https://doi.org/10.1016/j.applthermaleng.2026.131694.

21. G. M. Magableh, M. Z. Mistarihi and S. Abu Dalu, A Hybrid MCDM Approach to Optimize Molten Salt Selection for Off-Grid CSP Systems, Energies, 2025, 18, 4323. https://doi.org/10.3390/en18164323.

22. H. Kim, J. Seo, Y. A. Hassan, J. Yoo, S. Qin and J. L. Hartvigsen, Evaluation and selection of eutectic salts combined with metal foams for applications in high-temperature latent heat thermal energy storage, J. Energy Storage, 2024, 76, 109790. https://doi.org/10.1016/j.est.2023.109790.

23. K. M. Chung, T. Feng, J. Zeng, S. R. Adapa, X. Zhang, A. Z. Zhao, Y. Zhang, P. Li, Y. Zhao, J. E. Garay and R. Chen, Thermal conductivity measurement using modulated photothermal radiometry for nitrate and chloride molten salts, Int. J. Heat Mass Transfer, 2023, 217, 124652. https://doi.org/10.1016/j.ijheatmasstransfer.2023.124652.

24. J. Woods, A. Mahvi, A. Goyal, E. Kozubal, A. Odukomaiya and R. Jackson, Rate capability and Ragone plots for phase change thermal energy storage, Nat. Energy, 2021, 6, 295–302. https://doi.org/10.1038/s41560-021-00778-w.

25. J. D. Kocher, J. Woods, A. Odukomaiya, A. Mahvi and S. K. Yee, Thermal battery cost scaling analysis: minimizing the cost per kW h, Energy Environ. Sci., 2024, 17, 2206–2218. https://doi.org/10.1039/D3EE03594H.

26. A. Singh, S. Rangarajan and B. Sammakia, Predictive correlation of optimum phase change material for thermal energy storage, Commun. Eng., 2026, 5, 143. https://doi.org/10.1038/s44172-026-00655-y.

27. B. Walsh and G. Su, Realistic performance metric for latent heat thermal energy storage in advanced low-carbon energy systems, Appl. Therm. Eng., 2026, 303, 132138. https://doi.org/10.1016/j.applthermaleng.2026.132138.

28. X. Chen, Z. Liang, L. Qu, X. Li, X. Wang and Y. Wu, Experimental study on thermophysical properties of Si3N4 molten salt nanofluids for solar thermal utilization, J. Energy Storage, 2026, 159, 121765. https://doi.org/10.1016/j.est.2026.121765.

29. X. Xiao, J. Liu and M. Yao, Investigation of thermophysical properties enhancement of nanofluids based on molten salt for solar energy storage: a molecular dynamic study, Sol. Energy Mater. Sol. Cells, 2026, 299, 114183. https://doi.org/10.1016/j.solmat.2026.114183.

30. S. Zhang and Y. Yan, Evaluation of discharging performance of molten salt/ceramic foam composite phase change material in a shell-and-tube latent heat thermal energy storage unit, Renewable Energy, 2022, 198, 1210–1223. https://doi.org/10.1016/j.renene.2022.08.124.

31. X. Xiao, H. Jia, D. Wen, Y. G. Akhlaghi and A. Badiei, Experimental investigation of a latent heat thermal energy storage unit encapsulated with molten salt/metal foam composite seeded with nanoparticles, Energy Built Environ., 2023, 4, 74–85. https://doi.org/10.1016/j.enbenv.2021.08.003.

32. X. Xiao, H. Jia, D. Wen and X. Zhao, Thermal performance analysis of a solar energy storage unit encapsulated with HITEC salt/copper foam/nanoparticles composite, Energy, 2020, 192, 116593. https://doi.org/10.1016/j.energy.2019.116593.

33. B. El Far, S. M. M. Rizvi, Y. Nayfeh and D. Shin, Study of viscosity and heat capacity characteristics of molten salt nanofluids for thermal energy storage, Sol. Energy Mater. Sol. Cells, 2020, 210, 110503. https://doi.org/10.1016/j.solmat.2020.110503.

34. Y. Grosu, A. Anagnostopoulos, B. Balakin, J. Krupanek, M. E. Navarro, L. González-Fernández, Y. Ding and A. Faik, Nanofluids based on molten carbonate salts for high-temperature thermal energy storage: Thermophysical properties, stability, compatibility and life cycle analysis, Sol. Energy Mater. Sol. Cells, 2021, 220, 110838. https://doi.org/10.1016/j.solmat.2020.110838.

35. R. Lahdelma, J. Hokkanen and P. Salminen, SMAA - Stochastic multiobjective acceptability analysis, Eur. J. Oper. Res., 1998, 106, 137–143. https://doi.org/10.1016/S0377-2217(97)00163-X.

36. B. J. McKeon, C. J. Swanson, M. V. Zagarola, R. J. Donnelly and A. J. Smits, Friction factors for smooth pipe flow, J. Fluid Mech., 2004, 511, 41–44. https://doi.org/10.1017/S0022112004009796.

37. J. Huang, L. Sang and X. Hu, Combined experimental and molecular dynamics study of stainless steel corrosion in KNO₂-KNO₃-K₂CO₃ at high temperatures, Sol. Energy, 2026, 305, 114275. https://doi.org/10.1016/j.solener.2025.114275.

38. W. Ding, H. Shi, Y. Xiu, A. Bonk, A. Weisenburger, A. Jianu and T. Bauer, Hot corrosion behavior of commercial alloys in thermal energy storage material of molten MgCl₂/KCl/NaCl under inert atmosphere, Sol. Energy Mater. Sol. Cells, 2018, 184, 22–30. https://doi.org/10.1016/j.solmat.2018.04.025.

39. Q. Gong, H. Shi, Y. Chai, R. Yu, A. Weisenburger, D. Wang, A. Bonk, T. Bauer and W. Ding, Molten chloride salt technology for next-generation CSP plants: Compatibility of Fe-based alloys with purified molten MgCl₂-KCl-NaCl salt at 700 °C, Appl. Energy, 2022, 324, 119708. https://doi.org/10.1016/j.apenergy.2022.119708.

40. U.S. Geological Survey, Mineral commodity summaries 2026, Reston, VA, 2026, 222 pp. https://doi.org/10.3133/mcs2026.

41. B. Wu, N. Yin, J. Hu, X. Wei, H. Zhao and Q. Shi, Thermodynamic Property of Molten Salt Thermal Energy Storage Materials Using Drop Calorimetric Technique, Chem. J. Chinese Univ., 2025, 46, 20250170. https://doi.org/10.7503/cjcu20250170.

42. C. E. Shannon, A Mathematical Theory of Communication, Bell Syst. Tech. J., 1948, 27, 379–423. https://doi.org/10.1002/j.1538-7305.1948.tb01338.x.

43. L. S. Shapley, A value for n-person games, in Contributions to the Theory of Games II, ed. H. W. Kuhn and A. W. Tucker, Princeton University Press, Princeton, 1953, pp. 307–317.

44. E. Song, B. L. Nelson and J. Staum, Shapley Effects for Global Sensitivity Analysis: Theory and Computation, SIAM/ASA J. Uncertain. Quantif., 2016, 4, 1060–1083. https://doi.org/10.1137/15M1048070.

45. A. N. Angelopoulos and S. Bates, Conformal Prediction: A Gentle Introduction, Found. Trends Mach. Learn., 2023, 16, 494–591. https://doi.org/10.1561/2200000101.

46. F. Pedregosa, G. Varoquaux, A. Gramfort, V. Michel, B. Thirion, O. Grisel, M. Blondel, P. Prettenhofer, R. Weiss, V. Dubourg, J. Vanderplas, A. Passos, D. Cournapeau, M. Brucher, M. Perrot and É. Duchesnay, Scikit-learn: Machine Learning in Python, J. Mach. Learn. Res., 2011, 12, 2825–2830.

47. P. Andreu-Cabedo, R. Mondragon, L. Hernandez, R. Martinez-Cuenca, L. Cabedo and J. E. Julia, Increment of specific heat capacity of solar salt with SiO2 nanoparticles, Nanoscale Res. Lett., 2014, 9, 582. https://doi.org/10.1186/1556-276X-9-582.

48. M. Chieruzzi, G. F. Cerritelli, A. Miliozzi and J. M. Kenny, Effect of nanoparticles on heat capacity of nanofluids based on molten salts as PCM for thermal energy storage, Nanoscale Res. Lett., 2013, 8, 448. https://doi.org/10.1186/1556-276X-8-448.

49. M.-C. Lu and C.-H. Huang, Specific heat capacity of molten salt-based alumina nanofluid, Nanoscale Res. Lett., 2013, 8, 292. https://doi.org/10.1186/1556-276X-8-292.

50. Q. Wang, D. Zhou, Y. Chen and Z. Wu, Corrosion of stainless steel 316 in a ternary nitrate salt and its composite with expanded graphite for solar thermal applications, Sol. Energy Mater. Sol. Cells, 2021, 219, 110823. https://doi.org/10.1016/j.solmat.2020.110823.

51. Z. Li and Z.-G. Wu, Development of medium-temperature composite phase change material with high thermal stability and conductivity, Sol. Energy Mater. Sol. Cells, 2016, 155, 341–347. https://doi.org/10.1016/j.solmat.2016.06.027.

52. H. Tiznobaik, D. Banerjee and D. Shin, Effect of formation of “long range” secondary dendritic nanostructures in molten salt nanofluids on the values of specific heat capacity, Int. J. Heat Mass Transfer, 2015, 91, 342–346. https://doi.org/10.1016/j.ijheatmasstransfer.2015.05.072.

53. B. Jo and D. Banerjee, Effect of solvent on specific heat capacity enhancement of binary molten salt-based carbon nanotube nanomaterials for thermal energy storage, Int. J. Therm. Sci., 2015, 98, 219–227. https://doi.org/10.1016/j.ijthermalsci.2015.07.020.

54. B. Ma, D. Shin and D. Banerjee, Synthesis and Characterization of Molten Salt Nanofluids for Thermal Energy Storage Application in Concentrated Solar Power Plants—Mechanistic Understanding of Specific Heat Capacity Enhancement, Nanomaterials, 2020, 10, 2266. https://doi.org/10.3390/nano10112266.

55. F. M. Abir and D. Shin, Specific Heat Capacity of Solar Salt-Based Nanofluids: Molecular Dynamics Simulation and Experiment, Materials, 2024, 17, 506. https://doi.org/10.3390/ma17020506.

56. Z. Rao, K. Ye, H. Wang and S. Liao, Effects of interface layer on the thermophysical properties of solar salt‐SiO₂ nanofluids: A molecular dynamics simulation, Int. J. Energy Res., 2021, 45, 13323–13337. https://doi.org/10.1002/er.6659.

57. H. Tiznobaik and D. Shin, Enhanced specific heat capacity of high-temperature molten salt-based nanofluids, Int. J. Heat Mass Transfer, 2013, 57, 542–548. https://doi.org/10.1016/j.ijheatmasstransfer.2012.10.062.

58. B. Dudda and D. Shin, Effect of nanoparticle dispersion on specific heat capacity of a binary nitrate salt eutectic for concentrated solar power applications, Int. J. Therm. Sci., 2013, 69, 37–42. https://doi.org/10.1016/j.ijthermalsci.2013.02.003.

59. U. Nithiyanantham, Y. Grosu, L. González-Fernández, A. Zaki, J. M. Igartua and A. Faik, Corrosion aspects of molten nitrate salt-based nanofluids for thermal energy storage applications, Sol. Energy, 2019, 189, 219–227. https://doi.org/10.1016/j.solener.2019.07.050.

60. U. Nithiyanantham, Y. Grosu, A. Anagnostopoulos, E. Carbó-Argibay, O. Bondarchuk, L. González-Fernández, A. Zaki, J. M. Igartua, M. E. Navarro, Y. Ding and A. Faik, Nanoparticles as a high-temperature anticorrosion additive to molten nitrate salts for concentrated solar power, Sol. Energy Mater. Sol. Cells, 2019, 203, 110171. https://doi.org/10.1016/j.solmat.2019.110171.

61. M. E. Navarro, A. Palacios, Z. Jiang, A. Avila, G. Qiao, E. Mura and Y. Ding, Effect of SiO2 nanoparticles concentration on the corrosion behaviour of solar salt-based nanofluids for Concentrating Solar Power plants, Sol. Energy Mater. Sol. Cells, 2022, 247, 111923. https://doi.org/10.1016/j.solmat.2022.111923.

62. Y. Grosu, N. Udayashankar, O. Bondarchuk, L. González-Fernández and A. Faik, Unexpected effect of nanoparticles doping on the corrosivity of molten nitrate salt for thermal energy storage, Sol. Energy Mater. Sol. Cells, 2018, 178, 91–97. https://doi.org/10.1016/j.solmat.2018.01.002.

63. V. Viswanathan, K. Mongird, R. Franks, X. Li, V. Sprenkle and R. Baxter, 2022 Grid Energy Storage Technology Cost and Performance Assessment, PNNL-33283, Pacific Northwest National Laboratory, 2022, https://www.energy.gov/sites/default/files/2022-09/2022%20Grid%20Energy%20Storage%20Technology%20Cost%20and%20Performance%20Assessment.pdf.

64. J. W. Lim, M. Day, S. Cui and S. K. Yee, Iso-cost-performance of thermal energy storage, J. Phys. Energy, 2026, 8, 011001. https://doi.org/10.1088/2515-7655/ae2a6c.

65. J. Osorio, M. Mehos, L. Imponenti, B. Kelly, H. Price, J. Torres-Madronero, A. Rivera-Alvarez, C. Nieto-Londono, C. Ni, Z. Yu, W. Hamilton and J. Martinek, Failure Analysis for Molten Salt Thermal Energy Storage Tanks for In-Service CSP Plants, NREL/TP-5700-89036, National Renewable Energy Laboratory, 2024. https://doi.org/10.2172/2331241.

66. Z. Sun, L. Su, X. Gao, G. Lu, X. Song and J. Yu, Influences of impurity Cl⁻ on the thermal performance of solar salt for thermal energy storage, Sol. Energy, 2021, 216, 90–95. https://doi.org/10.1016/j.solener.2020.12.057.

67. N. Li, H. Wang, H. Yin, Q. Liu and Z. Tang, Effect of Temperature and Impurity Content to Control Corrosion of 316 Stainless Steel in Molten KCl-MgCl2 Salt, Materials, 2023, 16, 2025. https://doi.org/10.3390/ma16052025.

68. Q. Meng, L. Lai, W. Rao, A. Li, H. Yu and P. La, Creep Properties and Corrosion Behavior of TP347H Stainless Steel with Al in Molten Carbonate Salt, Materials, 2024, 17, 6108. https://doi.org/10.3390/ma17246108.

69. H. Wang, J. Li, Y. Zhong, X. Liu and M. Wang, Novel Wide-Working-Temperature NaNO₃-KNO₃-Na₂SO₄ Molten Salt for Solar Thermal Energy Storage, Molecules, 2024, 29, 2328. https://doi.org/10.3390/molecules29102328.

70. X. Wei, P. Xie, X. Zhang, W. Wang, J. Lu and J. Ding, Research on preparation and thermodynamic properties of chloride molten salt materials, CIESC J., 2020, 71, 2423–2431. https://doi.org/10.11949/0438-1157.20191541.
