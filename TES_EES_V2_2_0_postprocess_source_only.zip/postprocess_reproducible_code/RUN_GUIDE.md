
# Local Arial figure-rendering guide

## Recommended Windows route

1. Confirm CPython 3.12 is installed and available through `py -3.12`.
2. Confirm Arial is installed as a Windows system font.
3. Confirm the sibling folder `../upstream_reproducible_code` contains the matching TES-EES-V2.2.0-20260909 upstream results.
4. Run:

```bat
SETUP_ENV.bat
RUN_POSTPROCESS.bat
```

A successful run must report:

- six main figures;
- seventeen supplementary figures;
- 42/42 post-processing validation checks;
- `POSTPROCESS_RELEASE_STATUS.json` = PASS.
- `ENGINEERING_FIGURE_STATUS.json` = PASS for the preceding 22-figure stage;
- `EXTERNAL_FIGURE_STATUS.json` = PASS for Supplementary Figure 17;
- `POSTPROCESS_RELEASE_STATUS.json` reports the final 6 main and 17 supplementary vector PDFs and 600 dpi PNGs;
- `pipeline_execution_status.json` = PASS, all 11 stages completed.

## Full from-scratch route

To regenerate the scientific results before rendering:

```bat
cd ..\upstream_reproducible_code
SETUP_ENV.bat
RUN_FULL_RECOMPUTE.bat
cd ..\postprocess_reproducible_code
SETUP_ENV.bat
RUN_POSTPROCESS.bat
```

## Release rules

- Do not set `ALLOW_ARIAL_FALLBACK=1` for submission rendering.
- Do not manually copy selected CSV files into the post-processing package; use the synchronization stage.
- Do not edit generated figures independently of the source tables and renderer.
- Preserve both PNG and vector PDF outputs locally for final journal submission and archive only after the PASS status is generated.
