from __future__ import annotations

from pathlib import Path
import argparse
from decimal import Decimal, ROUND_HALF_UP
import json
import math
import shutil
import textwrap
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm, LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.lines import Line2D
from matplotlib.patches import Patch, Rectangle, Ellipse, FancyBboxPatch
from PIL import Image

import certified_figure_support as L
from public_figure_language import clean_public_labels

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT/'outputs'/'tables'
MAIN = ROOT/'outputs'/'main_figures'
SUPP = ROOT/'outputs'/'supplementary_figures'
CONTACT = ROOT/'outputs'/'contact_sheets'
QA = ROOT/'outputs'/'qa'
QC = ROOT/'outputs'/'qc'
DOCS = ROOT/'docs'
for p in [MAIN,SUPP,CONTACT,QA,QC,DOCS]: p.mkdir(parents=True,exist_ok=True)

V='submission'; BASE='core'; STAT='statistical'
SERVICE_ORDER=L.SCENARIOS; SERVICE={s:L.scenario_code(s) for s in L.SCENARIOS}; SCOL=L.SCENARIO_COLOR

# One active visual grammar. Arial is mandatory for the submission render.
# ALLOW_ARIAL_FALLBACK=1 is reserved for non-submission CI smoke tests.
import os
try:
    mpl.font_manager.findfont('Arial', fallback_to_default=False)
    _TEXT_FONT='Arial'
except Exception:
    if os.environ.get('ALLOW_ARIAL_FALLBACK','0')!='1':
        raise RuntimeError('Arial is required. Install Arial as a system font; no font files are bundled.')
    _TEXT_FONT='Liberation Sans'
mpl.rcParams.update({
    'font.family':_TEXT_FONT,'font.sans-serif':[_TEXT_FONT],
    'mathtext.fontset':'custom','mathtext.rm':_TEXT_FONT,'mathtext.it':_TEXT_FONT+':italic','mathtext.bf':_TEXT_FONT+':bold','mathtext.fallback':'stix','mathtext.default':'regular',
    'axes.unicode_minus':False,'font.size':8.0,'axes.labelsize':7.1,
    'xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.3,
    'axes.linewidth':.62,'xtick.major.width':.52,'ytick.major.width':.52,
    'xtick.direction':'out','ytick.direction':'out','pdf.fonttype':42,'ps.fonttype':42,
    'figure.facecolor':'white','axes.facecolor':'white','savefig.dpi':300,
})

# Rebind only the certified helper/supplementary module. No decision_boundary→statistical→prior release→prior release call chain is used.
L.VERSION=V; L.ROOT=ROOT; L.TABLES=TABLES; L.MAIN=MAIN; L.SUPP=SUPP; L.CONTACT=CONTACT; L.QC=QC; L.QA=QA; L.DOCS=DOCS

NAVY=L.NAVY; BLUE=L.BLUE; PALE_BLUE=L.PALE_BLUE; OLIVE=L.OLIVE; MUSTARD=L.MUSTARD
TERRACOTTA=L.TERRACOTTA; ROSE_LIGHT=L.ROSE_LIGHT; ROSE=L.ROSE; BURGUNDY=L.BURGUNDY
CREAM=L.CREAM; INK=L.INK; MID_GREY=L.MID_GREY; LIGHT_GREY=L.LIGHT_GREY; VERY_LIGHT=L.VERY_LIGHT
NEUTRAL=L.NEUTRAL; MAIN_W=2126/300
L.MAIN_W=MAIN_W; L.SUPP_W=MAIN_W

FIGURE_RECORDS=[]

def read(stem:str, version:str|None=None, **kwargs)->pd.DataFrame:
    versions=[version] if version else [V,STAT,BASE]
    matches=[]
    for ver in versions:
        if ver is None: continue
        p=TABLES/f'{ver}_{stem}.csv'
        if p.exists(): matches.append(p)
    if len(matches)>1:
        raise RuntimeError(f'Ambiguous table version for {stem}: {[p.name for p in matches]}. Pass an explicit version.')
    if len(matches)==1:
        return pd.read_csv(matches[0],**kwargs)
    raise FileNotFoundError(f'No table found for {stem} under {versions}')

def short_id(value:str)->str:
    value=str(value)
    mapping={
        'solar_salt_ss60':'Solar Salt','knc':'KNC','qncc':'QNCC','mgcl_kcl_nacl':'MgCl$_2$ mix',
        'nkca':'NKCA','pcm_lif_s1':'Carbonate–LiF','pcm_binary_carbonate':'Binary carbonate',
        'hitec':'HITEC','hitec_xl':'HITEC XL','quat_s7':'Nitrate S7','tms2':'TMS-2',
        'nknkcl_2026':'NKN-KCl','nkckcl_2026':'NKC-KCl','linak_carbonate':'LiNaK carbonate',
        'flinak_rr':'FLiNaK RR','none':'No selection','__NO_SELECTION__':'No selection'
    }
    return mapping.get(value,L.short_candidate(value))

LEADER_LABELS={
    'NaNO3-KNO3-Na2CO3-NaCl':r'NaNO$_3$–KNO$_3$–Na$_2$CO$_3$–NaCl',
    'Solar Salt SS60':r'Solar Salt · NaNO$_3$–KNO$_3$',
    'NaNO3-KNO3-Ca(NO3)2 eutectic (16:48:36 wt%)':r'NaNO$_3$–KNO$_3$–Ca(NO$_3$)$_2$',
    'HITEC':'HITEC',
    'KNO2-KNO3-K2CO3':r'KNO$_2$–KNO$_3$–K$_2$CO$_3$',
    'MgCl2-KCl-NaCl eutectic':r'MgCl$_2$–KCl–NaCl',
    'S1 Na2CO3-Li2CO3-LiF':r'S1 · Na$_2$CO$_3$–Li$_2$CO$_3$–LiF',
    'Na2CO3-Li2CO3':r'Na$_2$CO$_3$–Li$_2$CO$_3$',
    'NaCl-KCl-CaCl2':r'NaCl–KCl–CaCl$_2$ (reference)',
    'NaCl-KCl-CaCl2 23.5-25.0-51.5 wt%':r'NaCl–KCl–CaCl$_2$ (23.5:25.0:51.5 wt%)',
    'none':'No valid leader',
}

def leader_label(value:str)->str:
    """Compact, non-truncated candidate label with chemical subscripts."""
    value=str(value)
    return LEADER_LABELS.get(value,L.chem_label(value.replace(' eutectic','')))

def panel(ax,letter,x=-.075,y=1.055):
    ax.text(x,y,letter,transform=ax.transAxes,fontsize=9.1,fontweight='bold',ha='left',va='top',clip_on=False)

def value_badge(ax,x,y,text,dx=6,dy=0,ha='left',va='center',color=INK,fc='white',ec=None,clip_on=True,zorder=8,arrow=False,fontsize=5.15):
    if ec is None: ec=color
    arrowprops=dict(arrowstyle='-',color=ec,lw=.48,shrinkA=1,shrinkB=2) if arrow else None
    return ax.annotate(str(text),(x,y),xytext=(dx,dy),textcoords='offset points',ha=ha,va=va,
                fontsize=fontsize,fontweight='bold',color=color,clip_on=clip_on,zorder=zorder,
                bbox=dict(boxstyle='round,pad=.16',fc=fc,ec=ec,lw=.48,alpha=.96),arrowprops=arrowprops)

def outside_note(ax,text,x=.98,y=1.08,ha='right'):
    ax.text(x,y,text,transform=ax.transAxes,ha=ha,va='bottom',fontsize=5.0,color=MID_GREY,clip_on=False)

def clean(ax,grid=None):
    for sp in ax.spines.values(): sp.set_visible(True); sp.set_color(INK); sp.set_linewidth(.60)
    if grid: ax.grid(axis=grid,color=LIGHT_GREY,lw=.45,zorder=0)
    ax.set_axisbelow(True)

def barh_headroom(ax,n,extra=.75): ax.set_ylim(-.5,max(.5,n-.5+extra))

def top_legend(ax,handles,ncol=3,anchor=(.5,1.13),**kwargs):
    return ax.legend(handles=handles,ncol=ncol,loc='upper center',bbox_to_anchor=anchor,frameon=False,
                     handlelength=1.0,columnspacing=.55,handletextpad=.28,borderaxespad=0,**kwargs)


def compact_service_label(s):
    return {'coal_flexibility_storage':'Coal','csp_sensible_storage':'CSP','industrial_medium_heat':'Ind.',
            'sco2_high_temperature_storage':r'sCO$_2$','pcm_target_350C':'PCM350',
            'pcm_target_425C':'PCM425','pcm_target_500C':'PCM500'}.get(str(s),str(s))

def save(fig,num,title,sources,supp=False):
    clean_public_labels(fig)
    out=SUPP if supp else MAIN; prefix='Supp_Fig' if supp else 'Fig'; stem=f'{V}_{prefix}{num}'
    png=out/f'{stem}.png'; pdf=out/f'{stem}.pdf'
    fig.savefig(png,dpi=300,facecolor='white',bbox_inches=None,pad_inches=0)
    fig.savefig(pdf,facecolor='white',bbox_inches=None,pad_inches=0,metadata={'Creator':'submission clean postprocess','CreationDate':None,'ModDate':None})
    with Image.open(png) as im:
        width,height=im.size
    FIGURE_RECORDS.append({'figure':f'{prefix}{num}','title':title,'width_px':width,'height_px':height,'aspect_ratio':width/height,'source_tables':';'.join(sources)})
    plt.close(fig)

def ellipse90(ax,r,color):
    if not np.isfinite(r.ellipse90_major_radius) or not np.isfinite(r.ellipse90_minor_radius): return
    e=Ellipse((r.representative_performance_score,r.representative_credibility_score),
              width=2*r.ellipse90_major_radius,height=2*r.ellipse90_minor_radius,angle=r.ellipse90_angle_deg,
              facecolor=color,edgecolor=color,alpha=.12,lw=.65,zorder=1)
    ax.add_patch(e)

def candidate_color(sid):
    return {'solar_salt_ss60':NAVY,'knc':ROSE,'qncc':MUSTARD,'mgcl_kcl_nacl':TERRACOTTA,'nkca':OLIVE,
            'pcm_lif_s1':ROSE_LIGHT,'pcm_binary_carbonate':BURGUNDY,'hitec':BLUE,'hitec_xl':CREAM,'quat_s7':'#A48B55',
            'tms2':'#5F8D72','nknkcl_2026':'#7F6AAE','nkckcl_2026':'#D57A66',
            'linak_carbonate':'#3F7C85','flinak_rr':'#8C6F4E'}.get(str(sid),MID_GREY)

# ------------------------------ FIGURE 1 ---------------------------------
def fig1():
    dbfun=read('database_to_shortlist_transition'); lit=read('literature_evidence_flow')
    scope=read('candidate_scope_and_inclusion_audit')
    attr=read('evidence_attrition','expanded_v3'); fam=read('family_evidence_coverage','expanded_v3')
    fig=plt.figure(figsize=(MAIN_W,7.55),constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[.96,1.16,1.00],hspace=.085,wspace=.060)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1]); axe=fig.add_subplot(gs[2,:])

    # a — two source universes are kept separate because their records and formula systems
    # are not interchangeable denominators.
    panel(axa,'a'); axa.axis('off')
    official=[('976','official\nrecords'),('937','with $T_m$'),('250','service-\ncompatible'),('74','minimum\ncoverage')]
    application=[('779','property\nrecords'),('83','formula\nsystems'),('142','exact\ncandidates')]
    lane_specs=[(.72,'Official thermophysical screen',official,NAVY),(.25,'Application evidence library',application,TERRACOTTA)]
    for y0,title,items,col in lane_specs:
        axa.text(.01,y0+.17,title,transform=axa.transAxes,fontsize=6.1,fontweight='bold',color=col,va='center')
        xs=np.linspace(.03,.79,len(items))
        for i,(x0,(num,lab)) in enumerate(zip(xs,items)):
            axa.add_patch(FancyBboxPatch((x0,y0-.09),.18,.17,boxstyle='round,pad=.012',transform=axa.transAxes,fc='white',ec=col,lw=.8))
            axa.text(x0+.09,y0+.025,num,transform=axa.transAxes,ha='center',va='center',fontsize=8.0,fontweight='bold',color=col)
            axa.text(x0+.09,y0-.048,lab,transform=axa.transAxes,ha='center',va='center',fontsize=4.5,color=INK,linespacing=.9)
            if i<len(items)-1: axa.annotate('',xy=(xs[i+1]-.012,y0),xytext=(x0+.195,y0),xycoords=axa.transAxes,arrowprops=dict(arrowstyle='-|>',lw=.65,color=MID_GREY))
    axa.text(.99,.02,'Counts describe different evidence objects; they are not pooled.',transform=axa.transAxes,ha='right',fontsize=5.0,color=MID_GREY)

    # b — evidence stream Sankey/alluvial, using the supplied high-end grammar.
    panel(axb,'b')
    lf=lit.groupby(['evidence_stream','candidate_family'],as_index=False).unique_source_candidate_link.sum()
    sm={'Reference databases':'Databases','System benchmarks':'Benchmarks','Thermophysical literature':'Thermophysical','Corrosion literature':'Corrosion','Contextual literature':'Context','Other literature':'Other'}
    fm={'Nitrate/nitrite':'Nitrate','Chloride':'Chloride','Carbonate/fluoride':'Carbonate/F'}
    lf['evidence_stream']=lf.evidence_stream.map(sm).fillna(lf.evidence_stream); lf['candidate_family']=lf.candidate_family.map(fm).fillna(lf.candidate_family)
    sc={'Databases':NAVY,'Benchmarks':BLUE,'Thermophysical':MUSTARD,'Corrosion':BURGUNDY,'Context':CREAM,'Other':NEUTRAL}
    fc={'Nitrate':MUSTARD,'Chloride':TERRACOTTA,'Carbonate/F':ROSE}
    L.weighted_alluvial(axb,lf,['evidence_stream','candidate_family'],'unique_source_candidate_link','evidence_stream',sc,node_color_map={**sc,**fc},stage_labels=['Evidence stream','Chemistry family'],outer_labels=True,label_min_fraction=.018,node_width=.07,gap=.008,node_top=.91,node_bottom=.01,stage_label_y=.985)

    # c — family-resolved property coverage across all 142 exact candidates.
    panel(axc,'c')
    cols=['candidates_with_melting','candidates_with_upper_boundary','candidates_with_cp','candidates_with_density','candidates_with_latent','candidates_with_cycles']
    labs=['$T_m$','Upper\nbound','$c_p$','Density','Latent','Cycles']
    m=fam.sort_values('exact_candidates',ascending=False).head(10).reset_index(drop=True)
    share=m[cols].div(m.exact_candidates,axis=0)
    im=axc.imshow(share,aspect='auto',cmap=LinearSegmentedColormap.from_list('cov',[VERY_LIGHT,CREAM,OLIVE]),vmin=0,vmax=1)
    axc.set_xticks(range(len(cols)),labs); axc.set_yticks(range(len(m)),[f'{x}  (n={n})' for x,n in zip(m.family,m.exact_candidates)]); axc.tick_params(axis='y',labelsize=4.9)
    for i in range(len(m)):
        for j,c in enumerate(cols):
            v=int(m.loc[i,c]); axc.text(j,i,str(v),ha='center',va='center',fontsize=4.6,color='white' if share.iloc[i,j]>.62 else INK)
    cax=axc.inset_axes([.34,1.11,.60,.026]); cb=fig.colorbar(im,cax=cax,orientation='horizontal'); cb.ax.xaxis.set_ticks_position('top'); cb.ax.tick_params(labelsize=5.2,length=1.2,pad=.2); cb.outline.set_linewidth(.4); axc.text(.31,1.125,'Within-family coverage',transform=axc.transAxes,ha='right',fontsize=5.2,clip_on=False)
    clean(axc,None)

    # d — claim-boundary bubble map; size = applications, fill = evidence score, symbol = exact database link.
    panel(axd,'d')
    plot=scope.copy(); xclass={'measured_and_database_validated':0,'measured_exact_composition':1,'measured_exact_composition_conditional_chemistry':1,'measured_exact_composition_corrosion_adjacent_only':1,'measured_exact_composition_corrosion_gated':1,'commercial_benchmark':2,'commercial_benchmark_review_average':2,'measured_latent_predicted_density_cp':3,'measured_latent_density_derived_not_direct':3,'partly_measured_partly_predicted':3}
    xclass.update({'measured_exact_composition_partial_transport':1,
                   'measured_exact_composition_scalar_domain_unresolved':1,
                   'measured_exact_composition_corrosion_unresolved':1,
                   'measured_exact_composition_review_harmonised_corrosion_bounded':1,
                   'multi_lab_round_robin_composition_variability':1})
    plot['x']=plot.property_data_class.map(xclass).fillna(3); plot['score']=pd.to_numeric(plot.evidence_score,errors='coerce')
    jitter=np.linspace(-.12,.12,len(plot));
    for j,r in enumerate(plot.itertuples(index=False)):
        mk='s' if r.exact_formula_system_match else 'o'
        axd.scatter(r.x+jitter[j],r.score,s=34+16*r.registered_application_count,marker=mk,color=candidate_color(r.system_id),edgecolor=INK if r.evidence_score<.5 else 'white',lw=.65,zorder=3)
        label_offsets={
            'hitec_xl':(-16,9),
            'pcm_lif_s1':(-30,14),
            'pcm_binary_carbonate':(-30,-15),
            'qncc':(-22,-11),
            'mgcl_kcl_nacl':(-28,10),
            'tms2':(-24,-15),
            'nknkcl_2026':(24,-22),
            'nkckcl_2026':(28,4),
            'linak_carbonate':(32,18),
            'flinak_rr':(32,-15),
        }
        off=label_offsets.get(str(r.system_id),(0,5))
        ha='right' if off[0]<0 else ('left' if off[0]>0 else 'center')
        axd.annotate(short_id(r.system_id),(r.x+jitter[j],r.score),xytext=off,textcoords='offset points',ha=ha,va='bottom' if off[1]>=0 else 'top',fontsize=5.1,clip_on=False,arrowprops=dict(arrowstyle='-',lw=.45,color=MID_GREY) if str(r.system_id) in label_offsets else None)
    axd.axhline(.75,color=MID_GREY,lw=.7,ls='--'); axd.text(3.45,.765,'registered evidence floor',ha='right',fontsize=5.2,color=MID_GREY)
    axd.set_xticks(range(4),['Database-\nvalidated','Exact measured','Commercial\nbenchmark','Derived /\npredicted'])
    axd.set_xlim(-.45,3.45); axd.set_ylim(.18,1.03); axd.set_ylabel('Registered evidence score'); clean(axd,'y')
    top_legend(axd,[Line2D([0],[0],marker='s',ls='',mfc='white',mec=INK,label='Exact database formula link',markersize=4.5),Line2D([0],[0],marker='o',ls='',mfc=NEUTRAL,mec='white',label='Area: registered applications',markersize=5.0)],ncol=2,anchor=(.5,1.12),fontsize=5.2)

    # e — conditional retention locates the evidence bottlenecks without redrawing panel a.
    panel(axe,'e')
    wanted=['Candidate-service pairs across seven frozen duties','Physical-window-compatible pairs','Quantitative thermophysical pairs','Service-domain-supported thermophysical pairs','Service-domain-supported pairs linked to frozen engineering registry']
    counts=attr.set_index('stage').loc[wanted]['count'].astype(int).to_numpy()
    numerators=counts[1:]; denominators=counts[:-1]; retention=np.divide(numerators,denominators,out=np.zeros_like(numerators,dtype=float),where=denominators>0)
    x=np.arange(len(retention)); stage_lab=['Physical\nwindow','Quantitative\nproperties','Service-domain\nsupport','Engineering\nregistry link']; stage_cols=[BLUE,MUSTARD,TERRACOTTA,OLIVE]
    axe.bar(x,retention,width=.62,color=stage_cols,edgecolor='white',lw=.65,zorder=3)
    axe.scatter(x,retention,s=23,color=stage_cols,edgecolor='white',lw=.55,zorder=4)
    for i,(num,den,val,col) in enumerate(zip(numerators,denominators,retention,stage_cols)):
        value_badge(axe,i,max(float(val),.015),f'{int(num):,}/{int(den):,}  ·  {val:.1%}',dx=0,dy=7,ha='center',va='bottom',color=col,ec=col,clip_on=False,fontsize=4.8)
    axe.set_xticks(x,stage_lab); axe.set_ylim(0,1.08); axe.set_ylabel('Conditional retention from preceding gate'); axe.yaxis.set_major_formatter(mpl.ticker.PercentFormatter(1.0)); clean(axe,'y')
    axe.text(.01,1.12,'142 exact candidates × 7 frozen services = 994 evaluated pairs',transform=axe.transAxes,ha='left',va='bottom',fontsize=5.4,fontweight='bold',clip_on=False)
    axe.text(.99,1.12,'Each percentage uses the preceding gate as its denominator',transform=axe.transAxes,ha='right',va='bottom',fontsize=5.0,color=MID_GREY,clip_on=False)
    pd.DataFrame({'gate':stage_lab,'numerator':numerators,'preceding_denominator':denominators,'conditional_retention':retention}).to_csv(QA/'fig1e_conditional_retention_audit.csv',index=False)

    save(fig,1,'A two-universe evidence architecture separates thermophysical opportunity from frozen-registry formal assessment',['database_to_shortlist_transition','literature_evidence_flow','expanded_v3_family_evidence_coverage','candidate_scope_and_inclusion_audit','expanded_v3_evidence_attrition'])

# ------------------------------ FIGURE 2 ---------------------------------
def fig2():
    story=read('cross_layer_storyline','expanded_v3')
    dom=read('domain_validated_thermophysical_mc','expanded_v3')
    layered=read('layered_selection_frequencies'); nosel=read('no_selection_frequencies')
    external=pd.read_csv(TABLES/'joule_external_scalar_performance.csv')
    fig=plt.figure(figsize=(MAIN_W,7.85),constrained_layout=True)
    gs=fig.add_gridspec(3,2,height_ratios=[1.10,1.14,.96],hspace=.085,wspace=.060)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1]); axe=fig.add_subplot(gs[2,:])

    # a — full-library contractions by service.
    panel(axa,'a')
    y=np.arange(len(story)); cats=['physical_window_pairs','quantitative_pairs','service_domain_supported_pairs']; labs=['Physical window','Quantitative properties','Service-domain supported']; cols=[BLUE,MUSTARD,OLIVE]
    for off,(c,lab,col) in zip([-.22,0,.22],zip(cats,labs,cols)):
        axa.barh(y+off,story[c],height=.19,color=col,label=lab)
        for yy,v in zip(y+off,story[c]):
            if v>0: axa.text(v+.45,yy,str(int(v)),va='center',fontsize=4.7,color=col,fontweight='bold')
    axa.set_yticks(y,[compact_service_label(x) for x in story.service_id]); axa.invert_yaxis(); axa.set_xlabel('Candidate–service pairs'); axa.set_xlim(0,max(28,story.physical_window_pairs.max()+4)); clean(axa,'x')
    top_legend(axa,[Patch(facecolor=c,label=l) for c,l in zip(cols,labs)],ncol=3,anchor=(.5,1.15),fontsize=4.7)

    # b — independent rule-transfer test. Nine exact nitrate formulations report
    # high scalar performance at 300 °C, but none spans a registered duty window.
    panel(axb,'b')
    ext=external.sort_values('volumetric_heat_capacity_MJ_m3K_at_300C').reset_index(drop=True)
    y=np.arange(len(ext)); values=ext.volumetric_heat_capacity_MJ_m3K_at_300C.to_numpy()
    cols_ext=np.where(ext.candidate_id.eq('botejara_salt_7'),TERRACOTTA,BLUE)
    axb.hlines(y,0,values,color=PALE_BLUE,lw=1.7,zorder=1)
    axb.scatter(values,y,s=32,color=cols_ext,edgecolor='white',lw=.55,zorder=3)
    for i,(value,col) in enumerate(zip(values,cols_ext)):
        axb.text(value+.10,i,f'{value:.2f}',ha='left',va='center',fontsize=4.3,color=col,fontweight='bold')
    solar_reference=1.50*1.90
    axb.axvline(solar_reference,color=INK,lw=.75,ls='--',zorder=0)
    axb.text(solar_reference+.06,len(ext)-.60,'Solar Salt reference\n2.85',ha='left',va='top',fontsize=4.25,color=INK)
    axb.set_yticks(y,ext.display_name); axb.tick_params(axis='y',labelsize=4.7,pad=1)
    axb.set_xlim(0,9.15); axb.set_ylim(-.75,len(ext)+1.0)
    axb.set_xlabel(r'Volumetric heat capacity at 300 °C (MJ m$^{-3}$ K$^{-1}$)'); clean(axb,'x')
    viscosity_min=float(ext.viscosity_relative_to_solar_salt.min()); viscosity_max=float(ext.viscosity_relative_to_solar_salt.max())
    axb.text(.99,.980,'Independent 2026 set: 9 exact formulations',transform=axb.transAxes,ha='right',va='top',fontsize=4.8,fontweight='bold',color=INK)
    axb.text(.99,.915,f'Viscosity: {viscosity_min:.1f} to {viscosity_max:.1f}× Solar Salt',transform=axb.transAxes,ha='right',va='top',fontsize=4.4,color=MID_GREY)
    axb.text(.99,.020,'27 physical windows · 27 scalar pairs · 0 full-duty-supported pairs',transform=axb.transAxes,ha='right',va='bottom',fontsize=4.45,fontweight='bold',color=BURGUNDY)
    ext.assign(solar_salt_reference_MJ_m3K=solar_reference,physical_window_pairs=27,service_domain_supported_pairs=0).to_csv(QA/'fig2b_external_rule_transfer_audit.csv',index=False)

    # c — service-domain-supported thermophysical rank-1 frequencies, retaining the new 2025 chloride opportunity.
    panel(axc,'c')
    q=dom[(dom.display_system.ne('none')) & dom.thermophysical_rank1_frequency.ge(.001)].copy()
    q['label']=[f'{compact_service_label(s)} · {leader_label(c)}' for s,c in zip(q.service_id,q.display_system)]
    q=q.sort_values('thermophysical_rank1_frequency').reset_index(drop=True); y=np.arange(len(q))
    axc.hlines(y,0,q.thermophysical_rank1_frequency,color=PALE_BLUE,lw=1.8); axc.scatter(q.thermophysical_rank1_frequency,y,s=34,color=[SCOL[s] for s in q.service_id],edgecolor=np.where(q.display_system.str.contains('23.5-25.0-51.5',regex=False),INK,'white'),lw=.75)
    axc.set_yticks(y,q.label); axc.tick_params(axis='y',labelsize=4.5,pad=1); axc.set_xlim(0,1.14); barh_headroom(axc,len(q),.45); axc.set_xlabel('Service-domain-supported rank-1 frequency'); clean(axc,'x')
    for i,r in q.iterrows(): value_badge(axc,r.thermophysical_rank1_frequency,i,f'{r.thermophysical_rank1_frequency:.0%}',dx=5,color=SCOL[r.service_id],ec=SCOL[r.service_id],fontsize=4.5)

    # d — formal evidence-bounded outcomes. No-selection is a result, not missing data.
    panel(axd,'d')
    sel=layered[(layered.ranking_layer.eq('evidence_qualified'))&(layered.weight_prior.eq('balanced'))&layered.selection_frequency.gt(0)][['scenario','system_id','selection_frequency']].copy()
    ns=nosel[(nosel.ranking_layer.eq('evidence_qualified'))&(nosel.weight_prior.eq('balanced'))][['scenario','no_selection_frequency']].copy(); ns['system_id']='__NO_SELECTION__'; ns=ns.rename(columns={'no_selection_frequency':'selection_frequency'}); sel=pd.concat([sel,ns],ignore_index=True)
    cand=['solar_salt_ss60','hitec','__NO_SELECTION__']; cm=[NAVY,BLUE,BURGUNDY]; piv=sel.pivot(index='scenario',columns='system_id',values='selection_frequency').reindex(SERVICE_ORDER).fillna(0); y=np.arange(len(piv)); left=np.zeros(len(piv))
    for c,col in zip(cand,cm):
        v=piv[c].to_numpy() if c in piv else np.zeros(len(piv)); axd.barh(y,v,left=left,height=.62,color=col)
        for i,z in enumerate(v):
            if z>=.09: axd.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.0,color='white')
        left+=v
    axd.set_yticks(y,[compact_service_label(s) for s in piv.index]); axd.set_xlim(0,1); barh_headroom(axd,len(piv),.28); axd.set_xlabel('Formal selection frequency under registered priors'); clean(axd,'x')
    top_legend(axd,[Patch(facecolor=c,label=l) for c,l in zip(cm,['Solar Salt','HITEC','No formal selection'])],ncol=3,anchor=(.5,1.13),fontsize=4.7)

    # e — the PCM500 counterexample: a new exact composition is physically competitive,
    # yet every candidate remains outside the formal evidence-bounded layer.
    panel(axe,'e')
    p=dom[(dom.service_id.eq('pcm_target_500C'))&(dom.display_system.ne('none'))].sort_values('thermophysical_rank1_frequency').reset_index(drop=True); y=np.arange(len(p))
    labels=[leader_label(x) for x in p.display_system]; cols2=[BURGUNDY if '23.5-25.0-51.5' in str(x) else MUSTARD for x in p.display_system]
    axe.hlines(y,0,p.thermophysical_rank1_frequency,color=CREAM,lw=2.4); axe.scatter(p.thermophysical_rank1_frequency,y,s=48,color=cols2,edgecolor='white',lw=.6)
    for i,r in p.iterrows(): value_badge(axe,r.thermophysical_rank1_frequency,i,f'{r.thermophysical_rank1_frequency:.1%}',dx=6,color=cols2[i],ec=cols2[i])
    axe.set_yticks(y,labels); axe.set_xlim(0,1.05); barh_headroom(axe,len(p),.72); axe.set_xlabel('PCM500 service-domain-supported rank-1 frequency'); clean(axe,'x')
    new_chloride=p[p.display_system.str.contains('23.5-25.0-51.5',regex=False)]
    if len(new_chloride)!=1:
        raise RuntimeError(f'Expected one new 2025 chloride PCM500 row, found {len(new_chloride)}')
    new_chloride_frequency=float(new_chloride.iloc[0].thermophysical_rank1_frequency)
    new_chloride_percent=(Decimal(str(new_chloride_frequency))*Decimal('100')).quantize(Decimal('0.01'),rounding=ROUND_HALF_UP)
    axe.text(.99,.94,f'New 2025 chloride: {new_chloride_percent}% thermophysical opportunity · formal assessment pending',transform=axe.transAxes,ha='right',va='top',fontsize=5.5,fontweight='bold',color=BURGUNDY)
    axe.text(.99,.79,'Outside the frozen 15-candidate engineering registry; corrosion and cycling evidence remain unresolved',transform=axe.transAxes,ha='right',va='top',fontsize=5.0,color=MID_GREY)
    pd.DataFrame({'scenario':p.service_id,'candidate':p.display_system,'rank1_frequency':p.thermophysical_rank1_frequency}).to_csv(QA/'fig2_pcm500_opportunity_audit.csv',index=False)

    save(fig,2,'Independent evidence tests show why scalar performance cannot replace full-duty support',['expanded_v3_cross_layer_storyline','joule_external_scalar_performance','joule_external_validation_summary','expanded_v3_domain_validated_thermophysical_mc','layered_selection_frequencies','no_selection_frequencies'])

# ------------------------------ FIGURE 3 ---------------------------------
def fig3():
    joint=read('joint_threshold_regime_map'); cov=read('service_coverage_threshold_sensitivity'); sweep=read('threshold_retention_sweep')
    entry=read('new_candidate_entry_audit','expanded_v3'); arche=read('service_regime_archetype_summary',V)
    thermal_boundaries=pd.read_csv(ROOT/'config'/'core_service_thermal_boundary_registry.csv').rename(columns={'service_mode':'registered_service_mode'})
    fig=plt.figure(figsize=(MAIN_W,8.85),constrained_layout=True)
    gs=fig.add_gridspec(3,6,height_ratios=[.88,1.10,1.00],hspace=.13,wspace=.16)
    axa=fig.add_subplot(gs[0,0:3]); axb=fig.add_subplot(gs[0,3:6]); axc=fig.add_subplot(gs[1,0:2]); axd=fig.add_subplot(gs[1,2:6]); axe=fig.add_subplot(gs[2,:])

    # a — one-axis stacked summary of all 630 registered joint states.
    panel(axa,'a')
    regimes=['robust access','conditional access','no bounded access']; rc={'robust access':OLIVE,'conditional access':MUSTARD,'no bounded access':BURGUNDY}
    share=(joint.groupby(['scenario','decision_regime']).size().unstack(fill_value=0).reindex(SERVICE_ORDER).reindex(columns=regimes,fill_value=0))
    share=share.div(share.sum(axis=1),axis=0); y=np.arange(len(share)); left=np.zeros(len(share))
    for rg in regimes:
        v=share[rg].to_numpy(); axa.barh(y,v,left=left,height=.62,color=rc[rg],label=rg.title())
        for i,z in enumerate(v):
            if z>=.14: axa.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.4,color='white' if rg=='no bounded access' else INK)
        left+=v
    axa.set_yticks(y,[SERVICE[x] for x in share.index]); axa.set_xlim(0,1); barh_headroom(axa,len(share),.18)
    axa.set_xlabel('Share of 90 coverage–evidence states'); clean(axa,'x')
    top_legend(axa,[Patch(facecolor=rc[x],label=x.title()) for x in regimes],ncol=3,anchor=(.5,1.15),fontsize=4.9)

    # b — coverage uncertainty curves for the three informative services.
    panel(axb,'b')
    for ss in ['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat']:
        g=cov[cov.scenario.eq(ss)].sort_values('coverage_threshold'); x=g.coverage_threshold.to_numpy(); yy=g.no_selection_frequency.to_numpy(); n=g.mc_iterations.to_numpy(); se=np.sqrt(np.maximum(yy*(1-yy)/n,0))
        axb.fill_between(x,np.clip(yy-1.645*se,0,1),np.clip(yy+1.645*se,0,1),color=SCOL[ss],alpha=.16,lw=0); axb.plot(x,yy,color=SCOL[ss],lw=1.2,marker='o',ms=2.5,label=SERVICE[ss])
    axb.set_xlim(.948,1.002); axb.set_ylim(-.02,.55); axb.set_xlabel('Minimum service coverage'); axb.set_ylabel('No-selection frequency'); clean(axb,'both')
    top_legend(axb,[Line2D([0],[0],color=SCOL[x],marker='o',lw=1,label=SERVICE[x],markersize=3) for x in ['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat']],ncol=3,anchor=(.5,1.15),fontsize=5.1)

    # c — full evidence-threshold response. The former breakpoint-only panel hid
    # the sharp loss of bounded access between 0.75 and 0.85.
    panel(axc,'c'); evidence_services=['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat']; audit=[]
    for ss in evidence_services:
        g=joint[(joint.scenario.eq(ss)) & np.isclose(joint.coverage_threshold,joint.coverage_threshold.min())].sort_values('evidence_threshold')
        axc.step(g.evidence_threshold,g.no_selection_frequency,where='post',lw=1.35,color=SCOL[ss],label=SERVICE[ss])
        axc.scatter(g.evidence_threshold,g.no_selection_frequency,s=8,color=SCOL[ss],edgecolor='white',lw=.25,zorder=3)
        audit.append({'scenario':ss,'minimum_no_selection':g.no_selection_frequency.min(),'maximum_no_selection':g.no_selection_frequency.max(),'transition_count':int(g.no_selection_frequency.nunique()-1)})
    axc.axvspan(.75,.85,color=CREAM,alpha=.25,lw=0); axc.text(.80,.05,'decision cliff',ha='center',fontsize=4.8,color=MID_GREY)
    axc.set_xlim(.23,.97); axc.set_ylim(-.03,1.03); axc.set_xlabel('Candidate-specific evidence threshold'); axc.set_ylabel('No-formal-selection frequency'); clean(axc,'both')
    pd.DataFrame(audit).to_csv(QA/'fig3c_evidence_response_audit.csv',index=False)

    # d — signed thermal-headroom matrix for the four newly audited compositions.
    # This replaces a zero-heavy gate diagram. It answers a distinct physical
    # question: how far each candidate-service pair lies from thermal admissibility.
    panel(axd,'d'); entry=entry.copy()
    d=entry.merge(thermal_boundaries,on='service_id',how='left',validate='many_to_one')
    if d.registered_service_mode.isna().any() or not d.service_mode.eq(d.registered_service_mode).all():
        raise RuntimeError('Service thermal-boundary registry is incomplete or inconsistent with the candidate-entry audit.')
    def thermal_margin(row):
        # A failed upper-boundary gate may mean either a measured-but-insufficient
        # stability limit or a genuinely unreported limit. Only the latter is unknown.
        if pd.isna(row.stability_temperature_C): return np.nan
        if row.service_mode=='sensible':
            cold_margin=float(row.fixed_Tcold_C)-float(row.melting_temperature_C)
            upper_margin=float(row.stability_temperature_C)-float(row.fixed_Thot_C)
            return min(cold_margin,upper_margin)
        centre=(float(row.phase_target_min_C)+float(row.phase_target_max_C))/2
        half_width=(float(row.phase_target_max_C)-float(row.phase_target_min_C))/2
        return half_width-abs(float(row.melting_temperature_C)-centre)
    d['thermal_margin_C']=[thermal_margin(r) for r in d.itertuples(index=False)]
    d['thermal_margin_status']=np.where(d.stability_temperature_C.notna(),'resolved','upper_boundary_unreported')
    resolved=d.thermal_margin_status.eq('resolved')
    if not ((d.loc[resolved,'thermal_margin_C']>=0).to_numpy()==d.loc[resolved,'physical_window_pass'].astype(bool).to_numpy()).all():
        raise RuntimeError('Signed thermal-margin reconstruction does not match the registered physical-window gate.')
    candidate_order=['NaCl-KCl-CaCl2 23.5-25.0-51.5 wt%','HXLN 95% Hitec XL + 5% NaNO2','NKM-12 ternary sulfate','Na2CO3-NaCl-KCl ternary eutectic']
    candidate_short={
        'NaCl-KCl-CaCl2 23.5-25.0-51.5 wt%':r'NaCl–KCl–CaCl$_2$ (2025)',
        'HXLN 95% Hitec XL + 5% NaNO2':'HXLN','NKM-12 ternary sulfate':'NKM-12',
        'Na2CO3-NaCl-KCl ternary eutectic':r'Na$_2$CO$_3$–NaCl–KCl'
    }
    def next_boundary(g):
        if g.stability_temperature_C.notna().sum()==0: return 'Upper boundary\nunreported'
        physical=int(g.physical_window_pass.sum())
        if physical==0: return 'No thermally\nadmissible duty'
        if g.quantitative_thermophysical_complete.sum()==0: return f'Property fields incomplete\nafter {physical} thermal fits'
        if g.service_domain_supported.sum()==0: return 'Service-domain support\nunresolved'
        if g.engineering_registry_linked.sum()==0: return 'Outside frozen\nengineering registry'
        if g.formal_assessment_completed.sum()==0: return 'Formal evidence\nincomplete'
        return 'Formally assessed'
    boundary_by_candidate={name:next_boundary(g) for name,g in d.groupby('display_system')}
    d['first_post_thermal_boundary']=d.display_system.map(boundary_by_candidate).str.replace('\n',' ',regex=False)
    margins=d.pivot(index='display_system',columns='service_id',values='thermal_margin_C').reindex(index=candidate_order,columns=SERVICE_ORDER)
    cmap=LinearSegmentedColormap.from_list('thermal_headroom',[BURGUNDY,ROSE_LIGHT,CREAM,OLIVE])
    # Missing upper-stability evidence is a categorical state, not a zero margin.
    # A pale-blue fill, blue hatch and navy N/R label keep it outside the signed scale.
    cmap.set_bad(PALE_BLUE); norm=TwoSlopeNorm(vmin=-450,vcenter=0,vmax=130)
    axd.imshow(margins.to_numpy(float),aspect='auto',cmap=cmap,norm=norm,interpolation='nearest')
    for i,name in enumerate(candidate_order):
        for j,ss in enumerate(SERVICE_ORDER):
            value=margins.loc[name,ss]
            if pd.isna(value):
                axd.add_patch(Rectangle((j-.5,i-.5),1,1,facecolor='none',edgecolor=BLUE,lw=.48,hatch='////'))
                axd.text(j,i,'N/R',ha='center',va='center',fontsize=4.15,fontweight='bold',color=NAVY)
            else:
                axd.text(j,i,f'{value:+.0f}',ha='center',va='center',fontsize=4.35,fontweight='bold',color='white' if value < -185 or value > 75 else INK)
        axd.text(7.14,i-.08,candidate_short[name],ha='left',va='bottom',fontsize=4.15,fontweight='bold',color=INK)
        axd.text(7.14,i+.06,boundary_by_candidate[name],ha='left',va='top',fontsize=3.95,color=BURGUNDY if 'Outside frozen' in boundary_by_candidate[name] else MID_GREY,linespacing=.90)
    chloride_row=candidate_order.index('NaCl-KCl-CaCl2 23.5-25.0-51.5 wt%'); pcm500_col=SERVICE_ORDER.index('pcm_target_500C')
    axd.add_patch(Rectangle((pcm500_col-.5,chloride_row-.5),1,1,facecolor='none',edgecolor=INK,lw=1.0))
    axd.axvline(6.72,color=LIGHT_GREY,lw=.65)
    axd.text(7.14,-.72,'Candidate · first post-thermal boundary',ha='left',va='center',fontsize=4.45,fontweight='bold')
    axd.set_xticks(range(len(SERVICE_ORDER)),['Coal','CSP','Industrial',r'sCO$_2$','PCM350','PCM425','PCM500'],rotation=28,ha='right')
    axd.set_yticks(range(len(candidate_order)),['']*len(candidate_order)); axd.tick_params(axis='y',length=0)
    axd.set_xlim(-.5,10.7); axd.set_ylim(len(candidate_order)-.5,-.94); clean(axd,None)
    axd.set_title('Signed limiting thermal headroom (°C) · non-negative values pass · N/R = upper stability boundary not reported',loc='left',fontsize=4.45,color=MID_GREY,pad=3)
    d.to_csv(QA/'fig3d_candidate_service_thermal_margin_audit.csv',index=False)
    supp_roles={
        1:'full-library chemistry, property coverage and source density',2:'database/provenance matching and atomic credibility',3:'deterministic thermophysical profiles',4:'pairwise performance probability and conditional cost',
        5:'partial-overlap overclaim penalty',6:'threshold registry and convergence',7:'condition-specific engineering-evidence intervals',8:'source-omission sensitivity',9:'credibility shortfall and model sensitivity',
        10:'readiness and candidate archetypes',11:'evidence-action interactions and non-additivity',12:'predictive-model and value-function validation',13:'composite-media response and system coupling'
    }
    pd.DataFrame([{'supplementary_figure':f'Supp Fig. {i}','supplementary_role':role,'fig3d_role':'candidate-service signed limiting thermal headroom and first post-thermal boundary','shared_primary_metric':False,'duplicate_panel':False} for i,role in supp_roles.items()]).to_csv(QA/'fig3d_supplement_nonduplication_audit.csv',index=False)

    # e — compact archetype bubble strip. Empty nominal categories are omitted:
    # an unoccupied "stable" column would imply an observed outcome that is absent.
    panel(axe,'e'); a=arche.copy()
    a.loc[a.uncertainty_structure_class.eq('service-incomplete'),'regime_archetype']='structural service limitation'
    base_xcats=['multi-boundary regime','joint threshold-sensitive','evidence-sensitive','structural service limitation','structural evidence lock','stable single regime']
    present_archetypes=set(a.regime_archetype.astype(str))
    xcats=[x for x in base_xcats if x in present_archetypes]+sorted(present_archetypes-set(base_xcats))
    xlabels={'multi-boundary regime':'Multi-\nboundary','joint threshold-sensitive':'Joint\nthreshold','evidence-sensitive':'Evidence\nresponse','structural service limitation':'Service\nlimited','structural evidence lock':'Evidence\nlocked','stable single regime':'Stable'}
    xmap={x:i for i,x in enumerate(xcats)}
    for i,r in enumerate(a.itertuples(index=False)):
        x=xmap[str(r.regime_archetype)]; size=28+2.0*r.registered_joint_states
        axe.scatter(x,i,s=size,color=SCOL[r.scenario],edgecolor=INK if r.main_map_informative else 'white',lw=.7)
        axe.text(x,i,str(int(r.decision_regime_count)),ha='center',va='center',fontsize=5.4,color='white' if SCOL[r.scenario] in [BURGUNDY,TERRACOTTA,NAVY] else INK)
    axe.set_yticks(range(len(a)),[SERVICE[x] for x in a.scenario]); axe.set_xticks(range(len(xcats)),[xlabels.get(x,str(x).replace(' ','\n')) for x in xcats])
    axe.set_xlim(-.5,len(xcats)-.5); axe.set_ylim(-.6,len(a)-.15); clean(axe,'both'); axe.set_xlabel('Service-level regime archetype')
    axe.text(.995,.02,'Number inside = distinct joint regimes · black edge = informative boundary map',transform=axe.transAxes,ha='right',va='bottom',fontsize=4.65,color=MID_GREY,bbox=dict(facecolor='white',edgecolor='none',pad=.25,alpha=.90))
    archetype_audit=a.groupby('regime_archetype',as_index=False).size().rename(columns={'size':'service_count'})
    archetype_audit['displayed_in_fig3e']=archetype_audit.regime_archetype.isin(xcats)
    archetype_audit.to_csv(QA/'fig3e_populated_regime_archetypes.csv',index=False)

    save(fig,3,'Evidence thresholds create decision cliffs while signed thermal margins expose candidate-specific stopping mechanisms',['joint_threshold_regime_map','service_coverage_threshold_sensitivity','threshold_retention_sweep','expanded_v3_new_candidate_entry_audit','core_service_thermal_boundary_registry','submission_service_regime_archetype_summary'])

# ------------------------------ FIGURE 4 ---------------------------------
def fig4():
    pa=read('pareto_joint_uncertainty_and_robustness',STAT); dom=read('pareto_dominance_mechanism_summary',V); scope=read('decision_scope_matrix',STAT); flow=read('figure_selection_alluvial_flows')
    fig=plt.figure(figsize=(MAIN_W,9.45),constrained_layout=True)
    fig.set_constrained_layout_pads(w_pad=.018,h_pad=.012,wspace=0,hspace=0)
    gs=fig.add_gridspec(4,6,height_ratios=[1.47,1.02,.92,.82],hspace=.078,wspace=.050)
    gsa=gs[0,:].subgridspec(2,3,hspace=0,wspace=0)
    facet_positions=[(0,0),(0,1),(0,2),(1,0),(1,1)]
    axa_list=[fig.add_subplot(gsa[r,c]) for r,c in facet_positions]
    axa_single=fig.add_subplot(gsa[1,2])
    axb=fig.add_subplot(gs[1,0:3]); axc=fig.add_subplot(gs[1,3:6])
    gsd=gs[2,:].subgridspec(2,1,height_ratios=[1.42,.78],hspace=.025)
    axd=fig.add_subplot(gsd[0,0]); axdm=fig.add_subplot(gsd[1,0],sharex=axd)
    axe=fig.add_subplot(gs[3,0:3]); axf=fig.add_subplot(gs[3,3:6])

    # a — five service-faceted representative Pareto geometries plus a matched
    # singleton-service evidence-precision panel. Singleton services are shown as
    # evidence intervals only and are never presented as informative Pareto fronts.
    # Marginal 5–95% intervals replace cross-service joint ellipses, which previously
    # obscured the within-service front.
    q=pa[(pa.frontier_scope=='opportunity')&pa.joint_valid_draws.gt(0)].copy()
    facet_services=['coal_flexibility_storage','csp_sensible_storage','industrial_medium_heat','sco2_high_temperature_storage','pcm_target_500C']
    fig4a_label_artists=[]
    fig4_direct_label_artists=[]
    label_offsets={
        ('coal_flexibility_storage','knc'):(3,-7,'left'),('coal_flexibility_storage','mgcl_kcl_nacl'):(3,4,'left'),
        ('coal_flexibility_storage','qncc'):(3,4,'left'),('coal_flexibility_storage','nkckcl_2026'):(-3,-8,'right'),('coal_flexibility_storage','solar_salt_ss60'):(-3,-8,'right'),
        ('csp_sensible_storage','qncc'):(3,4,'left'),('csp_sensible_storage','nkckcl_2026'):(-3,4,'right'),('csp_sensible_storage','solar_salt_ss60'):(-3,-8,'right'),
        ('industrial_medium_heat','nkckcl_2026'):(3,3,'left'),('industrial_medium_heat','hitec_xl'):(3,4,'left'),('industrial_medium_heat','qncc'):(3,-8,'left'),
        ('industrial_medium_heat','hitec'):(-3,-9,'right'),('industrial_medium_heat','solar_salt_ss60'):(-3,4,'right'),
        ('sco2_high_temperature_storage','mgcl_kcl_nacl'):(3,-8,'left'),('sco2_high_temperature_storage','linak_carbonate'):(-3,4,'right'),
        ('pcm_target_500C','nkca'):(3,4,'left'),('pcm_target_500C','pcm_binary_carbonate'):(-3,4,'right')
    }
    for k,(ax,ss) in enumerate(zip(axa_list,facet_services)):
        if k==0: panel(ax,'a',x=-.17,y=1.13)
        g=q[q.scenario.eq(ss)].sort_values('representative_performance_score').copy()
        front=g[g.representative_frontier_member].sort_values('representative_performance_score')
        if len(front)>=2: ax.plot(front.representative_performance_score,front.representative_credibility_score,color=OLIVE,lw=1.05,zorder=1)
        for r in g.itertuples(index=False):
            x=float(r.representative_performance_score); y0=float(r.representative_credibility_score)
            xerr=np.array([[max(0,x-float(r.performance_q05))],[max(0,float(r.performance_q95)-x)]])
            yerr=np.array([[max(0,y0-float(r.credibility_q05))],[max(0,float(r.credibility_q95)-y0)]])
            ax.errorbar(x,y0,xerr=xerr,yerr=yerr,fmt='none',ecolor=MID_GREY,elinewidth=.90,capsize=2.0,capthick=.75,alpha=.72,zorder=2)
            filled=bool(r.representative_frontier_member)
            ax.scatter(x,y0,s=30,facecolor=OLIVE if filled else 'white',edgecolor=INK,lw=.65,zorder=4)
            dx,dy,ha=label_offsets.get((ss,r.system_id),((-3 if x>.72 else 3),4,('right' if x>.72 else 'left')))
            label=ax.annotate(short_id(r.system_id),(x,y0),xytext=(dx,dy),textcoords='offset points',ha=ha,va='bottom' if dy>=0 else 'top',fontsize=3.85,color=INK,clip_on=True,zorder=5,bbox=dict(facecolor='white',edgecolor='none',pad=.15,alpha=.82))
            fig4a_label_artists.append((SERVICE[ss],short_id(r.system_id),label))
            fig4_direct_label_artists.append((f'4a · {SERVICE[ss]}',short_id(r.system_id),label))
        ax.set_title(SERVICE[ss],fontsize=5.35,fontweight='bold',pad=2)
        ax.set_box_aspect(.47)
        ax.set_xlim(-.045,1.045); ax.set_ylim(-.045,1.045)
        col=k%3
        x_ticklabels=['0.0','0.5',''] if col==0 else (['','0.5',''] if col==1 else ['','0.5','1.0'])
        ax.set_xticks([0,.5,1],x_ticklabels); ax.set_yticks([0,.5,1]); ax.tick_params(labelsize=4.3,pad=1)
        if k in [0,3]: ax.set_ylabel('Evidence-readiness',fontsize=5.1)
        else: ax.tick_params(axis='y',labelleft=False)
        if k in [3,4]: ax.set_xlabel('Representative performance',fontsize=5.1,labelpad=2)
        clean(ax,'both')
    top_legend(axa_list[1],[Line2D([0],[0],marker='o',ls='',mfc=OLIVE,mec=INK,label='Representative frontier',markersize=4),Line2D([0],[0],marker='o',ls='',mfc='white',mec=INK,label='Dominated at representative draw',markersize=4),Line2D([0],[0],color=MID_GREY,lw=.9,label='Marginal 5–95% draw range')],ncol=3,anchor=(.5,1.22),fontsize=4.5)
    single=q[q.scenario.isin(['pcm_target_350C','pcm_target_425C'])].sort_values('scenario',ascending=False).reset_index(drop=True)
    sy=np.arange(len(single))
    axa_single.axvline(.5,color=LIGHT_GREY,lw=.65,ls='--',zorder=0)
    for i,r in single.iterrows():
        lo=float(r.credibility_q05); mid=float(r.representative_credibility_score); hi=float(r.credibility_q95)
        xerr=np.array([[mid-lo],[hi-mid]])
        axa_single.errorbar(mid,i,xerr=xerr,fmt='o',ms=5.2,mfc=SCOL[r.scenario],mec=INK,mew=.65,ecolor=SCOL[r.scenario],elinewidth=1.05,capsize=2.2,capthick=.80,zorder=3)
        candidate_label=axa_single.text(.448,i+.13,f'{SERVICE[r.scenario]} · {short_id(r.system_id)}',ha='left',va='bottom',fontsize=3.8,color=INK,zorder=4,bbox=dict(facecolor='white',edgecolor='none',pad=.25,alpha=.90),clip_on=True)
        value_label=axa_single.text(hi+.0025,i,f'{mid:.2f}',ha='left',va='center',fontsize=4.2,color=INK,clip_on=True,zorder=4,bbox=dict(facecolor='white',edgecolor='none',pad=.15,alpha=.86))
        fig4a_label_artists.extend([('Singleton',f'{SERVICE[r.scenario]} candidate',candidate_label),('Singleton',f'{SERVICE[r.scenario]} value',value_label)])
        fig4_direct_label_artists.extend([('4a · Singleton',f'{SERVICE[r.scenario]} candidate',candidate_label),('4a · Singleton',f'{SERVICE[r.scenario]} value',value_label)])
    axa_single.set_title('Singleton services · scope only',fontsize=5.35,fontweight='bold',pad=2)
    axa_single.set_yticks(sy); axa_single.tick_params(axis='y',labelleft=False)
    axa_single.set_xlim(.445,.565); axa_single.set_xticks([.45,.50,.55]); axa_single.tick_params(axis='x',labelsize=4.3,pad=1)
    axa_single.get_xticklabels()[0].set_ha('left')
    axa_single.set_ylim(-.55,len(single)-.45); axa_single.set_box_aspect(.47)
    axa_single.set_xlabel('Evidence-readiness, 5–95%',fontsize=5.1,labelpad=2); clean(axa_single,'x')
    axa_single.text(.99,.97,'Interval only; no Pareto claim',transform=axa_single.transAxes,ha='right',va='top',fontsize=4.05,color=MID_GREY)
    q['displayed_in_fig4a']=True
    q['fig4a_role']=np.where(q.scenario.isin(facet_services),'comparative_service_facet','singleton_scope_interval')
    q.to_csv(QA/'fig4a_within_service_geometry_audit.csv',index=False)

    # b — frontier membership forest plot with bootstrap interval.
    panel(axb,'b'); z=q[q.frontier_membership_frequency.ge(.01)].sort_values('frontier_membership_frequency').tail(14); y=np.arange(len(z))
    axb.hlines(y,z.frontier_frequency_bootstrap_p05,z.frontier_frequency_bootstrap_p95,color=MID_GREY,lw=.9)
    axb.scatter(z.frontier_membership_frequency,y,s=30,color=[SCOL[s] for s in z.scenario],edgecolor=np.where(z.threshold_50_member,INK,'white'),lw=.65,zorder=3)
    axb.set_yticks(y,[f'{SERVICE[s]} · {short_id(c)}' for s,c in zip(z.scenario,z.system_id)]); axb.tick_params(axis='y',labelsize=5.1); barh_headroom(axb,len(z),.6); axb.set_xlim(0,1.03); axb.set_xlabel('Pareto membership frequency, bootstrap 5–95%'); clean(axb,'x')

    # c — dominance mechanism bubble matrix, no redundant shortfall panel.
    panel(axc,'c'); classes=['reference frontier','performance-dominated','evidence-dominated','dual-dominated','draw-unstable frontier','not evaluable']; cm={'reference frontier':OLIVE,'performance-dominated':MUSTARD,'evidence-dominated':BLUE,'dual-dominated':BURGUNDY,'draw-unstable frontier':ROSE,'not evaluable':LIGHT_GREY}
    counts=dom.groupby(['scenario','dominance_class']).size().unstack(fill_value=0).reindex(SERVICE_ORDER).reindex(columns=classes,fill_value=0)
    for i,s in enumerate(counts.index):
        for j,c in enumerate(classes):
            v=counts.loc[s,c]
            if v>0:
                axc.scatter(j,i,s=26+38*v,color=cm[c],edgecolor='white',lw=.5)
                count_label=axc.text(j,i,str(int(v)),ha='center',va='center',fontsize=5.2,color='white' if cm[c] in [BURGUNDY,BLUE] else INK)
                fig4_direct_label_artists.append(('4c',f'{SERVICE[s]} · {c}',count_label))
    axc.set_yticks(range(len(counts)),[SERVICE[s] for s in counts.index]); axc.set_xticks(range(len(classes)),['Reference\nfront','Performance','Evidence','Dual','Draw-\nunstable','Not\nevaluable'],rotation=28,ha='right'); axc.set_xlim(-.5,len(classes)-.5); axc.set_ylim(-.6,len(counts)-.35); clean(axc,'both'); axc.set_xlabel('Representative-draw dominance mechanism')

    # d — full-width UpSet intersection. Precise operational terms replace the
    # overloaded "Robust Pareto" wording used in the former one-third-width panel.
    panel(axd,'d')
    opp=pa[pa.frontier_scope.eq('opportunity')][['scenario','system_id','threshold_50_member']].rename(columns={'threshold_50_member':'robust_pareto'})
    sm=scope.merge(opp,on=['scenario','system_id'],how='left'); sm['robust_pareto']=sm.robust_pareto.fillna(False); sm['strict_eligible']=sm.decision_scope_class.eq('decision_ready'); sm['selected']=sm.evidence_qualified_selection_frequency.ge(.01)
    inter=sm.groupby(['robust_pareto','strict_eligible','selected']).size().reset_index(name='count').sort_values('count',ascending=False); inter=inter[inter['count']>0].head(7).reset_index(drop=True)
    xx=np.arange(len(inter))
    def inter_color(r):
        if bool(r['selected']): return OLIVE
        if bool(r['robust_pareto']) and bool(r['strict_eligible']): return MUSTARD
        if bool(r['robust_pareto']): return BLUE
        if bool(r['strict_eligible']): return TERRACOTTA
        return ROSE
    inter_cols=[inter_color(r) for _,r in inter.iterrows()]
    axd.bar(xx,inter['count'],color=inter_cols,width=.62,edgecolor='white',linewidth=.45)
    matrix_y=[2.0,1.0,0.0]
    for i,r in inter.iterrows():
        for j,key in enumerate(['robust_pareto','strict_eligible','selected']):
            axdm.scatter(i,matrix_y[j],s=36,facecolor=OLIVE if r[key] else 'white',edgecolor=INK,lw=.6)
        on=[j for j,k in enumerate(['robust_pareto','strict_eligible','selected']) if r[k]]
        if len(on)>1: axdm.vlines(i,matrix_y[max(on)],matrix_y[min(on)],color=INK,lw=.75)
        count_badge=value_badge(axd,i,r['count'],str(int(r['count'])),dx=0,dy=4,ha='center',color=inter_cols[i],ec=inter_cols[i],clip_on=True)
        fig4_direct_label_artists.append(('4d',f'Intersection {i+1} count',count_badge))
    count_top=float(inter['count'].max())
    axd.set_xlim(-.55,len(inter)-.45); axd.set_ylim(0,count_top+7.0); axd.set_ylabel('Count'); axd.tick_params(axis='x',bottom=False,labelbottom=False); clean(axd,'y')
    axdm.set_xticks(xx,[f'Intersection {i+1}' for i in xx]); axdm.tick_params(axis='x',labelsize=4.8,pad=1.5)
    axdm.set_yticks(matrix_y,['Pareto membership ≥50%','Decision-ready evidence','Formal selection ≥1%']); axdm.tick_params(axis='y',labelsize=5.3,pad=3)
    axdm.set_ylim(-.45,2.45); clean(axdm,None)
    inter.to_csv(QA/'fig4d_intersection_audit.csv',index=False)

    # e — cross-service breadth lollipop.
    panel(axe,'e')
    breadth=opp.groupby('system_id').robust_pareto.sum().rename('pareto').reset_index(); sel=sm.groupby('system_id').selected.sum().rename('selected').reset_index(); breadth=breadth.merge(sel,on='system_id').sort_values(['pareto','selected']); y=np.arange(len(breadth))
    axe.hlines(y,breadth.selected,breadth.pareto,color=PALE_BLUE,lw=1.7); axe.scatter(breadth.pareto,y,s=28,color=MUSTARD,label='Pareto ≥50%'); axe.scatter(breadth.selected,y,s=24,color=OLIVE,label='Selected')
    for i,r in breadth.reset_index(drop=True).iterrows():
        breadth_badge=value_badge(axe,float(r.pareto),i,str(int(r.pareto)),color=MUSTARD,dx=4,fontsize=4.5)
        fig4_direct_label_artists.append(('4e',f'{short_id(r.system_id)} Pareto breadth',breadth_badge))
    axe.set_yticks(y,[short_id(x) for x in breadth.system_id]); axe.tick_params(axis='y',labelsize=4.9); barh_headroom(axe,len(breadth),.25); axe.set_xlim(-.2,max(3.8,breadth.pareto.max()+.9)); axe.set_xlabel('Number of services'); clean(axe,'x'); top_legend(axe,[Line2D([0],[0],marker='o',ls='',mfc=MUSTARD,mec='white',label='Pareto membership ≥50%',markersize=4),Line2D([0],[0],marker='o',ls='',mfc=OLIVE,mec='white',label='Formal selection',markersize=4)],ncol=2,anchor=(.5,1.11),fontsize=4.8)

    # f — small redirection inset, retained only as contextual link to the strict layer.
    panel(axf,'f')
    f=flow.groupby('transition_class').transition_draws.sum(); labs=['retained','redirected','no_selection']; vals=np.array([f.get(x,0) for x in labs],float); vals=vals/vals.sum(); cols=[OLIVE,MUSTARD,BURGUNDY]
    axf.barh(np.arange(3),vals,color=cols,height=.58); axf.set_yticks(np.arange(3),['Retained','Redirected','No selection']); axf.set_xlim(0,1); axf.set_xlabel('Strict-layer transition share'); clean(axf,'x')
    for i,v in enumerate(vals):
        transition_badge=value_badge(axf,v,i,f'{v:.0%}',dx=5,dy=0,color=cols[i],ec=cols[i])
        fig4_direct_label_artists.append(('4f',f'{labs[i]} transition share',transition_badge))

    # Freeze the global constrained layout, then impose one publication-wide
    # horizontal coordinate system.  The outer axes of 4a inherit the exact
    # 4b-left and 4c-right anchors; 4d and its matrix inherit the same anchors
    # and therefore also align with 4e-left and 4f-right.  A fixed 0.260 width
    # keeps each 4a facet materially narrower than 4b/4c while the remaining
    # span is split into two equal compact gutters.
    fig.canvas.draw()
    layout_axes=[('coal_top',axa_list[0]),('csp_top',axa_list[1]),('industrial_top',axa_list[2]),('sco2_bottom',axa_list[3]),('pcm500_bottom',axa_list[4]),('singleton_bottom',axa_single)]
    fig.set_layout_engine('none')
    canonical_left=max(axb.get_position().x0,axe.get_position().x0)
    canonical_right=min(axc.get_position().x1,axf.get_position().x1)
    fixed_width=.260
    fixed_gutter=(canonical_right-canonical_left-3*fixed_width)/2
    if fixed_gutter <= 0:
        raise RuntimeError('Fig. 4a canonical span cannot accommodate three fixed-width facets')
    fixed_x0=[canonical_left,canonical_left+fixed_width+fixed_gutter,canonical_right-fixed_width]
    for col,axes in enumerate([(axa_list[0],axa_list[3]),(axa_list[1],axa_list[4]),(axa_list[2],axa_single)]):
        for ax in axes:
            pos=ax.get_position(); ax.set_box_aspect(None)
            ax.set_position([fixed_x0[col],pos.y0,fixed_width,pos.height])
    for ax in [axd,axdm]:
        pos=ax.get_position()
        ax.set_position([canonical_left,pos.y0,canonical_right-canonical_left,pos.height])
    fig.canvas.draw()
    layout_rows=[]
    for name,ax in layout_axes:
        pos=ax.get_position()
        layout_rows.append({'panel':name,'x0':pos.x0,'y0':pos.y0,'x1':pos.x1,'y1':pos.y1,'width':pos.width,'height':pos.height})
    pd.DataFrame(layout_rows).to_csv(QA/'fig4a_layout_alignment_audit.csv',index=False)
    alignment_specs=[
        ('4a left axis = 4b left axis',axa_list[0].get_position().x0,axb.get_position().x0),
        ('4a right axis = 4c right axis',axa_list[2].get_position().x1,axc.get_position().x1),
        ('4d left axis = 4b left axis',axd.get_position().x0,axb.get_position().x0),
        ('4d right axis = 4c right axis',axd.get_position().x1,axc.get_position().x1),
        ('4d left axis = 4e left axis',axd.get_position().x0,axe.get_position().x0),
        ('4d right axis = 4f right axis',axd.get_position().x1,axf.get_position().x1),
        ('4d matrix left axis = 4d bar left axis',axdm.get_position().x0,axd.get_position().x0),
        ('4d matrix right axis = 4d bar right axis',axdm.get_position().x1,axd.get_position().x1),
    ]
    alignment_rows=[]
    for check,observed,target in alignment_specs:
        delta=abs(float(observed)-float(target))
        alignment_rows.append({'check':check,'observed':observed,'target':target,'absolute_difference':delta,'tolerance':2e-4,'passed':delta<=2e-4})
    alignment_rows.extend([
        {'check':'4a equal column gutters','observed':fixed_x0[1]-(fixed_x0[0]+fixed_width),'target':fixed_x0[2]-(fixed_x0[1]+fixed_width),'absolute_difference':abs((fixed_x0[1]-(fixed_x0[0]+fixed_width))-(fixed_x0[2]-(fixed_x0[1]+fixed_width))),'tolerance':2e-4,'passed':abs((fixed_x0[1]-(fixed_x0[0]+fixed_width))-(fixed_x0[2]-(fixed_x0[1]+fixed_width)))<=2e-4},
        {'check':'right-page safety margin','observed':1-canonical_right,'target':.008,'absolute_difference':max(0,.008-(1-canonical_right)),'tolerance':0,'passed':(1-canonical_right)>=.008},
    ])
    pd.DataFrame(alignment_rows).to_csv(QA/'fig4_panel_alignment_audit.csv',index=False)
    renderer=fig.canvas.get_renderer(); collision_rows=[]
    for i,(panel_i,label_i,artist_i) in enumerate(fig4a_label_artists):
        bbox_i=artist_i.get_window_extent(renderer=renderer)
        for panel_j,label_j,artist_j in fig4a_label_artists[i+1:]:
            if panel_i!=panel_j: continue
            bbox_j=artist_j.get_window_extent(renderer=renderer)
            overlap_w=max(0,min(bbox_i.x1,bbox_j.x1)-max(bbox_i.x0,bbox_j.x0))
            overlap_h=max(0,min(bbox_i.y1,bbox_j.y1)-max(bbox_i.y0,bbox_j.y0))
            collision_rows.append({'panel':panel_i,'label_a':label_i,'label_b':label_j,'overlap_area_px2':overlap_w*overlap_h,'collision':bool(overlap_w>0 and overlap_h>0)})
    pd.DataFrame(collision_rows).to_csv(QA/'fig4a_label_collision_audit.csv',index=False)

    # Direct-label QA is evaluated after the final geometry is fixed and covers
    # candidate labels, matrix counts and all value badges in 4d–4f.
    boundary_rows=[]; direct_collision_rows=[]
    fig_bbox=fig.bbox
    for panel_name,label_name,artist in fig4_direct_label_artists:
        bbox=artist.get_window_extent(renderer=renderer); axes_bbox=artist.axes.bbox
        boundary_rows.append({
            'panel':panel_name,'label':label_name,
            'inside_figure':bool(bbox.x0>=fig_bbox.x0-.75 and bbox.x1<=fig_bbox.x1+.75 and bbox.y0>=fig_bbox.y0-.75 and bbox.y1<=fig_bbox.y1+.75),
            'inside_parent_axes':bool(bbox.x0>=axes_bbox.x0-.75 and bbox.x1<=axes_bbox.x1+.75 and bbox.y0>=axes_bbox.y0-.75 and bbox.y1<=axes_bbox.y1+.75),
            'x0_px':bbox.x0,'x1_px':bbox.x1,'y0_px':bbox.y0,'y1_px':bbox.y1,
        })
    for i,(panel_i,label_i,artist_i) in enumerate(fig4_direct_label_artists):
        bbox_i=artist_i.get_window_extent(renderer=renderer)
        for panel_j,label_j,artist_j in fig4_direct_label_artists[i+1:]:
            if panel_i!=panel_j: continue
            bbox_j=artist_j.get_window_extent(renderer=renderer)
            overlap_w=max(0,min(bbox_i.x1,bbox_j.x1)-max(bbox_i.x0,bbox_j.x0))
            overlap_h=max(0,min(bbox_i.y1,bbox_j.y1)-max(bbox_i.y0,bbox_j.y0))
            direct_collision_rows.append({'panel':panel_i,'label_a':label_i,'label_b':label_j,'overlap_area_px2':overlap_w*overlap_h,'collision':bool(overlap_w>0 and overlap_h>0)})
    pd.DataFrame(boundary_rows).to_csv(QA/'fig4_direct_label_boundary_audit.csv',index=False)
    pd.DataFrame(direct_collision_rows).to_csv(QA/'fig4_direct_label_collision_audit.csv',index=False)

    save(fig,4,'Uncertainty-aware Pareto structure distinguishes robust non-dominance from formal selection',['pareto_joint_uncertainty_and_robustness','submission_pareto_dominance_mechanism_summary','decision_scope_matrix','figure_selection_alluvial_flows'])

# ------------------------------ FIGURE 5 ---------------------------------
def fig5():
    """Separate continuous variance, categorical information and structural closure-depth response."""
    st=read('structural_stochastic_uncertainty_classification',STAT)
    cont=read('continuous_decision_variance_attribution',STAT)
    cat=read('categorical_selection_information_attribution',STAT)
    prop=read('property_domain_contraction_summary',V)
    ev=read('atomic_evidence_unlock_summary',V)
    depth=read('gate_closure_depth_response')
    dep=read('performance_evidence_dependence_audit',STAT)

    fig=plt.figure(figsize=(MAIN_W,10.45),constrained_layout=True)
    fig.get_layout_engine().set(w_pad=.035,h_pad=.035,wspace=.025,hspace=.025)
    gs=fig.add_gridspec(5,2,height_ratios=[1.02,.68,.90,.58,.76],hspace=.065,wspace=.032)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0]); axc=fig.add_subplot(gs[1,1])
    axd=fig.add_subplot(gs[2,0]); axe=fig.add_subplot(gs[2,1]); axg=fig.add_subplot(gs[4,:])

    # a — service-to-uncertainty structure alluvial.
    panel(axa,'a'); af=st[['scenario','uncertainty_structure_class']].copy(); af['Service']=af.scenario.map(SERVICE); af['Regime']=af.uncertainty_structure_class.str.replace('-',' ',regex=False).str.title(); af['weight']=1
    rc={'Evidence Variable Single Candidate':BLUE,'Stochastic Multicandidate':OLIVE,'Service Incomplete':NEUTRAL,'Evidence Locked':BURGUNDY,'Preference Sensitive':MUSTARD,'Deterministic Single Candidate':PALE_BLUE}
    node={**{SERVICE[s]:SCOL[s] for s in SERVICE_ORDER},**{x:rc.get(x,MID_GREY) for x in af.Regime.unique()}}
    L.weighted_alluvial(axa,af,['Service','Regime'],'weight','Regime',{x:rc.get(x,MID_GREY) for x in af.Regime.unique()},node_color_map=node,stage_labels=['TES service','Decision-uncertainty structure'],outer_labels=True,label_min_fraction=.035,node_width=.065,gap=.012,node_top=.90,node_bottom=.015,stage_label_y=.985)

    blocks=['thermophysical','evidence','preference']; bcols=[NAVY,MUSTARD,OLIVE]; blab=['Thermophysical','Evidence','Preference']
    # b — continuous response only.
    panel(axb,'b',x=-.055); q=cont[cont.uncertainty_block.isin(blocks)&cont.normalized_shapley_variance_share.notna()].copy(); rows=[]
    for serv,g in q.groupby('scenario'): rows.append((SERVICE[serv],g.set_index('uncertainty_block').normalized_shapley_variance_share.reindex(blocks).fillna(0).to_numpy()))
    y=np.arange(len(rows)); left=np.zeros(len(rows))
    for j,(lab,col) in enumerate(zip(blab,bcols)):
        vals=np.array([r[1][j] for r in rows]); axb.barh(y,vals,left=left,height=.60,color=col,label=lab)
        for i,z in enumerate(vals):
            if z>=.07: axb.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.35,color='white' if col==NAVY else INK)
        left+=vals
    axb.set_yticks(y,[r[0] for r in rows]); axb.set_xlim(0,1); barh_headroom(axb,len(rows),.06); axb.set_xlabel('Shapley variance share · continuous margin'); clean(axb,'x')
    top_legend(axb,[Patch(facecolor=c,label=l) for c,l in zip(bcols,blab)],ncol=3,anchor=(.5,1.105),fontsize=5.0)

    # c — categorical information response; no ordinary ANOVA.
    panel(axc,'c',x=-.055); q=cat[cat.uncertainty_block.isin(blocks)&cat.normalized_shapley_information_share.notna()].copy(); rows=[]
    for serv,g in q.groupby('scenario'): rows.append((SERVICE[serv],g.set_index('uncertainty_block').normalized_shapley_information_share.reindex(blocks).fillna(0).to_numpy()))
    y=np.arange(len(rows)); left=np.zeros(len(rows))
    for j,(lab,col) in enumerate(zip(blab,bcols)):
        vals=np.array([r[1][j] for r in rows]); axc.barh(y,vals,left=left,height=.60,color=col,label=lab)
        for i,z in enumerate(vals):
            if z>=.07: axc.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',fontsize=5.35,color='white' if col==NAVY else INK)
        left+=vals
    axc.set_yticks(y,[r[0] for r in rows]); axc.set_xlim(0,1); barh_headroom(axc,len(rows),.06); axc.set_xlabel('Shapley information share · categorical state'); clean(axc,'x')
    top_legend(axc,[Patch(facecolor=c,label=l) for c,l in zip(bcols,blab)],ncol=3,anchor=(.5,1.105),fontsize=5.0)

    # d — property-domain contraction.
    panel(axd,'d',x=-.055); q=prop[prop.coverage_loss_due_to_registered_property_domains.gt(.01)].sort_values('coverage_loss_due_to_registered_property_domains').tail(12).reset_index(drop=True); y=np.arange(len(q))
    axd.hlines(y,0,q.coverage_loss_due_to_registered_property_domains,color=PALE_BLUE,lw=2.1); axd.scatter(q.coverage_loss_due_to_registered_property_domains,y,s=30,color=[SCOL[s] for s in q.scenario],edgecolor='white',lw=.55,zorder=3)
    xmax=max(.1,float(q.coverage_loss_due_to_registered_property_domains.max())); axd.set_xlim(0,min(1.14,xmax*1.23+.02))
    for i,r in q.iterrows(): value_badge(axd,r.coverage_loss_due_to_registered_property_domains,i,f'{r.coverage_loss_due_to_registered_property_domains:.2f}',dx=5,color=SCOL[r.scenario],ec=SCOL[r.scenario])
    axd.set_yticks(y,[f'{SERVICE[s]} · {short_id(c)}' for s,c in zip(q.scenario,q.system_id)]); axd.tick_params(axis='y',labelsize=4.65,pad=1.5); barh_headroom(axd,len(q),.18); axd.set_xlabel('Service coverage lost to registered property domains'); clean(axd,'x')

    # e: candidate-specific engineering-evidence unlock.
    panel(axe,'e',x=-.055); q=ev.groupby(['gate','gate_label'],as_index=False).agg(unlock=('shapley_unlock_contribution','sum'),services=('scenario','nunique')).sort_values('unlock').reset_index(drop=True); y=np.arange(len(q))
    gatecols={'corrosion':BURGUNDY,'cycling_phase':MUSTARD,'containment':OLIVE,'literature_validation':ROSE,'data_completeness':BLUE}
    axe.hlines(y,0,q.unlock,color=CREAM,lw=2.4); axe.scatter(q.unlock,y,s=34+12*q.services,color=[gatecols.get(g,MID_GREY) for g in q.gate],edgecolor='white',lw=.55,zorder=3)
    xmax=max(.01,float(q.unlock.max())); axe.set_xlim(0,xmax*1.24)
    for i,r in q.iterrows(): value_badge(axe,r.unlock,i,f'{r.unlock:.2f}',dx=5,color=gatecols.get(r.gate,MID_GREY),ec=gatecols.get(r.gate,MID_GREY))
    axe.set_yticks(y,[str(x).replace('Literature replication','Replication') for x in q.gate_label]); barh_headroom(axe,len(q),.14); axe.set_xlabel('Summed Shapley unlock contribution'); clean(axe,'x'); outside_note(axe,'Point area = contributing services',x=.99,y=1.045)

    # f — service-specific closure-depth response. The seven axes are deliberately
    # narrowed and centred so that the strip aligns with the outer edges of the
    # paired panels above instead of spanning the full alluvial-panel width.
    # Its shared legend is centred above the strip, outside every data axis.
    sub=gs[3,:].subgridspec(1,9,width_ratios=[.70,1,1,1,1,1,1,1,1.60],wspace=.075)
    closure_handles=[
        Patch(facecolor=MID_GREY,alpha=.20,label='Minimum–maximum'),
        Line2D([0],[0],color=MID_GREY,marker='o',lw=1,label='Median')
    ]
    for k,serv in enumerate(SERVICE_ORDER):
        ax=fig.add_subplot(sub[0,k+1])
        if k==0: panel(ax,'f',x=-.30,y=1.30)
        g=depth[depth.scenario.eq(serv)].sort_values('closed_gate_count')
        ax.fill_between(g.closed_gate_count,g.minimum_retained_frequency,g.maximum_retained_frequency,color=SCOL[serv],alpha=.20,lw=0)
        ax.plot(g.closed_gate_count,g.median_retained_frequency,color=SCOL[serv],lw=1.15,marker='o',ms=2.4)
        ax.set_title(SERVICE[serv],fontsize=5.25,pad=2,color=INK); ax.set_xlim(-.15,6.15); ax.set_ylim(-.04,1.04); ax.set_xticks([0,3,6]); ax.tick_params(labelsize=4.25,pad=.8)
        if k==0: ax.set_ylabel('Retained frequency',fontsize=5.1,labelpad=1.5); ax.set_yticks([0,.5,1])
        else: ax.set_yticks([])
        ax.set_xlabel('Closed gates',fontsize=4.65,labelpad=.7); clean(ax,None)
        if k==3:
            ax.legend(handles=closure_handles,loc='lower center',bbox_to_anchor=(.5,1.18),
                      frameon=False,ncol=2,fontsize=5.0,columnspacing=.65,
                      handlelength=.95,handletextpad=.30,borderaxespad=0)

    # g — P–C dependence, wide to avoid label collisions.
    panel(axg,'g',x=-.050,y=1.045); q=dep.dropna(subset=['pearson_performance_credibility','spearman_performance_credibility']).copy()
    axg.axhline(0,color=LIGHT_GREY,lw=.65); axg.axvline(0,color=LIGHT_GREY,lw=.65); axg.plot([-.05,1.02],[-.05,1.02],color=MID_GREY,lw=1.05,ls='--')
    offsets={('pcm_target_500C','nkca'):(-9,-15),('pcm_target_500C','pcm_binary_carbonate'):(7,7)}
    for r in q.itertuples(index=False):
        axg.scatter(r.pearson_performance_credibility,r.spearman_performance_credibility,s=26+18*r.joint_valid_draws/20000,color=SCOL[r.scenario],edgecolor='white',lw=.5)
        if abs(r.pearson_performance_credibility)>.2 or (r.scenario,r.system_id)==('pcm_target_500C','nkca'):
            off=offsets.get((r.scenario,r.system_id),(-5,7)); ha='left' if off[0]>0 else 'right'; va='top' if off[1]<0 else 'bottom'
            axg.annotate(f'{SERVICE[r.scenario]} · {short_id(r.system_id)}',(r.pearson_performance_credibility,r.spearman_performance_credibility),xytext=off,textcoords='offset points',ha=ha,va=va,fontsize=5.0,clip_on=True)
    axg.set_xlim(-.04,1.04); axg.set_ylim(-.04,.82); axg.set_xlabel('Pearson performance–evidence dependence'); axg.set_ylabel('Spearman dependence'); clean(axg,'both')
    ins=axg.inset_axes([.68,.10,.26,.35]); near=q[q.pearson_performance_credibility.abs().lt(.05)&q.spearman_performance_credibility.abs().lt(.05)]
    for r in near.itertuples(index=False): ins.scatter(r.pearson_performance_credibility,r.spearman_performance_credibility,s=12,color=SCOL[r.scenario],edgecolor='white',lw=.3)
    ins.axhline(0,color=LIGHT_GREY,lw=.4); ins.axvline(0,color=LIGHT_GREY,lw=.4); ins.set_xlim(-.02,.01); ins.set_ylim(-.022,.012); ins.tick_params(labelsize=3.9,length=1); ins.set_title('Near-zero cluster',fontsize=4.6,pad=1); clean(ins,None)

    save(fig,5,'Continuous variance, categorical information and service-specific closure depth are separated from structural bottlenecks',['structural_stochastic_uncertainty_classification','continuous_decision_variance_attribution','categorical_selection_information_attribution','submission_property_domain_contraction_summary','submission_atomic_evidence_unlock_summary','gate_closure_depth_response','performance_evidence_dependence_audit'])

# ------------------------------ FIGURE 6 ---------------------------------
def fig6():
    """DAG-constrained back-tracing with complete action-set and candidate redistribution diagnostics."""
    scope=read('decision_scope_matrix',STAT); mins=read('dag_constrained_minimal_action_sets',STAT)
    act=read('research_action_frontier_summary',V); signed=read('counterfactual_candidate_signed_changes'); priority=read('candidate_research_priority_summary',V)
    fig=plt.figure(figsize=(MAIN_W,9.35),constrained_layout=True)
    fig.get_layout_engine().set(w_pad=.035,h_pad=.035,wspace=.03,hspace=.03)
    gs=fig.add_gridspec(4,2,height_ratios=[1.03,1.42,.98,.88],hspace=.070,wspace=.035)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0]); axc=fig.add_subplot(gs[1,1]); axd=fig.add_subplot(gs[2,0]); axe=fig.add_subplot(gs[2,1]); axf=fig.add_subplot(gs[3,:])

    # a — precedence-valid current state → action → endpoint.
    panel(axa,'a'); rows=[]
    for r in priority.itertuples(index=False):
        cls=r.research_priority_class
        if cls=='current formal selection': action='No new evidence'; end='Formal benchmark'
        elif cls=='one-step evidence opportunity': action='Targeted registered programme'; end='Potential ≥1% selection'
        elif cls=='multi-step evidence programme': action='Integrated evidence programme'; end='Potential ≥1% selection'
        elif cls=='stop: service/property limited': action='Measure / redesign'; end='Reassess service fit'
        else: action='Stop / reframe'; end='No evidence-only route'
        rows.append({'Current':cls,'Action':action,'Endpoint':end,'weight':1})
    af=pd.DataFrame(rows); cc={'current formal selection':OLIVE,'one-step evidence opportunity':MUSTARD,'multi-step evidence programme':ROSE,'stop: service/property limited':TERRACOTTA,'stop: no registered evidence lever':NEUTRAL,'not reachable under registered actions':PALE_BLUE}
    ac={'No new evidence':OLIVE,'Targeted registered programme':MUSTARD,'Integrated evidence programme':ROSE,'Measure / redesign':TERRACOTTA,'Stop / reframe':NEUTRAL}; ec={'Formal benchmark':OLIVE,'Potential ≥1% selection':ROSE,'Reassess service fit':TERRACOTTA,'No evidence-only route':NEUTRAL}
    L.weighted_alluvial(axa,af,['Current','Action','Endpoint'],'weight','Current',cc,node_color_map={**cc,**ac,**ec},stage_labels=['Current decision state','Precedence-valid action','Decision endpoint'],outer_labels=True,label_min_fraction=.035,node_width=.06,gap=.009,node_top=.90,node_bottom=.015,stage_label_y=.985)

    # b — submission complete minimum admissible action-set matrix for scientifically evaluable pairs.
    panel(axb,'b'); targets=['become_bounded','reach_1pct_selection','alter_top_choice']; target_lab=['Become bounded','Reach ≥1%','Alter leader']
    pairs=mins[['scenario','system_id']].drop_duplicates().merge(scope[['scenario','system_id','decision_scope_class']],on=['scenario','system_id'],how='left')
    pairs=pairs[~pairs.decision_scope_class.isin(['outside_standardized_service','physical_service_window_limited'])].copy(); pairs['label']=[f'{SERVICE[s]} · {short_id(c)}' for s,c in zip(pairs.scenario,pairs.system_id)]; pairs=pairs.sort_values(['scenario','label']).reset_index(drop=True)
    classes=['property-domain first','direct-risk stop','not reachable','reachable, no action','reachable, programme']; cols=[MUSTARD,BURGUNDY,PALE_BLUE,OLIVE,ROSE]
    def cls(row):
        if row is None: return 'not reachable'
        rc0=str(row.reachability_class)
        if 'thermophysical_domain' in rc0: return 'property-domain first'
        if 'direct-risk' in rc0: return 'direct-risk stop'
        if rc0.startswith('reachable'): return 'reachable, no action' if str(row.admissible_minimal_action_set)=='none' else 'reachable, programme'
        return 'not reachable'
    arr=[]
    for pr in pairs.itertuples(index=False):
        row=[]
        for t in targets:
            z=mins[(mins.scenario==pr.scenario)&(mins.system_id==pr.system_id)&(mins.target==t)]; row.append(cls(z.iloc[0] if len(z) else None))
        arr.append(row)
    code={c:i for i,c in enumerate(classes)}; mat=np.array([[code[x] for x in r] for r in arr])
    axb.imshow(mat,aspect='auto',cmap=ListedColormap(cols),norm=BoundaryNorm(np.arange(-.5,len(cols)+.5),len(cols)),interpolation='nearest')
    axb.set_xticks(range(3),target_lab,rotation=20,ha='right'); axb.set_yticks(range(len(pairs)),pairs.label); axb.tick_params(axis='y',labelsize=4.35,pad=1)
    for x in np.arange(4)-.5: axb.axvline(x,color='white',lw=.5)
    for yy in np.arange(len(pairs)+1)-.5: axb.axhline(yy,color='white',lw=.42)
    clean(axb,None); top_legend(axb,[Patch(facecolor=c,label=l) for l,c in zip(classes,cols)],ncol=2,anchor=(.5,1.12),fontsize=4.55)

    # c — registered action benefit.
    panel(axc,'c',x=-.055); q=act[(act.decision_benefit.gt(0))|(act.total_newly_eligible_candidates.gt(0))].copy().sort_values('decision_benefit').reset_index(drop=True)
    action_map={'literature_replication_closure':'Replication','exact_composition_corrosion_closure':'Exact corrosion','combined_atomic_evidence_closure':'Evidence programme','service_redesign_95pct':'Service redesign','property_measurement_precision_50pct':'Property precision','comprehensive_upper_bound':'Diagnostic upper bound'}
    y=np.arange(len(q))*.78
    axc.hlines(y,0,q.decision_benefit,color=np.where(q.release_scope.str.startswith('registered evidence'),PALE_BLUE,CREAM),lw=2.3)
    axc.scatter(q.decision_benefit,y,s=34+8*q.total_newly_eligible_candidates,color=np.where(q.non_dominated_under_registered_ordering,OLIVE,ROSE),edgecolor=np.where(q.adverse_application_fraction>0,BURGUNDY,'white'),lw=.7,zorder=3)
    xmax=max(.01,float(q.decision_benefit.max())); axc.set_xlim(0,xmax*1.28)
    for i,r in q.iterrows():
        col=OLIVE if r.non_dominated_under_registered_ordering else ROSE; value_badge(axc,r.decision_benefit,y[i],f'{r.decision_benefit:.2f}',dx=5,color=col,ec=col)
    axc.set_yticks(y,[action_map.get(str(x),str(x).replace('_',' ')) for x in q.closure_action]); axc.tick_params(axis='y',labelsize=4.9,pad=1.5); axc.set_ylim(-.42,y[-1]+.45 if len(y) else .5)
    axc.set_ylabel('Action',labelpad=2); axc.set_xlabel('Largest registered benefit (diagnostic)'); clean(axc,'x')
    top_legend(axc,[Line2D([0],[0],marker='o',ls='',mfc=OLIVE,mec='white',label='Non-dominated action',markersize=4),Line2D([0],[0],marker='o',ls='',mfc=ROSE,mec=BURGUNDY,label='Diagnostic / adverse',markersize=4),Line2D([0],[0],color=CREAM,lw=2,label='Diagnostic boundary')],ncol=3,anchor=(.5,1.12),fontsize=4.65)
    axc.text(.01,.99,'Eligibility may increase even when registered benefit = 0',transform=axc.transAxes,ha='left',va='top',fontsize=4.55,color=MID_GREY)

    # d — ordinal burden–benefit map.
    panel(axd,'d'); q=act.copy()
    for r in q.itertuples(index=False):
        fill=OLIVE if r.non_dominated_under_registered_ordering else (MUSTARD if str(r.release_scope).startswith('registered evidence') else ROSE); edge=BURGUNDY if r.adverse_application_fraction>0 else 'white'
        axd.scatter(r.burden_ordinal_index,r.decision_benefit,s=34+7*r.total_newly_eligible_candidates,color=fill,edgecolor=edge,lw=.7)
        if r.decision_benefit>0 or str(r.release_scope).startswith('registered evidence'):
            short=action_map.get(r.closure_action,str(r.closure_action).replace('_closure','').replace('_',' ')); 
            if short=='Diagnostic upper bound':
                short='Upper bound'; off=(-10,-17); ha='right'; va='top'
            elif short=='Evidence programme':
                off=(-10,16); ha='right'; va='bottom'
            elif short=='Replication':
                off=(4,-9); ha='left'; va='top'
            elif r.burden_ordinal_index>=4.5:
                off=(-4,5); ha='right'; va='bottom'
            else:
                off=(3,4); ha='left'; va='bottom'
            axd.annotate(short,(r.burden_ordinal_index,r.decision_benefit),xytext=off,textcoords='offset points',fontsize=4.5,clip_on=True,ha=ha,va=va)
    axd.set_xlim(.7,5.25); axd.set_ylim(-.015,max(.50,q.decision_benefit.max()+.05)); axd.set_xlabel('Ordinal evidence burden'); axd.set_ylabel('Largest registered benefit'); clean(axd,'both'); axd.text(.02,.98,'Order only; not cost, duration or success probability',transform=axd.transAxes,va='top',fontsize=4.8,color=MID_GREY)

    # e — submission candidate-selection redistribution, limited to preregistered |Δ| ≥1% effects.
    panel(axe,'e'); z=signed[signed.delta_selection_frequency.abs().ge(.01)].copy(); amap={'comprehensive_upper_bound':'Upper bound','combined_atomic_evidence_closure':'Combined','service_redesign_95pct':'95% redesign','property_measurement_precision_50pct':'Property precision','exact_composition_corrosion_closure':'Exact corrosion','literature_replication_closure':'Replication'}
    z['label']=[f"{amap.get(str(a),str(a).replace('_closure','').replace('_',' '))} · {SERVICE[s]} · {short_id(c)}" for a,s,c in zip(z.closure_action,z.scenario,z.system_id)]
    z=z.reindex(z.delta_selection_frequency.abs().sort_values(ascending=False).index).head(8).sort_values('delta_selection_frequency').reset_index(drop=True); y=np.arange(len(z))
    axe.hlines(y,0,z.delta_selection_frequency,color=PALE_BLUE,lw=1.8); axe.scatter(z.delta_selection_frequency,y,c=np.where(z.delta_selection_frequency>=0,OLIVE,BURGUNDY),s=40,edgecolor='white',lw=.5); axe.axvline(0,color=INK,lw=.7)
    span=max(.05,float(z.delta_selection_frequency.abs().max())); axe.set_xlim(min(-.05,float(z.delta_selection_frequency.min())-.13*span),max(.05,float(z.delta_selection_frequency.max())+.25*span))
    for i,r in z.iterrows(): value_badge(axe,r.delta_selection_frequency,i,f'{r.delta_selection_frequency:+.0%}',dx=5 if r.delta_selection_frequency>=0 else -5,ha='left' if r.delta_selection_frequency>=0 else 'right',color=OLIVE if r.delta_selection_frequency>=0 else BURGUNDY,ec=OLIVE if r.delta_selection_frequency>=0 else BURGUNDY)
    axe.set_yticks(y,L.label_wrap(z.label,24)); axe.tick_params(axis='y',labelsize=4.45,pad=1); barh_headroom(axe,len(z),.25); axe.set_xlabel('Selection-frequency change (|Δ| ≥ 1%)'); clean(axe,'x')

    # f — second-stage composite coupling: evidence contraction and dynamic response remain explicit.
    panel(axf,'f'); axf.axis('off')
    summary=read('composite_system_summary',BASE).set_index('metric')['value'].astype(float)
    dynamic=read('composite_dynamic_summary',BASE)
    prop=read('composite_property_response',BASE)
    # Reserve a wide central label gutter: the right-hand y labels must remain
    # visually independent from the left evidence ladder at manuscript scale.
    left_ax=axf.inset_axes([.02,.08,.27,.80]); right_ax=axf.inset_axes([.655,.08,.325,.80])
    ladder=[('Conditions',summary['experimental_condition_records']),('Capacity quantified',summary['quantified_capacity_records']),('Capacity + viscosity',summary['coupled_capacity_viscosity_records']),('Full-duty qualifiers',summary['formal_composite_eligible_links'])]
    ly=np.arange(len(ladder))[::-1]; lv=np.array([v for _,v in ladder])
    left_ax.hlines(ly,0,lv,color=PALE_BLUE,lw=2.6); left_ax.scatter(lv,ly,s=43,color=[NAVY,BLUE,MUSTARD,BURGUNDY],edgecolor='white',lw=.6,zorder=3)
    for yy,v in zip(ly,lv): value_badge(left_ax,v,yy,str(int(v)),dx=5,color=INK,ec=LIGHT_GREY,fontsize=4.8)
    left_ax.set_yticks(ly,[x[0] for x in ladder]); left_ax.set_xlim(0,25.5); left_ax.set_xlabel('Composite evidence records'); clean(left_ax,'x')

    diagnostic=[]
    for rid,label,metric in [
        ('ELFAR_SIO2_LOW_SHEAR',r'SiO$_2$ · 10 s$^{-1}$','capacity'),
        ('ELFAR_SIO2_HIGH_SHEAR',r'SiO$_2$ · 240 s$^{-1}$','capacity'),
        ('GROSU_AL2O3',r'Al$_2$O$_3$ · capacity/pump','capacity'),
        ('GROSU_AL2O3',r'Al$_2$O$_3$ · + transport','transport')]:
        r=dynamic[dynamic.record_id.eq(rid)].iloc[0]
        prefix='transport_adjusted_index' if metric=='transport' else 'capacity_pumping_index'
        diagnostic.append((label,float(r[f'{prefix}_p05']),float(r[f'{prefix}_p50']),float(r[f'{prefix}_p95']),OLIVE if metric=='transport' else NAVY))
    foam=prop[prop.record_id.eq('XIAO_FOAM_AL2O3')].iloc[0]
    diagnostic.extend([('Foam · charging',float(foam.charge_power_ratio),float(foam.charge_power_ratio),float(foam.charge_power_ratio),TERRACOTTA),('Foam · bidirectional',float(foam.bidirectional_power_ratio),float(foam.bidirectional_power_ratio),float(foam.bidirectional_power_ratio),BURGUNDY)])
    ry=np.arange(len(diagnostic))[::-1]
    right_ax.axvline(1,color=INK,lw=.75,ls='--')
    for yy,(label,lo,mid,hi,col) in zip(ry,diagnostic):
        right_ax.hlines(yy,lo,hi,color=col,lw=1.6); right_ax.scatter(mid,yy,s=31,color=col,edgecolor='white',lw=.5,zorder=3)
        value_badge(right_ax,mid,yy,f'{mid:.2f}',dx=4,color=col,ec=col,fontsize=4.4)
    right_ax.set_yticks(ry,[x[0] for x in diagnostic]); right_ax.set_xlim(.15,3.85); right_ax.set_ylim(-.65,5.35); right_ax.set_xlabel('Response ratio to exact base system'); clean(right_ax,'x')
    right_ax.text(.99,.03,'5–95% hydraulic envelope; foam values are reported point ratios',transform=right_ax.transAxes,ha='right',va='bottom',fontsize=4.25,color=MID_GREY)

    save(fig,6,'Precedence-constrained decisions extend to a separate composite-system layer in which property gains face hydraulic and bidirectional constraints',['submission_candidate_research_priority_summary','dag_constrained_minimal_action_sets','submission_research_action_frontier_summary','counterfactual_candidate_signed_changes','core_composite_system_summary','core_composite_dynamic_summary','core_composite_property_response'])

# -------------------------- SUPPLEMENTARY LAYER --------------------------
def supp_base(n:int):
    # The certified supplementary grammar provides complete-detail views and is rebound to submission output paths.
    getattr(L,f'make_ed{n}')()
    source_map={
        1:['exact_formula_candidate_evidence_audit','literature_source_registry'],
        2:['candidate_readiness_profile','candidate_scope_and_inclusion_audit'],
        3:['candidate_service_coverage_map','property_domain_coverage_audit'],
        4:['pairwise_superiority_matrix','system_value_monte_carlo_summary'],
        5:['layered_selection_frequencies','no_selection_frequencies','candidate_readiness_profile'],
        6:['joint_threshold_regime_map','service_coverage_threshold_sensitivity','threshold_retention_sweep'],
        7:['atomic_interval_profiles_by_dimension'],
        8:['pareto_joint_uncertainty_and_robustness','pareto_dominance_mechanism_summary'],
        9:['continuous_decision_variance_attribution','categorical_selection_information_attribution'],
        10:['performance_evidence_dependence_audit','gate_pair_synergy_summary'],
    }
    supplementary_titles={
        1:'Database curation and chemistry-family structure',
        2:'Provenance linkage and atomic credibility',
        3:'Unique thermophysical profiles',
        4:'Pairwise performance and material-cost boundary',
        5:'Complete-service overclaim penalty',
        6:'Threshold sensitivity and convergence',
        7:'Condition-specific engineering-evidence intervals',
        8:'Full Pareto membership and dominance diagnostics',
        9:'Uncertainty-source attribution with bootstrap validation',
        10:'Performance–evidence dependence and covariance structure',
    }
    png=SUPP/f'{V}_Supp_Fig{n}.png'
    with Image.open(png) as im:
        width,height=im.size
    FIGURE_RECORDS.append({'figure':f'Supp_Fig{n}','title':supplementary_titles[n],'width_px':width,'height_px':height,'aspect_ratio':width/height,'source_tables':';'.join(source_map[n])})



def supp1():
    """Complete full-library evidence audit; expands Fig. 1 without redrawing it."""
    fam=read('family_evidence_coverage','expanded_v3')
    cand=read('exact_composition_candidate_summary','expanded_v3')
    records=read('unified_property_record_audit','expanded_v3')
    fig=plt.figure(figsize=(MAIN_W,7.05),constrained_layout=True)
    gs=fig.add_gridspec(2,2,height_ratios=[1.02,.98],hspace=.10,wspace=.085)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1])

    panel(axa,'a'); q=fam.sort_values('exact_candidates').reset_index(drop=True); y=np.arange(len(q))
    axa.hlines(y,0,q.exact_candidates,color=PALE_BLUE,lw=2.0); axa.scatter(q.exact_candidates,y,s=32,color=NAVY,edgecolor='white',lw=.5)
    axa.set_yticks(y,q.family); axa.tick_params(axis='y',labelsize=4.7); axa.set_xlabel('Exact-composition candidates'); clean(axa,'x')
    for i,v in enumerate(q.exact_candidates): value_badge(axa,v,i,str(int(v)),dx=4,color=NAVY,ec=NAVY,fontsize=4.4)
    axa.set_xlim(-1,max(10,float(q.exact_candidates.max())*1.18))

    panel(axb,'b'); cols=['candidates_with_melting','candidates_with_upper_boundary','candidates_with_cp','candidates_with_density','candidates_with_latent','candidates_with_cycles']; labs=['$T_m$','Upper','Cp','Density','Latent','Cycles']
    m=fam.sort_values('exact_candidates',ascending=False).reset_index(drop=True); share=m[cols].div(m.exact_candidates,axis=0)
    im=axb.imshow(share,aspect='auto',cmap=LinearSegmentedColormap.from_list('suppcov',[VERY_LIGHT,CREAM,OLIVE]),vmin=0,vmax=1)
    axb.set_xticks(range(len(cols)),labs,rotation=26,ha='right'); axb.set_yticks(range(len(m)),m.family); axb.tick_params(axis='y',labelsize=4.25)
    for i in range(len(m)):
        for j,c in enumerate(cols): axb.text(j,i,str(int(m.loc[i,c])),ha='center',va='center',fontsize=4.0,color='white' if share.iloc[i,j]>.64 else INK)
    cax=axb.inset_axes([.40,1.07,.55,.025]); cb=fig.colorbar(im,cax=cax,orientation='horizontal'); cb.ax.xaxis.set_ticks_position('top'); cb.ax.tick_params(labelsize=4.7,length=1,pad=.1); cb.outline.set_linewidth(.4); clean(axb,None)

    panel(axc,'c'); families=cand.family.value_counts().head(6).index.tolist(); fcols={f:c for f,c in zip(families,[NAVY,BLUE,MUSTARD,TERRACOTTA,OLIVE,ROSE])}
    for r in cand.itertuples(index=False):
        axc.scatter(r.source_count,r.property_record_count,s=17+8*min(float(r.quality_weight_median),1),color=fcols.get(r.family,LIGHT_GREY),edgecolor='white',lw=.35,alpha=.85)
    axc.set_xlim(.7,max(5.4,cand.source_count.max()+.4)); axc.set_yscale('log'); axc.set_ylim(.8,max(120,cand.property_record_count.max()*1.35)); axc.set_xlabel('Independent sources per exact candidate'); axc.set_ylabel('Property records per exact candidate (log)'); clean(axc,'both')
    top_legend(axc,[Line2D([0],[0],marker='o',ls='',mfc=fcols[f],mec='white',label=f,markersize=3.8) for f in families],ncol=3,anchor=(.5,1.13),fontsize=4.35)

    panel(axd,'d'); b=cand.material_boundary.fillna('unclassified').value_counts().sort_values().reset_index(); b.columns=['boundary','count']; y=np.arange(len(b))
    cols2=[BURGUNDY if 'outside' in str(x) else (OLIVE if 'inside' in str(x) else MID_GREY) for x in b.boundary]
    axd.barh(y,b['count'],color=cols2,height=.60); axd.set_yticks(y,[str(x).replace('_',' ') for x in b.boundary]); axd.tick_params(axis='y',labelsize=4.5); axd.set_xlim(0,max(10,float(b['count'].max())*1.12)); axd.set_xlabel('Exact candidates'); clean(axd,'x')
    for i,v in enumerate(b['count']): value_badge(axd,v,i,str(int(v)),dx=5,color=cols2[i],ec=cols2[i],fontsize=4.5)
    axd.text(.98,.04,f'{len(records):,} property records in the evidence library',transform=axd.transAxes,ha='right',fontsize=5.0,color=MID_GREY)

    save(fig,1,'Complete full-library chemistry, property coverage, source density and material-boundary audit',['expanded_v3_family_evidence_coverage','expanded_v3_exact_composition_candidate_summary','expanded_v3_unified_property_record_audit'],supp=True)


def supp6():
    # Non-duplicative full threshold audit: main Fig. 3b already shows coverage-response curves.
    joint=read('joint_threshold_regime_map'); sweep=read('threshold_retention_sweep'); conv=read('independent_convergence_summary')
    fig=plt.figure(figsize=(MAIN_W,5.75),constrained_layout=True)
    gs=fig.add_gridspec(2,2,height_ratios=[1.12,.88],hspace=.085,wspace=.055)
    axa=fig.add_subplot(gs[0,:]); axb=fig.add_subplot(gs[1,0]); axc=fig.add_subplot(gs[1,1])
    panel(axa,'a')
    # Full 630-state categorical registry as seven compact 6x15 strips, not a repeated coverage curve.
    regimes=['robust access','conditional access','no bounded access']; cmap=ListedColormap([OLIVE,MUSTARD,BURGUNDY]); code={r:i for i,r in enumerate(regimes)}
    mats=[]; labels=[]
    covs=sorted(joint.coverage_threshold.unique()); evs=sorted(joint.evidence_threshold.unique())
    for ss in SERVICE_ORDER:
        g=joint[joint.scenario.eq(ss)].pivot(index='coverage_threshold',columns='evidence_threshold',values='decision_regime').reindex(index=covs,columns=evs)
        mats.append(g.apply(lambda col: col.map(code)).astype(float).to_numpy()); labels.append(SERVICE[ss])
    full=np.vstack([np.vstack([m, np.full((1,len(evs)),np.nan)]) for m in mats])[:-1]
    axa.imshow(full,aspect='auto',interpolation='nearest',cmap=cmap,vmin=0,vmax=2)
    centers=[]; start=0
    for lab,m in zip(labels,mats):
        centers.append(start+(m.shape[0]-1)/2); start+=m.shape[0]+1
    axa.set_yticks(centers,labels); axa.set_xticks(range(0,len(evs),2),[f'{evs[i]:.2f}' for i in range(0,len(evs),2)],rotation=0)
    axa.set_xlabel('Evidence threshold'); axa.set_ylabel('Coverage-threshold rows (95–100%)'); clean(axa,None)
    top_legend(axa,[Patch(facecolor=cmap(i),label=r.title()) for i,r in enumerate(regimes)],ncol=3,anchor=(.5,1.09),fontsize=5.2)
    panel(axb,'b')
    # Full evidence-threshold response uses expected strict-complete candidate count, distinct from main Fig. 3b.
    plotted=[]
    for ss in SERVICE_ORDER:
        g=sweep[sweep.scenario.eq(ss)].sort_values('evidence_threshold')
        if g.expected_strict_complete_candidate_count.nunique()>1:
            axb.step(g.evidence_threshold,g.expected_strict_complete_candidate_count,where='post',lw=1.2,color=SCOL[ss],label=SERVICE[ss]); plotted.append(ss)
    axb.set_xlabel('Evidence threshold'); axb.set_ylabel('Expected strict-complete candidates'); clean(axb,'both')
    if plotted: top_legend(axb,[Line2D([0],[0],color=SCOL[x],lw=1.2,label=SERVICE[x]) for x in plotted],ncol=min(3,len(plotted)),anchor=(.5,1.12),fontsize=5.0)
    panel(axc,'c',x=-.14,y=1.10)
    axc.plot(conv.n_draws,conv.median_absolute_error,marker='o',ms=3,color=NAVY,label='Median')
    axc.plot(conv.n_draws,conv.p95_absolute_error,marker='s',ms=3,color=BURGUNDY,label='95th percentile')
    axc.set_xscale('log'); axc.xaxis.set_major_formatter(mpl.ticker.FuncFormatter(lambda value,pos:f'{value:g}')); axc.xaxis.set_minor_formatter(mpl.ticker.NullFormatter())
    axc.set_xlabel('Independent draws'); axc.set_ylabel('Modal-frequency error'); clean(axc,'both'); top_legend(axc,[Line2D([0],[0],color=NAVY,marker='o',label='Median'),Line2D([0],[0],color=BURGUNDY,marker='s',label='95th percentile')],ncol=2,anchor=(.5,1.12),fontsize=5.0)
    save(fig,6,'Full joint-state registry, evidence-threshold candidate response and independent convergence',['joint_threshold_regime_map','threshold_retention_sweep','independent_convergence_summary'],supp=True)

def supp11():
    """Complementary action diagnostics only; no redraw of main Fig. 5f, Fig. 6b or Fig. 6e."""
    dag=read('evidence_action_dag_registry',STAT)
    inter=read('nonzero_gate_interaction_summary',V)
    nonadd=read('evidence_programme_nonadditivity')
    fig=plt.figure(figsize=(MAIN_W,6.15),constrained_layout=True)
    fig.get_layout_engine().set(w_pad=.035,h_pad=.035,wspace=.035,hspace=.055)
    outer=fig.add_gridspec(2,1,height_ratios=[1.0,.90],hspace=.10)
    top=outer[0].subgridspec(1,3,wspace=.055)
    axa=fig.add_subplot(top[0,0]); axb=fig.add_subplot(top[0,1]); axc=fig.add_subplot(top[0,2])
    axd=fig.add_subplot(outer[1])

    panel(axa,'a'); q=dag.sort_values('burden_ordinal'); y=np.arange(len(q)); axa.barh(y,q.burden_ordinal,color=CREAM); axa.set_yticks(y,[x.replace('_',' ') for x in q.action_id]); axa.tick_params(axis='y',labelsize=4.8); axa.set_xlabel('Ordinal burden (not cost)'); clean(axa,'x')

    panel(axb,'b'); atomic=['corrosion_compatibility','cycling_phase_stability','containment_validation','literature_replication','data_completeness']; arr=[]
    for r in dag.itertuples(index=False): closed=set(str(r.closes_dimensions).split(';')); arr.append([1 if d in closed else 0 for d in atomic])
    axb.imshow(arr,aspect='auto',cmap=ListedColormap([VERY_LIGHT,BURGUNDY]),vmin=0,vmax=1); axb.set_xticks(range(5),['Corr.','Cycl.','Cont.','Repl.','Data'],rotation=35,ha='right'); axb.set_yticks(range(len(dag)),[x.replace('_',' ') for x in dag.action_id]); axb.tick_params(axis='y',labelsize=4.3); clean(axb,None)

    panel(axc,'c'); q=inter.sort_values('mean_synergy').reset_index(drop=True); y=np.arange(len(q)); supp11c_value_artists=[]
    if len(q):
        point_sizes=32+12*q.nonzero_service_count
        cols=np.where(q.mean_synergy>=0,MUSTARD,BLUE); axc.hlines(y,0,q.mean_synergy,color=PALE_BLUE,lw=2); axc.scatter(q.mean_synergy,y,s=point_sizes,color=cols,edgecolor='white',lw=.5); axc.axvline(0,color=INK,lw=.6)
        labs=[str(x).replace('Incomplete Service','Service').replace('Literature Validation','Replication').replace('Data Completeness','Data') for x in q.pair_label]; axc.set_yticks(y,L.label_wrap(labs,18)); axc.tick_params(axis='y',labelsize=4.4)
        # Put every exact value below its sphere.  This uniform placement keeps
        # the largest value visible without using out-of-axis annotation space.
        for i,r in q.iterrows():
            artist=value_badge(axc,r.mean_synergy,i,f'{r.mean_synergy:.2f}',dx=0,dy=-8,ha='center',va='top',color=MUSTARD if r.mean_synergy>=0 else BLUE,ec=MUSTARD if r.mean_synergy>=0 else BLUE,fontsize=4.5)
            supp11c_value_artists.append((i,str(r.pair_label),float(r.mean_synergy),float(point_sizes.iloc[i]),artist))
        vmax=float(q.mean_synergy.max()); vmin=float(q.mean_synergy.min()); xspan=max(vmax-vmin,.05)
        axc.set_xlim(min(-.004,vmin-.05*xspan),vmax+.13*xspan)
        axc.set_ylim(-.42,len(q)-.5+.34)
    axc.set_xlabel('Gate-pair synergy'); clean(axc,'x')

    panel(axd,'d'); qd=nonadd[nonadd.nonadditivity_delta_selection_probability.abs().gt(1e-9)].sort_values('nonadditivity_delta_selection_probability').reset_index(drop=True); y=np.arange(len(qd)); supp11d_value_artists=[]
    if len(qd):
        axd.hlines(y,0,qd.nonadditivity_delta_selection_probability,color=CREAM,lw=2.4); axd.scatter(qd.nonadditivity_delta_selection_probability,y,s=38,color=[SCOL[s] for s in qd.scenario],edgecolor='white',lw=.55)
        axd.set_yticks(y,[SERVICE[s] for s in qd.scenario]); axd.set_xlim(0,1.04)
        axd.set_xticks([0,.25,.50,.75,1.00])
        for i,r in qd.iterrows():
            value=float(r.nonadditivity_delta_selection_probability); inward=value>=.90
            artist=value_badge(axd,value,i,f'{value:.0%}',dx=-6 if inward else 6,ha='right' if inward else 'left',color=SCOL[r.scenario],ec=SCOL[r.scenario])
            supp11d_value_artists.append((i,str(r.scenario),value,inward,artist))
    axd.set_xlabel('Combined minus summed candidate-specific selection gain'); clean(axd,'x')

    # Renderer-level publication QA.  It checks the actual drawn text boxes,
    # not only source-code offsets, after constrained layout has settled.
    fig.canvas.draw(); renderer=fig.canvas.get_renderer()
    c_rows=[]
    for row,label,value,marker_size,artist in supp11c_value_artists:
        bbox=artist.get_window_extent(renderer=renderer); centre=axc.transData.transform((value,row)); radius=(marker_size**.5)/2*fig.dpi/72
        c_rows.append({'row':row,'pair_label':label,'value':value,'label_below_sphere':bool(bbox.y1<=centre[1]-radius+.75),'label_inside_axes':bool(bbox.x0>=axc.bbox.x0-.75 and bbox.x1<=axc.bbox.x1+.75 and bbox.y0>=axc.bbox.y0-.75 and bbox.y1<=axc.bbox.y1+.75),'x0_px':bbox.x0,'x1_px':bbox.x1,'y0_px':bbox.y0,'y1_px':bbox.y1})
    c_collision_rows=[]
    for i,(row_a,label_a,_,_,artist_a) in enumerate(supp11c_value_artists):
        bbox_a=artist_a.get_window_extent(renderer=renderer)
        for row_b,label_b,_,_,artist_b in supp11c_value_artists[i+1:]:
            bbox_b=artist_b.get_window_extent(renderer=renderer); ow=max(0,min(bbox_a.x1,bbox_b.x1)-max(bbox_a.x0,bbox_b.x0)); oh=max(0,min(bbox_a.y1,bbox_b.y1)-max(bbox_a.y0,bbox_b.y0))
            c_collision_rows.append({'row_a':row_a,'label_a':label_a,'row_b':row_b,'label_b':label_b,'overlap_area_px2':ow*oh,'collision':bool(ow>0 and oh>0)})
    d_rows=[]
    for row,scenario,value,inward,artist in supp11d_value_artists:
        bbox=artist.get_window_extent(renderer=renderer); centre=axd.transData.transform((value,row)); radius=(38**.5)/2*fig.dpi/72
        d_rows.append({'row':row,'scenario':scenario,'value':value,'display_label':f'{value:.0%}','is_98_percent':bool(abs(value-.98)<.005),'inward_placement':bool(inward),'label_clear_of_sphere':bool(bbox.x1<=centre[0]-radius+.75 if inward else bbox.x0>=centre[0]+radius-.75),'label_inside_axes':bool(bbox.x0>=axd.bbox.x0-.75 and bbox.x1<=axd.bbox.x1+.75 and bbox.y0>=axd.bbox.y0-.75 and bbox.y1<=axd.bbox.y1+.75),'x0_px':bbox.x0,'x1_px':bbox.x1,'y0_px':bbox.y0,'y1_px':bbox.y1})
    panel_rows=[]
    for name,axis in [('11c',axc),('11d',axd)]:
        pos=axis.get_position(); panel_rows.append({'panel':name,'x0':pos.x0,'x1':pos.x1,'width':pos.width,'y0':pos.y0,'y1':pos.y1,'height':pos.height})
    pd.DataFrame(c_rows).to_csv(QA/'supp11c_value_label_layout_audit.csv',index=False)
    pd.DataFrame(c_collision_rows).to_csv(QA/'supp11c_value_label_collision_audit.csv',index=False)
    pd.DataFrame(d_rows).to_csv(QA/'supp11d_value_label_layout_audit.csv',index=False)
    pd.DataFrame(panel_rows).to_csv(QA/'supp11_panel_layout_audit.csv',index=False)
    save(fig,11,'Complementary evidence-action interactions and programme non-additivity',['evidence_action_dag_registry','submission_nonzero_gate_interaction_summary','evidence_programme_nonadditivity'],supp=True)


def supp12():
    """Validation, applicability-domain and candidate-invariant-value audit."""
    validation=read('ai_model_validation',BASE)
    applicability=read('ai_candidate_applicability_audit',BASE)
    invariant=read('candidate_invariant_value_selection',BASE)
    comparison=read('candidate_invariant_value_comparison',BASE)
    grouped='nested_group_split_conformal_test'; random='random_record_cv_optimism_diagnostic'
    targets=['melting_temperature_K','density_kg_m3']; target_labels=['Melting temperature','Density']
    fig=plt.figure(figsize=(MAIN_W,6.45),constrained_layout=True)
    gs=fig.add_gridspec(2,2,height_ratios=[.88,1.12],hspace=.10,wspace=.09)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1])

    panel(axa,'a'); x=np.arange(2); width=.32
    grouped_r2=[]; random_r2=[]
    for target in targets:
        g=validation[(validation.target.eq(target)) & validation.validation_scheme.eq(grouped)].iloc[0]
        r=validation[(validation.target.eq(target)) & validation.validation_scheme.eq(random)].iloc[0]
        grouped_r2.append(float(g.r2)); random_r2.append(float(r.r2))
    axa.bar(x-width/2,grouped_r2,width,color=NAVY,label='Formula-system grouped test')
    axa.bar(x+width/2,random_r2,width,color=PALE_BLUE,edgecolor=NAVY,lw=.55,label='Random-record diagnostic')
    for xx,v in zip(np.r_[x-width/2,x+width/2],grouped_r2+random_r2):
        axa.text(xx,v+.025,f'{v:.2f}',ha='center',va='bottom',fontsize=5.3,fontweight='bold')
    axa.set_xticks(x,target_labels); axa.set_ylim(0,1.02); axa.set_ylabel(r'$R^2$'); clean(axa,'y')
    top_legend(axa,[Patch(facecolor=NAVY,label='Grouped external system'),Patch(facecolor=PALE_BLUE,edgecolor=NAVY,label='Random-record optimism diagnostic')],ncol=2,anchor=(.5,1.14),fontsize=4.8)

    panel(axb,'b'); coverage=[]; widths=[]
    for target in targets:
        g=validation[(validation.target.eq(target)) & validation.validation_scheme.eq(grouped)].iloc[0]
        coverage.append(float(g.interval_empirical_coverage)); widths.append(float(g.mean_interval_width))
    bars=axb.bar(x,coverage,width=.52,color=[MUSTARD,TERRACOTTA])
    axb.axhline(.90,color=INK,lw=.7,ls='--',label='Nominal 90%')
    for i,(bar,cov,wid) in enumerate(zip(bars,coverage,widths)):
        unit='K' if i==0 else r'kg m$^{-3}$'
        axb.text(bar.get_x()+bar.get_width()/2,cov+.018,f'{cov:.1%}\nwidth {wid:.0f} {unit}',ha='center',va='bottom',fontsize=5.2)
    axb.set_xticks(x,target_labels); axb.set_ylim(0,1.05); axb.set_ylabel('Independent interval coverage'); clean(axb,'y')
    top_legend(axb,[Line2D([0],[0],color=INK,ls='--',lw=.8,label='Nominal 90%')],ncol=1,anchor=(.5,1.12),fontsize=5.0)

    panel(axc,'c'); app=applicability.copy()
    app=app.sort_values(['ai_use_class','system_id'],ascending=[True,True]).reset_index(drop=True)
    arr=app[['melting_temperature_K_in_domain','density_kg_m3_in_domain']].astype(bool).astype(int).to_numpy()
    axc.imshow(arr,aspect='auto',cmap=ListedColormap([VERY_LIGHT,OLIVE]),vmin=0,vmax=1)
    axc.set_xticks([0,1],['Melting','Density']); axc.set_yticks(range(len(app)),[short_id(x) for x in app.system_id]); axc.tick_params(axis='y',labelsize=5.0)
    for i,row in enumerate(arr):
        for j,value in enumerate(row): axc.text(j,i,'in' if value else 'blocked',ha='center',va='center',fontsize=4.8,color='white' if value else MID_GREY)
    axc.set_title('Applicability domain (both required; unseen elements hard blocked)',fontsize=6.0,pad=5); clean(axc,None)

    panel(axd,'d'); active=invariant[(invariant.selection_frequency.gt(0)) | (invariant.relative_minmax_selection_frequency.gt(0))].copy()
    active['label']=[f"{SERVICE.get(s,s)} · {short_id(m)}" for s,m in zip(active.scenario,active.system_id)]
    active=active.sort_values(['scenario','selection_frequency']).reset_index(drop=True); y=np.arange(len(active))
    axd.hlines(y,active.relative_minmax_selection_frequency,active.selection_frequency,color=LIGHT_GREY,lw=2.2)
    axd.scatter(active.relative_minmax_selection_frequency,y,s=36,facecolor='white',edgecolor=NAVY,lw=.8,label='Within-draw min–max')
    axd.scatter(active.selection_frequency,y,s=36,color=OLIVE,edgecolor='white',lw=.55,label='Benchmark-anchored')
    axd.set_yticks(y,active.label); axd.tick_params(axis='y',labelsize=5.0); axd.set_xlim(0,1.0); axd.set_xlabel('Selection frequency'); clean(axd,'x')
    minimum=float(comparison.same_draw_outcome_frequency.min())
    axd.text(.98,.04,f'Minimum draw-matched agreement: {minimum:.1%}\nIIA retained-winner audit: 100%',transform=axd.transAxes,ha='right',va='bottom',fontsize=5.2,color=MID_GREY)
    top_legend(axd,[Line2D([0],[0],marker='o',ls='',mfc='white',mec=NAVY,label='Within-draw min–max'),Line2D([0],[0],marker='o',ls='',mfc=OLIVE,mec='white',label='Benchmark-anchored')],ncol=2,anchor=(.5,1.12),fontsize=5.0)
    save(fig,12,'Leakage-resistant property-model validation, applicability domain and candidate-invariant value audit',['ai_model_validation','ai_model_fold_validation','ai_candidate_applicability_audit','ai_decision_firewall_audit','candidate_invariant_value_selection','candidate_invariant_value_comparison','candidate_invariant_iia_audit'],supp=True)


def supp13():
    """Primary-source composite evidence, uncertainty and system-direction audit."""
    prop=read('composite_property_response',BASE)
    dynamic=read('composite_dynamic_summary',BASE)
    summary=read('composite_system_summary',BASE).set_index('metric')['value'].astype(float)
    coupling=read('composite_service_coupling',BASE)
    fig=plt.figure(figsize=(MAIN_W,7.15),constrained_layout=True)
    gs=fig.add_gridspec(2,2,hspace=.11,wspace=.11)
    axa=fig.add_subplot(gs[0,0]); axb=fig.add_subplot(gs[0,1]); axc=fig.add_subplot(gs[1,0]); axd=fig.add_subplot(gs[1,1])

    panel(axa,'a'); stages=[('Reported conditions',summary['experimental_condition_records']),('Exact base linked',summary['exact_base_linked_records']),('Capacity quantified',summary['quantified_capacity_records']),('Capacity + viscosity',summary['coupled_capacity_viscosity_records']),('Direction-resolved stationary',summary['direction_resolved_stationary_records']),('Formal full-duty',summary['formal_composite_eligible_links'])]
    y=np.arange(len(stages))[::-1]; vals=np.array([v for _,v in stages]); colors=[NAVY,BLUE,PALE_BLUE,MUSTARD,TERRACOTTA,BURGUNDY]
    axa.hlines(y,0,vals,color=LIGHT_GREY,lw=1.2); axa.scatter(vals,y,s=42,color=colors,edgecolor='white',lw=.55,zorder=3)
    for yy,v,col in zip(y,vals,colors): value_badge(axa,v,yy,str(int(v)),dx=5,color=col,ec=col,fontsize=4.7)
    axa.set_yticks(y,[x[0] for x in stages]); axa.set_xlim(0,25.5); axa.set_xlabel('Experimental condition records'); clean(axa,'x')

    panel(axb,'b'); q=prop[prop.source_id.isin(['ANDREU_2014','CHIERUZZI_2013']) & prop.capacity_ratio.notna()].copy()
    q['series']=np.where(q.source_id.eq('ANDREU_2014'),'Replicated SiO$_2$',q.additive.astype(str).map({'SiO2':'SiO$_2$','Al2O3':'Al$_2$O$_3$','TiO2':'TiO$_2$','82% SiO2 + 18% Al2O3':'Hybrid'}))
    series=list(q.series.drop_duplicates()); cmap={s:c for s,c in zip(series,[NAVY,BLUE,TERRACOTTA,OLIVE,ROSE])}; offsets={s:(i-(len(series)-1)/2)*.035 for i,s in enumerate(series)}
    for s,g in q.groupby('series',sort=False):
        xx=g.additive_fraction_wt_pct.astype(float).to_numpy()+offsets[s]; mid=g.capacity_ratio.astype(float).to_numpy(); lo=g.capacity_ratio_low.astype(float).to_numpy(); hi=g.capacity_ratio_high.astype(float).to_numpy()
        axb.errorbar(xx,mid,yerr=np.vstack([mid-lo,hi-mid]),fmt='o',ms=3.5,color=cmap[s],ecolor=cmap[s],elinewidth=.75,capsize=1.7,label=s)
    axb.axhline(1,color=INK,lw=.7,ls='--'); axb.set_xlim(.38,1.62); axb.set_ylim(.72,1.31); axb.set_xticks([.5,1.0,1.5]); axb.set_xlabel('Additive concentration (wt%)'); axb.set_ylabel('Liquid heat-capacity ratio'); clean(axb,'both')
    top_legend(axb,[Line2D([0],[0],marker='o',ls='',mfc=c,mec=c,label=s,markersize=3.5) for s,c in cmap.items()],ncol=3,anchor=(.5,1.14),fontsize=4.5)
    axb.text(.02,.03,'Intervals: replicate 90% delta or study-motivated ±6% sensitivity',transform=axb.transAxes,fontsize=4.2,color=MID_GREY)

    panel(axc,'c'); entries=[]
    for rid,label,metric in [('ELFAR_SIO2_LOW_SHEAR',r'SiO$_2$ · 10 s$^{-1}$','capacity'),('ELFAR_SIO2_HIGH_SHEAR',r'SiO$_2$ · 240 s$^{-1}$','capacity'),('GROSU_AL2O3',r'Al$_2$O$_3$ · capacity/pump','capacity'),('GROSU_AL2O3',r'Al$_2$O$_3$ · + transport','transport')]:
        r=dynamic[dynamic.record_id.eq(rid)].iloc[0]; prefix='transport_adjusted_index' if metric=='transport' else 'capacity_pumping_index'
        entries.append((label,float(r[f'{prefix}_p05']),float(r[f'{prefix}_p50']),float(r[f'{prefix}_p95']),float(r[f'probability_{prefix}_gt_1'])))
    y=np.arange(len(entries))[::-1]; axc.axvline(1,color=INK,lw=.7,ls='--')
    for yy,(lab,lo,mid,hi,p) in zip(y,entries):
        col=OLIVE if p>=.5 else (MUSTARD if p>0 else BURGUNDY); axc.hlines(yy,lo,hi,color=col,lw=1.8); axc.scatter(mid,yy,s=38,color=col,edgecolor='white',lw=.5); value_badge(axc,hi,yy,f'P>1: {p:.0%}',dx=4,color=col,ec=col,fontsize=4.45)
    axc.set_yticks(y,[x[0] for x in entries]); axc.set_xlim(.15,1.30); axc.set_xlabel(r'Coupled index, $R_C/R_\mu^{\beta}$ (and $\times R_k$ where shown)'); clean(axc,'x')
    outside_note(axc,r'$\beta\sim U(0.25,1.0)$; points and lines are median and 5–95%',x=.98,y=1.025)

    panel(axd,'d'); foam=prop[prop.record_id.eq('XIAO_FOAM_AL2O3')].iloc[0]; eg=prop[prop.record_id.eq('WANG_EG10')].iloc[0]
    stationary=[('Foam charging power',float(foam.charge_power_ratio),TERRACOTTA,'higher'),('Foam bidirectional power',float(foam.bidirectional_power_ratio),BURGUNDY,'higher'),('EG thermal conductivity',float(eg.thermal_conductivity_ratio),OLIVE,'higher'),('EG active-salt fraction',float(eg.active_salt_mass_fraction),MUSTARD,'higher'),('EG 316SS corrosion rate',float(eg.corrosion_rate_ratio),BLUE,'lower')]
    y=np.arange(len(stationary))[::-1]; axd.axvline(1,color=INK,lw=.7,ls='--')
    for yy,(lab,val,col,direction) in zip(y,stationary):
        if not np.isfinite(val):
            axd.text(1.12,yy,'Not quantified',fontsize=5,color=MID_GREY,va='center')
            continue
        axd.hlines(yy,min(1,val),max(1,val),color=col,lw=1.8); axd.scatter(val,yy,s=39,color=col,edgecolor='white',lw=.5)
        value_badge(axd,val,yy,f'{val:.2f}',dx=4,color=col,ec=col,fontsize=4.5)
    axd.set_xscale('log'); axd.set_xlim(.58,5); axd.set_yticks(y,[x[0] for x in stationary]); axd.set_xlabel('Reported ratio to unmodified base (log scale)'); clean(axd,'x')
    outside_note(axd,'Ratios retain their physical direction; no utility score is formed',x=.98,y=1.025)

    pd.DataFrame({'metric':['experimental_condition_records','formal_composite_eligible_links','full_composite_domain_links'],'value':[summary['experimental_condition_records'],summary['formal_composite_eligible_links'],summary['full_composite_domain_links']]}).to_csv(QA/'supp13_composite_evidence_audit.csv',index=False)
    pd.DataFrame(entries,columns=['diagnostic','p05','p50','p95','probability_gt_1']).to_csv(QA/'supp13_dynamic_response_audit.csv',index=False)
    save(fig,13,'Composite-media evidence contraction, nanoparticle response uncertainty, hydraulic coupling and stationary-scaffold directionality',['core_composite_property_response','core_composite_dynamic_summary','core_composite_system_summary','core_composite_service_coupling'],supp=True)

def make_contact(paths,out,cols,thumb_width):
    ims=[]
    for p in paths:
        with Image.open(p) as src:
            im=src.convert('RGB')
        ratio=thumb_width/im.width; h=max(1,int(im.height*ratio)); im=im.resize((thumb_width,h),Image.Resampling.LANCZOS); ims.append(im)
    rows=math.ceil(len(ims)/cols); row_heights=[]
    for r in range(rows): row_heights.append(max(im.height for im in ims[r*cols:(r+1)*cols]))
    sheet=Image.new('RGB',(cols*thumb_width,sum(row_heights)),'white'); y=0
    for r in range(rows):
        for c in range(cols):
            idx=r*cols+c
            if idx<len(ims): sheet.paste(ims[idx],(c*thumb_width,y+(row_heights[r]-ims[idx].height)//2))
        y+=row_heights[r]
    sheet.save(out,quality=92)


def write_docs():
    story='''# scientific storyline

Two non-interchangeable evidence universes → 142 exact candidates and 994 candidate–service pairs → physical and service-domain contraction → evidence-bounded formal decisions → threshold cliffs and non-compensatory Pareto structure → uncertainty attribution → precedence-constrained experiments.

The expanded library changes the opportunity layer, not the formal evidence rule. A newly documented NaCl–KCl–CaCl2 composition acquires a 23.48% PCM500 thermophysical rank-1 frequency in the service-domain-supported opportunity layer. It lies outside the frozen 15-candidate engineering registry, so no formal outcome is assigned. Within the registered decision set, commercial benchmarks retain formal comparability because their evidence chains are more continuous.

A separate second-stage module links nanoparticle and stationary-scaffold records to their exact base salts. It retains heat capacity, viscosity and pumping, conductivity, active-salt displacement, bidirectional power, durability and corrosion as separate gates. The coupled result overturns enhancement-only reasoning: isolated property gains are frequent, but none of the 60 base-qualified composite record–service links closes the full system evidence chain.
'''
    (DOCS/'STORYLINE.md').write_text(story,encoding='utf-8')
    captions='''# main figures

## Fig. 1 — Two-universe evidence architecture and gate-specific retention
**a**, separate official-screen and application-library count lanes. **b**, evidence-stream to chemistry-family alluvial. **c**, property coverage across the ten largest exact-composition families. **d**, registered engineering-evidence score by claim class. **e**, gate-specific conditional retention after the 142-candidate by seven-service expansion, with the denominator at every gate stated explicitly.

## Fig. 2 — Cross-layer rank reversal and independent rule transfer
**a**, physical, quantitative and service-domain-supported pair counts by service. **b**, registered screening rules applied without recalibration to nine independently reported nitrate formulations. The panel compares scalar volumetric heat capacity at 300 °C, the Solar Salt benchmark and the absence of complete service-domain support. **c**, service-domain-supported rank-1 frequencies for every non-negligible candidate. **d**, formal evidence-bounded outcome composition, including explicit no-selection states. **e**, PCM500 comparison showing a 23.48% thermophysical opportunity for the new 2025 NaCl–KCl–CaCl₂ composition while formal assessment remains outside the frozen registry.

## Fig. 3 — Evidence thresholds and traceable new-candidate exclusion
**a**, compact stacked shares of all registered coverage–evidence states. **b**, coverage-threshold response for the three non-degenerate services. **c**, full evidence-threshold no-selection response exposing the 0.75–0.85 decision cliff. **d**, candidate-service signed thermal-headroom matrix for the four newly added exact compositions, with exact °C margins and the first post-thermal evidence boundary; non-negative values are thermally admissible and blue-hatched N/R cells denote an unreported upper stability boundary. **e**, service-level regime archetypes; structurally flat services are compressed rather than repeated.

## Fig. 4 — No universal salt: uncertainty-aware non-compensatory Pareto structure
**a**, five service-faceted representative performance–evidence maps with marginal 5–95% draw ranges; PCM350 and PCM425 are omitted from geometric comparison because each has only one evaluable candidate. **b**, bootstrap Pareto-membership forest. **c**, dominance-mechanism matrix. **d**, full-width intersections of ≥50% Pareto membership, decision-ready evidence and ≥1% formal selection. **e**, cross-service ≥50% Pareto-membership and formal-selection breadth. **f**, strict-layer transition summary.

## Fig. 5 — Uncertainty-source attribution and structural bottlenecks
**a**, service-to-uncertainty-structure alluvial. **b**, continuous-margin Shapley variance shares. **c**, categorical-state Shapley information shares. **d**, property-domain coverage losses with endpoint badges. **e**, candidate-specific engineering-evidence unlock contributions with endpoint badges. **f**, seven service-specific evidence-closure-depth responses showing the median retained frequency and registered minimum-to-maximum range. **g**, performance–evidence dependence with the PCM500 label displaced from the data point.

## Fig. 6 — Decision-boundary back-tracing and evidence investment priorities
**a**, precedence-valid state–action–endpoint alluvial. **b**, complete minimum admissible action-set matrix for scientifically evaluable candidate–service pairs. **c**, compact action-benefit forest. **d**, ordinal burden–gain map. **e**, candidate selection-frequency redistribution for registered effects with |Δ| ≥1%. **f**, second-stage composite evidence contraction and coupled response ratios. Heat-capacity enhancement is tested against viscosity-sensitive pumping, while foam charging is separated from bidirectional power.
'''
    (DOCS/'MAIN_FIGURE_CAPTIONS.md').write_text(captions,encoding='utf-8')
    checklist='''# figure and panel checklist

## Main figures

### Figure 1 | Two-universe evidence architecture and gate-specific retention
- **1a** Separate official-screen and application-library count lanes; denominators are not pooled.
- **1b** Evidence provenance alluvial: evidence streams to chemistry families.
- **1c** Family-resolved property coverage across 142 exact candidates.
- **1d** Claim-boundary map: evidence score across database-validated, exact-measured, commercial-benchmark and derived/predicted classes.
- **1e** Gate-specific conditional retention: 76/994 physical (7.6%) → 18/76 quantitative (23.7%) → 11/18 service-domain supported (61.1%) → 8/11 linked to the frozen engineering registry (72.7%).

### Figure 2 | Cross-layer rank reversal and independent rule transfer
- **2a** Physical, quantitative and temperature-domain pair counts by service.
- **2b** Independent rule-transfer test for nine nitrate formulations. All nine have scalar measurements at 300 °C, yet none supports a complete service-domain assessment.
- **2c** Temperature-domain rank-1 frequencies.
- **2d** Formal outcome composition with no-selection treated as an outcome.
- **2e** PCM500 opportunity: new 2025 chloride at 23.48% thermophysical rank-1 frequency; formal assessment is pending outside the frozen registry.

### Figure 3 | Gradient regimes and application-dependent switching
- **3a** Stacked shares of robust, conditional and no-bounded-access states across all services.
- **3b** Coverage-threshold no-selection response for Coal, CSP and Industrial heat.
- **3c** Full evidence-threshold response exposing the decision cliff.
- **3d** Candidate-service signed thermal-headroom matrix with exact °C margins and the first post-thermal evidence boundary; non-negative cells are thermally admissible and blue-hatched N/R cells mark an unreported upper stability boundary.
- **3e** Service-level regime archetype matrix; only populated archetypes are shown, so no empty stable class is implied.

### Figure 4 | Uncertainty-aware Pareto structure
- **4a** Five multi-candidate performance–evidence maps plus a matched evidence-readiness interval panel for the two singleton services; the singleton panel is scope-only and makes no Pareto claim.
- **4b** Bootstrap Pareto-membership frequency forest.
- **4c** Dominance-mechanism matrix.
- **4d** Full-width ≥50% Pareto-membership, decision-ready-evidence and ≥1%-formal-selection intersections.
- **4e** Cross-service ≥50% Pareto-membership and formal-selection breadth.
- **4f** Retained, redirected and no-selection strict-layer transition shares.

### Figure 5 | Uncertainty-source attribution and structural bottlenecks
- **5a** TES service to decision-uncertainty structure alluvial.
- **5b** Continuous decision-margin Shapley variance attribution.
- **5c** Categorical selected-state Shapley information attribution.
- **5d** Service coverage lost to registered property domains.
- **5e** Candidate-specific engineering-evidence unlock contribution.
- **5f** Seven service-specific evidence-closure-depth responses.
- **5g** Pearson–Spearman performance–evidence dependence and near-zero inset.

### Figure 6 | Decision-boundary back-tracing and evidence priorities
- **6a** Current state → precedence-valid action → endpoint alluvial.
- **6b** Complete minimum admissible action-set matrix for scientifically evaluable candidate–service pairs.
- **6c** Registered action decision-benefit forest.
- **6d** Ordinal evidence burden versus decision benefit.
- **6e** Candidate selection-frequency redistribution for |Δ| ≥1%.
- **6f** Second-stage composite evidence contraction and coupled response ratios. Response ratios are referenced to each exact base system and are not combined into a cross-material score.

## Supplementary figures

### Supplementary Figure 1 | Complete full-library evidence audit
- **S1a** Exact-candidate counts for all chemistry families.
- **S1b** Complete family-by-property coverage matrix.
- **S1c** Independent-source density versus property-record density for all 142 candidates.
- **S1d** Explicit material-boundary disposition.

### Supplementary Figure 2 | Provenance linkage and candidate-specific credibility
- **S2a** Candidate database/provenance match lollipop with numerical match badges.
- **S2b** Candidate atomic-credibility heatmap.

### Supplementary Figure 3 | Unique thermophysical profiles
- **S3** Column-normalized deterministic thermophysical profile heatmap after exact-duplicate collapse.

### Supplementary Figure 4 | Pairwise performance and material-cost boundary
- **S4a** Pairwise energy-density superiority probabilities with endpoint badges.
- **S4b** Conditional raw-material-cost 5–95% forest with median badges.

### Supplementary Figure 5 | Complete-service overclaim penalty
- **S5** Partial-overlap energy-overclaim lollipop with overclaim and coverage annotations.

### Supplementary Figure 6 | Threshold sensitivity and convergence
- **S6a** Full seven-service 630-state coverage–evidence regime registry.
- **S6b** Evidence-threshold response of expected strict-complete candidate count.
- **S6c** Independent Monte Carlo convergence of modal-frequency error.

### Supplementary Figure 7 | Candidate-specific engineering-evidence intervals
- **S7a** Corrosion credibility intervals.
- **S7b** Cycling/phase credibility intervals.
- **S7c** Containment credibility intervals.

### Supplementary Figure 8 | Omission sensitivity
- **S8a** Candidate-omission decisiveness scatter.
- **S8b** Exact source-omission outcome-group heatmap.

### Supplementary Figure 9 | Credibility shortfall and model sensitivity
- **S9a** Unique credibility-shortfall profile heatmap.
- **S9b** Registered null audit across 14 credibility-model–service contrasts.

### Supplementary Figure 10 | Readiness and candidate archetypes
- **S10a** Deduplicated readiness profiles.
- **S10b** PCM strict-complete probabilities.
- **S10c** Bounded-candidate multiplicity.
- **S10d** Exploratory candidate archetype clusters.

### Supplementary Figure 11 | Complementary evidence-action diagnostics
- **S11a** Registered evidence-action ordinal burden.
- **S11b** Action-to-evidence-dimension closure matrix.
- **S11c** Non-zero gate-pair interaction diagnostics.
- **S11d** Programme non-additivity and complementarity.

### Supplementary Figure 12 | Model-upgrade validation and value-function audit
- **S12a** Formula-system grouped versus random-record validation performance.
- **S12b** Independently evaluated split-conformal coverage and interval width.
- **S12c** Candidate-level applicability-domain disposition with unseen-element blocking.
- **S12d** Benchmark-anchored versus within-draw min–max selection frequencies and IIA audit.

### Supplementary Figure 13 | Composite-media system coupling
- **S13a** Evidence contraction from 22 reported conditions to zero full-duty formal qualifiers.
- **S13b** Concentration-resolved Solar Salt nanoparticle heat-capacity ratios with replicate or protocol-sensitivity intervals.
- **S13c** Hydraulic-exponent envelopes for capacity–pumping and transport-adjusted indices.
- **S13d** Direction-preserving stationary-scaffold ratios for charging, bidirectional power, conductivity, active-salt fraction and corrosion.


## Global submission typography and layout checks
- Legends requested above axes are single-row and outside data fields.
- Obsolete legend reserve space is removed.
- Lollipop/forest endpoints use consistent numerical badges where scientifically useful.
- Chemical formulae and units use mathtext subscripts/superscripts, including sCO$_2$, MgCl$_2$, kWh m$^{-3}$ and kWh$_{th}^{-1}$.
- Structurally flat or repeated services are compressed rather than redrawn.
- Main and supplementary figures answer distinct questions; full-detail scans remain supplementary.
- Registered DAG semantics are explicit: containment qualification requires corrosion compatibility; independent replication requires data completeness; atomic cycling can begin independently within a defensible service window.
'''
    (DOCS/'FIGURE_AND_PANEL_CHECKLIST.md').write_text(checklist,encoding='utf-8')
    rel=pd.DataFrame([
        ('Fig1','Supp1–3','Evidence provenance and full-library contraction','Supplement 1 gives complete family, source-density and material-boundary audits; main Fig. 1 keeps only the decision-relevant summary.'),
        ('Fig2','Supp3–5','Independent rule transfer, ranked service-domain opportunity and formal outcomes','Supplement contains complete property distributions, pairwise comparisons and partial-overlap diagnostics; it does not repeat the independent rule-transfer test.'),
        ('Fig3','Supp6–7','Coverage/evidence boundaries and candidate-service signed thermal headroom','Supplementary Fig. 6 gives the complete threshold registry and convergence tests; Supplementary Fig. 7 gives condition-specific engineering-evidence intervals. Neither reproduces the candidate-service signed thermal-headroom matrix or its post-thermal boundary annotations.'),
        ('Fig4','Supp8–10','Within-service representative Pareto geometry, singleton evidence precision and formal-scope separation','Supplement retains omission sensitivity, covariance and readiness records; main 4a separates multi-candidate geometry from scope-only singleton intervals and remains distinct from 4b membership probability and 4c dominance classes.'),
        ('Fig5','Supp9–11','Separated attribution, bottlenecks and closure-depth response','Supplement retains full attribution and gate-interaction diagnostics without redrawing closure-depth curves.'),
        ('Fig6','Supp11, Supp13','Actionable paths, redistribution and composite-system coupling','Supplementary Fig. 11 retains programme-complementarity diagnostics. Supplementary Fig. 13 resolves concentration, uncertainty and directionality records without redrawing the compact Fig. 6f synthesis.')],columns=['main_figure','supplement','main_role','nonduplication_rule'])
    rel.to_csv(QA/f'{V}_MAIN_SUPPLEMENT_RELATIONSHIP.csv',index=False)
    style={'native_width_mm':180,'font_family':'Arial (strict system-font requirement)','body_pt':8.0,'axis_pt':7.1,'tick_pt':6.5,'legend_pt':6.3,'panel_letter_pt':9.1,'main_figure_rule':'one dominant anchor plus non-redundant mechanism panels','zero_flat_rule':'do not render all-zero, singleton or repeated-flat states as standalone main panels','annotation_rule':'endpoint badges remain inside axes where possible; leader lines used for displaced labels','typography_rule':'chemical formulae and units use mathtext subscripts/superscripts','scientific_boundary':'expanded thermophysical opportunity and frozen formal engineering registry are explicitly separated; Pareto definition, attribution and DAG semantics unchanged'}
    (ROOT/'config'/'visual_style_lock.json').write_text(json.dumps(style,indent=2),encoding='utf-8')


def build_qa():
    rows=[]
    for kind,folder,prefix,n in [('main',MAIN,'Fig',6),('supplementary',SUPP,'Supp_Fig',13)]:
        for i in range(1,n+1):
            png=folder/f'{V}_{prefix}{i}.png'; pdf=folder/f'{V}_{prefix}{i}.pdf'
            with Image.open(png) as im:
                width,height=im.size
            rows.append({'figure_type':kind,'figure':f'{prefix}{i}','png_exists':png.exists(),'pdf_exists':pdf.exists(),'width_px':width,'height_px':height,'aspect_ratio':width/height,'png_bytes':png.stat().st_size,'pdf_bytes':pdf.stat().st_size})
    idx=pd.DataFrame(rows); idx.to_csv(QC/'figure_index.csv',index=False)

    fig2_pcm=pd.read_csv(QA/'fig2_pcm500_opportunity_audit.csv')
    fig2b=pd.read_csv(QA/'fig2b_external_rule_transfer_audit.csv')
    fig3c=pd.read_csv(QA/'fig3c_evidence_response_audit.csv')
    fig3d=pd.read_csv(QA/'fig3d_candidate_service_thermal_margin_audit.csv')
    fig3d_nondup=pd.read_csv(QA/'fig3d_supplement_nonduplication_audit.csv')
    fig3e=pd.read_csv(QA/'fig3e_populated_regime_archetypes.csv')
    fig4a=pd.read_csv(QA/'fig4a_within_service_geometry_audit.csv')
    fig4a_layout=pd.read_csv(QA/'fig4a_layout_alignment_audit.csv').set_index('panel')
    fig4a_labels=pd.read_csv(QA/'fig4a_label_collision_audit.csv')
    fig4_alignment=pd.read_csv(QA/'fig4_panel_alignment_audit.csv')
    fig4_direct_bounds=pd.read_csv(QA/'fig4_direct_label_boundary_audit.csv')
    fig4_direct_collisions=pd.read_csv(QA/'fig4_direct_label_collision_audit.csv')
    supp5_layout=pd.read_csv(QA/'supp5_coverage_label_layout_audit.csv')
    supp5_collisions=pd.read_csv(QA/'supp5_label_collision_audit.csv')
    supp11c_layout=pd.read_csv(QA/'supp11c_value_label_layout_audit.csv')
    supp11c_collisions=pd.read_csv(QA/'supp11c_value_label_collision_audit.csv')
    supp11d_layout=pd.read_csv(QA/'supp11d_value_label_layout_audit.csv')
    supp11_panels=pd.read_csv(QA/'supp11_panel_layout_audit.csv').set_index('panel')
    expected_official_steps=[
        'Raw MSD-TP composition records',
        'Melting temperature available',
        'Application-specific melting/phase lower-bound compatibility',
        'Minimum thermophysical coverage (melting + at least two fields)',
    ]
    official=read('database_to_shortlist_transition').set_index('screen_step').loc[expected_official_steps,'retained_count'].astype(int).tolist()
    attr=read('evidence_attrition','expanded_v3')
    attr_expected=[142,994,76,18,11,8]
    attr_actual=attr[attr.stage.isin([
        'Exact-composition candidates after canonical deduplication',
        'Candidate-service pairs across seven frozen duties',
        'Physical-window-compatible pairs','Quantitative thermophysical pairs',
        'Service-domain-supported thermophysical pairs',
        'Service-domain-supported pairs linked to frozen engineering registry'
    ])].set_index('stage').loc[[
        'Exact-composition candidates after canonical deduplication',
        'Candidate-service pairs across seven frozen duties',
        'Physical-window-compatible pairs','Quantitative thermophysical pairs',
        'Service-domain-supported thermophysical pairs',
        'Service-domain-supported pairs linked to frozen engineering registry'
    ],'count'].astype(int).tolist()
    dag=read('evidence_action_dag_registry',STAT).copy()
    prereq=dag.set_index('action_id').prerequisite_dimensions.fillna('').astype(str).to_dict()
    dag_semantics=(prereq.get('system_containment_qualification')=='corrosion_compatibility'
                   and prereq.get('independent_replication')=='data_completeness'
                   and prereq.get('long_duration_cycling')=='')
    rules=[
        ('Six main and thirteen supplementary figures rendered',len(idx)==19),
        ('Fig. 1a preserves the official 976→937→250→74 screening counts',official==[976,937,250,74]),
        ('Fig. 1e preserves the full-library 142→994→76→18→11→8 scope logic',attr_actual==attr_expected),
        ('All PNG/PDF pairs exist',bool(idx.png_exists.all() and idx.pdf_exists.all())),
        ('Exact 180-mm native width',bool((idx.width_px==2126).all())),
        ('Fig. 2e retains the new 2025 chloride PCM500 opportunity at 20–25%',bool(fig2_pcm.candidate.str.contains('23.5-25.0-51.5',regex=False).any() and fig2_pcm.loc[fig2_pcm.candidate.str.contains('23.5-25.0-51.5',regex=False),'rank1_frequency'].between(.20,.25).all())),
        ('Fig. 2b transfers the registered rules to nine independent nitrate formulations without granting full-duty support',bool(len(fig2b)==9 and fig2b.candidate_id.nunique()==9 and fig2b.volumetric_heat_capacity_MJ_m3K_at_300C.max()>8.0 and fig2b.service_domain_supported_pairs.eq(0).all() and fig2b.physical_window_pairs.eq(27).all())),
        ('Fig. 3c contains non-flat evidence-threshold responses',bool((fig3c.maximum_no_selection-fig3c.minimum_no_selection>.45).all())),
        ('Fig. 3d reconstructs 28 candidate-service thermal margins, distinguishes measured failure from missing upper bounds, and preserves the frozen-registry boundary',bool(len(fig3d)==28 and fig3d.display_system.nunique()==4 and fig3d.service_id.nunique()==7 and fig3d.thermal_margin_status.eq('resolved').sum()==21 and fig3d.thermal_margin_status.eq('upper_boundary_unreported').sum()==7 and fig3d.loc[fig3d.thermal_margin_status.eq('resolved'),'thermal_margin_C'].notna().all() and (fig3d.loc[fig3d.thermal_margin_status.eq('resolved'),'thermal_margin_C'].abs()>1e-9).all() and ((fig3d.loc[fig3d.thermal_margin_status.eq('resolved'),'thermal_margin_C']>=0).to_numpy()==fig3d.loc[fig3d.thermal_margin_status.eq('resolved'),'physical_window_pass'].astype(str).str.lower().eq('true').to_numpy()).all() and len(fig3d[fig3d.display_system.str.contains('HXLN',case=False,na=False)&fig3d.service_id.eq('sco2_high_temperature_storage')&fig3d.thermal_margin_status.eq('resolved')&fig3d.thermal_margin_C.lt(0)])==1 and fig3d.service_domain_supported.sum()==1 and fig3d.engineering_registry_linked.sum()==0 and fig3d.formal_assessment_completed.sum()==0 and fig3d.first_post_thermal_boundary.notna().all())),
        ('Fig. 3d primary metric and scientific role are not duplicated by any supplementary figure',bool(len(fig3d_nondup)==13 and fig3d_nondup.supplementary_figure.nunique()==13 and not fig3d_nondup.shared_primary_metric.astype(str).str.lower().eq('true').any() and not fig3d_nondup.duplicate_panel.astype(str).str.lower().eq('true').any())),
        ('Fig. 3d separates unreported upper-stability evidence from the signed margin scale with blue-hatched N/R cells',bool("cmap.set_bad(PALE_BLUE)" in Path(__file__).read_text(encoding='utf-8') and "axd.text(j,i,'N/R',ha='center',va='center',fontsize=4.15,fontweight='bold',color=NAVY)" in Path(__file__).read_text(encoding='utf-8'))),
        ('Three non-degenerate joint-regime maps retained; four flat services compressed',int(read('service_regime_archetype_summary',V).main_map_informative.sum())==3),
        ('No ordinary ANOVA applied to categorical candidate identity',not read('categorical_selection_information_attribution',STAT).method.str.contains(r'(?<!no linear )ANOVA',case=False,regex=True).any()),
        ('Robust Pareto designation requires ≥50% membership',((read('pareto_joint_uncertainty_and_robustness',STAT).threshold_50_member)==(read('pareto_joint_uncertainty_and_robustness',STAT).frontier_membership_frequency>=.5)).all()),
        ('Registered DAG prerequisites match the implemented scientific rationale',bool(dag_semantics)),
        ('Rejected DAG routes are explicitly audited and never evaluated as decision-changing paths',len(read('inadmissible_action_combination_audit',STAT))>0 and read('inadmissible_action_combination_audit',STAT).rejection_reason.astype(str).str.contains('requires',case=False).all()),
        ('Arial font available and explicitly locked',any(f.name=='Arial' for f in mpl.font_manager.fontManager.ttflist) or os.environ.get('ALLOW_ARIAL_FALLBACK','0')=='1'),
        ('Fig. 3e displays only populated regime archetypes and does not imply an unobserved stable class',bool((fig3e.service_count>0).all() and fig3e.displayed_in_fig3e.all() and 'stable single regime' not in set(fig3e.regime_archetype))),
        ('Fig. 4a separates multi-candidate Pareto geometry from scope-only singleton evidence intervals',bool(fig4a.displayed_in_fig4a.all() and set(fig4a.fig4a_role)=={'comparative_service_facet','singleton_scope_interval'} and fig4a.loc[fig4a.fig4a_role.eq('comparative_service_facet'),'scenario'].nunique()==5 and fig4a.loc[fig4a.fig4a_role.eq('comparative_service_facet')].groupby('scenario').size().ge(2).all() and set(fig4a.loc[fig4a.fig4a_role.eq('singleton_scope_interval'),'scenario'])=={'pcm_target_350C','pcm_target_425C'})),
        ('Fig. 4a uses narrow equal-width facets whose outer axes exactly inherit the 4b-left and 4c-right anchors',bool(abs(fig4a_layout.loc['coal_top','x0']-fig4a_layout.loc['sco2_bottom','x0'])<.002 and abs(fig4a_layout.loc['industrial_top','x0']-fig4a_layout.loc['singleton_bottom','x0'])<.002 and fig4a_layout.height.max()/fig4a_layout.height.min()<1.02 and np.allclose(fig4a_layout.width,.260,atol=.002) and abs((fig4a_layout.loc['csp_top','x0']-fig4a_layout.loc['coal_top','x1'])-(fig4a_layout.loc['industrial_top','x0']-fig4a_layout.loc['csp_top','x1']))<.002 and .025<(fig4a_layout.loc['csp_top','x0']-fig4a_layout.loc['coal_top','x1'])<.050 and bool(fig4_alignment.passed.astype(str).str.lower().eq('true').all()) and "fixed_width=.260" in Path(__file__).read_text(encoding='utf-8') and "canonical_left=max(axb.get_position().x0,axe.get_position().x0)" in Path(__file__).read_text(encoding='utf-8') and "canonical_right=min(axc.get_position().x1,axf.get_position().x1)" in Path(__file__).read_text(encoding='utf-8'))),
        ('Fig. 4a uses visible capped 5–95% error bars and has no within-facet label collisions',bool("ecolor=MID_GREY,elinewidth=.90,capsize=2.0,capthick=.75" in Path(__file__).read_text(encoding='utf-8') and len(fig4a_labels)>0 and not fig4a_labels.collision.astype(str).str.lower().eq('true').any())),
        ('Fig. 4 direct labels and badges stay inside their parent axes and do not overlap',bool(len(fig4_direct_bounds)>0 and fig4_direct_bounds.inside_figure.astype(str).str.lower().eq('true').all() and fig4_direct_bounds.inside_parent_axes.astype(str).str.lower().eq('true').all() and len(fig4_direct_collisions)>0 and not fig4_direct_collisions.collision.astype(str).str.lower().eq('true').any())),
        ('Supplementary Fig. 5 places every coverage label before its sphere and every overclaim value after it without collisions',bool(len(supp5_layout)==14 and supp5_layout.coverage_before_sphere.astype(str).str.lower().eq('true').all() and supp5_layout.value_after_sphere.astype(str).str.lower().eq('true').all() and supp5_layout.coverage_inside_axes.astype(str).str.lower().eq('true').all() and supp5_layout.value_inside_axes.astype(str).str.lower().eq('true').all() and not supp5_layout.same_row_collision.astype(str).str.lower().eq('true').any() and len(supp5_collisions)>0 and not supp5_collisions.collision.astype(str).str.lower().eq('true').any())),
        ('Supplementary Fig. 11c places every exact synergy value below its sphere, inside the axis and without label collisions',bool(len(supp11c_layout)==len(read('nonzero_gate_interaction_summary',V)) and supp11c_layout.label_below_sphere.astype(str).str.lower().eq('true').all() and supp11c_layout.label_inside_axes.astype(str).str.lower().eq('true').all() and len(supp11c_collisions)>0 and not supp11c_collisions.collision.astype(str).str.lower().eq('true').any())),
        ('Supplementary Fig. 11d is wider than 11c and keeps the 98% endpoint badge inside the quantitative axis',bool(supp11_panels.loc['11d','width']>=1.45*supp11_panels.loc['11c','width'] and len(supp11d_layout)==len(read('evidence_programme_nonadditivity').query('abs(nonadditivity_delta_selection_probability) > 1e-9')) and supp11d_layout.label_clear_of_sphere.astype(str).str.lower().eq('true').all() and supp11d_layout.label_inside_axes.astype(str).str.lower().eq('true').all() and supp11d_layout.is_98_percent.astype(str).str.lower().eq('true').sum()==1 and supp11d_layout.loc[supp11d_layout.is_98_percent.astype(str).str.lower().eq('true'),'inward_placement'].astype(str).str.lower().eq('true').all())),
        ('Fig. 4e Pareto breadth badges are drawn once',Path(__file__).read_text(encoding='utf-8').split('def build_qa():')[0].count("value_badge(axe,float(r.pareto),i,str(int(r.pareto))") == 1),
        ('Fig. 4d uses a vertically separated intersection matrix, in-axis count headroom and the shared 4b–4c/4e–4f outer anchors',"gsd=gs[2,:].subgridspec(2,1,height_ratios=[1.42,.78]" in Path(__file__).read_text(encoding='utf-8') and "matrix_y=[2.0,1.0,0.0]" in Path(__file__).read_text(encoding='utf-8') and "count_top+7.0" in Path(__file__).read_text(encoding='utf-8') and bool(fig4_alignment.passed.astype(str).str.lower().eq('true').all())),
        ('Chemical subscripts rendered through mathtext labels',SERVICE['sco2_high_temperature_storage']==r'sCO$_2$'),
        ('Fig. 5f shared legend is centred above the seven-panel strip',"bbox_to_anchor=(.5,1.18)" in Path(__file__).read_text(encoding='utf-8') and "if k==3:" in Path(__file__).read_text(encoding='utf-8')),
        ('Fig. 5f strip uses asymmetric centring margins to align with paired panels above',"width_ratios=[.70,1,1,1,1,1,1,1,1.60]" in Path(__file__).read_text(encoding='utf-8')),
    ]
    pd.DataFrame(rules,columns=['rule','passed']).to_csv(QA/'release_gate.csv',index=False)
    comp_summary=read('composite_system_summary',BASE).set_index('metric')['value'].astype(float)
    rules.extend([
        ('Composite second-stage evidence remains separate from base-salt formal selection',int(comp_summary['formal_composite_eligible_links'])==0 and int(comp_summary['base_qualified_service_links'])==60),
        ('Supplementary Fig. 13 dynamic-response audit is present and finite',bool((QA/'supp13_dynamic_response_audit.csv').exists() and pd.read_csv(QA/'supp13_dynamic_response_audit.csv').p50.notna().all())),
    ])
    pd.DataFrame(rules,columns=['rule','passed']).to_csv(QA/'release_gate.csv',index=False)
    status={'status':'PASS' if all(x[1] for x in rules) else 'REVIEW','main_figures':6,'supplementary_figures':13,'active_renderer':'src/run_postprocess.py','legacy_version_call_chain':False,'science_changed':True,'core_scientific_baseline_changed':True,'scientific_extension_added':'second-stage composite-system coupling','dag_semantics':'containment requires corrosion; independent replication requires data completeness; atomic cycling has no artificial universal predecessor'}
    (QC/f'{V}_POSTPROCESS_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    return status


def render_all():
    # Clean renderer-owned artefacts only.  Do not delete the environment or
    # upstream-contract status files created by the release pipeline before
    # rendering; those files are consumed by final release validation.
    for folder in [MAIN,SUPP,CONTACT,QA]:
        for p in folder.glob(f'{V}_*'):
            if p.is_file():
                p.unlink()
    for name in [f'{V}_POSTPROCESS_STATUS.json', 'figure_index.csv', 'pdf_font_audit.csv', 'postprocess_release_gate.csv', 'postprocess_validation_status.json', 'POSTPROCESS_RELEASE_STATUS.json', 'POSTPROCESS_RELEASE_CONTRACT_AUDIT.json']:
        p = QC / name
        if p.exists():
            p.unlink()
    legacy_fig3d=QA/'fig3d_new_candidate_gate_audit.csv'
    if legacy_fig3d.exists():
        legacy_fig3d.unlink()
    fig1(); fig2(); fig3(); fig4(); fig5(); fig6()
    supp1()
    for i in [2,3,4,5,7,8,9,10]: supp_base(i)
    supp6()
    supp11()
    supp12()
    supp13()
    make_contact([MAIN/f'{V}_Fig{i}.png' for i in range(1,7)],CONTACT/f'{V}_main_figures_contact_sheet.jpg',2,1250)
    make_contact([SUPP/f'{V}_Supp_Fig{i}.png' for i in range(1,14)],CONTACT/f'{V}_supplementary_figures_contact_sheet.jpg',3,900)
    write_docs(); pd.DataFrame(FIGURE_RECORDS).to_csv(QA/'figure_source_map.csv',index=False); status=build_qa(); print(json.dumps(status,indent=2))

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--render-key',default='all'); args=ap.parse_args()
    funcs={f'fig{i}':globals()[f'fig{i}'] for i in range(1,7)}|{'supp1':supp1}|{f'supp{i}':(lambda n=i:supp_base(n)) for i in [2,3,4,5,7,8,9,10]}|{'supp6':supp6}|{'supp11':supp11}|{'supp12':supp12}|{'supp13':supp13}
    if args.render_key=='all': render_all()
    elif args.render_key in funcs: funcs[args.render_key]()
    else: raise SystemExit(f'Unknown render key: {args.render_key}')
