"""Evidence structure and rank redistribution at the final manuscript width."""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.patches import Patch
from matplotlib.lines import Line2D


def candidate_label(name):
    names={
        'Solar Salt SS60':'Solar Salt',
        'NaNO3-KNO3-Na2CO3-NaCl':'QNCC',
        'NaNO3-KNO3-Ca(NO3)2 eutectic (16:48:36 wt%)':'Ca-nitrate',
        'KNO2-KNO3-K2CO3':'KNC',
        'MgCl2-KCl-NaCl eutectic':'MgCl$_2$ mix',
        'S1 Na2CO3-Li2CO3-LiF':'C–LiF',
        'Na2CO3-Li2CO3':'Binary carbonate',
        'NaCl-KCl-CaCl2':'Cl-reference',
        'NaCl-KCl-CaCl2 23.5-25.0-51.5 wt%':'Cl-2025',
        'none':'No candidate',
    }
    return names.get(name,name)


def figure1(P):
    B=P['B']; axis=P['axis']; finish=P['finish']; SERV=P['SERV']; SL=P['SL']
    fig=plt.figure(figsize=(6.3,6.7))
    a=axis(fig,[.085,.735,.40,.205],'a');a.axis('off')
    db=B.read('database_to_shortlist_transition')
    counts=db.loc[db.screen_order.isin([1,4,5,6]),'retained_count'].astype(int).tolist()
    a.text(0,1.03,'Reference-database screen',weight='bold',fontsize=8,color=B.NAVY)
    for i,(v,lab) in enumerate(zip(counts,['Records','$T_m$\nreported','Phase-rule\ncompatible','Minimum\ncoverage'])):
        x=.10+i*.257
        a.text(x,.77,str(v),ha='center',fontsize=11,weight='bold',color=B.NAVY)
        a.text(x,.60,lab,ha='center',va='top',fontsize=7.1)
        if i<3:a.annotate('',xy=(x+.18,.79),xytext=(x+.085,.79),arrowprops={'arrowstyle':'->','lw':.7,'color':B.MID_GREY})
    a.text(0,.28,'Application library',weight='bold',fontsize=8,color=B.TERRACOTTA)
    for x,n,lab in [(.1,779,'Records'),(.49,83,'Formula systems'),(.90,142,'Exact compositions')]:
        a.text(x,.065,str(n),ha='center',fontsize=11,weight='bold',color=B.TERRACOTTA)
        a.text(x,-.035,lab,ha='center',va='top',fontsize=7.1)

    b=axis(fig,[.67,.735,.20,.195],'b')
    flow=B.read('literature_evidence_flow')
    flow=flow.groupby(['evidence_stream','candidate_family'],as_index=False).unique_source_candidate_link.sum()
    sm={'Reference databases':'Database','System benchmarks':'Benchmark','Thermophysical literature':'Thermophys.','Corrosion literature':'Corrosion','Contextual literature':'Context','Other literature':'Other'}
    fm={'Nitrate/nitrite':'Nitrate','Chloride':'Chloride','Carbonate/fluoride':'Carbonate/F'}
    flow.evidence_stream=flow.evidence_stream.map(sm);flow.candidate_family=flow.candidate_family.map(fm)
    sc={'Database':B.NAVY,'Benchmark':B.BLUE,'Thermophys.':B.MUSTARD,'Corrosion':B.BURGUNDY,'Context':B.CREAM,'Other':B.NEUTRAL}
    fc={'Nitrate':B.MUSTARD,'Chloride':B.TERRACOTTA,'Carbonate/F':B.ROSE}
    B.L.weighted_alluvial(b,flow,['evidence_stream','candidate_family'],'unique_source_candidate_link','evidence_stream',sc,node_color_map={**sc,**fc},stage_labels=['',''],outer_labels=True,label_min_fraction=.01,node_width=.09,gap=.012,node_top=.96,node_bottom=.03,stage_label_y=1.05)
    for txt in b.texts:txt.set_fontsize(7.1)
    b.text(.5,1.10,f'{int(flow.unique_source_candidate_link.sum())} source–candidate links',ha='center',weight='bold',fontsize=8,transform=b.transAxes)
    b.text(.5,-.08,'15-composition engineering registry',ha='center',fontsize=7.1,transform=b.transAxes)

    raw=B.read('exact_composition_candidate_summary','expanded_v3')
    fields=['melting_temperature_C','stability_temperature_C','cp_J_gK','density_kg_m3']
    patterns=raw[fields].notna().value_counts().rename('count').reset_index()
    assert int(patterns['count'].sum())==142
    c=axis(fig,[.115,.365,.17,.265],'c');counts_ax=axis(fig,[.305,.365,.18,.265])
    c.set_title('Joint property availability',loc='left',pad=22,fontsize=8,weight='bold')
    for i,row in patterns.iterrows():
        present=row[fields].to_numpy(bool); col=B.BURGUNDY if present.all() else B.OLIVE
        idx=np.flatnonzero(present)
        if len(idx)>1:c.plot([idx.min(),idx.max()],[i,i],color=col,lw=.7,zorder=1)
        for j,has in enumerate(present):c.scatter(j,i,s=24,fc=col if has else 'white',ec=col if has else B.MID_GREY,lw=.65,zorder=3)
        counts_ax.barh(i,row['count'],height=.57,color=col)
        counts_ax.text(row['count']+2,i,str(row['count']),va='center',fontsize=7.3)
    for ax in [c,counts_ax]:ax.set_ylim(len(patterns)-.5,-.7);ax.set_yticks([])
    c.set_xlim(-.5,3.5);c.set_xticks(range(4),['$T_m$','Upper','$c_p$',r'$\rho$']);c.xaxis.tick_top();c.tick_params(axis='x',length=0,pad=4)
    for sp in c.spines.values():sp.set_visible(False)
    counts_ax.set_xlim(0,77);counts_ax.set_xticks([0,20,40,60]);counts_ax.set_xlabel('Compositions')
    c.text(.0,-.17,'● Reported   ○ Not reported',transform=c.transAxes,fontsize=7.1)
    patterns.to_csv(B.QA/'ees_fig1_joint_property_patterns.csv',index=False)

    d=axis(fig,[.67,.365,.28,.265],'d')
    duty=pd.read_csv(B.ROOT/'config/core_service_thermal_boundary_registry.csv').set_index('service_id').loc[SERV]
    for i,(ss,row) in enumerate(duty.iterrows()):
        sensible=row.service_mode=='sensible'
        lo,hi=(row.fixed_Tcold_C,row.fixed_Thot_C) if sensible else (row.phase_target_min_C,row.phase_target_max_C)
        col=B.NAVY if sensible else B.MUSTARD
        d.plot([lo,hi],[i,i],lw=3.5,color=col,solid_capstyle='butt')
        d.scatter([lo,hi],[i,i],marker='|' if sensible else 's',s=18,color=col,zorder=3)
        value=f'{lo:.0f}–{hi:.0f}' if sensible else f'{(lo+hi)/2:.0f} ± 15'
        d.annotate(value,((lo+hi)/2,i),xytext=(0,6),textcoords='offset points',ha='center',fontsize=7.1)
    d.set_yticks(range(7),[SL[s] for s in SERV]);d.set_ylim(6.7,-.8);d.set_xlim(220,745);d.set_xticks([250,400,550,700]);d.set_xlabel('Temperature (°C)')
    d.set_title('Prescribed thermal duties',loc='left',pad=9,fontsize=8,weight='bold')

    e=axis(fig,[.115,.085,.835,.155],'e')
    attr=B.read('evidence_attrition','expanded_v3').set_index('stage')['count']
    stages=['Candidate-service pairs across seven frozen duties','Physical-window-compatible pairs','Quantitative thermophysical pairs','Service-domain-supported thermophysical pairs','Service-domain-supported pairs linked to frozen engineering registry']
    values=attr.loc[stages].to_numpy(int);rates=values[1:]/values[:-1]
    colors=[B.NAVY,B.MUSTARD,B.OLIVE,B.BURGUNDY]
    e.bar(range(4),rates,color=colors,width=.58)
    for i,(v,n,den,col) in enumerate(zip(rates,values[1:],values[:-1],colors)):
        e.text(i,v+.055,f'{n}/{den} · {v:.1%}',ha='center',fontsize=7.3,color=col,weight='bold')
    e.set_xticks(range(4),['Physical window','Quantitative','Complete duty','Registry link']);e.set_ylim(0,1);e.set_yticks([0,.5,1]);P['pct'](e,'y');e.set_ylabel('Conditional retention')
    e.text(0,1.18,'142 compositions × 7 duties = 994 pairs',transform=e.transAxes,weight='bold',fontsize=8)
    finish(fig,1,'Composition evidence and prescribed duties define the assessment',
           ['database_to_shortlist_transition','literature_evidence_flow','expanded_v3_evidence_attrition','expanded_v3_exact_composition_candidate_summary','core_service_thermal_boundary_registry'])


def figure2(P):
    B=P['B'];axis=P['axis'];finish=P['finish'];SERV=P['SERV'];SL=P['SL'];T=B.TABLES
    story=B.read('cross_layer_storyline','expanded_v3').set_index('service_id').loc[SERV]
    dom=B.read('domain_validated_thermophysical_mc','expanded_v3')
    scalar=B.read('thermophysical_opportunity_mc','expanded_v3')
    fig=plt.figure(figsize=(6.3,6.7))
    a=axis(fig,[.135,.745,.35,.19],'a')
    cols=['physical_window_pairs','quantitative_pairs','service_domain_supported_pairs']
    vals=story[cols].to_numpy(int)
    a.imshow(vals,aspect='auto',cmap=LinearSegmentedColormap.from_list('counts',['#f6f4ea',B.NAVY]),vmin=0,vmax=28)
    for i,row in enumerate(vals):
        for j,v in enumerate(row):a.text(j,i,str(v),ha='center',va='center',fontsize=8,color='white' if v>15 else B.INK)
    a.set_xticks(range(3),['Physical','Quantitative','Full duty']);a.set_yticks(range(7),[SL[s] for s in SERV]);a.tick_params(length=0);a.set_title('Candidate–duty pairs',loc='left',fontsize=8,pad=9,weight='bold')

    b=axis(fig,[.65,.745,.30,.19],'b')
    ext=pd.read_csv(T/'joule_external_scalar_performance.csv').sort_values('candidate_id')
    offsets={1:(0,12),2:(-5,-14),3:(-11,2),4:(-7,8),5:(2,-12),6:(0,-14),7:(8,-4),8:(4,9),9:(8,0)}
    for r in ext.itertuples():
        n=int(r.display_name.split()[-1]);x=r.volumetric_heat_capacity_relative_to_solar_salt;y=r.viscosity_relative_to_solar_salt
        b.scatter(x,y,s=28,color=B.BURGUNDY if n==7 else B.NAVY,zorder=3)
        b.annotate(str(n),(x,y),xytext=offsets[n],textcoords='offset points',fontsize=7.3,ha='center',va='center',
                   arrowprops={'arrowstyle':'-','lw':.45,'color':B.MID_GREY,'shrinkA':1.5,'shrinkB':3.5})
    b.scatter([1],[1],s=30,marker='s',color=B.MUSTARD);b.text(1.08,.85,'Solar Salt',va='center',fontsize=7.3)
    b.axvline(1,color=B.MID_GREY,ls=':',lw=.7);b.axhline(1,color=B.MID_GREY,ls=':',lw=.7)
    b.set(xlim=(.8,3.1),ylim=(.2,8.0),xlabel='Volumetric heat-capacity ratio',ylabel='Viscosity ratio');b.set_xticks([1,2,3]);b.set_yticks([1,3,5,7])
    b.set_title('External formulations at 300 °C',loc='left',fontsize=8,pad=9,weight='bold')

    c=axis(fig,[.26,.375,.225,.255],'c')
    q=dom[dom.display_system.ne('none')].copy()
    q['order']=q.service_id.map({s:i for i,s in enumerate(SERV)})
    q=q.sort_values(['order','thermophysical_rank1_frequency'],ascending=[True,False])
    for i,r in enumerate(q.itertuples()):
        v=r.thermophysical_rank1_frequency;col=B.BURGUNDY if '23.5-25.0' in r.display_system else B.SCOL[r.service_id]
        c.hlines(i,0,v,color=B.PALE_BLUE,lw=1.2);c.scatter(v,i,s=23,color=col,zorder=3)
        c.text(1.65,i,P['percentage'](v),fontsize=7.1,va='center',ha='right',color=col)
    c.set_yticks(range(len(q)),[f'{SL[s]} · {candidate_label(n)}' for s,n in zip(q.service_id,q.display_system)],fontsize=7.1)
    c.set_ylim(len(q)-.4,-.7);c.set_xlim(-.02,1.70);c.set_xticks([0,.5,1]);P['pct'](c);c.set_xlabel('Rank-one frequency')
    c.text(-.61,1.11,'All 11 complete-duty-supported pairs',transform=c.transAxes,fontsize=8,weight='bold')

    d=axis(fig,[.65,.375,.30,.255],'d')
    sel=B.read('layered_selection_frequencies');ns=B.read('no_selection_frequencies')
    sel=sel[(sel.ranking_layer=='evidence_qualified')&(sel.weight_prior=='balanced')]
    piv=sel.pivot(index='scenario',columns='system_id',values='selection_frequency').reindex(SERV).fillna(0)
    ns=ns[(ns.ranking_layer=='evidence_qualified')&(ns.weight_prior=='balanced')].set_index('scenario').loc[SERV]
    left=np.zeros(7)
    for values,col in [(piv.solar_salt_ss60.to_numpy(),B.NAVY),(piv.hitec.to_numpy(),B.BLUE),(ns.no_selection_frequency.to_numpy(),B.BURGUNDY)]:
        d.barh(range(7),values,left=left,color=col,height=.65)
        for i,v in enumerate(values):
            if v>.15:d.text(left[i]+v/2,i,f'{v:.0%}',ha='center',va='center',color='white',fontsize=7.3)
        left+=values
    d.set_yticks(range(7),[SL[s] for s in SERV]);d.set_ylim(6.7,-.7);d.set_xlim(0,1);d.set_xticks([0,.5,1]);P['pct'](d);d.set_xlabel('Formal selection frequency')
    d.legend([Patch(fc=c) for c in [B.NAVY,B.BLUE,B.BURGUNDY]],['Solar Salt','HITEC','No selection'],frameon=False,loc='lower center',bbox_to_anchor=(.44,1.035),ncol=3,fontsize=7.0,handlelength=.9,handletextpad=.4,columnspacing=.55)

    delta=scalar.merge(dom,on=['service_id','candidate_key','display_system'],how='outer',suffixes=('_scalar','_domain'),validate='one_to_one')
    delta['delta_pp']=100*(delta.thermophysical_rank1_frequency_domain.fillna(0)-delta.thermophysical_rank1_frequency_scalar.fillna(0))
    chosen=delta.loc[delta.delta_pp.abs().ge(1),'display_system'].unique()
    names=sorted(chosen,key=lambda name: -delta.loc[delta.display_system==name,'delta_pp'].abs().max())
    matrix=delta[delta.display_system.isin(names)].pivot(index='display_system',columns='service_id',values='delta_pp').reindex(index=names,columns=SERV[:4])
    e=axis(fig,[.26,.065,.69,.185],'e')
    cmap=LinearSegmentedColormap.from_list('rank_shift',[B.BURGUNDY,'#fafafa',B.NAVY]);cmap.set_bad('#eaecef')
    e.imshow(matrix,aspect='auto',cmap=cmap,norm=TwoSlopeNorm(vmin=-85,vcenter=0,vmax=85))
    for i,row in enumerate(matrix.to_numpy()):
        for j,v in enumerate(row):
            txt='—' if np.isnan(v) else ('0' if abs(v)<.005 else f'{v:+.1f}')
            e.text(j,i,txt,ha='center',va='center',fontsize=7.3,color='white' if abs(v)>48 else B.INK)
    e.set_yticks(range(len(names)),[candidate_label(n) for n in names],fontsize=7.3);e.set_xticks(range(4),[SL[s] for s in SERV[:4]]);e.tick_params(length=0)
    e.text(0,1.15,'Full-duty minus scalar rank-one frequency (percentage points)',transform=e.transAxes,fontsize=8,weight='bold')
    delta.to_csv(B.QA/'ees_fig2_rank_redistribution.csv',index=False)
    finish(fig,2,'Duty-resolved opportunity and engineering qualification produce different choices',
           ['expanded_v3_cross_layer_storyline','joule_external_scalar_performance','joule_external_validation_summary','expanded_v3_domain_validated_thermophysical_mc','expanded_v3_thermophysical_opportunity_mc','layered_selection_frequencies','no_selection_frequencies'])
