"""Independent drop-calorimetry check, with explicit dependent diagnostics."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fitz

ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'outputs/tables';S=ROOT/'outputs/supplementary_figures'
NAVY='#243746';TEAL='#397B78';GOLD='#B78028'

def main():
    curve=pd.read_csv(T/'external_enthalpy_curve.csv')
    intervals=pd.read_csv(T/'external_enthalpy_intervals.csv')
    primary=intervals[intervals.complete_primary_interval].iloc[0]
    anchored=intervals[intervals.low_C.eq(250)].sort_values('high_C')
    assert len(curve)==9 and len(intervals)==36 and len(anchored)==8
    plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.labelsize':8,
        'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
        'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,
        'mathtext.fontset':'stixsans'})
    fig=plt.figure(figsize=(6.5,6.2))
    boxes=[[.12,.61,.34,.29],[.62,.61,.34,.29],[.12,.13,.34,.29],[.62,.13,.34,.29]]
    axes=[fig.add_axes(b) for b in boxes]
    for letter,ax in zip('abcd',axes):
        p=ax.get_position();fig.text(p.x0-.065,p.y1+.035,letter,fontsize=11,weight='bold')
        ax.grid(axis='y',color='#E5E5E5',lw=.5,zorder=0)
    a=axes[0]
    a.plot(curve.temperature_C,curve.model_increment_kJ_kg,color=NAVY,lw=1.4,label='Fixed model')
    a.scatter(curve.temperature_C,curve.observed_increment_kJ_kg,color=TEAL,s=23,zorder=3,label='Calorimetry')
    a.set(xlabel='Temperature (°C)',ylabel=r'Enthalpy from 250 °C (kJ kg$^{-1}$)',xlim=(242,408),ylim=(-8,260),xticks=[250,300,350,400])
    a.legend(frameon=False,loc='upper left')
    b=axes[1]
    err=anchored.common_scale_sensitivity_kJ_kg+anchored.endpoint_repeatability_envelope_kJ_kg
    b.errorbar(anchored.model_minus_observed_kJ_kg,anchored.high_C,xerr=err,fmt='o',ms=3.3,
        color=TEAL,ecolor='#849D9C',elinewidth=1,capsize=3,zorder=3)
    b.axvline(0,color=NAVY,lw=.8,ls='--')
    b.set(xlabel=r'Model − measured (kJ kg$^{-1}$)',ylabel='Upper temperature (°C)',ylim=(250,410),xlim=(-17,23),yticks=[260,300,350,400],xticks=[-10,0,10,20])
    b.text(.02,1.045,'Sensitivity scenario; common 250 °C anchor',transform=b.transAxes,fontsize=6.7)
    c=axes[2]
    c.scatter(intervals.delta_T_K,intervals.relative_error_percent,s=25,facecolors='none',edgecolors=TEAL,lw=.8,zorder=3,label='All 36 intervals')
    c.scatter(primary.delta_T_K,primary.relative_error_percent,marker='D',s=35,color=GOLD,zorder=4,label='250–400 °C')
    c.axhline(0,color=NAVY,lw=.8,ls='--')
    c.set(xlabel='Temperature span (K)',ylabel='Enthalpy error (%)',xlim=(0,163),ylim=(-13,35),xticks=[0,50,100,150])
    c.legend(frameon=False,loc='upper right',handletextpad=.5)
    d=axes[3]
    values=[primary.reference_mass_for_1kWh_kg,primary.model_mass_for_1kWh_kg]
    d.bar([0,1],values,width=.48,color=[TEAL,NAVY],zorder=2)
    for i,v in enumerate(values):d.text(i,v+.32,f'{v:.2f}',ha='center',va='bottom',fontsize=8)
    d.set(xticks=[0,1],xticklabels=['Calorimetry','Fixed model'],ylabel='Material mass for 1 kWh (kg)',ylim=(0,20.5),xlim=(-.65,1.65))
    d.text(.5,1.045,'250–400 °C; model mass bias −3.72%',transform=d.transAxes,ha='center',fontsize=7)
    path=S/'submission_Supp_Fig17.pdf'
    fig.savefig(path,metadata={'CreationDate':None,'ModDate':None});plt.close(fig)
    with fitz.open(path) as doc:
        assert len(doc)==1 and '\ufffd' not in doc[0].get_text()
        doc[0].get_pixmap(dpi=600,alpha=False).save(path.with_suffix('.png'))
        bounds=doc[0].rect
        outside=[b[:4] for b in doc[0].get_text('blocks') if not bounds.contains(fitz.Rect(b[:4]))]
        assert not outside,outside
    mapping_path=ROOT/'outputs/qa/figure_source_map.csv'
    mapping=pd.read_csv(mapping_path);mapping=mapping[mapping.figure.ne('Supp_Fig17')]
    mapping=pd.concat([mapping,pd.DataFrame([dict(figure='Supp_Fig17',title='Independent Solar Salt enthalpy check',
        width_px=3900,height_px=3720,aspect_ratio=6.5/6.2,
        source_tables='external_enthalpy_curve;external_enthalpy_intervals')])],ignore_index=True)
    assert mapping.figure.nunique()==23
    mapping.to_csv(mapping_path,index=False,encoding='utf-8-sig')
    status=dict(status='PASS',figure=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),dpi=600,
        n_sources=1,n_compositions=1,n_temperatures=9,n_dependent_intervals=36,
        text_inside_page=True,visual_review='required_after_rendering',
        source_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [T/'external_enthalpy_curve.csv',T/'external_enthalpy_intervals.csv']})
    (ROOT/'outputs/qc/EXTERNAL_FIGURE_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    final_path=ROOT/'outputs/qc/POSTPROCESS_RELEASE_STATUS.json'
    final=json.loads(final_path.read_text());assert final['status']=='PASS'
    final.update(main_figures=6,supplementary_figures=17,final_renderer='src/render_external_enthalpy.py',
        presentation_status='RENDERED_PENDING_VISUAL_REVIEW')
    final['checks'].append(dict(check='final_six_main_seventeen_supplementary_600dpi',passed=True))
    final_path.write_text(json.dumps(final,indent=2),encoding='utf-8')
    # Final captions and panel descriptions supersede intermediate-renderer notes.
    docs=ROOT/'docs'
    captions=(docs/'FINAL_FIGURE_CAPTIONS.md').read_text(encoding='utf-8')
    story=(docs/'FINAL_STORYLINE.md').read_text(encoding='utf-8')
    (docs/'MAIN_FIGURE_CAPTIONS.md').write_text(captions,encoding='utf-8')
    (docs/'STORYLINE.md').write_text(story,encoding='utf-8')
    (docs/'FIGURE_STORY_AND_CAPTIONS_V10.md').write_text(story+'\n'+captions,encoding='utf-8')
    (docs/'FIGURE_AND_PANEL_CHECKLIST.md').write_text(story+'\n'+captions,encoding='utf-8')
    print(json.dumps(status,indent=2))

if __name__=='__main__':main()
