"""Figure S16: measured compatibility and evidence-index sensitivity."""
from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import fitz

ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'outputs/tables';S=ROOT/'outputs/supplementary_figures'
NAVY='#243746';GOLD='#BB8B35';RED='#8B374A';TEAL='#4B766D'

def main():
    d=pd.read_csv(T/'engineering_corrosion_endpoints.csv')
    r=pd.read_csv(T/'engineering_score_sensitivity.csv')
    plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.labelsize':8,
                         'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7,
                         'axes.spines.top':False,'axes.spines.right':False,
                         'pdf.fonttype':42,'mathtext.fontset':'stixsans'})
    fig=plt.figure(figsize=(6.3,6.3))
    boxes=[[.12,.64,.34,.25],[.63,.64,.33,.25],[.12,.12,.34,.30],[.63,.12,.33,.30]]
    axes=[fig.add_axes(b) for b in boxes]
    for letter,ax in zip('abcd',axes):
        pos=ax.get_position();fig.text(pos.x0-.055,pos.y1+.04,letter,weight='bold',fontsize=10)
        ax.grid(axis='y',color='#dddddd',lw=.45,zorder=0)
    ax=axes[0]
    group=d[d.system_id.eq('knc')]
    for temp,color,marker,offset in [(500,TEAL,'o',-.08),(700,RED,'s',.08)]:
        sub=group[group.temperature_C.eq(temp)].set_index('alloy').loc[['304','316L','310S','347H']]
        ax.scatter(np.arange(4)+offset,sub.rate_or_upper_bound_um_per_year,c=color,marker=marker,s=25,label=f'{temp} °C',zorder=3)
    ax.axhline(15,color=GOLD,ls='--',lw=1)
    ax.text(.98,15,'15',transform=ax.get_yaxis_transform(),ha='right',va='bottom',color=GOLD,fontsize=7)
    ax.set(yscale='log',ylim=(7,1100),xticks=range(4),xticklabels=['304','316L','310S','347H'],ylabel=r'Mass-loss rate ($\mu$m yr$^{-1}$)',xlabel='Alloy')
    ax.legend(loc='upper center',bbox_to_anchor=(.5,1.18),ncol=2,frameon=False)
    ax=axes[1]
    group=d[d.study_id.eq('DING_2018')]
    alloys=['SS310','In800H','HaC276']
    for i,alloy in enumerate(alloys):
        pair=group[group.alloy.eq(alloy)].set_index('endpoint')
        values=pair.loc[['mass_loss_rate','penetration_depth_rate'],'rate_or_upper_bound_um_per_year'].to_numpy()
        ax.plot([i-.10,i+.10],values,color='#999999',lw=.9,zorder=2)
        ax.scatter(i-.10,values[0],color=NAVY,s=24,zorder=3)
        ax.scatter(i+.10,values[1],color=GOLD,marker='D',s=23,zorder=3)
    ax.set(yscale='log',ylim=(40,2700),xticks=range(3),xticklabels=['SS310','In800H','C-276'],ylabel=r'Annualized rate ($\mu$m yr$^{-1}$)',xlabel='Alloy')
    from matplotlib.lines import Line2D
    ax.legend([Line2D([],[],color=NAVY,marker='o',ls=''),Line2D([],[],color=GOLD,marker='D',ls='')],['Mass loss','Penetration'],loc='upper center',bbox_to_anchor=(.5,1.18),ncol=2,frameon=False,columnspacing=.7)
    ax=axes[2]
    vals=d.set_index('observation_id').loc[['W21_BASE300','W21_EG300','W21_BASE500'],'rate_or_upper_bound_um_per_year'].tolist()
    ax.bar(range(3),vals,color=[NAVY,TEAL,NAVY],width=.55,zorder=2)
    for i,v in enumerate(vals):ax.text(i,v+.5,f'{v:g}',ha='center',fontsize=7.5)
    ax.set(ylim=(0,20),xticks=range(3),xticklabels=['Base\n300 °C','10% EG\n300 °C','Base\n500 °C'],ylabel=r'Reported rate ($\mu$m yr$^{-1}$)')
    ax.text(.5,1.06,'Same nitrate composition, 316, 1,440 h',ha='center',transform=ax.transAxes,fontsize=7.1)
    ax=axes[3]
    modes=['hierarchical_geometric','hierarchical_arithmetic','bottleneck_minimum','no_literature_replication','no_data_completeness']
    labels=['Geometric','Arithmetic','Minimum','Without replication','Without completeness']
    colors=[NAVY,TEAL,GOLD,RED,'#847499']
    group=r[r.scenario.eq('industrial_medium_heat')&r.system_id.eq('solar_salt_ss60')]
    for mode,label,color in zip(modes,labels,colors):
        sub=group[group.aggregation.eq(mode)].sort_values('credibility_weight')
        ax.plot(sub.credibility_weight,100*sub.selection_frequency,color=color,label=label,marker='o',ms=2.8,lw=1)
    ax.set(xlim=(-.03,1.03),ylim=(32,62),xticks=[0,.5,1],xlabel='Evidence-index weight',ylabel='Solar Salt selection frequency (%)')
    ax.legend(loc='lower center',bbox_to_anchor=(.5,1.02),ncol=2,frameon=False,fontsize=6.4,labelspacing=.3,columnspacing=.6,handlelength=1)
    fig.savefig(S/'submission_Supp_Fig16.pdf',metadata={'CreationDate':None,'ModDate':None})
    plt.close(fig)
    # Rasterize the final vector figures at their physical size for Word embedding.
    figures=sorted((ROOT/'outputs/main_figures').glob('submission_Fig*.pdf'))+sorted(S.glob('submission_Supp_Fig*.pdf'))
    records=[]
    for path in figures:
        with fitz.open(path) as doc:
            if len(doc)!=1:raise ValueError(f'Expected one figure page: {path}')
            doc[0].get_pixmap(dpi=600,alpha=False).save(path.with_suffix('.png'))
            texts=doc[0].get_text()
            if '\ufffd' in texts:raise ValueError(f'Invalid extracted glyph: {path}')
        records.append(dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),dpi=600))
    status=dict(status='PASS',main_figures=6,supplementary_figures=16,
                engineering_validation='engineering_evidence_validation.json',figures=records,
                visual_review='required_after_rendering')
    (ROOT/'outputs/qc/ENGINEERING_FIGURE_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    final_path=ROOT/'outputs/qc/POSTPROCESS_RELEASE_STATUS.json'
    final=json.loads(final_path.read_text(encoding='utf-8'))
    if final['status']!='PASS' or len(figures)!=22:
        raise ValueError('Earlier release checks or final figure inventory failed')
    final.update(main_figures=6,supplementary_figures=16,
                 final_renderer='src/render_engineering_evidence.py',
                 engineering_figure_status='PASS',presentation_status='RENDERED_PENDING_VISUAL_REVIEW')
    final['checks'].append(dict(check='final_six_main_sixteen_supplementary_600dpi',passed=True))
    final_path.write_text(json.dumps(final,indent=2),encoding='utf-8')
    source_map=ROOT/'outputs/qa/figure_source_map.csv'
    mapping=pd.read_csv(source_map)
    mapping=mapping[mapping.figure.ne('Supp_Fig16')]
    mapping=pd.concat([mapping,pd.DataFrame([dict(figure='Supp_Fig16',
        title='Condition-resolved corrosion and engineering-index sensitivity',
        width_px=3780,height_px=3780,aspect_ratio=1.0,
        source_tables='engineering_corrosion_endpoints;engineering_matched_comparisons;engineering_score_sensitivity')])],ignore_index=True)
    from PIL import Image
    for i,row in mapping.iterrows():
        folder=S if row.figure.startswith('Supp') else ROOT/'outputs/main_figures'
        with Image.open(folder/f'submission_{row.figure}.png') as im:
            mapping.loc[i,['width_px','height_px','aspect_ratio']]=[im.width,im.height,im.width/im.height]
    if mapping.figure.nunique()!=22:raise ValueError('Incomplete figure-source map')
    mapping.to_csv(source_map,index=False,encoding='utf-8-sig')
    print(json.dumps({'status':'PASS','figure_files':len(figures),'dpi':600}))

if __name__=='__main__':main()
