"""Presentation-only vocabulary shared by the scientific figure exporters."""
from matplotlib.text import Text

REPLACEMENTS={
    '(legacy)':'(reference)',
    'Registered evidence score':'Engineering-evidence score',
    'registered evidence floor':'evidence threshold',
    'Area: registered applications':'Area: evaluated duties',
    'Frozen registry\nlink':'Engineering\nregistry link',
    '7 frozen services':'7 prescribed duties',
    'under registered priors':'under specified priors',
    'Outside the frozen 15-candidate':'Outside the 15-candidate',
    'Outside frozen\nengineering registry':'Outside the\nengineering registry',
    'Strict-layer transition share':'Qualification transition share',
    'registered property domains':'reported property domains',
    'Targeted registered programme':'Targeted evidence programme',
    'not reachable under registered actions':'No route within tested actions',
    'Largest registered benefit (diagnostic)':'Largest selection gain (scenario)',
    'Largest registered benefit':'Largest selection gain',
    'Registered programme':'Evidence programme',
    'registered benefit = 0':'selection gain = 0',
    'Expected strict-complete candidates':'Expected full-duty-supported candidates',
    'Strict-complete probability':'Full-duty support probability',
    'registered threshold':'specified threshold',
    'IIA retained-winner audit':'IIA retained-winner consistency',
    'programme':'program',
    'Programme':'Program',
}

def clean_public_labels(figure):
    def clean_text(text):
        for old,new in REPLACEMENTS.items(): text=text.replace(old,new)
        return text
    for artist in figure.findobj(match=Text):
        text=clean_text(artist.get_text())
        if text!=artist.get_text(): artist.set_text(text)
    # Explicit categorical tick formatters can recreate labels during export.
    # Bind their cleaned strings to the same locations; numeric axes are untouched.
    for axes in figure.axes:
        for axis in (axes.xaxis,axes.yaxis):
            labels=[item.get_text() for item in axis.get_majorticklabels()]
            cleaned=[clean_text(label) for label in labels]
            if cleaned!=labels:
                axis.set_ticks(axis.get_majorticklocs(),labels=cleaned)
