from __future__ import annotations
from pathlib import Path
import json
import sys

from release_paths import (
    ENVIRONMENT_STATUS,
    POSTPROCESS_ENVIRONMENT_STATUS,
    UPSTREAM_RELEASE_STATUS,
    UPSTREAM_RELEASE_STATUS_COMPAT,
    POSTPROCESS_RELEASE_STATUS,
    POSTPROCESS_RELEASE_CONTRACT_AUDIT,
    first_existing,
)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'outputs'
QC = OUT / 'qc'
UQC = OUT / 'upstream_qc'


def load(path: Path) -> dict:
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding='utf-8'))

checks: list[dict] = []
required_local = [
    ENVIRONMENT_STATUS,
    POSTPROCESS_ENVIRONMENT_STATUS,
    'submission_UPSTREAM_CONTRACT_STATUS.json',
    'submission_POSTPROCESS_STATUS.json',
    'postprocess_validation_status.json',
]
for name in required_local:
    checks.append({'check': f'local_qc_file:{name}', 'passed': (QC / name).exists()})

upstream_path = first_existing(UQC, UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT)
checks.append({'check': 'synced_canonical_upstream_release_status_present', 'passed': upstream_path is not None})
upstream = load(upstream_path) if upstream_path else {}
checks.append({'check': 'synced_upstream_release_status_pass', 'passed': upstream.get('status') == 'PASS'})
checks.append({'check': 'synced_upstream_scientific_extension_declared', 'passed': upstream.get('science_changed') is True and upstream.get('scientific_extension_added') is True})
checks.append({'check': 'synced_upstream_fixed_mass_reference_declared', 'passed': upstream.get('core_scientific_baseline_changed') is True})
checks.append({'check': 'synced_release_id_current', 'passed': upstream.get('release_id') == 'TES-EES-V2.2.0-20260909'})
checks.append({'check': 'synced_upstream_declares_20000_draws', 'passed': upstream.get('mc_iterations') == 20000})
external = load(UQC / 'JOULE_EXTERNAL_VALIDATION_STATUS.json')
claims = load(UQC / 'JOULE_CLAIM_SYNTHESIS_STATUS.json')
checks.append({'check': 'external_rule_transfer_validation_pass', 'passed': external.get('status') == 'PASS'})
checks.append({'check': 'claim_registry_validation_pass', 'passed': claims.get('status') == 'PASS'})

canonical = UQC / UPSTREAM_RELEASE_STATUS
compat = UQC / UPSTREAM_RELEASE_STATUS_COMPAT
alias_ok = True
if canonical.exists() and compat.exists():
    alias_ok = load(canonical) == load(compat)
checks.append({'check': 'synced_upstream_status_alias_consistent', 'passed': alias_ok})
checks.append({
    'check': 'postprocess_environment_alias_consistent',
    'passed': load(QC / ENVIRONMENT_STATUS) == load(QC / POSTPROCESS_ENVIRONMENT_STATUS),
})

post = load(QC / 'submission_POSTPROCESS_STATUS.json')
validation = load(QC / 'postprocess_validation_status.json')
contract = load(QC / 'submission_UPSTREAM_CONTRACT_STATUS.json')
checks.append({'check': 'upstream_contract_pass', 'passed': contract.get('status') == 'PASS'})
checks.append({'check': 'renderer_status_pass', 'passed': post.get('status') == 'PASS'})
checks.append({'check': 'postprocess_validation_pass', 'passed': validation.get('status') == 'PASS'})
checks.append({'check': 'six_main_thirteen_supplementary', 'passed': validation.get('main_figures') == 6 and validation.get('supplementary_figures') == 13})

passed = all(row['passed'] for row in checks)
release = {
    'status': 'PASS' if passed else 'FAIL',
    'science_changed': True,
    'core_scientific_baseline_changed': True,
    'scientific_extension_added': True,
    'release_id': 'TES-EES-V2.2.0-20260909',
    'expanded_library_scope_semantics_corrected': True,
    'upstream_mc_iterations': upstream.get('mc_iterations'),
    'main_figures': validation.get('main_figures'),
    'supplementary_figures': validation.get('supplementary_figures'),
    'canonical_status_filename': POSTPROCESS_RELEASE_STATUS,
    'upstream_status_file_used': upstream_path.name if upstream_path else 'MISSING',
    'checks': checks,
    'policy': 'Canonical version-free status filenames are used across upstream generation, synchronization, rendering and release validation. The expanded thermophysical opportunity layer is kept separate from the frozen 15-candidate formal engineering registry.',
}
payload = json.dumps(release, indent=2)
(QC / POSTPROCESS_RELEASE_STATUS).write_text(payload, encoding='utf-8')
(QC / POSTPROCESS_RELEASE_CONTRACT_AUDIT).write_text(payload, encoding='utf-8')
print(payload)
if not passed:
    sys.exit(2)
