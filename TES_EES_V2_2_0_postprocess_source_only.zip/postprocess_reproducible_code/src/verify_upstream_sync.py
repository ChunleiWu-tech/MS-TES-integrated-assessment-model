from __future__ import annotations
from pathlib import Path
import csv
import json
import sys

from release_paths import UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT, first_existing

if len(sys.argv) != 2:
    raise SystemExit('Usage: verify_upstream_sync.py UPSTREAM_ROOT')
root = Path(sys.argv[1]).resolve()
table = root / 'outputs' / 'tables' / 'core_system_value_monte_carlo_summary.csv'
registry = root / 'data' / 'input' / 'core_candidate_property_registry.csv'
registry_summary = root / 'outputs' / 'tables' / 'core_curated_candidate_registry_summary.csv'
qc = root / 'outputs' / 'qc'
status_path = first_existing(qc, UPSTREAM_RELEASE_STATUS, UPSTREAM_RELEASE_STATUS_COMPAT)
if not table.exists():
    raise SystemExit(f'Missing upstream Monte Carlo summary: {table}')
if not registry.exists() or not registry_summary.exists():
    raise SystemExit('Missing upstream candidate registry or curated registry summary.')
if status_path is None:
    raise SystemExit(
        f'Missing final upstream release status. Expected {qc / UPSTREAM_RELEASE_STATUS} '
        f'or compatibility alias {qc / UPSTREAM_RELEASE_STATUS_COMPAT}.'
    )
with table.open(newline='', encoding='utf-8') as handle:
    rows = csv.DictReader(handle)
    values = sorted({int(float(row['mc_iterations'])) for row in rows})
if values != [20000]:
    raise SystemExit(f'Upstream outputs are not the registered 20,000-draw result: {values}')
with registry.open(newline='', encoding='utf-8-sig') as handle:
    candidate_ids = {row['system_id'] for row in csv.DictReader(handle) if row.get('system_id')}
with registry_summary.open(newline='', encoding='utf-8-sig') as handle:
    summary_rows = list(csv.DictReader(handle))
summary_count = int(float(summary_rows[0]['curated_candidate_count'])) if summary_rows else -1
if len(candidate_ids) != summary_count:
    raise SystemExit(
        f'Upstream candidate registry and computed output disagree: {len(candidate_ids)} input candidates versus {summary_count} output candidates.'
    )
status = json.loads(status_path.read_text(encoding='utf-8'))
if status.get('status') != 'PASS' or status.get('science_changed') is not True or status.get('core_scientific_baseline_changed') is not True:
    raise SystemExit(f'Final upstream status is not an unchanged PASS: {status}')
if status.get('mc_iterations') != 20000:
    raise SystemExit(f'Canonical upstream status does not declare 20,000 draws: {status}')
compat = qc / UPSTREAM_RELEASE_STATUS_COMPAT
canonical = qc / UPSTREAM_RELEASE_STATUS
if canonical.exists() and compat.exists():
    if json.loads(canonical.read_text(encoding='utf-8')) != json.loads(compat.read_text(encoding='utf-8')):
        raise SystemExit('Canonical upstream release status and compatibility alias disagree.')
print(f'Verified {summary_count} candidates, registered 20,000-draw outputs and final PASS status from {status_path.name}.')
