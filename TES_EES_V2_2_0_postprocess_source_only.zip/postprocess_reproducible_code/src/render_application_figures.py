from __future__ import annotations
from pathlib import Path
import json
import shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
import fitz

ROOT=Path(__file__).resolve().parents[1]
T=ROOT/'outputs/tables'; M=ROOT/'outputs/main_figures'; S=ROOT/'outputs/supplementary_figures'
COL={'Solar Salt':'#176B83','HITEC':'#CC7139','base':'#46515A','alumina_2wt':'#269D9E','alumina_copper_foam':'#B65448'}
LABEL={'base':'Base salt','alumina_2wt':r'2 wt% Al$_2$O$_3$','alumina_copper_foam':'Alumina + Cu foam'}

def style():
    font_manager.findfont('Arial',fallback_to_default=False)
    plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'pdf.fonttype':42,'ps.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'lines.linewidth':1.3,'mathtext.fontset':'stixsans'})

def finish(fig,path):
    fig.savefig(path.with_suffix('.pdf'))
    fig.savefig(path.with_suffix('.png'),dpi=600)
    plt.close(fig)

def panel(ax,letter):
    ax.text(-.17,1.08,letter,transform=ax.transAxes,fontweight='bold',fontsize=11,va='top')
    ax.tick_params(direction='out',length=3,width=.65)

def main():
    style(); M.mkdir(parents=True,exist_ok=True); S.mkdir(parents=True,exist_ok=True)
    status=json.loads((ROOT/'outputs/upstream_qc/APPLICATION_ASSESSMENT_STATUS.json').read_text())
    if status['status']!='PASS': raise RuntimeError('Application checks are not PASS')
    # The action-program figure moves intact to the supplement, avoiding repeated main panels.
    # Only do this after the base renderer; direct reruns preserve the existing action figure.
    if not (S/'submission_Supp_Fig14.pdf').exists():
        for ext in ['pdf','png']:
            shutil.copy2(M/f'submission_Fig6.{ext}',S/f'submission_Supp_Fig14.{ext}')
    action_path=S/'submission_Supp_Fig14.pdf'
    action=fitz.open(action_path)
    if action[0].rect.height > 650:
        rect=action[0].rect; clip=fitz.Rect(0,0,rect.width,rect.height*.795)
        trimmed=fitz.open(); page=trimmed.new_page(width=clip.width,height=clip.height)
        page.show_pdf_page(page.rect,action,0,clip=clip)
        output=action_path.with_name('application_action_trim.pdf')
        trimmed.save(output); trimmed.close(); action.close(); output.replace(action_path)
    else: action.close()
    with fitz.open(action_path) as document:
        document[0].get_pixmap(dpi=600).save(S/'submission_Supp_Fig14.png')
    pair=pd.read_csv(T/'application_paired_response.csv')
    grid=pd.read_csv(T/'application_duty_frontiers.csv')
    cond=pd.read_csv(T/'application_device_conditions.csv')
    chrono=pd.read_csv(T/'application_chronological_checks.csv')
    hydro=pd.read_csv(T/'application_equal_duty_hydraulics.csv')
    fig,axes=plt.subplots(3,2,figsize=(7.09,8.3))
    fig.subplots_adjust(left=.105,right=.97,bottom=.08,top=.95,hspace=.65,wspace=.43)
    for ax,letter in zip(axes.flat,'abcdef'): panel(ax,letter)
    ax=axes[0,0]
    for chemistry in ['Solar Salt','HITEC']:
        for material,marker in [('alumina_2wt','o'),('alumina_copper_foam','D')]:
            q=pair[(pair.chemistry==chemistry)&(pair.material==material)]
            ax.scatter(q.charge_ratio,q.discharge_ratio,s=22,marker=marker,facecolors='none' if marker=='o' else COL[chemistry],edgecolors=COL[chemistry],linewidth=.8,alpha=.85,label=f'{chemistry}, '+('nano' if marker=='o' else 'foam'))
    ax.axhline(1,color='#888888',lw=.7,ls='--'); ax.axvline(1,color='#888888',lw=.7,ls='--')
    ax.set(xlabel='Charging-power ratio',ylabel='Discharging-power ratio',xlim=(.9,3.7),ylim=(.65,1.12))
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.28),frameon=False,ncol=2,columnspacing=.65,handletextpad=.3,fontsize=6.3)
    ax=axes[0,1]
    for chemistry,hot,cold in [('Solar Salt',240,50),('HITEC',180,50)]:
        q=grid[(grid.chemistry==chemistry)&(grid.hot_C==hot)&(grid.cold_C==cold)&(grid.material=='alumina_copper_foam')]
        ax.plot(q.tc_over_td,q.volume_ratio,color=COL[chemistry],label=f'{chemistry}, {hot}→{cold} °C')
        p=pair[(pair.chemistry==chemistry)&(pair.hot_C==hot)&(pair.cold_C==cold)&(pair.material=='alumina_copper_foam')].iloc[0]
        ax.scatter([p.crossover_tc_over_td],[1],s=20,color=COL[chemistry],zorder=4)
    ax.axhline(1,color='#777777',ls='--',lw=.7)
    ax.set(xscale='log',xlabel=r'Charge / delivery time, $t_c/t_d$',ylabel='Foam / base transfer volume',ylim=(.2,1.3),xlim=(.02,8))
    ax.legend(frameon=False,loc='lower right',fontsize=6.3)
    ax=axes[1,0]
    c=chrono[(chrono.hot_C==180)&(chrono.cold_C==50)&(chrono.dt_h==.25)]
    apps=['short_charge','balanced','rapid_delivery']; x=np.arange(3)
    for j,material in enumerate(['base','alumina_2wt','alumina_copper_foam']):
        vals=[]
        for app in apps:
            p=c[c.archetype==app]; vals.append(float(p[p.material==material].lp_volume.iloc[0]/p[p.material=='base'].lp_volume.iloc[0]))
        ax.bar(x+(j-1)*.24,vals,.22,color=COL[material],label=LABEL[material])
    ax.axhline(1,color='#777777',lw=.7,ls='--')
    ax.set_xticks(x,['1 h / 10 h','8 h / 16 h','8 h / 2 h'])
    ax.set(xlabel='Charge / delivery windows',ylabel='Capacity-constrained volume ratio',ylim=(0,1.5))
    ax.text(.02,.97,'HITEC, 180→50 °C',transform=ax.transAxes,va='top',fontsize=7)
    ax.legend(loc='upper center',bbox_to_anchor=(.5,-.31),ncol=3,frameon=False,fontsize=5.7,columnspacing=.6,handlelength=1)
    ax=axes[1,1]
    q=cond[(cond.chemistry=='HITEC')&(cond.hot_C==180)]
    for material in ['base','alumina_2wt','alumina_copper_foam']:
        r=q[q.material==material].sort_values('cold_C')
        ax.plot(r.capacity_kWh_m3,r.discharge_power_kW_m3,marker='o',ms=3.5,color=COL[material])
        for row in r.itertuples():
            # Offset each temperature above its marker; material groups stay separated in x.
            ax.annotate(f'{int(row.cold_C)}', (row.capacity_kWh_m3,row.discharge_power_kW_m3),xytext=(0,5),textcoords='offset points',ha='center',fontsize=6.5,color=COL[material])
    ax.set(xlabel=r'Enthalpy capacity (kWh m$^{-3}$)',ylabel=r'Mean discharge power (kW m$^{-3}$)',xlim=(95,136),ylim=(8,17.4))
    ax.text(.03,.98,'HITEC at 180 °C\nLabels: delivery endpoint (°C)',transform=ax.transAxes,va='top',fontsize=6.7)
    ax=axes[2,0]
    for rec,label,color in [('ELFAR_SIO2_LOW_SHEAR',r'10 s$^{-1}$','#B65448'),('ELFAR_SIO2_HIGH_SHEAR',r'240 s$^{-1}$','#176B83')]:
        q=hydro[(hydro.record_id==rec)&(hydro.baseline_pump_kWh_per_kWhth==.01)]
        ax.plot(q.beta,q.pump_power_ratio,color=color,label=label)
    ax.axhline(1,color='#777777',lw=.7,ls='--')
    ax.set(xlabel=r'Friction exponent, $\beta$',ylabel='Equal-duty pumping-power ratio',xlim=(.25,1),ylim=(.65,4.15))
    ax.legend(frameon=False,loc='upper left')
    ax.text(.97,.35,r'$R_\mu^\beta/R_{c_p}^{3-\beta}$',ha='right',transform=ax.transAxes,fontsize=10)
    ax=axes[2,1]
    for rec,label,color,ls in [('ELFAR_SIO2_LOW_SHEAR',r'10 s$^{-1}$, $\beta=1$','#B65448','-'),('ELFAR_SIO2_HIGH_SHEAR',r'240 s$^{-1}$, $\beta=1$','#176B83','-'),('ELFAR_SIO2_HIGH_SHEAR',r'240 s$^{-1}$, $\beta=0.25$','#176B83','--')]:
        beta= .25 if '0.25' in label else 1.
        q=hydro[(hydro.record_id==rec)&np.isclose(hydro.beta,beta)]
        ax.plot(q.baseline_pump_kWh_per_kWhth*1000,q.incremental_pumping_kWh_per_MWhth,color=color,ls=ls,label=label)
    ax.axhline(0,color='#777777',ls='--',lw=.7)
    ax.set(xlabel=r'Base pumping input (kWh MWh$_{th}^{-1}$)',ylabel=r'Change in electricity (kWh MWh$_{th}^{-1}$)')
    ax.legend(frameon=False,loc='upper left',fontsize=6.3)
    finish(fig,M/'submission_Fig6')

    fig,axes=plt.subplots(2,2,figsize=(7.09,6.5))
    fig.subplots_adjust(left=.12,right=.97,top=.95,bottom=.12,wspace=.55,hspace=.65)
    for ax,letter in zip(axes.flat,'abcd'): panel(ax,letter)
    ax=axes[0,0]
    foam=pair[pair.material=='alumina_copper_foam'].copy().sort_values(['chemistry','cold_C','hot_C'])
    for i,r in enumerate(foam.itertuples()):
        ax.errorbar(r.crossover_tc_over_td,i,xerr=[[r.crossover_tc_over_td-r.crossover_low],[r.crossover_high-r.crossover_tc_over_td]],fmt='o',ms=3,color=COL[r.chemistry],capsize=2,lw=.9)
    ax.set_yticks(range(18),[f'{int(r.hot_C)}→{int(r.cold_C)}' for r in foam.itertuples()],fontsize=6)
    ax.set(xlabel=r'Volume crossover, $t_c/t_d$',ylabel='Measured temperature interval (°C)',xlim=(0,1.05))
    ax.axhline(8.5,color='#BBBBBB',lw=.6)
    ax.text(.97,.03,'HITEC',ha='right',color=COL['HITEC'],transform=ax.transAxes,fontsize=7)
    ax.text(.97,.97,'Solar Salt',ha='right',va='top',color=COL['Solar Salt'],transform=ax.transAxes,fontsize=7)
    ax=axes[0,1]
    q=grid[(grid.material=='alumina_copper_foam')&(grid.cold_C==50)&(((grid.chemistry=='Solar Salt')&(grid.hot_C==240))|((grid.chemistry=='HITEC')&(grid.hot_C==180)))]
    for chemistry,r in q.groupby('chemistry'):
        ax.plot(r.tc_over_td,100*(1/r.volume_ratio-1),color=COL[chemistry],label=chemistry)
    ax.axhline(0,color='#777777',ls='--',lw=.7)
    ax.set(xscale='log',xlabel=r'Charge / delivery time, $t_c/t_d$',ylabel='Break-even volumetric-cost premium (%)')
    ax.legend(frameon=False)
    ax=axes[1,0]
    for dt,marker in [(1.,'o'),(.25,'x')]:
        q=chrono[chrono.dt_h==dt]
        ax.scatter(q.analytical_volume,q.lp_volume,s=17,marker=marker,label=f'{dt:g} h step',alpha=.7)
    lim=[0,float(chrono.lp_volume.max())*1.07]
    ax.plot(lim,lim,color='#777777',lw=.7,ls='--')
    ax.set(xlabel=r'Closed-form volume (m$^3$ kWh$^{-1}$)',ylabel=r'Chronological LP volume (m$^3$ kWh$^{-1}$)',xlim=lim,ylim=lim)
    ax.legend(frameon=False)
    ax=axes[1,1]
    labels=[]
    for i,((chemistry,material),r) in enumerate(pair.groupby(['chemistry','material'])):
        errors=100*(1-r.discharge_ratio/r.charge_ratio)
        ax.scatter(errors,[i]*len(errors),s=17,facecolors='none',edgecolors=COL[chemistry],alpha=.8)
        ax.scatter([errors.median()],[i],s=28,marker='D',color=COL[chemistry])
        labels.append(chemistry+'\n'+('Alumina' if material=='alumina_2wt' else 'Alumina + foam'))
    ax.set_yticks(range(4),labels,fontsize=6.5)
    ax.set(xlabel='Charging-only sizing understatement (%)',ylim=(-.7,3.7),xlim=(0,85))
    ax.text(.03,.98,'Delivery-limited boundary\nOpen: conditions; diamond: median',transform=ax.transAxes,va='top',fontsize=6.3)
    finish(fig,S/'submission_Supp_Fig15')

    map_path=ROOT/'outputs/qa/figure_source_map.csv'
    mapping=pd.read_csv(map_path)
    old=mapping[mapping.figure=='Supp_Fig14'].copy()
    if old.empty:
        old=mapping[mapping.figure=='Fig6'].copy()
    old['figure']='Supp_Fig14'; old['title']='Precedence-valid evidence programs'
    old['source_tables']='submission_candidate_research_priority_summary;dag_constrained_minimal_action_sets;submission_research_action_frontier_summary;counterfactual_candidate_signed_changes'
    mapping=mapping[~mapping.figure.isin(['Fig6','Supp_Fig14','Supp_Fig15'])]
    source_names=';'.join(f'application_{x}' for x in ['paired_response','duty_frontiers','device_conditions','chronological_checks','equal_duty_hydraulics','application_scenarios'])
    rows=[]
    for name,title in [('Fig6','Material architecture and duty-dependent service value'),('Supp_Fig15','Application boundaries and numerical checks')]:
        rows.append({'figure':name,'title':title,'width_px':4254,'height_px':4980 if name=='Fig6' else 3900,'aspect_ratio':7.09/(8.3 if name=='Fig6' else 6.5),'source_tables':source_names})
    pd.concat([mapping,old,pd.DataFrame(rows)],ignore_index=True).to_csv(map_path,index=False)
    out={'status':'PASS','main_figures':6,'supplementary_figures':15,'application_status':status,'scope':'Figures use experiment-bounded mean powers and declared application assumptions.'}
    (ROOT/'outputs/qc/APPLICATION_FIGURE_STATUS.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    # This status describes the final, extended figure inventory, after the base QA.
    release=json.loads((ROOT/'outputs/qc/POSTPROCESS_RELEASE_STATUS.json').read_text())
    release.update(release_id='TES-EES-V2.2.0-20260909',main_figures=6,supplementary_figures=15,application_assessment_status='PASS',final_renderer='src/render_application_figures.py')
    (ROOT/'outputs/qc/POSTPROCESS_RELEASE_STATUS.json').write_text(json.dumps(release,indent=2),encoding='utf-8')
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
