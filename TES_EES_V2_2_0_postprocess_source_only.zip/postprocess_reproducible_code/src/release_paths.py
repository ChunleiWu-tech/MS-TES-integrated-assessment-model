from __future__ import annotations
from pathlib import Path

ENVIRONMENT_STATUS = "environment_status.json"
POSTPROCESS_ENVIRONMENT_STATUS = "POSTPROCESS_ENVIRONMENT_STATUS.json"
UPSTREAM_RELEASE_STATUS = "UPSTREAM_RELEASE_STATUS.json"
UPSTREAM_RELEASE_STATUS_COMPAT = "submission_UPSTREAM_STATUS.json"
POSTPROCESS_RELEASE_STATUS = "POSTPROCESS_RELEASE_STATUS.json"
POSTPROCESS_RELEASE_CONTRACT_AUDIT = "POSTPROCESS_RELEASE_CONTRACT_AUDIT.json"


def first_existing(folder: Path, *names: str) -> Path | None:
    for name in names:
        path = folder / name
        if path.exists():
            return path
    return None
