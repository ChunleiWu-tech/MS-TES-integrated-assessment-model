from __future__ import annotations
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "outputs"
if OUT.is_symlink() or OUT.resolve().parent != ROOT:
    raise RuntimeError('Refusing to clean a redirected generated-output directory')
for name in ["main_figures", "supplementary_figures", "contact_sheets", "qa", "qc"]:
    path = OUT / name
    if path.is_symlink() or path.resolve().parent != OUT.resolve():
        raise RuntimeError(f'Refusing redirected output: {path}')
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)
print("Postprocess generated figures and local QC cleaned; synced upstream tables/QC preserved.")
