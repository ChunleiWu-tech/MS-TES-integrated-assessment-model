"""Final EES presentation. Scientific inputs are read-only; all reductions are explicit."""
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
import json
import re
import textwrap
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.text import Text
from matplotlib.patches import Patch, Rectangle
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
import run_postprocess as B
from public_figure_language import clean_public_labels

ROOT=B.ROOT; T=B.TABLES; QA=B.QA
COL=[B.NAVY,B.MUSTARD,B.OLIVE,B.BURGUNDY]
SERV=B.SERVICE_ORDER
SL={s:B.compact_service_label(s).replace('Ind.','Industry') for s in SERV}
RECORDS=[]
ALIGNMENT=[]

def setup():
    plt.rcParams.update({'font.size':8, 'axes.labelsize':8, 'axes.titlesize':8,
        'xtick.labelsize':7.5,'ytick.labelsize':7.5,'legend.fontsize':7.5,
        'axes.spines.top':False,'axes.spines.right':False})

def axis(fig,rect,letter=None):
    ax=fig.add_axes(rect)
    if letter:
        txt=fig.text(max(.025,rect[0]-.04),rect[1]+rect[3]+.013,letter,weight='bold',fontsize=10,va='bottom')
        txt._ees_panel_axis=ax
    ax.tick_params(length=2.5,pad=2)
    ax.set_axisbelow(True)
    return ax

def pct(ax,direction='x'):
    getattr(ax,direction+'axis').set_major_formatter(B.mpl.ticker.PercentFormatter(1,decimals=0))

def label(ax,x,y,text,color=B.INK,dy=0):
    return ax.annotate(text,(x,y),xytext=(6,dy),textcoords='offset points',ha='left',va='center',color=color,fontsize=7.5)

def percentage(value,places=2):
    return str((Decimal(str(value))*100).quantize(Decimal('1').scaleb(-places),rounding=ROUND_HALF_UP))+'%'

def align_panel_letters(fig,name):
    """Use fixed column gutters and one common baseline per panel row."""
    fig.canvas.draw();fig.set_layout_engine('none')
    items=[]
    for txt in fig.texts:
        if hasattr(txt,'_ees_panel_axis'):
            items.append((txt,txt._ees_panel_axis))
    for ax in fig.axes:
        items.extend((txt,ax) for txt in ax.texts if txt.get_text() in list('abcdefg'))
    rows=[]
    for txt,ax in sorted(items,key=lambda pair:-pair[1].get_position().y1):
        pos=ax.get_position();top=pos.y1
        row=next((r for r in rows if abs(r['top']-top)<.035),None)
        if row is None:row={'top':top,'items':[]};rows.append(row)
        row['items'].append((txt,ax))
    for row_index,row in enumerate(rows):
        for txt,ax in row['items']:
            pos=ax.get_position();column=0 if len(row['items'])==1 or pos.width>=.599 or (pos.x0+pos.x1)/2<.54 else 1
            x=[.025,.53][column];y=min(.972,1-16/(fig.get_figheight()*72),row['top']+.015)
            txt.set_transform(fig.transFigure);txt.set_position((x,y));txt.set_fontsize(10);txt.set_fontweight('bold');txt.set_ha('left');txt.set_va('bottom');txt.set_clip_on(False)
            ALIGNMENT.append({'figure':name,'panel':txt.get_text(),'column':column,'row':row_index,'x':x,'y':y,'axis_x0':pos.x0,'axis_x1':pos.x1,'axis_y0':pos.y0,'axis_y1':pos.y1})


def finish(fig,n,title,sources,supp=False):
    if not supp:fig.set_size_inches(6.3,6.7)
    clean_public_labels(fig)
    align_panel_letters(fig,('Supp_Fig' if supp else 'Fig')+str(n))
    # Font sizes are specified for the final 160-mm manuscript width.
    fig.canvas.draw()
    out=B.SUPP if supp else B.MAIN
    stem=f"submission_{'Supp_Fig' if supp else 'Fig'}{n}"
    fig.savefig(out/(stem+'.pdf'),metadata={'CreationDate':None,'ModDate':None})
    fig.savefig(out/(stem+'.png'),dpi=300)
    RECORDS.append({'figure':('Supp_Fig' if supp else 'Fig')+str(n),'title':title,
        'width_px':round(fig.get_figwidth()*300),'height_px':round(fig.get_figheight()*300),
        'aspect_ratio':fig.get_figwidth()/fig.get_figheight(),'source_tables':';'.join(sources)})
    plt.close(fig)

def fig1():
    from render_ees_detail import figure1
    figure1(globals())


def fig2():
    from render_ees_detail import figure2
    figure2(globals())

def fig3():
    joint=B.read('joint_threshold_regime_map');cov=B.read('service_coverage_threshold_sensitivity')
    fig=plt.figure(figsize=(6.3,7.7))
    a=axis(fig,[.13,.70,.35,.22],'a');b=axis(fig,[.64,.70,.31,.22],'b')
    regimes=['robust access','conditional access','no bounded access']
    share=joint.groupby(['scenario','decision_regime']).size().unstack(fill_value=0).reindex(SERV).reindex(columns=regimes,fill_value=0);share=share.div(share.sum(axis=1),axis=0)
    left=np.zeros(7)
    for rg,col in zip(regimes,[B.OLIVE,B.MUSTARD,B.BURGUNDY]):
        a.barh(range(7),share[rg],left=left,color=col,height=.65);left+=share[rg]
    a.set_yticks(range(7),[SL[s] for s in SERV]);a.set_xlim(0,1);pct(a);a.set_xlabel('Coverage–evidence states')
    fig.legend([Patch(fc=c) for c in [B.OLIVE,B.MUSTARD,B.BURGUNDY]],['Robust access','Conditional access','No bounded access'],loc='upper center',bbox_to_anchor=(.53,.987),ncol=3,frameon=False)
    for ss in SERV[:3]:
        g=cov[cov.scenario==ss].sort_values('coverage_threshold');x=g.coverage_threshold.to_numpy();y=g.no_selection_frequency.to_numpy();se=np.sqrt(y*(1-y)/g.mc_iterations.to_numpy())
        b.fill_between(x,y-1.645*se,y+1.645*se,color=B.SCOL[ss],alpha=.2);b.plot(x,y,color=B.SCOL[ss],marker='o',ms=3,label=SL[ss])
    b.set(xlim=(.948,1.003),ylim=(-.02,.55),xlabel='Minimum service coverage',ylabel='No-selection frequency');b.set_xticks([.95,.975,1]);b.legend(frameon=False,loc='upper left',fontsize=7.5)
    c=axis(fig,[.13,.41,.28,.18],'c');d=axis(fig,[.54,.41,.41,.18],'d')
    for ss in SERV[:3]:
        g=joint[(joint.scenario==ss)&np.isclose(joint.coverage_threshold,joint.coverage_threshold.min())].sort_values('evidence_threshold')
        c.step(g.evidence_threshold,g.no_selection_frequency,where='post',color=B.SCOL[ss],lw=1.4)
    c.axvspan(.75,.85,color=B.CREAM,alpha=.4);c.set(xlim=(.23,.97),ylim=(-.03,1.05),xlabel='Evidence threshold',ylabel='No-selection frequency')
    c.set_xticks([.25,.5,.75]);c.text(.58,.70,'Access\ntransition',ha='center',fontsize=7.5,color=B.MID_GREY)
    margins=pd.read_csv(QA/'fig3d_candidate_service_thermal_margin_audit.csv')
    names=['NaCl-KCl-CaCl2 23.5-25.0-51.5 wt%','HXLN 95% Hitec XL + 5% NaNO2','NKM-12 ternary sulfate','Na2CO3-NaCl-KCl ternary eutectic']
    mat=margins.pivot(index='display_system',columns='service_id',values='thermal_margin_C').reindex(index=names,columns=SERV)
    cmap=LinearSegmentedColormap.from_list('headroom',[B.BURGUNDY,B.ROSE_LIGHT,B.CREAM,B.OLIVE]);cmap.set_bad(B.PALE_BLUE)
    d.imshow(mat,aspect='auto',cmap=cmap,norm=TwoSlopeNorm(vmin=-450,vcenter=0,vmax=130))
    for i,row in enumerate(mat.to_numpy()):
        for j,v in enumerate(row):
            if np.isnan(v):d.add_patch(Rectangle((j-.5,i-.5),1,1,fc='none',ec=B.BLUE,hatch='///',lw=.3))
            d.text(j,i,'N/R' if np.isnan(v) else f'{v:+.0f}',ha='center',va='center',fontsize=7,color=B.NAVY if np.isnan(v) else ('white' if v < -185 or v>75 else B.INK))
    d.set_yticks(range(4),['Cl-2025','HXLN','NKM-12','NC–Cl']);d.set_xticks(range(7),[SL[s] for s in SERV],rotation=60,ha='right');d.tick_params(axis='x',labelsize=7)
    d.text(.12,1.16,'Limiting thermal headroom (°C)',transform=d.transAxes,fontsize=8)
    e=axis(fig,[.13,.085,.82,.19],'e'); ar=B.read('service_regime_archetype_summary',B.V).copy()
    ar.loc[ar.uncertainty_structure_class=='service-incomplete','regime_archetype']='structural service limitation'
    kinds=list(dict.fromkeys(ar.regime_archetype)); labels={'multi-boundary regime':'Multiple\nboundaries','joint threshold-sensitive':'Joint\nthresholds','evidence-sensitive':'Evidence\nthreshold','structural service limitation':'Service\nlimited','structural evidence lock':'Evidence\nlocked','stable single regime':'Stable'}
    for i,row in enumerate(ar.itertuples()):
        xx=kinds.index(row.regime_archetype);e.scatter(xx,i,s=120,color=B.SCOL[row.scenario],edgecolor=B.INK if row.main_map_informative else 'white');e.text(xx,i,str(row.decision_regime_count),ha='center',va='center',fontsize=8,color='white' if B.SCOL[row.scenario] in [B.NAVY,B.BURGUNDY,B.TERRACOTTA] else B.INK)
    e.set_yticks(range(len(ar)),[SL[s] for s in ar.scenario]);e.set_xticks(range(len(kinds)),[labels.get(k,k) for k in kinds]);e.set_xlim(-.5,len(kinds)-.5);e.set_ylim(-.7,len(ar)-.3);e.grid(color=B.LIGHT_GREY,lw=.4)
    finish(fig,3,'Thermal headroom and evidence thresholds identify different stopping mechanisms',
        ['joint_threshold_regime_map','service_coverage_threshold_sensitivity','threshold_retention_sweep','expanded_v3_new_candidate_entry_audit','core_service_thermal_boundary_registry','submission_service_regime_archetype_summary'])

def fig4():
    pa=B.read('pareto_joint_uncertainty_and_robustness',B.STAT);scope=B.read('decision_scope_matrix',B.STAT)
    q=pa[(pa.frontier_scope=='opportunity')&(pa.joint_valid_draws>0)]
    ids=sorted(scope.system_id.unique());code={s:i+1 for i,s in enumerate(ids)}
    fig=plt.figure(figsize=(6.3,8.0));facets=[]
    for k,ss in enumerate([SERV[0],SERV[1],SERV[2],SERV[3],SERV[6]]):
        ax=axis(fig,[.13+(k%3)*.285,.78-(k//3)*.185,.25,.135],'a' if k==0 else None);facets.append(ax)
        g=q[q.scenario==ss];fr=g[g.representative_frontier_member].sort_values('representative_performance_score')
        if len(fr)>1:ax.plot(fr.representative_performance_score,fr.representative_credibility_score,color=B.OLIVE,lw=1)
        for r in g.itertuples():
            x=r.representative_performance_score;y=r.representative_credibility_score
            ax.errorbar(x,y,xerr=[[max(0,x-r.performance_q05)],[max(0,r.performance_q95-x)]],yerr=[[max(0,y-r.credibility_q05)],[max(0,r.credibility_q95-y)]],fmt='o',ms=4.8,mfc=B.OLIVE if r.representative_frontier_member else 'white',mec=B.INK,ecolor=B.MID_GREY,elinewidth=.9,capsize=2)
            dx=-5 if x>.7 else 5;dy=-9 if y>.75 else 6
            if ss==SERV[2]:
                dx,dy={2:(-5,12),3:(0,14),12:(7,-14),14:(-4,-16)}.get(code[r.system_id],(dx,dy))
            ax.annotate(str(code[r.system_id]),(x,y),xytext=(dx,dy),textcoords='offset points',ha='right' if dx<0 else 'left',fontsize=8,bbox={'fc':'white','ec':'none','pad':.1})
        ax.set(xlim=(-.07,1.07),ylim=(-.07,1.09));ax.set_xticks([0,.5,1]);ax.set_yticks([0,.5,1]);ax.set_title(SL[ss],pad=4,weight='bold')
        if k%3:ax.set_yticklabels([])
        if k<3:ax.set_xticklabels([])
    si=axis(fig,[.70,.595,.25,.135]);facets.append(si);g=q[q.scenario.isin(SERV[4:6])]
    for i,r in enumerate(g.itertuples()):
        si.errorbar(r.representative_credibility_score,i,xerr=[[r.representative_credibility_score-r.credibility_q05],[r.credibility_q95-r.representative_credibility_score]],fmt='o',capsize=2,color=B.SCOL[r.scenario])
        si.text(.455,i+.20,f'{SL[r.scenario]} · {code[r.system_id]}',fontsize=7.5)
    si.set(xlim=(.445,.565),ylim=(-.5,1.6));si.set_yticks([]);si.set_xticks([.45,.5,.55]);si.set_title('Singleton duties',pad=4,weight='bold');si.set_xlabel('Evidence score')
    fig.text(.043,.755,'Engineering evidence',rotation=90,ha='center',va='center',fontsize=8)
    fig.text(.38,.552,'Representative performance',ha='center',fontsize=8)
    fig.legend([Line2D([],[],marker='o',color=B.OLIVE,ls=''),Line2D([],[],marker='o',mfc='white',mec=B.INK,ls=''),Line2D([],[],color=B.MID_GREY)],['Frontier','Dominated','5–95% draw range'],loc='upper center',bbox_to_anchor=(.54,.982),ncol=3,frameon=False)
    b=axis(fig,[.13,.275,.39,.235],'b');c=axis(fig,[.75,.275,.20,.235],'c')
    z=q[q.frontier_membership_frequency>=.01].sort_values('frontier_membership_frequency').tail(14)
    b.hlines(range(len(z)),z.frontier_frequency_bootstrap_p05,z.frontier_frequency_bootstrap_p95,color=B.MID_GREY,lw=1.1);b.scatter(z.frontier_membership_frequency,range(len(z)),color=[B.SCOL[s] for s in z.scenario],s=20,zorder=3)
    b.set_yticks(range(len(z)),[f'{SL[s]} · {code[k]}' for s,k in zip(z.scenario,z.system_id)]);b.set_xlim(-.03,1.04);pct(b);b.set_xlabel('Pareto membership')
    opp=pa[pa.frontier_scope=='opportunity'][['scenario','system_id','threshold_50_member']].rename(columns={'threshold_50_member':'pareto'})
    sm=scope.merge(opp,on=['scenario','system_id'],how='left');sm['pareto']=sm.pareto.fillna(False).astype(bool);sm['ready']=sm.decision_scope_class=='decision_ready';sm['selected']=sm.evidence_qualified_selection_frequency>=.01
    br=sm.groupby('system_id')[['pareto','selected']].sum().reindex(ids)
    c.hlines(range(len(br)),br.selected,br.pareto,color=B.PALE_BLUE,lw=1.5);c.scatter(br.pareto,range(len(br)),color=B.MUSTARD,s=23);c.scatter(br.selected,range(len(br)),color=B.OLIVE,s=14)
    c.set_yticks(range(len(br)),[f'{code[s]} {B.short_id(s)}' for s in br.index]);c.tick_params(axis='y',labelsize=7);c.set_xlim(-.25,4.2);c.set_xticks(range(5));c.set_xlabel('Number of duties')
    c.legend([Line2D([],[],marker='o',color=B.MUSTARD,ls=''),Line2D([],[],marker='o',color=B.OLIVE,ls='')],['Pareto ≥50%','Selected ≥1%'],loc='upper left',bbox_to_anchor=(-.63,1.22),frameon=False,ncol=2,fontsize=7,columnspacing=.7)
    for txt in fig.texts:
        if txt.get_text()=='c':txt.set_position((.58,.523))
    d=axis(fig,[.13,.12,.82,.075],'d');dm=axis(fig,[.13,.038,.82,.065])
    inter=sm.groupby(['pareto','ready','selected']).size().reset_index(name='count').sort_values('count',ascending=False).reset_index(drop=True)
    d.bar(range(len(inter)),inter['count'],color=[B.OLIVE if v else B.NAVY for v in inter.selected],width=.6)
    for i,r in inter.iterrows():
        d.text(i,r['count']+.8,str(r['count']),ha='center',fontsize=8)
        on=[]
        for j,key in enumerate(['pareto','ready','selected']):
            dm.scatter(i,2-j,s=24,fc=B.OLIVE if r[key] else 'white',ec=B.INK,lw=.7)
            if r[key]:on.append(2-j)
        if len(on)>1:dm.plot([i,i],[min(on),max(on)],color=B.INK,lw=.7,zorder=0)
    for ax in (d,dm):ax.set_xlim(-.6,len(inter)-.4);ax.set_xticks([])
    d.set_ylim(0,inter['count'].max()+6);d.set_ylabel('Pairs');dm.set_ylim(-.5,2.5);dm.set_yticks([2,1,0],['Pareto','Evidence','Selected'])
    pd.DataFrame([{'code':code[s],'system_id':s,'label':B.short_id(s)} for s in ids]).to_csv(QA/'ees_fig4_candidate_key.csv',index=False)
    # Alignment is imposed in native coordinates, independent of label widths.
    finish(fig,4,'Frontier membership and formal selection describe different outcomes',
        ['statistical_pareto_joint_uncertainty_and_robustness','statistical_decision_scope_matrix'])

def fig5():
    st=B.read('structural_stochastic_uncertainty_classification',B.STAT);cont=B.read('continuous_decision_variance_attribution',B.STAT);cat=B.read('categorical_selection_information_attribution',B.STAT)
    prop=B.read('property_domain_contraction_summary',B.V);ev=B.read('atomic_evidence_unlock_summary',B.V);depth=B.read('gate_closure_depth_response')
    fig=plt.figure(figsize=(6.3,6.5))
    blocks=['thermophysical','evidence','preference']
    for rect,letter,data,value in [([.13,.68,.34,.20],'a',cont,'normalized_shapley_variance_share'),([.64,.68,.31,.20],'b',cat,'normalized_shapley_information_share')]:
        ax=axis(fig,rect,letter);q=data[data.uncertainty_block.isin(blocks)&data[value].notna()];p=q.pivot(index='scenario',columns='uncertainty_block',values=value).reindex(columns=blocks).fillna(0);left=np.zeros(len(p))
        for k,col in zip(blocks,COL):
            v=p[k].to_numpy();ax.barh(range(len(p)),v,left=left,color=col,height=.6)
            for i,z in enumerate(v):
                if z>.12:ax.text(left[i]+z/2,i,f'{z:.0%}',ha='center',va='center',color='white' if col==B.NAVY else B.INK,fontsize=7.5)
            left+=v
        ax.set_yticks(range(len(p)),[SL[s] for s in p.index]);ax.set_xlim(0,1);pct(ax);ax.set_xlabel('Variance share' if letter=='a' else 'Information share')
    fig.legend([Patch(fc=c) for c in COL[:3]],['Thermophysical','Evidence','Preference'],loc='upper center',bbox_to_anchor=(.55,.97),ncol=3,frameon=False)
    d=axis(fig,[.27,.355,.25,.21],'c');e=axis(fig,[.77,.355,.18,.21],'d')
    q=prop[prop.coverage_loss_due_to_registered_property_domains>.01].sort_values('coverage_loss_due_to_registered_property_domains').tail(12)
    d.hlines(range(len(q)),0,q.coverage_loss_due_to_registered_property_domains,color=B.PALE_BLUE);d.scatter(q.coverage_loss_due_to_registered_property_domains,range(len(q)),s=20,color=[B.SCOL[s] for s in q.scenario]);d.set_yticks(range(len(q)),[f'{SL[s]} · {B.short_id(k)}' for s,k in zip(q.scenario,q.system_id)]);d.tick_params(axis='y',labelsize=7);d.set_xlim(0,1.06);pct(d);d.set_xlabel('Duty coverage lost')
    q=ev.groupby(['gate','gate_label'],as_index=False).agg(unlock=('shapley_unlock_contribution','sum')).sort_values('unlock')
    e.barh(range(len(q)),q.unlock,color=B.OLIVE,height=.55);e.set_yticks(range(len(q)),[str(s).replace('Literature replication','Replication').replace(' ','\n') for s in q.gate_label]);e.tick_params(axis='y',labelsize=7.5);e.set_xlabel('Summed unlock\ncontribution');e.set_xlim(0,q.unlock.max()*1.14)
    f=axis(fig,[.13,.09,.82,.16],'e')
    m=depth.pivot(index='scenario',columns='closed_gate_count',values='median_retained_frequency').reindex(SERV)
    f.imshow(m,aspect='auto',cmap=LinearSegmentedColormap.from_list('retained',['#faf9f4',B.BLUE]),vmin=0,vmax=1)
    for i,row in enumerate(m.to_numpy()):
        for j,v in enumerate(row):f.text(j,i,f'{v:.1%}',ha='center',va='center',fontsize=7.5,color='white' if v>.55 else B.INK)
    f.set_yticks(range(7),[SL[s] for s in SERV]);f.set_xticks(range(len(m.columns)),m.columns);f.set_xlabel('Number of prerequisite gates closed')
    f.text(0,1.11,'Median retained frequency across action combinations at each depth',transform=f.transAxes,fontsize=7.5)
    finish(fig,5,'Uncertainty attribution identifies the next measurement and prerequisite',
        ['statistical_structural_stochastic_uncertainty_classification','statistical_continuous_decision_variance_attribution','statistical_categorical_selection_information_attribution','submission_property_domain_contraction_summary','submission_atomic_evidence_unlock_summary','core_gate_closure_depth_response'])

def legible_legacy(fig):
    """Reflow supplementary detail at its final physical width."""
    ratio=6.3/fig.get_figwidth()
    fig.set_size_inches(6.3,fig.get_figheight()*ratio)
    for txt in fig.findobj(match=Text):
        txt.set_fontsize(max(7.3,txt.get_fontsize()*ratio))
    for ax in fig.axes:
        ax.tick_params(labelsize=7.3)
    if isinstance(fig.get_layout_engine(),B.mpl.layout_engine.ConstrainedLayoutEngine):
        fig.get_layout_engine().set(w_pad=.05,h_pad=.08,wspace=.10,hspace=.10)
    clean_public_labels(fig)

def compact(text):
    replacements={
        'FLiNaK nominal eutectic round robin':'FLiNaK RR','FLiNaK nominal round robin':'FLiNaK RR',
        'Quaternary nitrate S7':'Nitrate S7','NaNO$_3$-KNO$_3$-K$_2$CO$_3$-KCl':'NKC-KCl',
        'NaNO$_3$-KNO$_3$-KCl process-informed':'NKN-KCl',
        'Li$_2$CO$_3$-Na$_2$CO$_3$-K$_2$CO$_3$':'LiNaK carbonate',
        'Li2CO3-Na2CO3-K2CO3 eutectic':'LiNaK carbonate',
        'NaNO$_3$-KNO$_3$-Na2SO4 TMS-2':'TMS-2',
        'MgCl$_2$ ternary':'MgCl$_2$ mix','Industrial':'Industry',
        'inside thermophysical boundary':'Within thermal\nboundary',
        'conditional material boundary':'Conditional\nmaterial boundary',
        'outside stationary TES material boundary':'Outside stationary\nTES boundary',
        'exact composition corrosion':'Corrosion','long duration cycling':'Cycling',
        'system containment qualification':'Containment','independent replication':'Replication',
        'full interval data completion':'Data completion',
        'integrated compatibility program':'Compatibility',
        'integrated reproducibility program':'Reproducibility',
        'comprehensive evidence program':'All evidence',
        'Grouped external system':'Held-out formula groups',
        'Random-record optimism diagnostic':'Random records',
        'Within-draw min–max':'Min–max','Benchmark-anchored':'Benchmark anchored',
        'Foam charging power':'Foam: charge','Foam bidirectional power':'Foam: bidirectional',
        'EG thermal conductivity':'EG: conductivity','EG active-salt fraction':'EG: salt fraction',
        'EG 316SS corrosion rate':'EG: 316SS corrosion',
        'C1 · Evidence opportunity':'C1: evidence\nopportunity','C2 · Deployability benchmark':'C2: qualified\nbenchmark',
        'Full-duty support probability':'Full-duty support',
        'sCO2':'sCO$_2$',
    }
    for a,b in replacements.items():text=text.replace(a,b)
    if 'shared profile' in text:text='Shared zero-service profile'
    return text

def supplement_layout(fig,n):
    for txt in fig.findobj(match=Text):txt.set_text(compact(txt.get_text()))
    for ax in fig.axes:
        for axis0 in [ax.xaxis,ax.yaxis]:
            labels=[t.get_text() for t in axis0.get_majorticklabels()]
            if any(compact(t)!=t for t in labels):axis0.set_ticks(axis0.get_majorticklocs(),labels=[compact(t) for t in labels])
        leg=ax.get_legend()
        if leg:
            ax.legend(leg.legend_handles,[compact(t.get_text()) for t in leg.get_texts()],loc=leg._loc,
                bbox_to_anchor=leg.get_bbox_to_anchor().transformed(ax.transAxes.inverted()),
                ncol=leg._ncols,frameon=False,fontsize=7.3,handletextpad=.55,columnspacing=1.1)
    layouts={
        1:([[.23,.56,.22,.32],[.72,.56,.23,.32],[.16,.12,.32,.28],[.75,.12,.20,.28]],6.6),
        2:([[.20,.14,.26,.75],[.72,.14,.23,.75]],6.7),
        4:([[.34,.64,.60,.25],[.34,.12,.60,.37]],6.2),
        10:([[.27,.51,.23,.34],[.73,.51,.22,.34],[.18,.12,.32,.22],[.69,.12,.26,.22]],7.3),
        11:([[.24,.58,.27,.32],[.72,.58,.23,.32],[.24,.15,.27,.27],[.72,.15,.23,.27]],6.5),
        12:([[.14,.62,.33,.25],[.65,.62,.30,.25],[.24,.13,.23,.31],[.72,.13,.23,.31]],7.0),
        13:([[.30,.60,.22,.28],[.66,.60,.29,.28],[.30,.15,.22,.28],[.74,.15,.21,.28]],6.7),
        14:([[.08,.84,.85,.12],[.25,.37,.23,.38],[.67,.37,.28,.38],[.13,.055,.33,.205],[.75,.055,.20,.205]],6.9),
    }
    if n in layouts:
        rects,height=layouts[n];fig.set_layout_engine('none');fig.set_size_inches(6.3,height)
        for ax,rect in zip(fig.axes,rects):ax.set_position(rect)
    if n==1:
        fig.axes[1].set_xticks(range(6),['$T_m$','Upper','$c_p$','$\u03c1$','Latent','Cycles'],rotation=60,ha='right')
        fig.axes[3].set_xlim(0,165)
        for txt in fig.axes[3].texts:
            if '779' in txt.get_text():txt.set_visible(False)
        fig.axes[2].get_legend().set_bbox_to_anchor((.45,1.27))
        for child in fig.axes[1].child_axes:child.set_xticks([0,.5,1],['0','0.5','1'])
    if n==2:
        a=fig.axes[0];a.set_xlim(-.05,1.55);a.set_xlabel('Component-set match')
        for txt in a.texts:
            if 'exact' in txt.get_text().lower() or 'literature' in txt.get_text().lower():txt.set_visible(False)
        a.legend([Line2D([],[],marker='o',color=B.NAVY,ls=''),Line2D([],[],marker='o',color=B.MUSTARD,ls='')],['Exact database link','Literature anchored'],frameon=False,loc='lower left',bbox_to_anchor=(-.20,1.03),fontsize=7.3)
    if n==4:
        fig.axes[0].set_xlim(-.02,1.3);fig.axes[0].set_xticks([0,.5,1]);fig.axes[1].set_xlabel('Conditional raw-material cost\n(USD kWh$_{th}^{-1}$; 5–95%)')
        for txt in fig.axes[0].texts:
            if re.fullmatch(r'\d+%',txt.get_text()) and txt.xy[0]<.5:
                txt.set_position((-7,0));txt.set_ha('right')
        for txt in list(fig.axes[1].texts):
            if re.fullmatch(r'\d+\.\d+',txt.get_text()):
                yy=txt.xy[1];value=txt.get_text();txt.set_visible(False)
                fig.axes[1].text(153,yy,value,va='center',ha='right',fontsize=7.3,color=B.MUSTARD)
        fig.axes[1].set_xlim(0,160)
    if n==5:
        fig.axes[0].set_xlim(-40,290);fig.axes[0].set_xticks([0,50,100,150,200,250])
    if n==7:
        fig.set_size_inches(6.3,7.4)
        for ax in fig.axes:
            for txt in list(ax.texts):
                if re.fullmatch(r'\d\.\d+',txt.get_text()):
                    yy=txt.xy[1];value=txt.get_text();txt.set_visible(False)
                    ax.text(1.08,yy,value,va='center',ha='center',fontsize=7.3,color=B.NAVY)
            ax.set_xlim(-.03,1.17);ax.set_xticks([0,.2,.4,.6,.8,1])
    if n==8:
        fig.axes[0].get_legend().set_visible(False)
    if n==9:
        for txt in fig.axes[1].texts:
            if '14 contrasts' in txt.get_text():txt.set_text('14 service–model\ncomparisons; none\nreaches the threshold');txt.set_position((.48,.04));txt.set_ha('center')
    if n==10:
        for ax in [fig.axes[0],fig.axes[2]]:
            ax.set_yticks(ax.get_yticks(),[t.get_text().replace('PCM350/425/500','All PCM').replace('Coal/CSP/Industry','Coal/CSP/Ind.') for t in ax.get_yticklabels()])
        fig.axes[0].set_xticks(range(7),['Corr.','Cycles','Cont.','Repl.','Data','Burden','Select.'],rotation=60,ha='right')
        fig.axes[2].get_legend().set_bbox_to_anchor((.5,1.27))
    if n==11:
        # a is burden-sorted; b retains the action-registry order and its own labels.
        fig.axes[0].set_xlabel('Ordinal burden');fig.axes[2].set_xlim(-.005,.10)
        fig.axes[2].set_xlabel('Gate-pair synergy');fig.axes[3].set_xlabel('Program non-additivity')
        fig.axes[3].set_xlim(0,1.15)
        fig.axes[3].set_ylim(-.5,3.4)
        for txt in fig.axes[3].texts:
            if re.fullmatch(r'\d+%',txt.get_text()):
                txt.set_position((0,-7));txt.set_ha('center');txt.set_va('top')
                if txt.xy[0]<.1:txt.set_position((4,-7));txt.set_ha('left')
        fig.axes[1].set_xticks(range(5),['Corr.','Cycles','Cont.','Repl.','Data'],rotation=60,ha='right')
    if n==12:
        fig.axes[2].set_title('',loc='center')
        fig.axes[2].set_title('Joint applicability domain',fontsize=7.3,loc='left',pad=7)
        fig.axes[0].get_legend().set_bbox_to_anchor((.6,1.25))
        for ax in fig.axes[:2]:ax.set_ylim(0,1.18);ax.set_xticks([0,1],['Melting\ntemperature','Density'])
        fig.axes[1].set_ylim(0,1.28)
        for txt in fig.axes[1].texts:
            if 'width ' in txt.get_text():
                txt.set_text(txt.get_text().replace('522 K','522\nK').replace('1187 kg','1187\nkg'))
        for txt in fig.axes[2].texts:
            if 'Applicability domain' in txt.get_text():txt.set_text('Joint applicability domain');txt.set_position((0,1.07));txt.set_ha('left')
            if txt.get_text()=='blocked':txt.set_text('out')
        for txt in fig.axes[3].texts:
            if 'Minimum draw-matched' in txt.get_text():txt.set_visible(False)
        fig.axes[3].get_legend().set_ncols(1)
        fig.axes[3].get_legend().set_bbox_to_anchor((.40,1.23))
    if n==13:
        fig.axes[0].set_xlim(0,29)
        fig.axes[1].set_ylim(.70,1.40)
        for ax in fig.axes:
            for txt in ax.texts:
                if any(k in txt.get_text() for k in ['Intervals:','points and lines','Ratios retain','P>1:']):txt.set_visible(False)
        fig.axes[1].get_legend().set_bbox_to_anchor((.5,1.30))
        fig.axes[2].set_xlabel('Property-level coupled index');fig.axes[2].set_xlim(.1,1.7)
        fig.axes[2].set_yticks(fig.axes[2].get_yticks(),[t.get_text().replace('capacity/pump','capacity/viscosity') for t in fig.axes[2].get_yticklabels()])
        fig.axes[3].set_xlabel('Reported ratio to base\n(log scale)')
        fig.axes[3].set_xlim(.4,8)
        fig.axes[3].set_xticks([.5,1,2,4],['0.5','1','2','4']);fig.axes[3].xaxis.set_minor_formatter(B.mpl.ticker.NullFormatter())
        for txt in list(fig.axes[3].texts):
            if re.fullmatch(r'\d+\.\d+',txt.get_text()):
                yy=txt.xy[1];value=txt.get_text();color=txt.get_color();txt.set_visible(False)
                fig.axes[3].text(6.7,yy,value,va='center',ha='right',fontsize=7.3,color=color)
    if n==14:
        a=fig.axes[0];a.clear();a.axis('off')
        a.text(-.04,1.07,'a',weight='bold',fontsize=10)
        for xx,title in [(.02,'Current state'),(.48,'Next action'),(.83,'Decision endpoint')]:a.text(xx,1.12,title,ha='left' if xx==.02 else 'center',weight='bold',fontsize=8)
        priority=B.read('candidate_research_priority_summary',B.V);counts=priority.research_priority_class.value_counts()
        states=[('stop: service/property limited','Service/property limited','Measure or redesign','Reassess duty'),('not reachable under registered actions','No tested evidence route','New measurement design','Reassess evidence'),('current formal selection','Current selection','No additional gate closure','Qualified benchmark'),('one-step evidence opportunity','Evidence opportunity','Targeted evidence','Test selection gain')]
        for j,(key,l,m,r) in enumerate(states):
            y=.85-j*.25
            a.text(.02,y,f'{l} ({int(counts.get(key,0))})',fontsize=7.3,va='center')
            a.text(.48,y,m,fontsize=7.3,va='center',ha='center')
            a.text(.83,y,r,fontsize=7.3,va='center',ha='center')
        for ax in fig.axes[1:]:
            for txt in ax.texts:
                if any(k in txt.get_text() for k in ['Eligibility may','Order only;']):txt.set_visible(False)
        leg=fig.axes[1].get_legend()
        handles=leg.legend_handles;labels=[t.get_text() for t in leg.get_texts()]
        small={'property-domain first':'Domain first','direct-risk stop':'Risk stop','not reachable':'No route','reachable, no action':'Qualified','reachable, program':'Evidence program'}
        leg.remove();fig.legend(handles,[small.get(t,t) for t in labels],loc='upper center',bbox_to_anchor=(.55,.84),ncol=3,fontsize=7.3,frameon=False)
        fig.axes[2].get_legend().set_visible(False)
        fig.axes[4].set_xlim(-.03,1.35)
        ax=fig.axes[4]
        ax.set_yticks(ax.get_yticks(),[t.get_text().replace('\n',' ').replace('Combined','Program').replace('Upper bound','Bound').replace('Carbonate–LiF','C–LiF').replace('Binary carbonate','Binary C').replace('95% redesign','95% duty') for t in ax.get_yticklabels()])
        fig.axes[3].set_ylim(-.02,.65)
        # Report one defined response per axis; do not aggregate unlike decision
        # metrics into a quantity labelled as a selection-frequency gain.
        act=B.read('research_action_frontier_summary',B.V)
        action_names={'literature_replication_closure':'Replication','exact_composition_corrosion_closure':'Corrosion','combined_atomic_evidence_closure':'Evidence program','service_redesign_95pct':'Duty redesign','property_measurement_precision_50pct':'Property precision','data_completeness_closure':'Data completion','containment_validation_closure':'Containment','pcm_cycling_phase_closure':'Cycling','comprehensive_upper_bound':'All-evidence bound'}
        c=fig.axes[2];c.clear();q=act.sort_values('mean_no_selection_reduction')
        c.barh(range(len(q)),q.mean_no_selection_reduction,color=[B.OLIVE if s=='combined_atomic_evidence_closure' else B.BLUE for s in q.closure_action],height=.6)
        c.set_yticks(range(len(q)),[action_names[s] for s in q.closure_action],fontsize=7.3);c.set_xlim(0,.61);pct(c);c.set_xlabel('Mean no-selection reduction',fontsize=7.3)
        for i,v in enumerate(q.mean_no_selection_reduction):label(c,v,i,f'{v:.1%}')
        c.text(-.1,1.05,'c',transform=c.transAxes,weight='bold',fontsize=10)
        d=fig.axes[3];d.clear()
        for r in act.itertuples():
            d.scatter(r.burden_ordinal_index,r.total_newly_eligible_candidates,s=30,color=B.OLIVE if r.closure_action=='combined_atomic_evidence_closure' else B.BLUE)
            if r.total_newly_eligible_candidates>5:
                d.annotate(action_names[r.closure_action],(r.burden_ordinal_index,r.total_newly_eligible_candidates),xytext=(-6,8 if r.closure_action=='combined_atomic_evidence_closure' else -12),textcoords='offset points',ha='right',fontsize=7.3)
            elif r.total_newly_eligible_candidates>0:
                is_replication='replication' in r.closure_action
                d.annotate(action_names[r.closure_action],(r.burden_ordinal_index,r.total_newly_eligible_candidates),xytext=(1.7,10) if is_replication else (3.9,8),textcoords='data',ha='center',fontsize=7.3,arrowprops={'arrowstyle':'-','lw':.6,'color':B.MID_GREY})
        d.set_xlim(.5,5.5);d.set_ylim(-2,act.total_newly_eligible_candidates.max()+5);d.set_xlabel('Ordinal evidence burden',fontsize=7.3);d.set_ylabel('Newly eligible memberships',fontsize=7.3)
        d.text(-.1,1.05,'d',transform=d.transAxes,weight='bold',fontsize=10)
    # Complete layout before fixing label positions; later constraint solves would
    # otherwise move the axes without moving the figure-coordinate letters.
    fig.canvas.draw();fig.set_layout_engine('none')
    # Place panel letters outside the data area in a shared figure coordinate system.
    for ax in fig.axes:
        for txt in ax.texts:
            if txt.get_text() in list('abcdefg'):
                pos=ax.get_position();xx=.025 if n==14 and txt.get_text()=='b' else max(.025,pos.x0-.04)
                txt.set_transform(fig.transFigure);txt.set_position((xx,min(.97,pos.y1+.012)));txt.set_fontsize(10);txt.set_va('bottom')
    fig.canvas.draw()

def refresh_supplements():
    oldsave=B.save; oldl=B.L.save_figure
    def direct(fig,n,title,sources,supp=False):
        if not supp and n==6:
            # The sixth legacy panel repeats composite metrics; those belong to
            # the application figure and Supplementary Fig. 13, not this action map.
            fig.axes[5].remove()
            fig.set_layout_engine('none')
            rects=[[.08,.78,.85,.16],[.25,.40,.23,.27],[.67,.40,.28,.27],[.13,.09,.33,.19],[.75,.09,.20,.19]]
            for ax,rect in zip(fig.axes,rects):ax.set_position(rect)
            n=14;supp=True;sources=sources[:4]+['statistical_decision_scope_matrix']
            title='Precedence-valid evidence programs distinguish eligibility from selection'
        legible_legacy(fig)
        supplement_layout(fig,n)
        finish(fig,n,title,sources,supp)
    def helper(fig,number,title,source_tables,extended=False):direct(fig,int(number),title,source_tables,extended)
    B.save=direct;B.L.save_figure=helper
    try:
        B.supp1()
        for n in [2,3,4,5,7,8,9,10]: B.supp_base(n)
        for fun in [B.supp6,B.supp11,B.supp12,B.supp13,B.fig6]:fun()
    finally:B.save=oldsave;B.L.save_figure=oldl

def refresh_application():
    import render_application_figures as A
    oldfinish=A.finish
    def save(fig,path):
        # At this width, the plot text is the text embedded in the manuscript.
        legible_legacy(fig)
        if path.stem=='submission_Fig6':
            fig.set_size_inches(6.3,6.7)
            fig.subplots_adjust(left=.115,right=.975,bottom=.09,top=.95,hspace=.88,wspace=.65)
            for idx,cols,anchor in [(0,2,(.50,-.27)),(2,3,(1.05,-.27))]:
                ax=fig.axes[idx];leg=ax.get_legend()
                ax.legend(leg.legend_handles,[t.get_text() for t in leg.get_texts()],loc='upper center',bbox_to_anchor=anchor,ncol=cols,fontsize=7.3,frameon=False,columnspacing=.8,handletextpad=.4)
            fig.axes[5].get_legend().set_bbox_to_anchor((-.02,1.29))
            fig.axes[3].set_ylim(8,18.5)
            fig.axes[0].set_ylabel('Heat-release power ratio')
            fig.axes[1].set_ylabel('Model transfer-volume ratio')
            fig.axes[2].set_ylabel('Model volume ratio')
            fig.axes[3].set_ylabel(r'Mean heat-release power (kW m$^{-3}$)',fontsize=7.3)
            for txt in fig.axes[3].texts:
                if 'Labels: delivery endpoint' in txt.get_text():
                    txt.set_text(txt.get_text().replace('Labels: delivery endpoint','Labels: discharge endpoint'))
        for ax in fig.axes:
            for txt in ax.texts:
                if txt.get_text() in list('abcdefg'):
                    p=ax.get_position();txt.set_transform(fig.transFigure);txt.set_position((max(.025,p.x0-.04),p.y1+.015));txt.set_fontsize(10);txt.set_va('bottom')
        align_panel_letters(fig,path.stem.replace('submission_',''))
        fig.savefig(path.with_suffix('.pdf'),metadata={'CreationDate':None,'ModDate':None})
        fig.savefig(path.with_suffix('.png'),dpi=300)
        plt.close(fig)
    A.finish=save
    # A's legacy crop is skipped for an already reflowed action figure.
    A.main()
    A.finish=oldfinish
    for name,folder in [('Fig6',B.MAIN),('Supp_Fig15',B.SUPP)]:
        from PIL import Image
        with Image.open(folder/f'submission_{name}.png') as im:
            mapping=pd.read_csv(QA/'figure_source_map.csv'); mask=mapping.figure==name
            mapping.loc[mask,['width_px','height_px','aspect_ratio']]=[im.width,im.height,im.width/im.height]
            mapping.to_csv(QA/'figure_source_map.csv',index=False)

def main():
    setup()
    refresh_supplements()
    refresh_application()
    for fun in [fig1,fig2,fig3,fig4,fig5]:fun()
    mapping=pd.read_csv(QA/'figure_source_map.csv');mapping=mapping[~mapping.figure.isin([r['figure'] for r in RECORDS])]
    pd.concat([mapping,pd.DataFrame(RECORDS)],ignore_index=True).to_csv(QA/'figure_source_map.csv',index=False)
    pd.DataFrame(ALIGNMENT).to_csv(QA/'ees_panel_alignment.csv',index=False)
    status={'status':'RENDERED_PENDING_VISUAL_REVIEW','main_panels_replanned':[1,2,3,4,5],
        'scientific_tables_modified':False,'font_design_width_mm':160,'rendered_figures':RECORDS,
        'scope':'Earlier geometric checks apply to the base renderer only. Final figures require visual and embedded-size verification.'}
    (ROOT/'outputs/qc/EES_PRESENTATION_STATUS.json').write_text(json.dumps(status,indent=2),encoding='utf-8')
    release=json.loads((ROOT/'outputs/qc/POSTPROCESS_RELEASE_STATUS.json').read_text())
    release.update(final_renderer='src/render_ees_presentation.py',presentation_status=status['status'])
    (ROOT/'outputs/qc/POSTPROCESS_RELEASE_STATUS.json').write_text(json.dumps(release,indent=2),encoding='utf-8')
    print(json.dumps(status,indent=2))

if __name__=='__main__':main()
