# MS-TES post-processing and figures

Release TES-EES-V2.2.0-20260909 produces six main and 17 supplementary figures. The sequence connects database scope, complete-duty support, selection boundaries, uncertainty, evidence actions and application-constrained material benefits.

Run the sibling upstream_reproducible_code workflow first. With 64-bit Python 3.12 and the exact requirements-lock.txt dependencies installed, run python src/run_pipeline.py. Windows wrappers are SETUP_ENV.bat and RUN_POSTPROCESS.bat; Linux/macOS wrappers use the same names with .sh. Both invoke the same task graph.

The pipeline synchronizes upstream tables and checks before rendering. Base figure validation precedes the application panels. Final counts and application-source mappings are written after all figures are produced. A real locally installed Arial font is required; proprietary fonts are not distributed.

Outputs are in outputs/main_figures/, outputs/supplementary_figures/, outputs/tables/ and outputs/qc/. The final outputs/qa/figure_source_map.csv connects all 23 figures to data. Supplementary Figure 13 describes composite-property evidence, Figure 14 compares evidence actions, Figure 15 gives switching boundaries, conditional cost implications, chronological checks and the charging-only sizing ablation, Figure 16 presents condition-resolved corrosion and evidence-index sensitivity, and Figure 17 compares the unchanged energy model with independent calorimetry over 250–400 °C. Main Figure 6 presents the material–architecture–duty comparison. Each has a separate analytical purpose.

## Condition-resolved engineering assessment

Release TES-EES-V2.2.0-20260909 includes 26 condition-specific corrosion records from five primary studies. Numerical corrosion endpoints and their reference-rate margins remain separate from ordinal evidence indices. The same 20,000 draws per duty support 175 service–scoring settings. The full upstream pipeline has 41 stages; the final postprocessing pipeline has 11 stages and produces six main and seventeen supplementary figures as vector PDFs and 600 dpi PNGs. The root RUN_ALL.ps1 invokes these same canonical pipelines.

## Decision traceability

The upstream traceability audit reconstructs every stored primary utility and retains composition–duty reasons, criterion assessments, source-condition links, interval provenance and exact closure denominators. It preserves the operational fixed burden transform 1/(1+B/2); source citations do not empirically calibrate the assigned index intervals. TRACEABILITY_AUDIT.json records the calculation checks. The Wei et al. temperature-masking analysis is retrospective because the publication already occurs in the source archive; it is not an independent held-out performance test.
