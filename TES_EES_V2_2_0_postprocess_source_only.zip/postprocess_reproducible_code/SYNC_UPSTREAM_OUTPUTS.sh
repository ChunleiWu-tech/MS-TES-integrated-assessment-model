#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
TES_PYTHON="${TES_PYTHON:-$PWD/.venv/bin/python}"
[[ -x "$TES_PYTHON" ]] || { echo "Run SETUP_ENV.sh first, or set TES_PYTHON." >&2; exit 2; }
exec "$TES_PYTHON" -X faulthandler -u src/sync_upstream.py "${1:-../upstream_reproducible_code}"
